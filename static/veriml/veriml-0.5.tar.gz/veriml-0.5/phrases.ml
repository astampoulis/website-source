type phrase = 
    PhrComplogicDef of
       string * Comp_cst.cterm * Logic_cst.lmodalterm * Camlp4.PreCast.Ast.loc
   | PhrExpDefinition of
       string * Comp_cst.cterm option * Comp_cst.cterm * Camlp4.PreCast.Ast.loc
   | PhrGlobalImport of
       string * Camlp4.PreCast.Ast.loc
   | PhrGlobalReset of
       Camlp4.PreCast.Ast.loc
   | PhrFullReset of
       Camlp4.PreCast.Ast.loc
   | PhrGlobalSave of
       string * Camlp4.PreCast.Ast.loc
   | PhrLogicInd of
       string * Logic_cst.lctxdesc * Logic_cst.lterm * (string * Logic_cst.lterm) list * Camlp4.PreCast.Ast.loc
   | PhrLogicMetadef of
       string * Logic_cst.lmodalterm option * Logic_cst.lmodalterm option * Camlp4.PreCast.Ast.loc
   | PhrTypDefinition of
       string * Comp_cst.cterm option * Comp_cst.cterm * Camlp4.PreCast.Ast.loc
   | PhrNone of Camlp4.PreCast.Ast.loc
   | PhrDirective of Camlp4.PreCast.Ast.str_item
   | PhrNeed of string * Camlp4.PreCast.Ast.loc
   | PhrLogicNotation of string * Logic_cst.lmodalterm * Camlp4.PreCast.Ast.loc


