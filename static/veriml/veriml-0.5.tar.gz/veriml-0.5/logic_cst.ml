open Utils
module LAst = Logic_ast
module BindLterm = LAst.BindLterm

type
  aqstring = StrId of string | StrAnt of Camlp4.PreCast.Loc.t * string

type 
  lterm =  LSort of LAst.lsort
	  |LVar of aqstring
	  |LLambda of aqstring * lterm * lterm
	  |LPi of aqstring * lterm * lterm
	  |LArrow of lterm * lterm
	  |LApp of lterm * lterm
	  |LEq of lterm * lterm
	  |LModal of lmodalterm * lsubst
	  |LModalOmitSubst of lmodalterm
	  |LTermList of lctxdesc
	  |LAny of int
	  |LAnt of Camlp4.PreCast.Loc.t * string
and
  lsubst = lterm list
and
  lctxdesc =   LCtxVar of aqstring
	     | LCtxAsList of (aqstring * lterm * LAst.lpolarity) list
	     | LCurctx
and
  lmodalterm =   LTermInCtx of lctxdesc * lterm
	       | LMeta of aqstring
	       | LMetaAnt of Camlp4.PreCast.Loc.t * string


let appmany (lt : lterm) (l : lterm list) =
  List.fold_left (fun res cur -> LApp(res, cur)) lt l

let lammany (l : (aqstring * lterm) list) (lt : lterm) =
  List.fold_right (fun (str,cur) res -> LLambda(str, cur, res)) l lt

let pimany (l : (aqstring * lterm) list) (lt : lterm) =
  List.fold_right (fun (str,cur) res -> LPi(str, cur, res)) l lt

let rec gather_pi e =
  match e with
      LPi(s,t,e') -> let ts, e'' = gather_pi e' in (s,t) :: ts, e''
    | LArrow(t,e') -> let ts, e'' = gather_pi e' in (StrId "",t) :: ts, e''
    | e -> [], e

let rec gather_app e =
  match e with
      LApp(e,e') -> let e0, es = gather_app e in e0, (es ++ [e'])
    | e -> e, []

let rec series_of_lookups l =
  match l with
      hd :: tl -> (try let res = Lazy.force hd in res with Not_found -> series_of_lookups tl | ExtDict.Not_found_key(a) -> series_of_lookups tl)
    | [] -> raise Not_found

type env_t = { curctx   : (string * LAst.lterm) list ;
	     cursubst : LAst.lterm list ;
	     fenv     : string list ;
	     benv     : string list ;
	     metabenv : (string * LAst.lmodalterm option * (lterm list) option) list ;
	     ctxbenv  : string list ;
	     defs     : LAst.lterm_defenv }

type logic_notations_t = lmodalterm Dict.t
let logic_notations : logic_notations_t ref = ref Dict.empty

let get_modal_arity n t =
  match t with
      Some (LAst.LTermInCtx(ctx, _)) -> List.length ctx
    | _ -> n

let str_remove_anti s = match s with StrId(s) -> s | StrAnt(_,s) -> failwith ("antiquotation should have been removed: " ^ s)

let conversions env app_type = 

  let cross_binder str t env =
    let t' = BindLterm.open_up ~howmany:(List.length env.benv) (List.length env.fenv) t in
    let curctx'   = env.curctx ++ [ str , t' ]  in
    let cursubst' = (List.map (BindLterm.shift_bound 1) env.cursubst) ++ [ LAst.LVar (LAst.LBVar(0)) ] in
    let benv'     = str :: env.benv in
    { curctx = curctx' ; cursubst = cursubst' ; fenv = env.fenv ; benv = benv' ; metabenv = env.metabenv ; ctxbenv = env.ctxbenv ; defs = env.defs }
  in
  let cross_silent_binder t env =
    let curctx'   = env.curctx in
    let cursubst' = List.map (BindLterm.shift_bound 1) env.cursubst in
    let benv'     = "" :: env.benv in
    { curctx = curctx' ; cursubst = cursubst' ; fenv = env.fenv ; benv = benv' ; metabenv = env.metabenv ; ctxbenv = env.ctxbenv ; defs = env.defs }
  in

  let rec ast_of_cst (env : env_t) (e : lterm) =
    match e with
	LSort(s) -> LAst.LSort(s)
      | LVar(str') ->
	let str = str_remove_anti str' in
	series_of_lookups
	  [ lazy(let i = ExtList.findindex  ((=) str) (env.benv)     in LAst.LVar (LAst.LBVar i));
	    lazy(let i = ExtList.findrindex ((=) str) (env.fenv)     in LAst.LVar (LAst.LFVar i));
	    lazy(let _ = ExtList.findindex (fun (s,_,_) -> s = str) (env.metabenv)  in ast_of_cst env (LModalOmitSubst(LMeta(str'))));
	    lazy(let _ = ExtList.findindex ((=) str) (env.ctxbenv)   in ast_of_cst env (LTermList(LCtxVar(str'))));
	    lazy(ast_of_cst env (LModalOmitSubst(LMeta(str')))) ]
      | LLambda(str, t1, t2) ->
  	  let str = str_remove_anti str in
	  let t1a  = ast_of_cst env t1 in
	  let env' = cross_binder str t1a env in
	  LAst.LLambda(Some str, t1a, ast_of_cst env' t2)
      | LPi(str, t1, t2) ->
  	  let str = str_remove_anti str in
	  let any = ast_of_cst env (LAny(0)) in
	  let t1a = ast_of_cst env t1 in
	  let env' = cross_binder str t1a env in
	  LAst.LPi(Some str, any, t1a, ast_of_cst env' t2)
      | LArrow(t1, t2) ->
	  let any = ast_of_cst env (LAny(0)) in
	  let t1a = ast_of_cst env t1 in
	  let env' = cross_silent_binder t1a env in
	  LAst.LPi(None, any, t1a, ast_of_cst env' t2)
      | LApp(t1, t2) ->
	  (let hd, args = gather_app e in
	   let any = ast_of_cst env (LAny(0)) in
	   let (=) aq s = (str_remove_anti aq) = s in
	   match hd with
	       LVar(s) when (s = "refl" || s = "symm" || s = "trans" || s = "leibn" || s = "beta" || s = "foralleq" || s = "lameq" || s = "metaunfold") ->
		 LAst.LEqAxiom( str_remove_anti s , List.map (ast_of_cst env) args)
	     | LVar(s) when s = "eq" ->
	         LAst.LEq( Some any,
		           ast_of_cst env (List.nth args 0) ,
			   ast_of_cst env (List.nth args 1) )
	     | _ ->
	       let inferred = if app_type then Some any else None in
	       (LAst.LApp(ast_of_cst env t1, inferred, ast_of_cst env t2)))
      | LEq(t1, t2) ->
	let any = ast_of_cst env (LAny(0)) in
	  LAst.LEq(Some any, ast_of_cst env t1, ast_of_cst env t2)
      | LModal(m, subst) ->
  	  let modal, subst = ast_of_modal env m, List.map (ast_of_cst env) subst in
	  LAst.modal_apply_subst modal subst
	  (* LAst.LModal(ast_of_modal env m, List.map (ast_of_cst env) subst) *)
      | LModalOmitSubst(m) ->
  	  let n = List.length env.cursubst in
  	  let subst =
	    match m with 
		LMeta(str) ->
  		  let str = str_remove_anti str in
		  series_of_lookups
		    [ lazy(let i = ExtList.findindex (fun (s,_,_) -> s = str) (env.metabenv) in 
			   let _, t, subst = List.nth env.metabenv i in
			   let arity = get_modal_arity n t in
			   let subst' = match subst with
			       Some s -> List.map (ast_of_cst env) s
			     | None -> ExtList.take (min arity n) env.cursubst
			   in
			   subst');
		      lazy(let arity = match ExtDict.find str !logic_notations with
			                 LTermInCtx(LCtxAsList(ctx),_) -> List.length ctx | _ -> 0 in
			   List.map (fun _ -> ast_of_cst env (LAny(0))) (increasing arity));
		      lazy(let arity = get_modal_arity n (Some (ExtDict.getfst str env.defs)) in
			   List.map (fun _ -> ast_of_cst env (LAny(0))) (increasing arity));
		      lazy(failwith ("metavariable " ^ str ^ " not found")) ]
	      | _ -> failwith "nested modal terms not allowed"
	  in
  	  let modal = ast_of_modal env m in
	  LAst.modal_apply_subst modal subst
          (* LAst.LModal(ast_of_modal env m, subst) *)
      | LTermList(ctxdesc) ->
	  let ctx, _ = ast_of_ctxdesc env ctxdesc in
	    LAst.LTermList(ctx)
      | LAny(i) ->
	let res = LAst.mk_infer (List.length (env.fenv)) (List.length (env.benv)) 0 (List.length (env.metabenv)) 0 (List.length (env.ctxbenv)) in
	if i < 0 then (match res with LAst.LInfer(l,f) -> (match !l with Uninst(_,o) -> l := Uninst(i,o); res | _ -> failwith "oops") | _ -> failwith "oops") else res

      | LAnt(_,s) -> failwith ("antiquotation should have been expanded: "^s)

  and ast_of_modal env m =
    match m with
	LTermInCtx(ctx, lt) ->
	  (let ctxA, env' = ast_of_ctxdesc env ctx in
	   let ltA = ast_of_cst env' lt in
	     match ctxA with
		 LAst.LCtxAsList(ctxA') -> LAst.LTermInCtx(ctxA', ltA)
	       | _ -> failwith "modal's context is not a list")
      | LMeta(str) ->
  	  let str = str_remove_anti str in
	  series_of_lookups
	    [ lazy(let i = ExtList.findindex (fun (s,_,_) -> s = str) (env.metabenv) in LAst.LBMeta(i)) ;
	      lazy(let t = ExtDict.find str !logic_notations in ast_of_modal env t);
	      lazy(LAst.LNMeta(str)) ]
      | LMetaAnt(_,s) -> failwith ("antiquotation should have been expanded: "^s)

  and ast_of_ctxdesc ?(addsorts=false) env c =
    match c with

	LCtxVar(str) -> 
  	  let str = str_remove_anti str in
	  let i = ExtList.findindex ((=) str) env.ctxbenv in
	  let sname     = "id_" ^ str in
	  let curctx'   = [ (sname, LAst.LTermList(LAst.LBCtx(i))) ] in
	  let cursubst' = [ LAst.LVar(LAst.LFVar(0)) ] in
	  let fenv'     = [ sname ] in
	  let env'      = { curctx = curctx' ; cursubst = cursubst' ; benv = env.benv ;
			    fenv = fenv' ; metabenv = env.metabenv ; ctxbenv = env.ctxbenv ; defs = env.defs } in
	  LAst.LBCtx(i), env'

      | LCtxAsList(ctx) ->

  	  let env0 =
	    match ctx with
		(_, LTermList(LCurctx), _) :: tl ->
		  { curctx = env.curctx ; cursubst = env.cursubst ; benv = [] ; fenv = [] ; metabenv = env.metabenv ; ctxbenv = env.ctxbenv ; defs = env.defs }
	      | _ ->
		  { curctx = [] ; cursubst = [] ; benv = [] ; fenv = [] ; metabenv = env.metabenv ; ctxbenv = env.ctxbenv ; defs = env.defs }
	  in

   	  let rec aux env ctx =
	    match ctx with
		[] -> [] , env

	      | (_, LTermList(LCurctx), _) :: tl ->
		let ctx_hd, env' = ast_of_ctxdesc ~addsorts:addsorts env LCurctx in
		let ctx_hd = match ctx_hd with LAst.LCtxAsList(ctx_hd) -> ctx_hd | _ -> failwith "problem in ast_of_ctxdesc" in
		let ctx_tl, env'' = aux env' tl in
		ctx_hd ++ ctx_tl, env''
	      
	      | (namehd, typehd, pol) :: tl ->
  		
		   let namehd = str_remove_anti namehd in
		   let namehd = match typehd with LTermList(LCtxVar(s)) when namehd = "" -> ("id_"^(str_remove_anti s)) | _ -> namehd in
		   let ctx_hd = ast_of_cst env typehd in
		   let ctx_hd_sort = if addsorts then Some (ast_of_cst env (LAny(0))) else None in

		   let curctx'   = env.curctx ++ [ namehd , ctx_hd ]  in
		   let cursubst' = env.cursubst ++ [ LAst.LVar (LAst.LFVar(List.length env.fenv)) ] in
		   let fenv'     = env.fenv ++ [ namehd ] in
		   let env'      = { curctx = curctx' ; cursubst = cursubst' ; fenv = fenv' ; benv = env.benv ;
				     metabenv = env.metabenv ; ctxbenv = env.ctxbenv ; defs = env.defs } in

		   let ctx_tl, env'' = aux env' tl in
		   (Some namehd , ctx_hd, ctx_hd_sort, pol) :: ctx_tl , env''
	  in
	  let ctxA, env' = aux env0 ctx in
	  LAst.LCtxAsList(ctxA), env'

      | LCurctx ->

	let ctxA =
	  ExtList.mapi
	    (fun i (name,hd) ->
	      let sort = if addsorts then Some (LAst.mk_infer i 0 0 (List.length (env.metabenv)) 0 (List.length (env.ctxbenv))) else None in
	      (Some name, hd, sort, LAst.LPAny))
	    env.curctx
	in
	let benv' = [] in
	let fenv' = List.map fst env.curctx in
	let env' =
	  { curctx = env.curctx ; cursubst = env.cursubst ; benv = benv' ; fenv = fenv' ;
	    metabenv = env.metabenv ; ctxbenv = env.ctxbenv ; defs = env.defs }
	in
	LAst.LCtxAsList(ctxA) , env'


  in
    (ast_of_cst env, ast_of_modal env, ast_of_ctxdesc ~addsorts:true env)

let empty_env defs = { curctx = [] ; cursubst = [] ; benv = [] ; fenv = [] ; metabenv = [] ; ctxbenv = [] ; defs = defs }

let ast_of_cst ?(app_type=false) ?(defs=Dict.empty) ?(env=empty_env defs) e =
  let (f,_,_) = conversions env app_type in f e
let ast_of_modal ?(app_type=false) ?(defs=Dict.empty) ?(env=empty_env defs) e =
  let (_,f,_) = conversions env app_type in f e
let ast_of_ctxdesc ?(app_type=false) ?(defs=Dict.empty) ?(env=empty_env defs) e =
  let (_,_,f) = conversions env app_type in f e


let aqstr s = StrId(s)

let rec logicint i =
  match i with
      0 -> LVar (aqstr "zero")
    | i when i > 0-> LApp (LVar (aqstr "succ"), logicint (i-1))
    | _ -> failwith "negative number passed to logicint"
	
(* potential bug: naming an inductive definition under something already in the context *)

let get_new_id default env s =
  let identbase = match s with Some(s) -> s | None -> default in
  let is_safe base = not (List.exists ((=) base) env) in
  let rec first_safe i base =
    let id = base ^ (string_of_int i) in (if is_safe id then id else first_safe (i+1) base)
  in
  let ident = if is_safe identbase then identbase else first_safe 0 identbase in
    ident

let conversions env =

  let add_to_normenv env elm =
    let benv' = elm :: env.benv in
    { curctx = env.curctx ; cursubst = env.cursubst ; benv = benv' ;
      fenv = env.fenv ; metabenv = env.metabenv ; ctxbenv = env.ctxbenv ; defs = env.defs }
  in
  let new_normenv env elm =
    let id = get_new_id "x" (env.benv ++ env.fenv) elm in
    (id, add_to_normenv env id)
  in
  let add_to_fenv env elm =
    let fenv' = env.fenv ++ [ elm ] in
    { curctx = env.curctx ; cursubst = env.cursubst ; benv = env.benv ;
      fenv = fenv' ; metabenv = env.metabenv ; ctxbenv = env.ctxbenv ; defs = env.defs }
  in
  let new_fenv env elm =
    let id = get_new_id "x" (env.benv ++ env.fenv) elm in
    (id, add_to_fenv env id)
  in

  let rec cst_of_ast env (e : LAst.lterm) =
    match e with
	LAst.LSort(s) -> LSort(s)
      | LAst.LVar(LAst.LBVar i) -> LVar(aqstr (try List.nth env.benv i with _ -> "b!!" ^ (string_of_int i)))
      | LAst.LVar(LAst.LFVar i) -> LVar(aqstr (try List.nth env.fenv i with _ -> "f!!" ^ (string_of_int i)))
      | LAst.LLambda(ss,t1,t2)  ->
	  (let s, env' = new_normenv env ss in
	   LLambda(aqstr s, cst_of_ast env t1, cst_of_ast env' t2))
      | LAst.LPi(ss,_,t1,t2) when BindLterm.has_bound_var 0 t2 ->
	  (let s, env' = new_normenv env ss in
	   LPi(aqstr s, cst_of_ast env t1, cst_of_ast env' t2))
      | LAst.LPi(ss,_,t1,t2) ->
	  (let env' = add_to_normenv env "" in
	   LArrow(cst_of_ast env t1, cst_of_ast env' t2))
      | LAst.LApp(t1,_,t2) ->
	  LApp(cst_of_ast env t1, cst_of_ast env t2)
      | LAst.LEq(_,t1,t2) ->
	  LEq(cst_of_ast env t1, cst_of_ast env t2)
      | LAst.LEqAxiom(s,l) ->
	  appmany (LVar(aqstr s)) (List.map (cst_of_ast env) l)
      | LAst.LModal(mt,subst) ->
	  LModal(cst_of_modal env mt,List.map (cst_of_ast env) subst)
      | LAst.LTermList(ctxdesc) ->
	  LTermList(cst_of_ctxdesc env ctxdesc)
      | LAst.LInfer(l,f) ->
	  (match !(LAst.match_lunif l) with
	       Inst(t,_)   -> (try cst_of_ast env ((LAst.lunif_function_full l f) t) with _ -> LAny(0))
	     | Uninst(i,_) -> LAny(i))

(* something wrong is going on here -- need to investigate more. *)
  and cst_of_modal env (e : LAst.lmodalterm) =
      match e with
	  LAst.LTermInCtx(ctx, t) ->
	    (let env0 = { curctx = [] ; cursubst = [] ; benv = [] ; fenv = [] ;
			  metabenv = env.metabenv ; ctxbenv = env.ctxbenv ; defs = env.defs } in
	     let ctx'', env' = cst_of_ctx env0 ctx in
	       LTermInCtx(LCtxAsList(ctx''), cst_of_ast env' t))
	| LAst.LFMeta(i) -> LMeta(aqstr ("f" ^ (string_of_int i)))
	| LAst.LBMeta(i) -> LMeta(aqstr (try let (s,_,_) = (List.nth env.metabenv i) in s with _ -> ("b!!" ^ (string_of_int i))))
	| LAst.LNMeta(s) -> LMeta(aqstr s)
		   
  and cst_of_ctx env (ctx : (string option * LAst.lterm * LAst.lterm option * LAst.lpolarity) list) =
    
    match ctx with
	[] -> [], env
      | (ss,tm,_,pol) :: tl ->
	  (let s, env' = new_fenv env ss in
	   let ctx', env'' = cst_of_ctx env' tl in
	   (aqstr s, cst_of_ast env tm, pol) :: ctx', env'')
  
  and cst_of_ctxdesc env (ctxdesc : LAst.lctxdesc) =
    
    match ctxdesc with
	LAst.LFCtx(i) -> LCtxVar(aqstr ("f" ^ (string_of_int i)))
      | LAst.LBCtx(i) -> LCtxVar(aqstr (try List.nth env.ctxbenv i with _ -> ("b!!" ^ (string_of_int i))))
      | LAst.LCtxAsList(ctx) -> (let ctx', _ = cst_of_ctx env ctx in LCtxAsList(ctx'))

  in

    (cst_of_ast env, cst_of_modal env, cst_of_ctxdesc env)

let cst_of_ast ?(env=empty_env Dict.empty) e = let (f,_,_) = conversions env in f e
let cst_of_modal ?(env=empty_env Dict.empty) e = let (_,f,_) = conversions env in f e
let cst_of_ctxdesc ?(env=empty_env Dict.empty) e = let (_,_,f) = conversions env in f e
