open Utils;;

let loaded_files : (unit Dict.t) ref = ref Dict.empty;;


let typecheck_extdef_result = ref false;;
let print_defs_tc = ref false;;
let print_defs = ref true;;
let suppress_ocaml_replies = ref true;;

let full_erasure = ref false;;
let no_erasure_allowed = ref false;;

let interactive = ref false;;
let real_staging = ref true;;

let dump_text_ast = ref false;;
let just_typecheck = ref false;;

let byte_dependencies = ref None;;

let staging () = not(!interactive) && !real_staging ;;

let print_after_syntax         = ref false;;
let print_after_typeinf1       = ref false;;
let print_after_typeinf2       = ref false;;
let print_after_hoist          = ref false;;
let print_after_everything     = ref false;;
let verimlc_directories     = ref [ "." ] ;;

let arg_spec =
  [ "--no-check-extdef", Arg.Clear typecheck_extdef_result,
    "Don't typecheck proof objects resulting from ExtDefinition execution. (default)";
    "--check-extdef", Arg.Set typecheck_extdef_result,
    "Typecheck proof objects resulting from ExtDefinition execution.";
    "--print-defs-tc", Arg.Set print_defs_tc,
    "Print info about computational definitions after type checking (but not evaluation) has taken place.";
    "--no-print-defs", Arg.Clear print_defs,
    "Don't print info about definitions.";
    "--ocaml-replies", Arg.Clear suppress_ocaml_replies,
    "Print replies from OCaml";
    "--full-erasure", Arg.Set full_erasure,
    "Erase all proof objects prior to evaluation";
    "--no-erasure", Arg.Set full_erasure,
    "Do not allow any erasure of proof objects";
    "--fast", Arg.Unit (fun u -> full_erasure := true; typecheck_extdef_result := false),
    "Fastest, least trustworthy evaluation (full erasure and no checking of proof objects)";
    "--real-staging", Arg.Set real_staging,
    "Use real staging for compiling (default)";
    "--no-real-staging", Arg.Clear real_staging,
    "Don't use real staging for compiling";
    "--text-ast", Arg.Set dump_text_ast,
    "Print text AST when compiling";
    "--just-typecheck", Arg.Set just_typecheck,
    "When compiling, quit after typechecking";
    "--byte-dependencies", Arg.String (fun s -> byte_dependencies := Some s),
    "Output utilized bytecode files to given filename";
    "--print-after-syntax", Arg.Set print_after_syntax,
    "Print result after converting concrete syntax to abstract syntax";
    "--print-after-typeinf1", Arg.Set print_after_typeinf1,
    "Print resulting AST after type inference 1";
    "--print-after-typeinf2", Arg.Set print_after_typeinf2,
    "Print resulting AST after type inference 2";
    "--print-after-hoist", Arg.Set print_after_hoist,
    "Print resulting AST after hoisting of static expressions";
    "--print-after-everything", Arg.Set print_after_everything,
    "Print resulting AST after all typing stuff"
(*
    "-I", Arg.String (fun d -> verimlc_directories := !verimlc_directories ++ [d]),
    "<directory> Add directory in search path for object files."  *)

]

