open Utils
open Logic_ast
open Comp_ast
open Logic_core
open Logic_typing

let case_kind f1 f2 f3 ~case:(_,t1) = 
  match t1 with
      CHol -> f1
    | CCtx -> f2
    | _ -> f3

let remove_infer_cterm =
  cterm_map ~cholterm:(fun t -> CHolTerm(remove_infer_lmodal t))
            ~cctxterm:(fun t -> CCtxTerm(remove_infer_lctxdesc t))
            ~ctypeascribe:(fun _ _ re _ -> re)
            ~cinfer:(fun l f rf ->
	      (match !(match_cunif l) with
                  Inst(t,_) -> rf t
                | Uninst(_,t) ->
		  let ts = match !t with
		            Some(l) -> (match !l with
				         Inst(t,_) -> ("failure to infer hole of type: " ^ Comp_print.string_of_cterm (rf t))
			               | _ -> "")
		          | None -> ""
		  in
		  print_string (ts ^ "\n");
		  flush stdout;
		  failwith ("couldn't infer comp. unification variable!")))

let subst_bound_ctx subst term =
  let term' = CtxbindCtermS.subst_bound subst term in term'

let rec elim_inst_cunif e =
  match e with
      CInfer(l,f) -> (match !(match_cunif l) with Inst(t,_) -> elim_inst_cunif (f t) | _ -> e)
    | _ -> e

let subst_bound ~case:t1 ~term:t2 ~subst:t3 =
  case_kind
    (function CHolTerm(t) -> MetabindCtermS.subst_bound t | _ -> failwith "problem in subst_bound")
    (function CCtxTerm(t) -> subst_bound_ctx t | _ -> failwith "problem in subst_bound")
    CbindCtermS.subst_bound
    ~case:t1
    (elim_inst_cunif t3)
    t2

let get_cdef_term n (cdefenv : cterm_defenv) = let (_, tm, _, _) = ExtDict.find n cdefenv in tm
let get_cdef_type n cdefenv = let (tp, _, _, _) = ExtDict.find n cdefenv in tp

let flatten_closure (metasubst,ctxsubst,compsubst) e =
    (MetabindCtermS.subst_bound_list (List.rev metasubst)
       (CtxbindCtermS.subst_bound_list (List.rev ctxsubst)
	  (CbindCtermS.subst_bound_list (List.rev compsubst) e)))
    
let rec ctype_whnf ?sumrecname e =
  let fixname t =
    match sumrecname with
	Some name ->
	  (match t with
	      CRecType(_, _, _, s) | CSumType(_, s) -> s := Some name
	    | _ -> ())
      | _ -> ()
  in
  match elim_inst_cunif e with
      CApp(t1, t3) ->
	( fixname t1;
	  match ctype_whnf ?sumrecname t1 with
	     CLambda(s, t1, t2) ->
	       ctype_whnf ?sumrecname (subst_bound ~case:s ~term:t2 ~subst:t3)
	   | t1' -> CApp(t1', t3))
    | CClosure(subst, e) ->
	ctype_whnf ?sumrecname (flatten_closure subst e)
    | t -> t

let rec ctype_whdelta cdefenv e =
  monadic option_monad in begin
    let rec aux e =
      match e with
	  CNVar(n) -> cmd { return (n, get_cdef_term n cdefenv) }
	| CApp(e1, e2) ->  cmd { (n,e1') <- aux e1 then
				 return (n,CApp(e1', e2)) }
	| e -> None
    in
      cmd { (n,e') <- aux e then
	    return (ctype_whnf ~sumrecname:n e') }
  end

let rec ctype_fullwhdelta cdefenv e =
  let e' = ctype_whnf e in
  let res =
    match ctype_whdelta cdefenv e with
	None -> e'
      | Some e'' -> ctype_fullwhdelta cdefenv e''
  in
  res



let add_to_metaenv ?(static=false) tp (defenv, cdefenv, metaenv, ctxenv, compenv) =
  let metaenv' = (tp, static) :: metaenv in
    (defenv, cdefenv, metaenv', ctxenv, compenv)

let add_to_ctxenv ?(static=false) tp (defenv, cdefenv, metaenv, ctxenv, compenv) =
  let ctxenv' = ((), static) :: ctxenv in
    (defenv, cdefenv, metaenv, ctxenv', compenv)

let add_to_compenv ?(static=false) tp (defenv, cdefenv, metaenv, ctxenv, compenv) =
  let compenv' = (tp, static) :: compenv in
    (defenv, cdefenv, metaenv, ctxenv, compenv')

let add_to_env ~case:var ?(static=false) t =
  case_kind
    (function CHolTerm(t) -> add_to_metaenv ~static:static t | _ -> failwith "add_to_env with HOL binder and non-HOL term")
    (function CSort(CCtx) -> add_to_ctxenv ~static:static () | _ -> failwith "add_to_env with CTX binder and non-CTX term")
    (function CHolTerm(_) | CSort(CCtx) -> failwith "add_to_env with COMP binder and non-COMP term"
      | t -> add_to_compenv ~static:static t)
    ~case:var
    (elim_inst_cunif t)
let env_len       ~case:var (_,_,metaenv,ctxenv,compenv) = case_kind (List.length metaenv) (List.length ctxenv) (List.length compenv) ~case:var
let open_up       ~case:var ?(howmany=1) env t =
  let n = env_len ~case:var env in
    case_kind (MetabindCterm.open_up ~howmany:howmany n)
              (CtxbindCterm.open_up  ~howmany:howmany n)
              (CbindCterm.open_up ~howmany:howmany n)
              ~case:var
              t
let close_down    ~case:var ?(howmany=1) env t =
  let n = env_len ~case:var env in
    case_kind (MetabindCterm.close_down ~howmany:howmany n)
              (CtxbindCterm.close_down  ~howmany:howmany n)
              (CbindCterm.close_down ~howmany:howmany n)
              ~case:var
              t
let has_bound_var = case_kind MetabindCterm.has_bound_var CtxbindCterm.has_bound_var CbindCterm.has_bound_var

let open_up_2 ~case1:((_,var1) as s1) ~case2:((_,var2) as s2) env =
  if var1 = var2 then open_up ~case:s1 ~howmany:2 env else compose (open_up ~case:s1 env) (open_up ~case:s2 env)

let close_down_2 ~case1:((_,var1) as s1) ~case2:((_,var2) as s2) env =
  if var1 = var2 then close_down ~case:s1 ~howmany:2 env else compose (close_down ~case:s1 env) (close_down ~case:s2 env)

let add_to_envn =
  case_kind
    (fun (defenv,cdefenv,metan,ctxn,compn) -> (defenv,cdefenv,metan+1,ctxn,compn))
    (fun (defenv,cdefenv,metan,ctxn,compn) -> (defenv,cdefenv,metan,ctxn+1,compn))
    (fun (defenv,cdefenv,metan,ctxn,compn) -> (defenv,cdefenv,metan,ctxn,compn+1))
let open_up_n ~case:var ?(howmany=1) (_,_,metan,ctxn,compn) t =
  let n = case_kind ~case:var metan ctxn compn in
    case_kind (MetabindCterm.open_up ~howmany:howmany n)
              (CtxbindCterm.open_up  ~howmany:howmany n)
              (CbindCterm.open_up ~howmany:howmany n)
              ~case:var
              t

let unified (t : cterm * cterm) = ()

let equate_optstrings s1 s2 =
  (match !s1, !s2 with
      Some s, None -> s2 := Some s
    | None, Some s -> s1 := Some s
    | _ -> ());
  true

let ctype_equal_n (defenv,cdefenv,metan,ctxn,compn) ctype_whnf e1 e2 =
  let rec auxfull ((_,_,metan,ctxn,compn) as envn) e1 e2 = 
    let aux = auxfull envn in
    let aux_under v t1 t2 = let envn' = add_to_envn ~case:v envn in auxfull envn' (open_up_n ~case:v envn t1) (open_up_n ~case:v envn t2) in
    let e1' = ctype_whnf e1 in
    let e2' = ctype_whnf e2 in
    match e1', e2' with
	CSort(s1), CSort(s2) -> s1 = s2
      | CPi(v, a1, b1), CPi(_, a2, b2) ->
	aux a1 a2 && aux_under v b1 b2
      | CLambda(v, a1, b1), CLambda(_, a2, b2) ->
	aux a1 a2 && aux_under v b1 b2
      | CApp(a1, b1), CApp(a2, b2) when aux a1 a2 && aux b1 b2 -> true
      | CHolTerm(t1), CHolTerm(t2) -> lmodal_equal defenv metan t1 t2
      | CCtxTerm(t1), CCtxTerm(t2) -> lctxdesc_equal defenv t1 t2
      | CUnitType, CUnitType -> true
      | CSigma(v, a1, b1), CSigma(_, a2, b2) ->
	aux a1 a2 && aux_under v b1 b2
      | CBVar(i1), CBVar(i2) -> i1 = i2
      | CFVar(i1), CFVar(i2) -> i1 = i2
      | CProdType(a1,b1), CProdType(a2,b2) -> aux a1 a2 && aux b1 b2
      | CRecType(v,a1,b1,s1), CRecType(_,a2,b2,s2) ->
	aux a1 a2 && aux_under v b1 b2 && equate_optstrings s1 s2
      | CSumType(b1,s1), CSumType(b2,s2) -> List.for_all2 aux b1 b2 && equate_optstrings s1 s2
      | CRefType(t1), CRefType(t2) -> aux t1 t2
      | CIntType, CIntType -> true
      | CStringType, CStringType -> true
      | CBoolType, CBoolType -> true
      | CArrayType(t1), CArrayType(t2) -> aux t1 t2
      | CInfer(l1,f1), CInfer(l2,f2) when match_cunif l1 == match_cunif l2 -> true
      | CInfer(l1,f1), CInfer(l2,f2) ->
	(let l1 = match_cunif l1 in
	 let l2 = match_cunif l2 in
	 (* cunifvar_type_unify aux l1 f1 l2 f2; *)
	 match !l1, !l2 with
	     Inst(t1,otyp1), _ -> aux (f1 t1) e2'
	   | _, Inst(t2,otyp2) -> aux e1' (f2 t2)
	   | (Uninst(_,otyp1)) , (Uninst(_,otyp2)) ->
	     unified (CInfer(l1,f1), CInfer(l2,f2));
	     l1 := Inst(CInfer(l2,fun x -> x),otyp2); true)

      | CInfer(l,f), e
      | e, CInfer(l,f) ->
	  (let l = match_cunif l in
	     match !l with
	       Inst(t,_) -> aux (f t) e
	     | Uninst(i,otyp) ->
		 (unified (CInfer(l,f), e);
		  l := Inst(e,otyp);
		   (* try aux e1' e2'
		      with _ -> failwith "can't unify" *)
		  aux e1' e2'))
      | CNVar(s1), CNVar(s2) when s1 = s2 -> true
      | CNVar(s1), e2 when aux (get_cdef_term s1 cdefenv) e2 -> true
      | e1, CNVar(s2) when aux e1 (get_cdef_term s2 cdefenv) -> true
      | e1, e2 -> (match ctype_whdelta cdefenv e1, ctype_whdelta cdefenv e2 with
		       Some(e1), Some(e2) -> aux e1 e2
		     | Some(e1), None -> aux e1 e2
		     | None, Some(e2) -> aux e1 e2
		     | None, None -> false)
  in
    auxfull (defenv,cdefenv,metan,ctxn,compn) e1 e2

let ctype_equal_n env e1 e2 = (ctype_equal_n env (fun t -> t) e1 e2) || (ctype_equal_n env ctype_whnf e1 e2)

let ctype_equal (defenv,cdefenv,metaenv,ctxenv,compenv) = ctype_equal_n (defenv,cdefenv,List.length metaenv,List.length ctxenv,List.length compenv)

let ctx_is_prefix defenv l1 l2 =
    if (List.length l1 > List.length l2) then false
    else ExtList.foldindex (fun i ((_,a,_,_),(_,b,_,_)) res -> res && (lterm_equal defenv i a b)) true
      (List.combine l1 (ExtList.take (List.length l1) l2))

let ctype_sub ((defenv,cdefenv,metaenv,ctxenv,compenv) as env) e1 e2 =

  let modal_subtype (defenv,_,metaenv,_,_) e1 e2 =
    match e1, e2 with
  	LTermInCtx(ct1,t1), LTermInCtx(ct2,t2) ->
  	  if ctx_is_prefix defenv ct1 ct2 then
	    lmodal_equal defenv (List.length metaenv) (LTermInCtx(ct2,t1)) (LTermInCtx(ct2,t2))
  	  else
  	    false
      | _, _ -> false
  in

  let rec subaux ((defenv,cdefenv,metan,ctxn,compn) as envn) e1 e2 =
    let (<:) = subaux envn in
    let sub_under v t1 t2 = 
      let env' = add_to_envn ~case:v envn in
      subaux env' (open_up_n ~case:v envn t1) (open_up_n ~case:v envn t2)
    in
    if ctype_equal_n envn e1 e2 then true
    else (match ctype_whnf e1, ctype_whnf e2 with
	      CPi(v, a1, b1), CPi(_, a2, b2) -> a2 <: a1 && sub_under v b1 b2
	    | CHolTerm(t1), CHolTerm(t2) -> modal_subtype env t1 t2

	    | CSigma(v, a1, b1), CSigma(_, a2, b2) when ctype_equal_n envn a1 a2 && sub_under v b1 b2 -> true
	    | CSigma(v, CHolTerm(LTermInCtx(ct1,t1)), b1), CSigma(_, CHolTerm(LTermInCtx(ct2,t2)), b2) ->
		if ctx_is_prefix defenv ct1 ct2 && lmodal_equal defenv metan (LTermInCtx(ct2,t1)) (LTermInCtx(ct2,t2)) then
		  let b2' = MetabindCtermS.subst_bound (LTermInCtx(ct1,LModal(LBMeta 0,freelist (List.length ct1)))) b2 in
		    sub_under v b1 b2'
		else
		  false
	    | CProdType(a1, b1), CProdType(a2, b2) -> a1 <: a2 && b1 <: b2
	    | CRecType(v, a1, b1, s1), CRecType(_, a2, b2, s2) -> ctype_equal_n envn a1 a2 && sub_under v b1 b2 && equate_optstrings s1 s2
	    | CSumType(b1,s1), CSumType(b2,s2) -> List.for_all2 (<:) b1 b2 && equate_optstrings s1 s2
	    | CNVar(s1), e2 when (get_cdef_term s1 cdefenv) <: e2 -> true
	    | e1, CNVar(s2) when e1 <: (get_cdef_term s2 cdefenv) -> true
	    | e1, e2 -> (match ctype_whdelta cdefenv e1, ctype_whdelta cdefenv e2 with
			     Some(e1), Some(e2) -> e1 <: e2
			   | Some(e1), None -> e1 <: e2
			   | None, Some(e2) -> e1 <: e2
			   | None, None -> false))
  in	    
    subaux (defenv, cdefenv, List.length metaenv, List.length ctxenv, List.length compenv) e1 e2

let rec ctype_appmany_open t =
  match t with
      CApp(t1, t2) -> (let base, args = ctype_appmany_open t1 in
			 base, List.append args [t2])
    | _ -> t, []

let rec ctype_appmany t l =
  List.fold_left (fun cur elm -> CApp(cur,elm)) t l
	 

(* SPECIFICATION OF THE LANGUAGE *)
let ctype_spec_abstractions =
  [ (CType, CType);
    (CCtx,  CType);
    (CHol,  CType);
    (CKind, CType);
    (CKind, CKind);
    (CHol,  CKind);
    (CCtx,  CKind)]

let ctype_spec_existentials =
  [ (CHol, CType);
    (CCtx, CType) ]

let rec is_idsubst curmax subst = ExtList.is_prefix (freelist curmax) subst

let subst_fmeta scrutinee subst tm =
  let i = match scrutinee with 
               CHolTerm(LFMeta(i)) -> Some i
             | CHolTerm(LTermInCtx(ctx, LModal(LFMeta(i), subst))) when is_idsubst (List.length ctx) subst -> Some i
	     | _ -> None
  in
  match i with
      Some i ->
	(nowarn let CHolTerm(t) = subst in
	 MetabindCterm.subst_fvar t i tm)
    | _ -> tm

let subst_fmeta_in_env ((defenv, cdefenv, metaenv, ctxenv, compenv) as env) scrutinee t =
  let i = match scrutinee with 
               CHolTerm(LFMeta(i)) -> Some i
             | CHolTerm(LTermInCtx(ctx, LModal(LFMeta(i), subst))) when is_idsubst (List.length ctx) subst -> Some i
	     | _ -> None
  in
  match i with
      Some i ->
	(nowarn let CHolTerm(t) = t in
	 let metaenv' = List.map (fun (w,s) -> (MetabindModal.subst_fvar t i w, s)) metaenv in
	 let compenv' = List.map (fun (w,s) -> (MetabindCterm.subst_fvar t i w, s)) compenv in
	   (defenv, cdefenv, metaenv', ctxenv, compenv'))
    | _ -> 
	env

let subst_fctx scrutinee subst tm =
  match scrutinee with
      CCtxTerm(LFCtx(i))
    | CCtxTerm(LCtxAsList([_,LTermList(LFCtx(i)),_,_])) ->
	(nowarn let CCtxTerm(t) = subst in
	 CtxbindCterm.subst_fvar t i tm)
    | _ -> tm

let subst_fctx_in_env ((defenv, cdefenv, metaenv, ctxenv, compenv) as env) i t =
  match i with
      CCtxTerm(LFCtx(i))
    | CCtxTerm(LCtxAsList([_,LTermList(LFCtx(i)),_,_])) ->
	(nowarn let CCtxTerm(t) = t in
	 let metaenv' = List.map (fun (w,s) -> (CtxbindModal.subst_fvar t i w, s)) metaenv in
	 let compenv' = List.map (fun (w,s) -> (CtxbindCterm.subst_fvar t i w, s)) compenv in
	   (defenv, cdefenv, metaenv', ctxenv, compenv'))
    | _ -> env

let many_add_to_env vars ts env =
  List.fold_left (fun env (var, t) -> add_to_env ~case:var t env) env (List.combine vars ts)

let check_static (defenv, cdefenv, metaenv, ctxenv, compenv) (e : cterm) =
  let check_logic_static = 
    lterm_map ~lfmeta:(fun i ->
      if not (snd (List.nth metaenv (List.length metaenv - i - 1))) then
	  failwith ("used static meta variable b" ^ (string_of_int i))
	else LFMeta(i))
      ~lfctx:(fun i ->
	if not (snd (List.nth ctxenv (List.length ctxenv - i - 1))) then
	  failwith ("used static ctx variable b" ^ (string_of_int i))
	else LFCtx(i))
  in
  let _ =
    cterm_map 
      ~cfvar:(fun i ->
	if not (snd (List.nth compenv (List.length compenv - i - 1))) then
	  failwith ("used static comp variable b" ^ (string_of_int i))
	else CFVar(i))
      ~cholterm:(fun mt -> let _ = check_logic_static (LModal(mt,[])) in CHolTerm(mt))
      ~cctxterm:(fun ct -> let _ = check_logic_static (LTermList(ct)) in CCtxTerm(ct))
      e
  in 
  ()

let check_env_static anyenv = 
  if (List.for_all snd anyenv) then () else failwith "static lambda inside dynamic code"

let rec reifiable cdefenv t =
  match ctype_fullwhdelta cdefenv t with
      CHolTerm(t) -> true
    | CCtxTerm(t) -> true
    | CSigma(var,t1,t2) -> reifiable cdefenv t1 && reifiable cdefenv t2
    | CProdType(t1,t2) -> reifiable cdefenv t1 && reifiable cdefenv t2
    | CIntType -> true
    | CUnitType -> true
    | _ -> false

let rec type_of_cterm ((defenv, cdefenv, metaenv, ctxenv, compenv) as env) (e : cterm) =
  match e with
      CSort(CType) -> CSort(CKind)
    | CSort(CKind) -> failwith "Kind does not have a classifier"
    | CSort(CCtx)  -> failwith "ctx is not part of the cterm language"
    | CSort(CHol)  -> failwith "HOL is not part of the cterm language"
    | CApp(CNVar(magic), t) when magic="magic" ->
	(match type_of_HOL env t with
	     CHolTerm(LTermInCtx(_, LSort(LProp))) -> CSigma((None,CHol), t, CUnitType)
	   | _ -> failwith "magic used wrongly")
    | CPi(var, t1, t2) ->
	(let t1_s = csort_of ~case:var env t1 in
	 let env' = add_to_env ~case:var t1 env in
	 let t2'  = open_up ~case:var env t2 in
	 let t2_s = csort_of_cterm env' t2' in
	   if List.mem (t1_s, t2_s) ctype_spec_abstractions then
	     CSort(t2_s)
	   else
	     failwith "non-allowed abstraction used")
    | CLambda(var, t1, e2) ->
	(let env' = add_to_env ~case:var t1 env in
	 let t2   = type_of_cterm env' (open_up ~case:var env e2) in
	 let tp   = CPi(var, t1, close_down ~case:var env' t2) in
	 let _    = type_of_cterm env tp in
	   tp)
    | CApp(e1, e2) ->
	(let t1 = ctype_fullwhdelta cdefenv (type_of_cterm env e1) in
	   match t1 with
	       CPi(var, t, t') ->
		 let t2 = type_of ~case:var env e2 in
		   if ctype_sub env t2 t then
		     subst_bound ~case:var ~term:t' ~subst:e2
		   else
		     failwith "types don't match in application"
	     | _ -> failwith "applying something to a non-functional type")
    | CHolTerm(t) ->
	failwith "HOL terms are not part of the cterm language"
    | CCtxTerm(t) ->
	failwith "ctx terms are not part of the cterm language"
    | CUnitType -> CSort(CType)
    | CUnitExpr -> CUnitType
    | CSigma(var, t1, t2) ->
	(let t1_s = csort_of ~case:var env t1 in
	 let env' = add_to_env ~case:var t1 env in
	 let t2'  = open_up ~case:var env t2 in
	 let t2_s = csort_of_cterm env' t2' in
	   if List.mem (t1_s, t2_s) ctype_spec_existentials then
	     CSort(t2_s)
	   else
	     failwith "non-allowed existential type used")
    | CPack(t1, var, ret, e) ->
	(let t1_t = type_of ~case:var env t1 in
	 let tp = CSigma(var, t1_t, ret) in
	 let _ = type_of_cterm env tp in
	 let e_t = type_of_cterm env e in
	 let e_expected = subst_bound ~case:var ~term:ret ~subst:t1 in
	   if ctype_sub env e_t e_expected then
	     tp
	   else
	     failwith "body of existential doesn't have expected type")
    | CUnpack(t1, var1, var2, e) ->
	(let t1_t = ctype_fullwhdelta cdefenv (type_of_cterm env t1) in
	   match t1_t with
	       CSigma(_, tt1, tt2) ->
		 let env' = add_to_env ~case:var1 tt1 env in
		 let tt2' = open_up ~case:var1 env tt2 in
		 let env'' = add_to_env ~case:var2 tt2' env' in
		 let e' = open_up_2 ~case1:var1 ~case2:var2 env e in
		 let e_t = close_down_2 ~case1:var1 ~case2:var2 env'' (type_of_cterm env'' e') in
		   if has_bound_var ~case:var1 0 e_t then
		     failwith "witness should not escape from existential unpacking"
		   else if csort_of_cterm env e_t = CType then
		     e_t
		   else
		     failwith "unpacking inside non-computational term"
	     | _ -> failwith "unpacking a non-existential term")
    | CBVar(i) -> failwith "type_of_cterm on a bound variable!"
    | CFVar(i) -> let (t,_) = List.nth compenv (List.length compenv - i - 1) in t
    | CNVar(s) -> get_cdef_type s cdefenv

    | CHolCase(ts,vars,ret,branches) ->
	(let check_one_scrutinee t =
	   let t_t = type_of_HOL env t in
	   let _ =
	     match t_t with
		 CHolTerm(LTermInCtx(_, LSort(_))) -> ()
	       | _ -> (match type_of_HOL env t_t with
			   CHolTerm(LTermInCtx(_, LSort(_))) -> ()
			 | _ ->failwith "cannot pattern match on proof objects!")
	   in
	     t_t
	 in
	
	 let ts_t = List.map check_one_scrutinee ts in
	 let env' = many_add_to_env vars ts_t env in
	 let open_in_env' = open_up ~case:(None, CHol) ~howmany:(List.length ts) env in

	 let ret' = open_in_env' ret in
	 let scrutinees = ts in

	 let env'' =
	   List.fold_left
	     (fun env' (i, scrutinee) ->
		subst_fmeta_in_env env' (open_in_env' scrutinee) (CHolTerm(LFMeta(List.length metaenv + i))))
	     env' (List.combine (increasing (List.length ts)) scrutinees)
	 in

	 let ret_s = csort_of_cterm env'' ret' in
	 let ret_f ts = MetabindCtermS.subst_bound_list (List.map (function CHolTerm(t) -> t | _ -> failwith "ret_f") ts) ret in
	   if ret_s = CType then
	     (let _ = List.iter (check_branch env ts_t scrutinees ret_f) branches in
		ret_f ts)
	   else
	     failwith "matching on HOL terms is only allowed for computational terms")

    | CCtxCase(t,var,ret,branches) ->
	(let t_t = type_of_ctx env t in
	 let env' = add_to_env ~case:var t_t env in
	 let ret' = open_up ~case:var env ret in

	 let scrutineevar = t in
	 let env'' = subst_fctx_in_env env' (open_up ~case:var env scrutineevar) (CCtxTerm(LFCtx(env_len ~case:var env))) in

	 let ret_s = csort_of_cterm env'' ret' in
	 let ret_f t = subst_bound ~case:var ~term:ret ~subst:t in
	   if ret_s = CType then
	     (let _ = List.iter (check_ctxbranch env scrutineevar ret_f) branches in
		ret_f t)
	   else
	     failwith "matching on context terms is only allowed for computational terms")

    | CProdType(t1,t2) ->
	(if ctype_equal env (type_of_cterm env t1) (CSort(CType)) &&
	    ctype_equal env (type_of_cterm env t2) (CSort(CType)) then
	   CSort(CType)
	 else
	   failwith "product type with non-product terms")
    | CTuple(e1,e2) ->
	(let t1 = type_of_cterm env e1 in
	 let t2 = type_of_cterm env e2 in
	 let tp = CProdType(t1,t2) in
	 let _ = type_of_cterm env tp in
	   tp)
    | CProj(i,e) ->
	(let t = ctype_fullwhdelta cdefenv (type_of_cterm env e) in
	   match t with
	       CProdType(t1,t2) ->
		 (if i = 1 then t1
		  else if i = 2 then t2
		  else failwith "proj with invalid index")
	     | _ -> failwith "proj on non-tuple")
    | CRecType(var, k, t, _) ->
	(let _ = if csort_of_cterm env k = CKind then () else failwith "recursive type's kind is not CKind" in
	 let env' = add_to_env ~case:var k env in
	 let t' = open_up ~case:var env t in
	   if ctype_equal env' (type_of_cterm env' t') (open_up ~case:var env k) then
	     k
	   else
	     failwith "recursive type's definition does not match expected kind")
    | CFold(e1, t2) ->
	(let t1 = type_of_cterm env e1 in
	 let _ = type_of_cterm env t2 in
	 let t2base, t2args = ctype_appmany_open (ctype_fullwhdelta cdefenv t2) in
	   match ctype_fullwhdelta cdefenv t2base with
	     CRecType(var, k, t, _) ->
	       (let t1exp = ctype_appmany (subst_bound ~case:var ~subst:t2base ~term:t) t2args in
		  if ctype_sub env t1 t1exp then
		    t2
		  else
		    failwith "fold applied to invalid instantiation of recursive type")
	     | _ ->
		 failwith "fold with non-recursive type")
    | CUnfold(e1) ->
	(let t1 = type_of_cterm env e1 in
	 let t1base, t1args = ctype_appmany_open (ctype_fullwhdelta cdefenv t1) in
	   match ctype_fullwhdelta cdefenv t1base with
	       CRecType(var, k, t, _) ->
		 ctype_appmany (subst_bound ~case:var ~subst:t1base ~term:t) t1args
	     | _ ->
		 failwith "unfold with non-recursive type argument")
    | CSumType(branches,_) ->
	(let checkbranch branch = ctype_equal env (type_of_cterm env branch) (CSort CType) in
	   if List.for_all checkbranch branches then
	     CSort(CType)
	   else
	     failwith "there is a branch with non-computational type")
    | CCtor(i,t,par) ->
	(let t' = ctype_fullwhdelta cdefenv t in
	 let par_t = type_of_cterm env par in
	   match t' with
	       CSumType(branches,_) ->
		 let branch_t = List.nth branches i in
		   if ctype_sub env par_t branch_t then 
		     t
		   else
		     failwith "parameter of constructor is not of right type"
	     | _ -> failwith "constructor used with non-sum type")
    | CMatch(e,branches) ->
	(let e_t = type_of_cterm env e in
	 let constrs_t = match ctype_fullwhdelta cdefenv e_t with CSumType(b,_) -> b | _ -> failwith "match on term of non-sum type" in
	   (* this is a hack. take care of it *)
	 let t = 
	   let constr_t = List.nth constrs_t 1 in
	   let (var,body) = List.nth branches 1 in
	   let env' = add_to_env ~case:var constr_t env in
	   let body' = open_up ~case:var env body in
	   let body_t = close_down ~case:var env' (type_of_cterm env' body') in
	     body_t
	 in
	 let checkbranch (var,body) constr_t =
	   let env' = add_to_env ~case:var constr_t env in
	   let body' = open_up ~case:var env body in
	   let body_t = close_down ~case:var env' (type_of_cterm env' body') in
	     if not (ctype_equal env body_t t) then failwith "branch doesn't match expected type"
	 in
	 let _ = List.iter2 checkbranch branches constrs_t in
	 let _ = if not (ctype_equal env (type_of_cterm env t) (CSort(CType))) then failwith "match with non-computational type as result" in
	   t)
    | CLetRec(defs, e) ->
	(let n = List.length defs in
	 let envlen = List.length compenv in
	 let envlen' = n + envlen in
	 let check_def_type (_,t,_) = if not (ctype_equal env (type_of_cterm env t) (CSort(CType))) then failwith "letrec with non-computational type of definition" in
	 let _ = List.iter check_def_type defs in
	 let env' = List.fold_left (fun env (var,t,_) -> add_to_env ~case:var t env) env defs in
	 let check_def (_,t,e) =
	   let e' = CbindCterm.open_up ~howmany:n envlen e in
	   let e_t = CbindCterm.close_down ~howmany:n envlen' (type_of_cterm env' e') in
	     if not (ctype_equal env e_t t) then failwith "a definition in letrec has wrong type!"
	 in
	 let _ = List.iter check_def defs in
	 let e_t = CbindCterm.close_down ~howmany:n envlen' (type_of_cterm env' (CbindCterm.open_up ~howmany:n envlen e)) in
	   if ctype_equal env (type_of_cterm env e_t) (CSort CType) then
	     e_t
	   else
	     failwith "letrec returning non-computational term")
    | CLet(v,d,e) ->
	(let d_t = type_of ~case:v env d in
	 let e_t = 
	   if ctype_equal env (type_of_cterm env d_t) (CSort(CType)) then
	     (let env' = add_to_env ~case:v d_t env in
		close_down ~case:v env' (type_of_cterm env' (open_up ~case:v env e)))
	   else
	     (type_of_cterm env (subst_bound ~case:v ~subst:d ~term:e))
	 in
	      if ctype_equal env (type_of_cterm env e_t) (CSort CType) then
		e_t
	      else
		failwith "let returning non-computational term")

    | CRefType(t) ->
	(let _ = check_computational env t in CSort(CType))
    | CMkRef(e,t') ->
	(let t = type_of_cterm env e in
	 let _ = check_computational env t in
	   if ctype_equal env t t' then
	     CRefType(t)
	   else
	     failwith "designated ref type doesn't match the value"
	)
    | CAssign(e1,e2) ->
	(let t1 = ctype_fullwhdelta cdefenv (type_of_cterm env e1) in
	 let t2 = type_of_cterm env e2 in
	   match t1 with
	       CRefType(t) ->
		 if ctype_equal env t2 t then
		   CUnitType
		 else
		   failwith "non type-compatible assignment"
	     | _ -> 
		 failwith "assignment to non-reference")
    | CReadRef(e) ->
	(let t = ctype_fullwhdelta cdefenv (type_of_cterm env e) in
	   match t with
	       CRefType(t) -> t
	     | _ -> failwith "dereferencing a non-reference")
    | CLoc(l,t) -> CRefType(t)
    | CSeq(e1,e2) ->
	(ensure_type_is env CUnitType e1;
	 let t2 = type_of_cterm env e2 in
	 let _ = check_computational env t2 in
	   t2)

    | CIntType -> CSort(CType)
    | CIntConst(i) -> CIntType
    | CStringType -> CSort(CType)
    | CStringConst(s) -> CStringType
    | CIntOp(o,e1,e2) ->
	(ensure_type_is env CIntType e1;
	 ensure_type_is env CIntType e2;
	 CIntType)
    | CIntTest(o,e1,e2) ->
	(ensure_type_is env CIntType e1;
	 ensure_type_is env CIntType e2;
	 CBoolType)
    | CBoolType -> CSort(CType)
    | CBoolConst(b) -> CBoolType
    | CBoolOp(o,e1,e2) ->
	(ensure_type_is env CBoolType e1;
	 ensure_type_is env CBoolType e2;
	 CBoolType)
    | CIfThenElse(e1,e2,e3) ->
	(ensure_type_is env CBoolType e1;
	 let t2 = type_of_cterm env e2 in
	 let t3 = type_of_cterm env e3 in
	   check_computational env t2;
	   if ctype_equal env t2 t3 then
	     t2
	   else
	     failwith "types of if-branches do not match")

    | CArrayType(t) ->
	check_computational env t;
	CSort(CType)

    | CArrayLit(ts,t) ->
	(let _ = List.iter (fun e -> if not (ctype_equal env (type_of_cterm env e) t) then failwith "array literal's members do not agree on type") ts in
	   CArrayType(t))

    | CMkArray(e1,e2,t_exp) ->
	  ensure_type_is env CIntType e1;
	  check_computational env t_exp;
	  ensure_type_is env t_exp e2;
	  CArrayType(t_exp)

    | CArrayGet(e1,e2) ->
	(let t1 = ctype_fullwhdelta cdefenv (type_of_cterm env e1) in
	  ensure_type_is env CIntType e2;
	  match t1 with
	      CArrayType(t) -> t
	    | _ -> failwith "array type expected when indexing array")

    | CArraySet(e1,e2,e3) ->
	(let t1 = ctype_fullwhdelta cdefenv (type_of_cterm env e1) in
	  ensure_type_is env CIntType e2;
	  match t1 with
	      CArrayType(t) ->
		if ctype_equal env (type_of_cterm env e3) t then
		  CUnitType
		else
		  failwith "assigning different-type value to array index"
	    | _ -> failwith "array type expected when indexing array")

    | CArrayLen(e) ->
	(let t = ctype_fullwhdelta cdefenv (type_of_cterm env e) in
	  match t with
	      CArrayType(_) -> CIntType
	    | _ -> failwith "array type expected when using arraylen")

    | CArrayLoc(_,t) -> CArrayType(t)

    | CHolHash(e) ->
	(let t = type_of_cterm env e in
	   check_computational env t;
	   CIntType)

    | CPrint(e) ->
	(let t = type_of_cterm env e in
	   check_computational env t;
	   CUnitType)

    | CClosure(subst, e) ->
	(let (_,_,metaenv',ctxenv',compenv') as env' = env_from_subst defenv cdefenv subst in
	 let (<.>) = compose in
	 let e' = ((MetabindCterm.open_up ~howmany:(List.length metaenv') 0) <.>
	            (CtxbindCterm.open_up ~howmany:(List.length ctxenv') 0) <.>
		    (CbindCterm.open_up ~howmany:(List.length compenv') 0)) e in
	  type_of_cterm env' e')

    | CTypeAscribe(e, t) ->
	(let t' = type_of_cterm env e in
	   if ctype_equal env t t' then
	     t'
	   else
	     failwith "type ascription does not match type")

(*
    | CPiStatic(var, t1, t2) ->
	(let _ = check_static env t1 in
	 let t1_s = csort_of ~case:var env t1 in
	 let env' = add_to_env ~case:var ~static:true t1 env in
	 let t2'  = open_up ~case:var env t2 in
	 let _ = check_static env' t2' in
	 let t2_s = csort_of_cterm env' t2' in
	   if reifiable cdefenv t1 && t1_s = CType && t2_s = CType then
	     CSort(t2_s)
	   else
	     failwith "non-allowed static abstraction used")
    | CLambdaStatic(var, t1, e2) ->
	(let _ = check_env_static compenv ; check_env_static metaenv ; check_env_static ctxenv in
	 (* only allow lambda static at the outer level *)
	 let env' = add_to_env ~case:var ~static:true t1 env in
	 let _    = check_static env' (open_up ~case:var env e2) in
	 let t2   = type_of_cterm env' (open_up ~case:var env e2) in
	 let tp   = CPiStatic(var, t1, close_down ~case:var env' t2) in
	 let _    = type_of_cterm env tp in
	   tp)
    | CApplyStatic(e1, e2) ->
	(let t1 = ctype_fullwhdelta cdefenv (type_of_cterm env e1) in
	   match t1 with
	       CPiStatic(var, t, t') ->
		 let _ = check_static env e2 in
		 let t2 = type_of ~case:var env e2 in
		   if ctype_sub env t2 t then
		     subst_bound ~case:var ~term:t' ~subst:e2
		   else
		     failwith "types don't match in static application"
	     | _ -> failwith "static applying something to a non static functional type")
*)

    | CStaticDo(e) ->
      (let _ = check_static env e in
       let tp = type_of_cterm env e in
       if reifiable cdefenv tp then
	 (check_computational env tp; tp)
       else
	 failwith "static do with non reifiable type")

    | CPrfErase(e) ->
      (let tp = type_of_cterm env e in
       check_computational env tp; tp)

    | CInfer(el, f) ->
	(match !(match_cunif el) with
	     Inst(ei,ti) ->
	       (let t' = type_of_cterm env (f ei) in
		  if (match !ti with Some ot -> ctype_equal env t' (CInfer(ot,f)) | _ -> true) then
		    t'
		  else
		    failwith "instantiation of inferred term with wrong type!")
	   | Uninst(i,otyp) ->
	       (match !otyp with
		    None -> (let uv = mk_cunifvar () in otyp := (Some uv); CInfer(uv, f))
		  | Some ti -> CInfer(ti, f)))
	               
	
and ensure_type_is ((defenv,cdefenv,_,_,_) as env) t e = 
  if not (ctype_equal env (type_of_cterm env e) t) then failwith "expected another type"
    
and check_computational ((defenv,cdefenv,_,_,_) as env) t =

  if not (ctype_equal env (type_of_cterm env t) (CSort(CType))) then failwith "computational type expected"

and check_pattern (defenv, _, _, _, _) metas t =

  (let ctx, tm = match t with CHolTerm(LTermInCtx(ctx,tm)) -> ctx, tm | _ -> failwith "patterns should be terms-in-context" in
     Logic_typing.check_pattern defenv ctx (List.length metas) tm)
	 
and check_branch ((defenv, cdefenv, metaenv, ctxenv, compenv) as env) typs scrutinees ret_f (pats, e) =
  
  let open_up_meta n = MetabindCterm.open_up ~howmany:n (List.length metaenv) in

  let replace_scrutinees_in_env open_up env scrutinees ts =
    List.fold_left
      (fun env (scrutinee, t) -> subst_fmeta_in_env env (open_up scrutinee) t)
      env (List.combine scrutinees ts)
  in

  let replace_scrutinees_in_tm open_up scrutinees ts tm =
    List.fold_left
      (fun tm (scrutinee, t) -> subst_fmeta (open_up scrutinee) t tm)
      tm (List.combine scrutinees ts)
  in

  let check_branchpattern env scrutinees typs pats = 
    ExtList.midfold
      (fun scrutinees_typs_pats (scrutinee,(typ,(metas,t))) (env, ncur, ts) ->
	 let nmetas = List.length metas in
	 let scrutinees, typs_pats = List.split scrutinees_typs_pats in
	 let env', _ = List.fold_left
	   (fun (env, i) (var,typ) ->
	      let open_up_in_env = open_up_meta (ncur + i) in
	      let typ' = open_up_in_env typ in
	      let _ = type_of_HOL env typ' in
	      let env' = add_to_env ~case:var typ' env in
		(env', i + 1))
	   (env, 0) metas
	 in
	 let open_up_in_env' = open_up_meta (ncur + nmetas) in
	 let t' = open_up_in_env' t in
	 let env'' = replace_scrutinees_in_env open_up_in_env' env' scrutinees ts in
	 let t_typ = type_of_HOL env'' t' in
	 let _ = check_pattern env' metas t in
	 let typ' = replace_scrutinees_in_tm open_up_in_env' scrutinees ts typ in
	   (if ctype_equal env' t_typ typ' then
	      ()
	    else
	      failwith "type of pattern is not the expected one");
	   (env', ncur + nmetas, List.append ts [open_up_in_env' t]))
      (List.combine scrutinees (List.combine typs pats))
      (env, 0, [])
  in

  let env', ncur, ts = check_branchpattern env scrutinees typs pats in
  let open_up_in_env' = open_up_meta ncur in
  let env'' = replace_scrutinees_in_env open_up_in_env' env' scrutinees ts in

  let e' = replace_scrutinees_in_tm open_up_in_env' scrutinees ts (open_up_in_env' e) in
  let e_typ = type_of_cterm env'' e' in
  let e_exp = ret_f ts in
    (if ctype_sub env' e_typ e_exp then
       ()
     else
       failwith "type of body of branch is not the expected one")

and check_ctxbranch ((defenv, cdefenv, metaenv, ctxenv, compenv) as env) scrutineevar ret_f (ctxvs, metas, t, e) =

  let open_up_ctx  n = CtxbindCterm.open_up ~howmany:n (List.length ctxenv) in
  let open_up_meta n = MetabindCterm.open_up ~howmany:n (List.length metaenv) in

  let env' = List.fold_left (fun env v -> add_to_env ~case:v (CSort(CCtx)) env) env ctxvs in
  let cn = List.length ctxvs in
  let metas' = ExtList.sndmap (open_up_ctx cn) metas in

  let env', n = List.fold_left (fun (env, n) (var, typ) ->
				  let typ' = open_up_meta n typ in
				  let _ = type_of_HOL env typ' in
				  let env' = add_to_env ~case:var typ' env in
				    (env', n+1)) (env',0) metas' in
  let t' = open_up_meta n (open_up_ctx cn t) in
  let _ = type_of_ctx env' t' in
  let _ = match t with CCtxTerm(LCtxAsList(l)) -> check_context_pattern env (List.length ctxenv) ctxvs metas l | _ -> failwith "only context lists allowed in context branches" in
  let e' = open_up_meta n (open_up_ctx cn e) in

  let env'' = subst_fctx_in_env env' (open_up_ctx cn scrutineevar) t' in
  let e'' = subst_fctx (open_up_ctx cn scrutineevar) t' e' in

  let e_typ = type_of_cterm env'' e'' in
  let e_exp = open_up_meta n (open_up_ctx cn (ret_f t)) in
    (if ctype_sub env' e_typ e_exp then
       ()
     else
       failwith "type of body of branch is not the expected one")

and env_from_subst defenv cdefenv (metasubst,ctxsubst,compsubst) =
  let metaenv = List.map (fun t -> type_of_modal ([], defenv, [], []) t, false) metasubst in
  let ctxenv  = List.map (fun t -> ctx_wf ([], defenv, [], []) t, false) ctxsubst in
  let compenv = List.map (fun t -> type_of_cterm (defenv, cdefenv, [], [], []) t, false) compsubst in
    (defenv, cdefenv, metaenv, ctxenv, compenv)

and type_of_HOL (defenv, cdefenv, metaenv, ctxenv, compenv) (e : cterm) =
  match e with
      CHolTerm(t) ->
	(let metaenv = List.map fst metaenv in
	 let ctxenv = List.map fst ctxenv in
	 let tp = Logic_typing.type_of_modal ([], defenv, metaenv, ctxenv) t in CHolTerm(tp))
    | _ -> failwith "non-HOL term in HOL position"
and csort_of_HOL (defenv, cdefenv, metaenv, ctxenv, compenv) (e : cterm) =
  match e with
      CHolTerm(LTermInCtx(_,_) as t) ->
	(let metaenv = List.map fst metaenv in
	 let ctxenv = List.map fst ctxenv in
	 nowarn let LTermInCtx(_, s) = Logic_typing.type_of_modal ([], defenv, metaenv, ctxenv) t in
	 let _ = match whnf defenv s with LSort(_) -> () | LInfer(_,_) -> () | _ -> failwith "type of modal in abstractor is not a sort" in
	 CHol)
    | CHolTerm(_) -> failwith "metavariables are not allowed as types of metavariables"
    | _ -> failwith "non-HOL term in HOL abstractor position"
and type_of_ctx (defenv, cdefenv, metaenv, ctxenv, compenv) (e : cterm) =
  match e with
      CCtxTerm(t) ->
	(let metaenv = List.map fst metaenv in
	 let ctxenv = List.map fst ctxenv in
	 let _ = Logic_typing.ctx_wf ([], defenv, metaenv, ctxenv) t in CSort(CCtx))
    | _ -> failwith "non-context term in context position"
and csort_of_ctx (defenv, cdefenv, metaenv, ctxenv, compenv) (e : cterm) =
  match e with
    | CInfer(_) | CSort(CCtx) -> CCtx
    | _ -> failwith "non-context term in context abstractor position"
and csort_of_cterm ((defenv, cdefenv, metaenv, ctxenv, compenv) as env) (e : cterm) =
  match ctype_fullwhdelta cdefenv (type_of_cterm env e) with
      CSort(CType) -> CType
    | CSort(CKind) -> CKind
    | _ -> failwith "non-allowed classifier in computational abstractor position"
and csort_of ~case:s env t = case_kind csort_of_HOL csort_of_ctx csort_of_cterm ~case:s env t
and type_of  ~case:s env t = case_kind type_of_HOL type_of_ctx type_of_cterm ~case:s env t


let type_of_cterm_expected env ?(expected=None) e =
  let tp = type_of_cterm env e in
  match expected with
      Some (tp', msg) when not (ctype_sub env tp tp') -> failwith msg
    | _ -> tp

