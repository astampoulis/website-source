open Logic_cst
open Logic_print
open Comp_cst
open Format

let pr_cterm_cst =
  let str ppf s = fprintf ppf "%s" s in
  let astr ppf s = 
    match s with
	StrId s -> fprintf ppf "%s" s
      | StrAnt(_,s) -> fprintf ppf "%a%a%a" str "$" str s str "$"
  in
  let pint ppf i = fprintf ppf "%d" i in
  let var ppf (s,k) = let c = match k with CAst.CCtx -> "#" | CAst.CHol -> "?" | _ -> "" in fprintf ppf "%s%a" c astr s in
  let rec pr_cterm ppf = function
      CSort(s) -> fprintf ppf "%a" pr_sort s
    | CPi(s,t1,t2) ->
	fprintf ppf "@[<1>%a@ %a%a%a%a@,%a@]" str "{" var s str ":" pr_cterm t1 str "}" pr_cterm t2
    | CLambda(s,t1,t2) ->
	fprintf ppf "@[<1>%a@ %a%a%a%a@,%a@]" str "fun" var s str ":" pr_cterm t1 str "=>" pr_cterm t2
    | CSigma(s,t1,t2) ->
	fprintf ppf "@[<1>%a@ %a%a%a%a@,%a@]" str "<" var s str ":" pr_cterm t1 str ">" pr_cterm t2
    | CSigmaUnit(t1) ->
	fprintf ppf "@[<1>%a%a%a@]" str "hol(" pr_cterm t1 str ")"
    | CArrow(t1,t2) ->
	fprintf ppf "@[<1>%a@ %a@ %a@]" pr_cterm_paren_app1 t1 str "->" pr_cterm t2
    | CApp(t1,t2) ->
	fprintf ppf "@[<2>%a@ %a@]" pr_cterm_paren_app1 t1 pr_cterm_paren_app2 t2
    | CHolTerm(t1) ->
	fprintf ppf "%a" pr_modal_cst t1
    | CCtxTerm(t1) ->
	fprintf ppf "%a%a" str "#" pr_ctxdesc_cst t1
    | CUnitType ->
	fprintf ppf "%a" str "Unit"
    | CUnitExpr ->
	fprintf ppf "%a" str "unit"
    | CVar(s) ->
	fprintf ppf "%a" astr s
    | CPack(t1,s1,ret,t2) ->
	fprintf ppf "@[%a@ %a@ %a@ %a@ %a@ %a@ %a@ %a @]" str "pack" pr_cterm t1 str "as" var s1
	  str "return" pr_cterm ret str "with" pr_cterm t2
    | CPackUnit(t1) ->
	fprintf ppf "@[%a@,%a@,%a@]" str "<|" pr_cterm t1 str "|>"
    | CUnpack(t1,s1,s2,t2) ->
	fprintf ppf "@[%a@ <%a,%a>%a%a@ %a@ %a@]" str "unpack" var s1 var s2 str "=" pr_cterm t1 str "in" pr_cterm t2
    | CHolCase(t1,name,ret,branches) ->
	fprintf ppf "@[%a@ %a@ %a@ %a@ %a@ %a@ %a@ %a@]"
	  str "holcase" (pr_list pr_cterm ",") t1 str "as" (pr_list var ",") name str "return" pr_cterm ret  str "with"
	  (pr_list pr_branch "|") branches
    | CCtxCase(t1,name,ret,branches) ->
	fprintf ppf "@[%a@ %a@ %a@ %a@ %a@ %a@ %a@ %a@]"
	  str "ctxcase" pr_cterm t1 str "as" var name str "return" pr_cterm ret  str "with"
	  (pr_list pr_ctxbranch "|") branches
    | CProdType(t1,t2) ->
	fprintf ppf "%a%a%a"
	  pr_cterm t1 str "*" pr_cterm t2
    | CRecType(v,t1,t2) ->
	fprintf ppf "@[%a@ %a%a%a%a%a@]"
	  str "u"
	  var v 
	  str ":"
	  pr_cterm t1
	  str "."
	  pr_cterm t2
    | CSumType(branches) ->
	fprintf ppf "@[(%a)@]"
	  (pr_list pr_cterm "+") branches
    | CFold(t1,t2) ->
	fprintf ppf "@[%a(%a,%a)@]"
	  str "fold"
	  pr_cterm t1
	  pr_cterm t2
    | CUnfold(t1) ->
	fprintf ppf "@[%a(%a)@]"
	  str "unfold"
	  pr_cterm t1
    | CCtor(i,t,p) ->
	fprintf ppf "@[%a%a%a%a%a%a%a%a@]"
	  str "ctor"
	  str "("
	  pint i
	  str ","
	  pr_cterm t
	  str ","
	  pr_cterm p
	  str ")"
    | CTuple(t1,t2) ->
	fprintf ppf "@[%a%a%a%a%a@]"
	  str "("
	  pr_cterm t1
	  str ","
	  pr_cterm t2
	  str ")"
    | CLet(name,d,e) ->
	fprintf ppf "@[%a@ %a@ %a@ %a@ %a@ %a@]"
	  str "let"
	  var name
	  str "="
	  pr_cterm d
	  str "in"
	  pr_cterm e
    | CLetRec(defs,e) ->
	fprintf ppf "@[%a@ %a@ %a@ %a@]"
	  str "letrec"
	  (pr_list pr_letrecdef "andrec") defs
	  str "in"
	  pr_cterm e
    | CMatch(e,branches) ->
	fprintf ppf "@[%a@ %a@ %a@ %a@]"
	  str "match"
	  pr_cterm e
	  str "with"
	  (pr_list pr_matchbranch "|") branches
    | CProj(i,e) when i=1 -> fprintf ppf "fst"
    | CProj(i,e) -> fprintf ppf "snd"
    | CRefType(t) -> fprintf ppf "%a@ %a" str "ref" pr_cterm t
    | CMkRef(t1,t2)  -> fprintf ppf "%a(%a,%a)" str "mkref" pr_cterm t1 pr_cterm t2
    | CAssign(t1,t2) -> fprintf ppf "%a%a%a" pr_cterm t1 str ":=" pr_cterm t2
    | CReadRef(t)    -> fprintf ppf "%a%a" str "!" pr_cterm t
    | CSeq(t1,t2)    -> fprintf ppf "%a%a%a" pr_cterm t1 str ";" pr_cterm t2
    | CLoc(l,_)      -> fprintf ppf "@[{{loc contents::%a}}@]" pr_cterm (!l)

    | CIntType -> fprintf ppf "int"
    | CIntConst(i) -> fprintf ppf "%d" i
    | CIntOp(o,t1,t2) -> fprintf ppf "%a%s%a" pr_cterm t1 (match o with
							       CAst.Plus -> "i+"
							     | CAst.Minus -> "i-"
							     | CAst.Times -> "i*"
							     | CAst.Mod -> "i%") pr_cterm t2
    | CIntTest(o,t1,t2) -> fprintf ppf "%a%s%a" pr_cterm t1 (match o with
								 CAst.LT -> "<"
							       | CAst.LE -> "<="
							       | CAst.GT -> ">"
							       | CAst.GE -> ">="
							       | CAst.EQ -> "=") pr_cterm t2
    | CBoolType -> fprintf ppf "bool"
    | CBoolConst(b) -> fprintf ppf "%b" b
    | CBoolOp(o,t1,t2) -> fprintf ppf "%a%s%a" pr_cterm t1 (match o with
								CAst.BAnd -> "&&"
							      | CAst.BOr -> "||") pr_cterm t2
    | CIfThenElse(t1,t2,t3) -> fprintf ppf "%a@ %a@ %a@ %a@ %a@ %a"
	str "if" pr_cterm t1 str "then" pr_cterm t2 str "else" pr_cterm t3

    | CArrayType(t) -> fprintf ppf "%a@ %a" str "array" pr_cterm t
    | CArrayLit(ts,t) -> fprintf ppf "@[%a%a%a@]@ %a@ %a" str "[|" (pr_list pr_cterm ",") ts str "|]" str "of" pr_cterm t
    | CMkArray(t1,t2,t3) -> fprintf ppf "%a(%a,%a,%a)" str "mkarray" pr_cterm t1 pr_cterm t2 pr_cterm t3
    | CArrayGet(t1,t2) -> fprintf ppf "%a.(%a)" pr_cterm t1 pr_cterm t2
    | CArraySet(t1,t2,t3) -> fprintf ppf "%a.(%a)%a%a" pr_cterm t1 pr_cterm t2 str "<-" pr_cterm t3
    | CArrayLoc(l,_) -> fprintf ppf "@[{{arrayloc contents::%a}}@]" (pr_list pr_cterm ",") (Array.to_list l)
    | CArrayLen(t) -> fprintf ppf "%a@ %a" str "arraylen" pr_cterm t

    | CHolHash(t) -> fprintf ppf "%a@ %a" str "hash" pr_cterm t
    | CPrint(t) -> fprintf ppf "%a@ %a" str "print" pr_cterm t
    | CStringConst(s) -> fprintf ppf "\"%a\"" str s
    | CStringType -> fprintf ppf "string"
    | CStaticDo(e) ->  fprintf ppf "static { %a }" pr_cterm e
    | CPrfErase(e) ->  fprintf ppf "trusted { %a }" pr_cterm e

    | CSetContext(ctx,e) ->
	fprintf ppf "%a@ %a@ %a@ %a@ %a@[%a@]" str "let" str "@" str "=" pr_ctxdesc_cst ctx str "in" pr_cterm e
    | CNuContext(x,e1,e2) ->
      fprintf ppf "nu %a : %a in %a" astr x pr_lterm_cst e1 pr_cterm e2
    | CUseMetaContext(e) ->
      fprintf ppf "let @ = @@ in %a" pr_cterm e
    | CTypeAscribe(e,t) ->
	fprintf ppf "%a :: %a" pr_cterm e pr_cterm t

    | CAny(i) ->
	fprintf ppf "%d" i
    | CAnt(_,s) -> fprintf ppf "%a%a%a" str "$" str s str "$"
  and pr_sort ppf sort =
    let s =
      match sort with
	  CAst.CType -> "CType"
	| CAst.CKind -> "Kind"
	| CAst.CCtx  -> "ctx"
	| CAst.CHol  -> "HOL"
    in
      fprintf ppf "%a" str s
  and pr_matchbranch ppf (name,e) =
    fprintf ppf "%a@ %a@ %a" var name str "|->" pr_cterm e
  and pr_letrecdef ppf (name,typ,tm) =
    fprintf ppf "%a@ %a@ %a@ %a@ %a" var name str ":" pr_cterm typ str "=" pr_cterm tm
  and pr_cterm_paren_app1 ppf e = match e with
      CSort _ | CVar _ | CApp _ | CHolTerm _ | CCtxTerm _ | CUnitType | CUnitExpr -> pr_cterm ppf e
    | _ -> fprintf ppf "(%a)" pr_cterm e
  and pr_cterm_paren_app2 ppf e = match e with
      CSort _ | CVar _ | CHolTerm _ | CCtxTerm _ | CUnitType | CUnitExpr -> pr_cterm ppf e
    | _ -> fprintf ppf "(%a)" pr_cterm e
  and pr_branchpat ppf (metas, t1) =
    fprintf ppf "@[%a%a%a%a%a@]"
      str "("
      (pr_list pr_binder ",") metas
      str ")"
      str "."
      pr_cterm t1
  and pr_branch ppf (pats, e1) =
    fprintf ppf "@[%a%a%a@ %a@ %a@]"
      str "{"
      (pr_list pr_holpat ",") pats
      str "}"
      str "|->"
      pr_cterm e1
  and pr_holpat ppf e =
    match e with
	CHPatNested(l) -> fprintf ppf "%a" (pr_list pr_branchpat ",") l
      | CHPatAnt(_,s) -> fprintf ppf "%a%a%a" str "$" str s str "$"
  and pr_ctxbranch ppf (ctxvs, metas, t1, e1) =
    fprintf ppf "@[%a%a%a%a%a%a%a%a%a@ %a@ %a@]"
      str "("
      (pr_list var ",") ctxvs
      str ")"
      str "."
      str "("
      (pr_list pr_binder ",") metas
      str ")"
      str "."
      pr_cterm t1
      str "|->"
      pr_cterm e1
  and pr_binder ppf (s, t) =
    fprintf ppf "%a%a%a"
      var s
      str ":"
      pr_cterm t
  in
    pr_cterm


let pr_typarg base ppf arg = ()
let pr_cterm_cst_compact =
  let str ppf s = fprintf ppf "%s" s in
  let astr ppf s = 
    match s with
	StrId s -> fprintf ppf "%s" s
      | StrAnt(_,s) -> fprintf ppf "%a%a%a" str "$" str s str "$"
  in
  let pint ppf i = fprintf ppf "%d" i in
  let var ppf (s,k) = let c = match k with CAst.CCtx -> "#" | CAst.CHol -> "?" | _ -> "" in fprintf ppf "%s%a" c astr s in
  let rec pr_cterm ppf = function
      CSort(s) -> fprintf ppf "%a" pr_sort s
    | CPi(s,t1,t2) ->
	fprintf ppf "@[<1>%a%a%a@,%a@]" str "{" var s str "}" pr_cterm t2
    | CLambda(s,t1,t2) ->
	fprintf ppf "@[<1>%a@ %a%a@,%a@]" str "fun" var s str "=>" pr_cterm t2
    | CSigma(s,t1,t2) ->
	fprintf ppf "@[<1>%a%a%a@,%a@]" str "<" var s str ">" pr_cterm t2
    | CSigmaUnit(t1) ->
	fprintf ppf "@[<1>%a%a%a@]" str "hol(" pr_cterm t1 str ")"
    | CArrow(t1,t2) ->
	fprintf ppf "@[<1>%a@ %a@ %a@]" pr_cterm_paren_app1 t1 str "->" pr_cterm t2
    | CApp(t1,t2) ->
	fprintf ppf "@[<2>%a@ %a@]" pr_cterm_paren_app1 t1 pr_cterm_paren_app2 t2
    | CHolTerm(t1) ->
	fprintf ppf "%a" pr_modal_cst t1
    | CCtxTerm(t1) ->
	fprintf ppf "%a%a" str "#" pr_ctxdesc_cst t1
    | CUnitType ->
	fprintf ppf "%a" str "Unit"
    | CUnitExpr ->
	fprintf ppf "%a" str "unit"
    | CVar(s) ->
	fprintf ppf "%a" astr s
    | CPack(t1,s1,ret,t2) ->
	fprintf ppf "@[%a@,%a,%a@,%a@]" str "<|" pr_cterm t1 pr_cterm t2 str "|>"
    | CPackUnit(t1) ->
	fprintf ppf "@[%a@,%a@,%a@]" str "<|" pr_cterm t1 str "|>"
    | CUnpack(t1,s1,s2,t2) ->
	fprintf ppf "@[%a@ <| %a,%a |>%a%a@ %a@ %a@]" str "unpack" var s1 var s2 str "=" pr_cterm t1 str "in" pr_cterm t2
    | CHolCase(t1,name,ret,branches) ->
	fprintf ppf "@[%a@ %a@ %a@ %a@]"
	  str "holcase" (pr_list pr_cterm ",") t1 str "with"
	  (pr_list pr_branch "|") branches
    | CCtxCase(t1,name,ret,branches) ->
	fprintf ppf "@[%a@ %a@ %a@ %a@ %a@ %a@ %a@ %a@]"
	  str "ctxcase" pr_cterm t1 str "as" var name str "return" pr_cterm ret  str "with"
	  (pr_list pr_ctxbranch "|") branches
    | CProdType(t1,t2) ->
	fprintf ppf "%a%a%a"
	  pr_cterm t1 str "*" pr_cterm t2
    | CRecType(v,t1,t2) ->
	fprintf ppf "@[%a@ %a%a%a@]"
	  str "u"
	  var v 
	  str "."
	  pr_cterm t2
    | CSumType(branches) ->
	fprintf ppf "@[(%a)@]"
	  (pr_list pr_cterm "+") branches
    | CFold(t1,t2) ->
	fprintf ppf "%a" pr_cterm t1
    | CUnfold(t1) ->
	fprintf ppf "%a" pr_cterm t1
    | CCtor(i,t,p) ->
	fprintf ppf "@[%a%a%a%a%a%a@]"
	  str "ctor"
	  str "("
	  pint i
	  str ","
	  pr_cterm p
	  str ")"
    | CTuple(t1,t2) ->
	fprintf ppf "@[%a%a%a%a%a@]"
	  str "("
	  pr_cterm t1
	  str ","
	  pr_cterm t2
	  str ")"
    | CLet(name,d,e) ->
	fprintf ppf "@[%a@ %a@ %a@ %a@ %a@ %a@]"
	  str "let"
	  var name
	  str "="
	  pr_cterm d
	  str "in"
	  pr_cterm e
    | CLetRec(defs,e) ->
	fprintf ppf "@[%a@ %a@ %a@ %a@]"
	  str "letrec"
	  (pr_list pr_letrecdef "andrec") defs
	  str "in"
	  pr_cterm e
    | CMatch(e,branches) ->
	fprintf ppf "@[%a@ %a@ %a@ %a@]"
	  str "match"
	  pr_cterm e
	  str "with"
	  (pr_list pr_matchbranch "|") branches
    | CProj(i,e) when i=1 -> fprintf ppf "fst"
    | CProj(i,e) -> fprintf ppf "snd"
    | CRefType(t) -> fprintf ppf "%a@ %a" str "ref" pr_cterm t
    | CMkRef(t1,t2)  -> fprintf ppf "%a(%a,%a)" str "mkref" pr_cterm t1 pr_cterm t2
    | CAssign(t1,t2) -> fprintf ppf "%a%a%a" pr_cterm t1 str ":=" pr_cterm t2
    | CReadRef(t)    -> fprintf ppf "%a%a" str "!" pr_cterm t
    | CSeq(t1,t2)    -> fprintf ppf "%a%a%a" pr_cterm t1 str ";" pr_cterm t2
    | CLoc(l,_)      -> fprintf ppf "@[{{loc contents::%a}}@]" pr_cterm (!l)

    | CIntType -> fprintf ppf "int"
    | CIntConst(i) -> fprintf ppf "%d" i
    | CIntOp(o,t1,t2) -> fprintf ppf "%a%s%a" pr_cterm t1 (match o with
							       CAst.Plus -> "i+"
							     | CAst.Minus -> "i-"
							     | CAst.Times -> "i*"
							     | CAst.Mod -> "i%") pr_cterm t2
    | CIntTest(o,t1,t2) -> fprintf ppf "%a%s%a" pr_cterm t1 (match o with
								 CAst.LT -> "<"
							       | CAst.LE -> "<="
							       | CAst.GT -> ">"
							       | CAst.GE -> ">="
							       | CAst.EQ -> "=") pr_cterm t2
    | CBoolType -> fprintf ppf "bool"
    | CBoolConst(b) -> fprintf ppf "%b" b
    | CBoolOp(o,t1,t2) -> fprintf ppf "%a%s%a" pr_cterm t1 (match o with
								CAst.BAnd -> "&&"
							      | CAst.BOr -> "||") pr_cterm t2
    | CIfThenElse(t1,t2,t3) -> fprintf ppf "%a@ %a@ %a@ %a@ %a@ %a"
	str "if" pr_cterm t1 str "then" pr_cterm t2 str "else" pr_cterm t3

    | CArrayType(t) -> fprintf ppf "%a@ %a" str "array" pr_cterm t
    | CArrayLit(ts,t) -> fprintf ppf "@[%a%a%a@]@ %a@ %a" str "[|" (pr_list pr_cterm ",") ts str "|]" str "of" pr_cterm t
    | CMkArray(t1,t2,t3) -> fprintf ppf "%a(%a,%a,%a)" str "mkarray" pr_cterm t1 pr_cterm t2 pr_cterm t3
    | CArrayGet(t1,t2) -> fprintf ppf "%a.(%a)" pr_cterm t1 pr_cterm t2
    | CArraySet(t1,t2,t3) -> fprintf ppf "%a.(%a)%a%a" pr_cterm t1 pr_cterm t2 str "<-" pr_cterm t3
    | CArrayLoc(l,_) -> fprintf ppf "@[{{arrayloc contents::%a}}@]" (pr_list pr_cterm ",") (Array.to_list l)
    | CArrayLen(t) -> fprintf ppf "%a@ %a" str "arraylen" pr_cterm t

    | CHolHash(t) -> fprintf ppf "%a@ %a" str "hash" pr_cterm t
    | CPrint(t) -> fprintf ppf "%a@ %a" str "print" pr_cterm t
    | CStringConst(s) -> fprintf ppf "\"%a\"" str s
    | CStringType -> fprintf ppf "string"

    | CStaticDo(e) -> fprintf ppf "static { %a }" pr_cterm e
    | CPrfErase(e) ->  fprintf ppf "trusted { %a }" pr_cterm e

    | CSetContext(ctx,e) ->
	fprintf ppf "%a@ %a@ %a@ %a@ %a@[%a@]" str "let" str "@" str "=" pr_ctxdesc_cst ctx str "in" pr_cterm e
    | CNuContext(x,e1,e2) ->
      fprintf ppf "nu %a : %a in %a" astr x pr_lterm_cst e1 pr_cterm e2
    | CUseMetaContext(e) ->
      fprintf ppf "let @ = @@ in %a" pr_cterm e
    | CTypeAscribe(e,t) ->
	fprintf ppf "%a :: %a" pr_cterm e pr_cterm t
    | CAny(i) ->
	fprintf ppf "%d" i
    | CAnt(_,s) -> fprintf ppf "%a%a%a" str "$" str s str "$"
  and pr_sort ppf sort =
    let s =
      match sort with
	  CAst.CType -> "CType"
	| CAst.CKind -> "Kind"
	| CAst.CCtx  -> "ctx"
	| CAst.CHol  -> "HOL"
    in
      fprintf ppf "%a" str s
  and pr_matchbranch ppf (name,e) =
    fprintf ppf "%a@ %a@ %a" var name str "|->" pr_cterm e
  and pr_letrecdef ppf (name,typ,tm) =
    fprintf ppf "%a@ %a@ %a@ %a@ %a" var name str ":" pr_cterm typ str "=" pr_cterm tm
  and pr_cterm_paren_app1 ppf e = match e with
      CSort _ | CVar _ | CApp _ | CHolTerm _ | CCtxTerm _ | CUnitType | CUnitExpr -> pr_cterm ppf e
    | _ -> fprintf ppf "(%a)" pr_cterm e
  and pr_cterm_paren_app2 ppf e = match e with
      CSort _ | CVar _ | CHolTerm _ | CCtxTerm _ | CUnitType | CUnitExpr -> pr_cterm ppf e
    | _ -> fprintf ppf "(%a)" pr_cterm e
  and pr_branchpat ppf (metas, t1) =
    fprintf ppf "@[%a@]"
      pr_cterm t1
  and pr_branch ppf (pats, e1) =
    fprintf ppf "@[%a%a%a@ %a@ %a@]"
      str "{"
      (pr_list pr_holpat ",") pats
      str "}"
      str "|->"
      pr_cterm e1
  and pr_holpat ppf e =
    match e with
	CHPatNested(l) -> fprintf ppf "%a" (pr_list pr_branchpat ",") l
      | CHPatAnt(_,s) -> fprintf ppf "%a%a%a" str "$" str s str "$"
  and pr_ctxbranch ppf (ctxvs, metas, t1, e1) =
    fprintf ppf "@[%a%a%a%a%a%a%a%a%a@ %a@ %a@]"
      str "("
      (pr_list var ",") ctxvs
      str ")"
      str "."
      str "("
      (pr_list pr_binder ",") metas
      str ")"
      str "."
      pr_cterm t1
      str "|->"
      pr_cterm e1
  and pr_binder ppf (s, t) =
    fprintf ppf "%a%a%a"
      var s
      str ":"
      pr_cterm t
  in
    pr_cterm


let pr_cterm ppf e = pr_cterm_cst(*_compact *) ppf (comp_cst_of_ast e)

let print_cterm (e : CAst.cterm) =
  fprintf std_formatter "%a@." pr_cterm e

let string_of_cterm (e : CAst.cterm) =
  fprintf str_formatter "%a" pr_cterm e; flush_str_formatter ()

