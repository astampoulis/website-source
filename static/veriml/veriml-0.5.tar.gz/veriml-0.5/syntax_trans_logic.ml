open Camlp4.PreCast
module LCst = Logic_cst
module LAst = Logic_ast

module LogicGram = MakeGram(Lexer)

let term = LogicGram.Entry.mk "term"
let modalterm = LogicGram.Entry.mk "contextual term"
let modalterm_paren = LogicGram.Entry.mk "contextual term (maybe parenthesized)"
let logicdef = LogicGram.Entry.mk "logic definition"
let ident = LogicGram.Entry.mk "identifier"
let context = LogicGram.Entry.mk "context"
let paramlist = LogicGram.Entry.mk "paramlist"


EXTEND LogicGram
  GLOBAL: term modalterm modalterm_paren ident context logicdef paramlist;

  term:
    [ "pilambda" RIGHTA
	[ "fun"; v = vars; "=>"; t' = term ->
	    LCst.lammany v t'
	| "forall"; v = vars; ","; t' = term ->
	    LCst.pimany v t' ]
    | "arrow" RIGHTA
	[ t = term; "->"; t' = term ->
	    LCst.LArrow(t, t') ]
    | "eq" NONA
	[ t = term; "="; t' = term ->
	    LCst.LEq( t, t' ) ]
    | "app" LEFTA
	[ t = term; t' = term ->
	    LCst.LApp(t, t')  ]
    | "simple"
        [ "Type" -> LCst.LSort(LAst.LType)
	| "Set"  -> LCst.LSort(LAst.LSet)
	| "Prop" -> LCst.LSort(LAst.LProp)
	| "??"  -> LCst.LAny(0)
	| x = ident -> LCst.LVar(x)
	| x = ident; "/"; "["; subst = LIST0 term SEP ","; "]" ->
	    LCst.LModal(LCst.LMeta(x), subst)
	| "?"; x = ident; "/"; "["; subst = LIST0 term SEP ","; "]" ->
	    LCst.LModal(LCst.LMeta(x), subst)
	| "?"; x = ident ->
	    LCst.LModalOmitSubst(LCst.LMeta(x))
	| i = INT ->
	    LCst.logicint (int_of_string i)
	| `ANTIQUOT("",x) -> LCst.LAnt(_loc,"lt:"^x)
	| "("; t = term; ")" -> t ] ];

  modalterm:
    [ [ ctx = context; "."; t = term ->
	    LCst.LTermInCtx(ctx, t)
      | "@??" ->
	    LCst.LTermInCtx(LCst.LCurctx, LCst.LAny(0))
      | "@"; t = term ->
	    LCst.LTermInCtx(LCst.LCurctx, t)
      | "?"; x = ident ->
	  LCst.LMeta(x)
      | `ANTIQUOT("mt",x) -> LCst.LMetaAnt(_loc,"mt:"^x) ] ];
  
  modalterm_paren:
    [ [ "("; t = modalterm; ")" -> t 
      | t = modalterm -> t ] ];

  context:
    [ [ "["; xs = LIST0 ctxelem SEP ","; "]" ->
	    LCst.LCtxAsList(xs)
      ] ];

  ctxelem:
    [ [ x = ident; ":"; t = term -> (x, t, LAst.LPAny) 
      | "#"; y = ident -> (LCst.StrId "", LCst.LTermList(LCst.LCtxVar(y)), LAst.LPAny)
      | y = ident -> (LCst.StrId "", LCst.LTermList(LCst.LCtxVar(y)), LAst.LPAny)
      (* | c = context -> ("", LCst.LTermList($c$)) *)
      | "@" -> (LCst.StrId "", LCst.LTermList(LCst.LCurctx), LAst.LPAny)
      | x = ident; ":"; "#"; y = ident -> (x, LCst.LTermList(LCst.LCtxVar(y)), LAst.LPAny)
      (* | x = ident; ":"; c = context -> ($str:x$, LCst.LTermList($c$)) *)
    ]];

   varlist:
    [ [ "("; is = LIST1 ident; ":"; t = term; ")" -> List.map (fun i -> (i,t)) is ] ];

  vars:
    [[  x = ident; ":"; t = term -> [(x,t)] 
     |	x = ident; xs = LIST0 ident ->
	  List.map (fun i -> (i, LCst.LAny(0))) (x::xs)
     |  xs = LIST1 varlist ->
	  let xs' = List.flatten xs in
 	    List.map (fun (i,t) -> (i, t)) xs' ]];

  ident:
    [ [ x = LIDENT -> LCst.StrId(x)
      | x = UIDENT -> LCst.StrId(x)
      | `ANTIQUOT("id", x) -> LCst.StrAnt(_loc, "id:"^x)
      | `ANTIQUOT("nid", x) -> LCst.StrAnt(_loc, "nid:"^x)
      ]];

  paramlist:
    [ [ ctx = context -> ctx
      | -> LCst.LCtxAsList([]) ] ];

  constr:
    [ [ name = ident; ":"; tp = term -> (name, tp) ] ];

  constrlist:
    [ [ c = LIST0 constr SEP "|" -> c ] ];

  optdot:
    [ [ "." -> () | -> () ] ];

  logicdef:
    [ [ "Axiom"; name = ident; params = paramlist; ":"; tp = term; optdot ->
         Phrases.PhrLogicMetadef(LCst.str_remove_anti name,
				 None, Some (LCst.LTermInCtx(params, tp)), _loc)
      | "Definition"; name = ident; params = paramlist; ":"; tp = term; ":="; tm = term; optdot ->
         Phrases.PhrLogicMetadef(LCst.str_remove_anti name,
				 Some (LCst.LTermInCtx(params,tm)), Some (LCst.LTermInCtx(params, tp)), _loc)
      | "Definition"; name = ident; ":="; tm = modalterm; optdot ->
         Phrases.PhrLogicMetadef(LCst.str_remove_anti name,
				 Some tm, None, _loc)
      | "Inductive"; name = ident; params = paramlist; ":"; tp = term; ":="; constrs = constrlist; optdot ->
         let name = LCst.str_remove_anti name in
	 let constrs = List.map (fun (s,t) -> (LCst.str_remove_anti s, t)) constrs in
         Phrases.PhrLogicInd(name, params, tp, constrs, _loc)
      | "Notation"; name = ident; params = paramlist; ":="; tm = term; optdot ->
         let name = LCst.str_remove_anti name in
	 Phrases.PhrLogicNotation(name,LCst.LTermInCtx(params,tm),_loc)
      ] ];


END;;

