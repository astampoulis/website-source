open Utils
open Binding
module LAst = Logic_ast
open Logic_cst
module CAst = Comp_ast

type cterm = CSort of CAst.csort
	     | CPi of cvarname * cterm * cterm
	     | CLambda of cvarname * cterm * cterm
	     | CArrow of cterm * cterm
	     | CApp of cterm * cterm
	     | CHolTerm of lmodalterm
	     | CCtxTerm of lctxdesc
	     | CUnitType
	     | CUnitExpr
	     | CVar of aqstring
	     | CSigma of cvarname * cterm * cterm
	     | CSigmaUnit of cterm
	     | CPack of cterm * cvarname * cterm * cterm
	     | CPackUnit of cterm
	     | CUnpack of cterm * cvarname * cvarname * cterm
	     | CHolCase of cterm list * cvarname list * cterm * (cholpattern list * cterm) list
	     | CCtxCase of cterm * cvarname * cterm * (cvarname list * (cvarname * cterm) list * cterm * cterm) list
	     | CProdType of cterm * cterm
	     | CTuple of cterm * cterm
	     | CProj of int * cterm
	     | CRecType of cvarname * cterm * cterm
	     | CFold of cterm * cterm
	     | CUnfold of cterm
	     | CSumType of cterm list
	     | CCtor of int * cterm * cterm
	     | CMatch of cterm (* term *) * (cvarname * cterm) list (* branches *)
	     | CLetRec of (cvarname * cterm * cterm) list * cterm
	     | CLet of cvarname * cterm * cterm

	     | CRefType of cterm
	     | CMkRef of cterm * cterm
	     | CAssign of cterm * cterm
	     | CReadRef of cterm
	     | CLoc of cterm ref * cterm
	     | CSeq of cterm * cterm

	     | CArrayType of cterm
	     | CArrayLit of cterm list * cterm
	     | CMkArray of cterm (* size *) * cterm (* default *) * cterm (* type *)
	     | CArrayGet of cterm * cterm
	     | CArraySet of cterm * cterm * cterm
	     | CArrayLoc of cterm array * cterm (* type *)
	     | CArrayLen of cterm
		 
	     | CIntType
	     | CIntConst of int
	     | CIntOp of CAst.cintop * cterm * cterm
	     | CIntTest of CAst.cinttest * cterm * cterm
		 
	     | CBoolType
	     | CBoolConst of bool
	     | CBoolOp of CAst.cboolop * cterm * cterm
	     | CIfThenElse of cterm * cterm * cterm

	     | CHolHash of cterm
	     | CPrint of cterm
	     | CStringConst of string
	     | CStringType

	     | CStaticDo of cterm
	     | CPrfErase of cterm

	     | CSetContext of lctxdesc * cterm
	     | CNuContext of aqstring * lterm * cterm
	     | CUseMetaContext of cterm

	     | CTypeAscribe of cterm * cterm

	     | CAny of int

	     | CAnt of Camlp4.PreCast.Loc.t * string

and cholpattern =  CHPatNested of ((cvarname * cterm) list * cterm) list
		 | CHPatAnt of Camlp4.PreCast.Loc.t * string

and cvarname = aqstring * CAst.csort
and cunpackctx =  CUNoCtx
		  | CUMetaCtx
		  | CUCtx of lctxdesc

let clammany lams term =
  List.fold_right (fun (str,cur) res -> CLambda(str, cur, res)) lams term

let cpimany pis term =
  List.fold_right (fun (str,cur) res -> CPi(str, cur, res)) pis term

let csigmamany sigs term =
  List.fold_right (fun (str,cur) res -> CSigma(str, cur, res)) sigs term

let cunpackmany term names body = 
  let mkunpack (t,(x,c1),n2,body) =
    match c1 with
	CUNoCtx -> CUnpack(t,x,fst n2,body)
      | CUCtx(ctx) -> CUnpack(CTypeAscribe(t,CSigma( (aqstr "~ctx",CAst.CHol), CHolTerm(LTermInCtx(ctx,LAny(0))), CAny(0))),x,fst n2,body)
      | CUMetaCtx -> CUnpack(CTypeAscribe(t,CSigma( (aqstr "~ctx",CAst.CHol), CUseMetaContext(CHolTerm(LTermInCtx(LCurctx,LAny(0)))), CAny(0))),x,fst n2,body)
  in
  let tempvarname = (aqstr "~pk", CAst.CType), None in
  let tempvar = CVar (aqstr "~pk") in
  let rest, n1, n2 = ExtList.last_two names in
  let body' = mkunpack(tempvar, n1, n2, body) in
  let almost = List.fold_right (fun str res -> mkunpack(tempvar, str, tempvarname, res)) rest body' in
    match almost with
	CUnpack( CTypeAscribe(_, tt), t1, t2, t3 ) -> CUnpack( CTypeAscribe(term,tt), t1, t2, t3)
      | CUnpack(_, t1, t2, t3) -> CUnpack(term, t1, t2, t3)
      | _ -> assert false

let case_sort f1 f2 f3 (_,k) =
  match k with
      CAst.CHol -> f1
    | CAst.CCtx -> f2
    | _ -> f3



(* notations *)

module NotationMap = Map.Make(struct 
                                type t = string * int
				let compare = Pervasives.compare
			      end);;

let comp_notations = ref NotationMap.empty

let cgatherapp e =
  let rec aux e args =
    match e with
	CApp(e',arg) -> aux e' (arg :: args)
      |	_ -> e, args
  in
  aux e []

let is_notation e =

  match cgatherapp e with
      CVar(s), l ->
	let s = str_remove_anti s in
	let arity = List.length l in
	NotationMap.mem (s,arity) !comp_notations
    | _ -> false

let handle_notation apptype defs env e =
  
  match cgatherapp e with
      CVar(s), l ->
	let s = str_remove_anti s in
	let arity = List.length l in
	let converter = NotationMap.find (s,arity) !comp_notations in
	converter apptype defs env l
    | _ -> failwith "nowarn"

let register_notation s arity f =
  comp_notations := NotationMap.add (s,arity) f !comp_notations

let cvar_remove_anti (s,k) = (str_remove_anti s, k)
let holpat_remove_anti pat =
  let pat' = List.fold_left (fun res -> function CHPatNested(l) -> res ++ l | CHPatAnt (_,s) -> failwith ("antiquotation should have been removed by now: " ^ s)) [] pat in
  List.map (function l,t' -> (List.map (function (v,t) -> cvar_remove_anti v, t) l, t')) pat'

(* main conversion *)

let comp_ast_of_cst ?(app_type=false) ?(defs=Dict.empty) ?(env=([],[],[],[],[],[],[])) (e : cterm) =

  let logicast_env (compenv, metaenv, ctxenv, curctx, cursubst, curmetactx, curmetasubst) = 
    { curctx = curctx; cursubst = cursubst ; metabenv = metaenv ; ctxbenv = ctxenv ;
      fenv = List.map fst curctx; benv = [] ; defs = defs }
  in
  let ast_of_modal ((compenv, metaenv, ctxenv, curctx, cursubst, curmetactx, curmetasubst) as env) t =
    ast_of_modal ~env:(logicast_env env) ~app_type:app_type t
  in
  let ast_of_ctxdesc ((compenv, metaenv, ctxenv, curctx, cursubst, curmetactx, curmetasubst) as env) t =
    ast_of_ctxdesc ~env:(logicast_env env) ~app_type:app_type t
  in
  let ast_of_lterm ((compenv, metaenv, ctxenv, curctx, cursubst, curmetactx, curmetasubst) as env) t =
    ast_of_cst ~env:(logicast_env env) ~app_type:app_type t
  in

  let add_compenv elm _ (compenv, metaenv, ctxenv, curctx, cursubst, curmetactx, curmetasubst) =
    (elm :: compenv, metaenv, ctxenv, curctx, cursubst, curmetactx, curmetasubst)
  in
  let add_metaenv elm (t,subst) (compenv, metaenv, ctxenv, curctx, cursubst, curmetactx, curmetasubst) =
    let curctx' = List.map (fun (s,t) -> (s, LAst.MetabindLterm.shift_bound 1 t)) curctx in
    let cursubst' = List.map (LAst.MetabindLterm.shift_bound 1) cursubst in
    let t' = match t with CAst.CHolTerm(t) -> Some t | _ -> None in
    let curmetactx' = curmetactx ++ [ elm , LAst.mk_infer (List.length curmetactx) 0 0 0 0 0 ] in
    let curmetasubst' = curmetasubst ++ [ LModalOmitSubst(LMeta(aqstr elm)) ] in
    (compenv, (elm,t',subst) :: metaenv, ctxenv, curctx', cursubst', curmetactx', curmetasubst')
  in
  let add_ctxenv  elm _ (compenv, metaenv, ctxenv, curctx, cursubst, curmetactx, curmetasubst) =
    let curctx' = List.map (fun (s,t) -> (s, LAst.CtxbindLterm.shift_bound 1 t)) curctx in
    let cursubst' = List.map (LAst.CtxbindLterm.shift_bound 1) cursubst in
    (compenv, metaenv, elm :: ctxenv, curctx', cursubst', curmetactx, curmetasubst)
  in
  let add_env (s,k) t = case_sort add_metaenv add_ctxenv add_compenv (s,k) s (t, None) in
  
  let unknown = CAst.CUnitExpr in (* unknown is used together with add_to_env so that when the type of the modal introduced is not known, the environment can still be updated. also when a computational or contextual binder is being added, and no modal type information needs to be included in the updated environment *)

  let nonefst (s,t) = (None, t) in
  let somefst (s,t) = (Some s, t) in
  let fixid t (name,sort) =
    match t with
	CAst.CHolTerm(_) -> (name, CAst.CHol)
      | CAst.CCtxTerm(_)
      | CAst.CSort(CAst.CCtx) -> (name, CAst.CCtx)
      | _ -> (name,sort)
  in
  let emptyid t = fixid t ("", CAst.CType) in
  let comptomodalid (name, sort) = match sort with CAst.CType -> (name, CAst.CHol) | _ -> (name, sort) in
  let comptoctxid (name, sort)   = match sort with CAst.CType -> (name, CAst.CCtx) | _ -> (name, sort) in
    
  let rec comp_ast_of_cst ((compenv, metaenv, ctxenv, curctx, cursubst, curmetactx, curmetasubst) as env) (e : cterm) = 
    match e with
	CSort(t) -> CAst.CSort(t)
      | CPi(s, t1, t2) ->
 	  let s = cvar_remove_anti s in
	  let t1a = comp_ast_of_cst env t1 in
	  let s = fixid t1a s in
	  let (compenv, metaenv, ctxenv, curctx, cursubst, curmetactx, curmetasubst) as env' = add_env s t1a env in
	  let env'' =
	    match s with
		(name, CAst.CCtx) -> 
		  (let curctx' = [ "id_"^name, LAst.LTermList(LAst.LBCtx(0)) ] in
		   let cursubst' = [ LAst.LVar(LAst.LFVar(0)) ] in
		     (compenv, metaenv, ctxenv, curctx', cursubst', curmetactx, curmetasubst))
	      | _ -> env'
	  in
	    CAst.CPi(somefst s, t1a, comp_ast_of_cst env'' t2)
      | CArrow(t1, t2) ->
	  let t1a = comp_ast_of_cst env t1 in
	  let id = emptyid t1a in
	  let env' = add_env id t1a env in
	    CAst.CPi(nonefst id, t1a, comp_ast_of_cst env' t2)
      | CLambda(s, t1, t2) ->
  	  let s = cvar_remove_anti s in
	  let t1a = comp_ast_of_cst env t1 in
	  let s = fixid t1a s in
	  let (compenv, metaenv, ctxenv, curctx, cursubst, curmetactx, curmetasubst) as env' = add_env s t1a env in
	  let env'' =
	    match s with
		(name, CAst.CCtx) -> 
		  (let curctx' = [ ("id_"^name, LAst.LTermList(LAst.LBCtx(0))) ] in
		   let cursubst' = [ LAst.LVar(LAst.LFVar(0)) ] in
		     (compenv, metaenv, ctxenv, curctx', cursubst', curmetactx, curmetasubst))
	      | _ -> env'
	  in
	    CAst.CLambda(somefst s, t1a, comp_ast_of_cst env'' t2)
      | _ when is_notation e ->
 	  handle_notation app_type defs env e
      | CApp(t1, t2) ->
	  CAst.CApp(comp_ast_of_cst env t1, comp_ast_of_cst env t2)
      | CHolTerm(t) ->
	  CAst.CHolTerm(ast_of_modal env t)
      | CCtxTerm(t) ->
	  let ctx, _ = ast_of_ctxdesc env t in
	  CAst.CCtxTerm(ctx)
      | CUnitType -> CAst.CUnitType
      | CUnitExpr -> CAst.CUnitExpr
      | CVar(s) ->
 	  let s = str_remove_anti s in
	  begin
	    try
	      (let i = ExtList.findindex ((=) s) compenv in CAst.CBVar(i))
	    with Not_found ->
	      CAst.CNVar(s)
	  end
      | CSigma(s,t1,t2) ->
	  let s = cvar_remove_anti s in
	  let t1a = comp_ast_of_cst env t1 in
	  let s = fixid t1a s in
	  let env' = add_env s t1a env in
	    CAst.CSigma(somefst s, t1a, comp_ast_of_cst env' t2)
      | CSigmaUnit(t1) ->
	  let t1a = comp_ast_of_cst env t1 in
	  let id = emptyid t1a in
	    CAst.CSigma(nonefst id, t1a, CAst.CUnitType)
      | CPack(t1,s1,t2ret,t2) ->
	  let t1a = comp_ast_of_cst env t1 in
	  let s1 = fixid t1a (cvar_remove_anti s1) in
	  let env' = add_env s1 t1a env in
	    CAst.CPack(t1a, somefst s1, comp_ast_of_cst env' t2ret, comp_ast_of_cst env t2)
      | CPackUnit(t1) ->
	  let t1a = comp_ast_of_cst env t1 in
	  let id = emptyid t1a in
	    CAst.CPack(t1a, nonefst id, CAst.CUnitType, CAst.CUnitExpr)
      | CUnpack(t1,s1,s2,e) ->
	  let s1 = cvar_remove_anti s1 in
	  let s2 = cvar_remove_anti s2 in
	  (* TODO: hack -- since usually we're unpacking modals *)
	  let s1 = comptomodalid s1 in
	  let env', t1 =
	    match s1, t1 with
	      | (_, CAst.CHol), CTypeAscribe(t1, CSigma(s,CHolTerm(LTermInCtx(ctx,_)), _)) when cvar_remove_anti s = ("~ctx", CAst.CHol) ->
		let t1ta = comp_ast_of_cst env (CHolTerm(LTermInCtx(ctx,LAny(0)))) in
		add_env s1 t1ta env, t1
	      | (_, CAst.CHol), CTypeAscribe(t1, CSigma(s,CUseMetaContext(CHolTerm(LTermInCtx(LCurctx,_))), _)) when cvar_remove_anti s = ("~ctx", CAst.CHol) ->
		let (s1, _) = s1 in
		add_metaenv s1 (unknown, Some curmetasubst) env, t1
	      | (_, CAst.CHol), _ ->
		let t1ta = comp_ast_of_cst env (CHolTerm(LTermInCtx(LCurctx,LAny(0)))) in
		add_env s1 t1ta env, t1
	      | _ -> add_env s1 unknown env, t1
	  in
	  let env'' = add_env s2 unknown env'  in
	    CAst.CUnpack(comp_ast_of_cst env t1, somefst s1, somefst s2, comp_ast_of_cst env'' e)
      | CHolCase(t1,vs,t2,branches) ->
	  let vs = List.map (compose comptomodalid cvar_remove_anti) vs in
	  let t1as = List.map (comp_ast_of_cst env) t1 in
	  let scrutinee_var t tast = 
	    match tast with
	        CAst.CHolTerm(LAst.LTermInCtx(_, LAst.LModal(LAst.LBMeta(i), _) ))
	      | CAst.CHolTerm(LAst.LBMeta(i)) ->
		(match t with
		    CHolTerm(LTermInCtx(_, LModalOmitSubst(LMeta(s))))
		  | CHolTerm(LTermInCtx(_, LVar(s)))
		  | CHolTerm(LMeta(s)) -> Some s
		  | _ -> None)
	      | _ -> None
	  in
	  let replace_scrutinee scrutinee metas ((compenv,metaenv,ctxenv,curctx,cursubst,curmetactx,curmetasubst) as env) =
	    match scrutinee with
		Some scrutinee ->
		  (try
		     let curmetasubst = ExtList.take (List.length curmetasubst - List.length metas) curmetasubst in
		     let curmetactx = ExtList.take (List.length curmetactx - List.length metas) curmetactx in
		     let (prev, _, tl), _ = ExtList.find_partition_index ((=) (LModalOmitSubst(LMeta(scrutinee)))) curmetasubst in
		     let metaterms = List.map (fun elm -> LModalOmitSubst(LMeta(aqstr elm))) metas in
		     let curmetasubst' = prev ++ metaterms ++ tl in

		     let (prev, _, tl), _ = ExtList.find_partition_index (fun (s,_) -> s = str_remove_anti scrutinee) curmetactx in
		     let prevn = List.length prev in
		     let names = metas ++ (List.map fst tl) in
		     let curmetactx' = prev ++ (ExtList.mapi (fun i name -> name, LAst.mk_infer (prevn+i) 0 0 0 0 0) names) in
		     (compenv, metaenv, ctxenv, curctx, cursubst, curmetactx', curmetasubst')
		   with ExtList.NotFoundPartition -> env)
	      | None -> env
	  in
	  let patconv scrutinee (metas, pat) env = 
	    let env', metas' = List.fold_left
	      (fun (env, metas') (var, t) ->
		let var = comptomodalid var in
		let ta = comp_ast_of_cst env t in
		let env' = add_env var ta env in
		let metas'' = (somefst var, ta) :: metas' in
		env', metas'')
	      (env, []) metas in
	    let metas' = List.rev metas' in
	    let env'' = replace_scrutinee scrutinee (List.map (fun ((s,_),_) -> s) metas) env' in
	      ((metas', comp_ast_of_cst env' pat), env'')
	  in
	  let branchconv (pats, e1) =
	    let pats = holpat_remove_anti pats in
	    let env', pats', _ =
	      List.fold_left
		(fun (env, pats', i) pat ->
		  let scrutinee = scrutinee_var (List.nth t1 i) (List.nth t1as i) in
		  let pat', env' = patconv scrutinee pat env in
		  (env', pat' :: pats', i+1))
		(env, [], 0) pats in
	    let pats' = List.rev pats' in
	      (pats', comp_ast_of_cst env' e1)
	  in
	  let vs', env' = List.map somefst vs, List.fold_left (fun x (y1,y2) -> add_env y1 y2 x) env (List.combine vs t1as) in
	    CAst.CHolCase(t1as, vs', comp_ast_of_cst env' t2, List.map branchconv branches)

      | CCtxCase(t1,v,t2,branches) ->
	  let v = cvar_remove_anti v in
	  let v = comptoctxid v in
	  let branchconv (ctxvs, metas, t1, e1) =
	    let ctxvs = List.map cvar_remove_anti ctxvs in
	    let metas = List.map (fun (s,t) -> cvar_remove_anti s, t) metas in
	    let ctxvs = List.map comptoctxid ctxvs in
	    let env' = List.fold_left (fun env var -> add_env var unknown env) env ctxvs in
	    let env', metas' = List.fold_left (fun (env, metas') (var, t) ->
						 let var = comptomodalid var in
						 let ta = comp_ast_of_cst env t in
						 let env' = add_env var ta env in
						 let metas'' = (somefst var, ta) :: metas' in
						   env', metas'') (env', []) metas in
	    let metas' = List.rev metas' in
	      (List.map somefst ctxvs, metas', comp_ast_of_cst env' t1, comp_ast_of_cst env' e1)
	  in
	  let env' = add_env v unknown env in
	    CAst.CCtxCase(comp_ast_of_cst env t1, somefst v, comp_ast_of_cst env' t2, List.map branchconv branches)
	      
      | CProdType(t1,t2) ->
	  CAst.CProdType(comp_ast_of_cst env t1, comp_ast_of_cst env t2)
      | CTuple(t1,t2) ->
	  CAst.CTuple(comp_ast_of_cst env t1, comp_ast_of_cst env t2)
      | CProj(i,t) ->
	  CAst.CProj(i, comp_ast_of_cst env t)
      | CRecType(v, t1, t2) ->
	  let v = cvar_remove_anti v in
	  let env' = add_env v unknown env in
	    CAst.CRecType(somefst v, comp_ast_of_cst env t1, comp_ast_of_cst env' t2, ref None)
      | CFold(t1, t2) ->
	  CAst.CFold(comp_ast_of_cst env t1, comp_ast_of_cst env t2)
      | CUnfold(t1) ->
	  CAst.CUnfold(comp_ast_of_cst env t1)
      | CSumType(branches) ->
	  CAst.CSumType(List.map (comp_ast_of_cst env) branches, ref None)
      | CCtor(i,t,p) ->
	  CAst.CCtor(i, comp_ast_of_cst env t, comp_ast_of_cst env p)
      | CMatch(e,branches) ->
	  let branchconv (s,b) = let s = cvar_remove_anti s in let env' = add_env s unknown env in (somefst s, comp_ast_of_cst env' b) in
	  CAst.CMatch(comp_ast_of_cst env e, List.map branchconv branches)
      | CLetRec(defs,e) ->
	  let env' = List.fold_left (fun env (s,_,_) -> add_env (cvar_remove_anti s) unknown env) env defs in
	  CAst.CLetRec(List.map (fun (s,a,b) -> (somefst (cvar_remove_anti s), comp_ast_of_cst env a, comp_ast_of_cst env' b)) defs, comp_ast_of_cst env' e)
      | CLet(v,d,e) ->
	  let v = cvar_remove_anti v in
	  let d' = comp_ast_of_cst env d in
	  let v = fixid d' v in
	  let env' = add_env v unknown env in
	    CAst.CLet(somefst v, d', comp_ast_of_cst env' e)

      | CRefType(t) ->
	  CAst.CRefType(comp_ast_of_cst env t)
      | CMkRef(t1,t2) ->
	  CAst.CMkRef(comp_ast_of_cst env t1, comp_ast_of_cst env t2)
      | CReadRef(t) ->
	  CAst.CReadRef(comp_ast_of_cst env t)
      | CAssign(t1,t2) ->
	  CAst.CAssign(comp_ast_of_cst env t1, comp_ast_of_cst env t2)
      | CLoc(_,_) ->
	  failwith "loc shouldn't exist at concrete syntax!"
	  (* CAst.CLoc(ref (comp_ast_of_cst env !l)) *)
      | CSeq(t1,t2) ->
	  CAst.CSeq(comp_ast_of_cst env t1, comp_ast_of_cst env t2)

      | CIntType -> CAst.CIntType
      | CIntConst(i) -> CAst.CIntConst(i)
      | CIntOp(o,t1,t2) -> CAst.CIntOp(o,comp_ast_of_cst env t1,comp_ast_of_cst env t2)
      | CIntTest(o,t1,t2) -> CAst.CIntTest(o,comp_ast_of_cst env t1,comp_ast_of_cst env t2)
      | CBoolType -> CAst.CBoolType
      | CBoolConst(b) -> CAst.CBoolConst(b)
      | CBoolOp(o,t1,t2) -> CAst.CBoolOp(o,comp_ast_of_cst env t1,comp_ast_of_cst env t2)
      | CIfThenElse(t1,t2,t3) -> CAst.CIfThenElse(comp_ast_of_cst env t1,comp_ast_of_cst env t2,comp_ast_of_cst env t3)

      | CArrayType(t) -> CAst.CArrayType(comp_ast_of_cst env t)
      | CArrayLit(ts,t) -> CAst.CArrayLit(List.map (comp_ast_of_cst env) ts, comp_ast_of_cst env t)
      | CMkArray(t1,t2,t3) -> CAst.CMkArray(comp_ast_of_cst env t1, comp_ast_of_cst env t2, comp_ast_of_cst env t3)
      | CArrayGet(t1,t2) -> CAst.CArrayGet(comp_ast_of_cst env t1, comp_ast_of_cst env t2)
      | CArraySet(t1,t2,t3) -> CAst.CArraySet(comp_ast_of_cst env t1, comp_ast_of_cst env t2, comp_ast_of_cst env t3)
      | CArrayLoc(_,_) -> failwith "arrayloc shouldn't exist at concrete syntax!"
      | CArrayLen(t) -> CAst.CArrayLen(comp_ast_of_cst env t)

      | CHolHash(t) -> CAst.CHolHash(comp_ast_of_cst env t)
      | CPrint(t) -> CAst.CPrint(comp_ast_of_cst env t)
      | CStringConst(s) -> CAst.CStringConst(s)
      | CStringType -> CAst.CStringType

      | CStaticDo(e) -> CAst.CStaticDo(comp_ast_of_cst env e)
      | CPrfErase(e) -> CAst.CPrfErase(comp_ast_of_cst env e)

      | CSetContext(ctx,t) ->
	  (let _, env' = ast_of_ctxdesc env ctx in
	   let env'' = (compenv, metaenv, ctxenv, env'.curctx, env'.cursubst, curmetactx, curmetasubst) in
	     comp_ast_of_cst env'' t)

      | CNuContext(s,t,e) ->
	  (let s = str_remove_anti s in 
	   let ta = ast_of_lterm env t in
	   let curctx' = curctx ++ [ s , ta ] in 
	   let cursubst' = cursubst ++ [ LAst.LVar(LAst.LFVar(List.length curctx)) ]  in
	   let curmetactx' = curmetactx ++ [ s, ta ]  in
	   let curmetasubst' = curmetasubst ++ [ LVar(aqstr s) ] in
	   let env' = (compenv, metaenv, ctxenv, curctx', cursubst', curmetactx', curmetasubst') in
	     comp_ast_of_cst env' e)

      | CUseMetaContext(e) ->
	 (let curctx' = curmetactx in
	  let cursubst' = [] in
	  let metaenv' = [] in
	  let ctxenv' = [] in
	  let curmetactx' = curmetactx in
	  let curmetasubst' = List.map (fun (s,_) -> LVar(aqstr s)) curmetactx' in
	  let env' = (compenv, metaenv', ctxenv', curctx', cursubst', curmetactx', curmetasubst') in
	  comp_ast_of_cst env' e)

      | CTypeAscribe(e,t) ->
	  CAst.CTypeAscribe(comp_ast_of_cst env e, comp_ast_of_cst env t)

      | CAny(_) ->
	CAst.mk_cinfer 0 (List.length compenv) 0 (List.length metaenv) 0 (List.length ctxenv)

      | CAnt(_,s) ->
	failwith ("antiquotation should have been expanded: "^s)
  in
    comp_ast_of_cst env e


let aqcvar (s,k) = (aqstr s, k)

let rec comp_cst_of_ast (e : CAst.cterm) =

  let add_compenv elm (compenv, metaenv, ctxenv) = (elm :: compenv, metaenv, ctxenv) in
  let add_metaenv elm (compenv, metaenv, ctxenv) = (compenv, elm :: metaenv, ctxenv) in
  let add_ctxenv  elm (compenv, metaenv, ctxenv) = (compenv, metaenv, elm :: ctxenv) in
  let new_compenv elm (compenv, metaenv, ctxenv) = let id = get_new_id "x" compenv elm in (id, CAst.CType), (id :: compenv, metaenv, ctxenv) in
  let new_metaenv elm (compenv, metaenv, ctxenv) = let id = get_new_id "X" metaenv elm in (id, CAst.CHol), (compenv, id :: metaenv, ctxenv) in
  let new_ctxenv  elm (compenv, metaenv, ctxenv) = let id = get_new_id "phi" ctxenv elm in (id, CAst.CCtx), (compenv, metaenv, id :: ctxenv) in
  let cst_of_modal (compenv, metaenv, ctxenv) t = cst_of_modal ~env:{ metabenv = List.map (fun s -> (s,None,None)) metaenv; ctxbenv = ctxenv; fenv=[]; benv=[]; curctx=[]; cursubst=[]; defs = Dict.empty } t in
  let cst_of_ctxdesc (compenv, metaenv, ctxenv) t = cst_of_ctxdesc ~env:{ metabenv = List.map (fun s -> (s,None,None)) metaenv; ctxbenv = ctxenv; fenv=[]; benv=[]; curctx=[]; cursubst=[]; defs = Dict.empty } t in
  let new_env (s,k) = CAst.case_sort new_metaenv new_ctxenv new_compenv (s,k) s in
  let add_env (s,k) = CAst.case_sort add_metaenv add_ctxenv add_compenv (s,k) s in
  let has_bound_var ss = CAst.case_sort CAst.MetabindCterm.has_bound_var CAst.CtxbindCterm.has_bound_var CAst.CbindCterm.has_bound_var ss in
  let emptyid (s,k) = ("",k) in

  let rec comp_cst_of_ast ((compenv, metaenv, ctxenv) as env) (e : CAst.cterm) = 
    match e with
	CAst.CSort(t) -> CSort(t)
      | CAst.CPi(ss, t1, t2) when has_bound_var ss 0 t2 ->
	  let s, env' = new_env ss env in
	    CPi(aqcvar s, comp_cst_of_ast env t1, comp_cst_of_ast env' t2)
      | CAst.CPi(ss, t1, t2) ->
	  let ss = emptyid ss in
	  let env' = add_env ss env in
	    CArrow(comp_cst_of_ast env t1, comp_cst_of_ast env' t2)
      | CAst.CLambda(ss, t1, t2) ->
	  let s, env' = new_env ss env in
	    CLambda(aqcvar s, comp_cst_of_ast env t1, comp_cst_of_ast env' t2)
      | CAst.CApp(t1, t2) ->
	  CApp(comp_cst_of_ast env t1, comp_cst_of_ast env t2)
      | CAst.CHolTerm(t) ->
	  CHolTerm(cst_of_modal env t)
      | CAst.CCtxTerm(t) ->
	  CCtxTerm(cst_of_ctxdesc env t)
      | CAst.CUnitType -> CUnitType
      | CAst.CUnitExpr -> CUnitExpr
      | CAst.CFVar(i) -> CVar(aqstr ("f" ^ (string_of_int i)))
      | CAst.CBVar(i) -> CVar(aqstr (try List.nth compenv i with _ -> "b!!" ^ (string_of_int i)))
      | CAst.CNVar(s) -> CVar(aqstr s)
      | CAst.CSigma(ss, t1, t2) when t2 = CAst.CUnitType ->
	  CSigmaUnit(comp_cst_of_ast env t1)
      | CAst.CSigma(ss, t1, t2)  ->
	  let s, env' = new_env ss env in
	    CSigma(aqcvar s, comp_cst_of_ast env t1, comp_cst_of_ast env' t2)
      | CAst.CPack(t1, ss, t2, e) when t2 = CAst.CUnitType && e = CAst.CUnitExpr ->
	  CPackUnit(comp_cst_of_ast env t1)
      | CAst.CPack(t1, ss, t2, e) ->
	  let s, env' = new_env ss env in
	    CPack(comp_cst_of_ast env t1, aqcvar s, comp_cst_of_ast env' t2, comp_cst_of_ast env e)
      | CAst.CUnpack(t1, ss1, ss2, e) ->
	  let s1, env' = new_env ss1 env in
	  let s2, env'' = new_env ss2 env' in
	    CUnpack(comp_cst_of_ast env t1, aqcvar s1, aqcvar s2, comp_cst_of_ast env'' e)
      | CAst.CHolCase(t1, vs, t2, branches) ->

	  (let patconv (metas, t1) env =
	    let env', metas' = List.fold_left (fun (env, metas') (var, t) ->
	  					 let s, env' = new_env var env in
	  					 let metas'' = (aqcvar s, comp_cst_of_ast env t) :: metas' in
	  					   env', metas'') (env, []) metas in
	    let metas' = List.rev metas' in
	      ((metas', comp_cst_of_ast env' t1), env')
	  in
	  let branchconv (pats, e1) =
	    let env', pats' = List.fold_left (fun (env, pats') pat ->
						let pat', env' = patconv pat env in
						  (env', pat' :: pats')) (env, []) pats in
	    let pats' = List.rev pats' in
	      ([CHPatNested(pats')], comp_cst_of_ast env' e1)
	  in
	  let vs', env' = List.fold_left (fun (vsout, env) s -> let snew, env' = new_env s env in
					    (aqcvar snew :: vsout, env')) ([],env) vs in
	  let vs' = List.rev vs' in
	    CHolCase(List.map (comp_cst_of_ast env) t1, vs', comp_cst_of_ast env' t2, List.map branchconv branches))

      | CAst.CCtxCase(t1,ss,t2,branches) ->
	  let branchconv (ctxvs, metas, t1, e1) =
	    let env', ctxss = List.fold_left (fun (env,ctxss) var ->
					 let s, env' = new_env var env in
					   env', (aqcvar s :: ctxss)) (env, []) ctxvs in
	    let env', metas' = List.fold_left (fun (env, metas') (var, t) ->
						 let s, env' = new_env var env in
						   env', ((aqcvar s, comp_cst_of_ast env t) :: metas'))
	                                      (env', []) metas in
	    let metas' = List.rev metas' in
	      (ctxss, metas', comp_cst_of_ast env' t1, comp_cst_of_ast env' e1)
	  in
	  let s, env' = new_env ss env in
	    CCtxCase(comp_cst_of_ast env t1, aqcvar s, comp_cst_of_ast env' t2, List.map branchconv branches)

      | CAst.CProdType(t1,t2) ->
	  CProdType(comp_cst_of_ast env t1, comp_cst_of_ast env t2)
      | CAst.CTuple(t1,t2) ->
	  CTuple(comp_cst_of_ast env t1, comp_cst_of_ast env t2)
      | CAst.CProj(i,t) ->
	  CProj(i, comp_cst_of_ast env t)
      | CAst.CRecType(ss, t1, t2,_) ->
	  let s, env' = new_env ss env in
	    CRecType(aqcvar s, comp_cst_of_ast env t1, comp_cst_of_ast env' t2)
      | CAst.CFold(t1, t2) ->
	  CFold(comp_cst_of_ast env t1, comp_cst_of_ast env t2)
      | CAst.CUnfold(t1) ->
	  CUnfold(comp_cst_of_ast env t1)
      | CAst.CSumType(branches,_) ->
	  CSumType(List.map (comp_cst_of_ast env) branches)
      | CAst.CCtor(i,t,p) ->
	  CCtor(i, comp_cst_of_ast env t, comp_cst_of_ast env p)
      | CAst.CMatch(e,branches) ->
	  let branchconv (vv,eb) = let v, env' = new_env vv env in  (aqcvar v, comp_cst_of_ast env' eb) in
	    CMatch(comp_cst_of_ast env e, List.map branchconv branches)
      | CAst.CLetRec(defs, e) ->
	  let vars, env' = List.fold_left (fun (vars,env) (v,_,_) -> let v, env' = new_env v env in (v :: vars, env')) ([], env) defs in
	  let vars = List.rev vars in
	  let defconv (_,a,b) v = (aqcvar v, comp_cst_of_ast env a, comp_cst_of_ast env' b) in
	    CLetRec(List.map2 defconv defs vars, comp_cst_of_ast env' e)
      | CAst.CLet(vv,d,e) ->
	  let v, env' = new_env vv env in
	    CLet(aqcvar v, comp_cst_of_ast env d, comp_cst_of_ast env' e)

      | CAst.CRefType(t) ->
	  CRefType(comp_cst_of_ast env t)
      | CAst.CMkRef(t1,t2) ->
	  CMkRef(comp_cst_of_ast env t1, comp_cst_of_ast env t2)
      | CAst.CReadRef(t) ->
	  CReadRef(comp_cst_of_ast env t)
      | CAst.CAssign(t1,t2) ->
	  CAssign(comp_cst_of_ast env t1, comp_cst_of_ast env t2)
      | CAst.CLoc(l,t) ->
	  CLoc(ref (comp_cst_of_ast env !l), comp_cst_of_ast env t)
      | CAst.CSeq(t1,t2) ->
	  CSeq(comp_cst_of_ast env t1, comp_cst_of_ast env t2)

      | CAst.CIntType -> CIntType
      | CAst.CIntConst(i) -> CIntConst(i)
      | CAst.CIntOp(o,t1,t2) -> CIntOp(o,comp_cst_of_ast env t1,comp_cst_of_ast env t2)
      | CAst.CIntTest(o,t1,t2) -> CIntTest(o,comp_cst_of_ast env t1,comp_cst_of_ast env t2)
      | CAst.CBoolType -> CBoolType
      | CAst.CBoolConst(b) -> CBoolConst(b)
      | CAst.CBoolOp(o,t1,t2) -> CBoolOp(o,comp_cst_of_ast env t1,comp_cst_of_ast env t2)
      | CAst.CIfThenElse(t1,t2,t3) -> CIfThenElse(comp_cst_of_ast env t1,comp_cst_of_ast env t2,comp_cst_of_ast env t3)

      | CAst.CArrayType(t) -> CArrayType(comp_cst_of_ast env t)
      | CAst.CArrayLit(ts,t) -> CArrayLit(List.map (comp_cst_of_ast env) ts, comp_cst_of_ast env t)
      | CAst.CMkArray(t1,t2,t3) -> CMkArray(comp_cst_of_ast env t1, comp_cst_of_ast env t2, comp_cst_of_ast env t3)
      | CAst.CArrayGet(t1,t2) -> CArrayGet(comp_cst_of_ast env t1, comp_cst_of_ast env t2)
      | CAst.CArraySet(t1,t2,t3) -> CArraySet(comp_cst_of_ast env t1, comp_cst_of_ast env t2, comp_cst_of_ast env t3)
      | CAst.CArrayLoc(l,t) -> CArrayLoc(Array.map (comp_cst_of_ast env) l, comp_cst_of_ast env t)
      | CAst.CArrayLen(t) -> CArrayLen(comp_cst_of_ast env t)

      | CAst.CHolHash(t) -> CHolHash(comp_cst_of_ast env t)
      | CAst.CPrint(t) -> CPrint(comp_cst_of_ast env t)
      | CAst.CStringConst(s) -> CStringConst(s)
      | CAst.CStringType -> CStringType
      | CAst.CStaticDo(e) -> CStaticDo(comp_cst_of_ast env e)
      | CAst.CPrfErase(e) -> CPrfErase(comp_cst_of_ast env e)
	  
      | CAst.CTypeAscribe(e,t) -> CTypeAscribe(comp_cst_of_ast env e, comp_cst_of_ast env t)

      | CAst.CClosure(subst, e) ->
      	  let metasubst, ctxsubst, _ = subst in
      	  let e' =
      	    (CAst.MetabindCtermS.subst_bound_list (List.rev metasubst)
      	       (CAst.CtxbindCtermS.subst_bound_list (List.rev ctxsubst)
      		  e))
      	  in
      	  comp_cst_of_ast env e'
	    
      | CAst.CInfer(l, f) ->
	(match !(CAst.match_cunif l) with
	    Inst(t, _) -> (try comp_cst_of_ast env (f t) with _ -> CAny(0))
	  | Uninst(i,_) -> CAny(i))

  in
    comp_cst_of_ast ([],[],[]) e
