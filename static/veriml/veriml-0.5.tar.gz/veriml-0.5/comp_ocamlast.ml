open Camlp4.PreCast

type typedef_t = Ast.loc -> Ast.str_item
type exprdef_t = Ast.loc -> Ast.str_item
type typ_t = Ast.loc -> Ast.ctyp
type expr_t = Ast.loc -> Ast.expr
type pat_t = Ast.loc -> Ast.patt

let ghost = Ast.loc_of_expr ( let _loc = Loc.ghost in <:expr< () >> )

let removetilde    s = let s = String.copy s in let i = ref 0 in String.iter (fun c -> if c = '~' then s.[!i] <- '_' ; i := !i + 1) s; s
let name_to_tyvar  s = "a" ^ (removetilde s)
let name_to_type   s = "v" ^ (removetilde s)
let name_to_constr s = "V" ^ (removetilde s)
let name_to_expr   s = "v" ^ (removetilde s)
let name_to_evar   s = "v" ^ (removetilde s)

let list_pairing f_empty f_pair =
  let rec aux l =
    match l with
	hd1 :: hd2 :: tl -> aux ((f_pair hd1 hd2) :: tl)
      | [ hd ] -> hd
      | [] -> f_empty
  in
    aux


module Staging = struct
  open Camlp4_import.Parsetree;;
  open Lexing;;
  open Camlp4;;
  open PreCast;;
  open Camlp4.Sig;;
  module Ast2pt = Camlp4.Struct.Camlp4Ast2OCamlAst.Make(Ast);;
  module Lexer = Camlp4.Struct.Lexer.Make(Token);;
  module Printer = Camlp4.Printers.OCaml.Make(Camlp4.PreCast.Syntax);;

  let printer = (new Printer.printer ())#implem

  let stage_expr e =
    let e = e ghost in
    let _loc = ghost in
    let str_item = <:str_item< let __vtemp = $e$ ;; >> in
    (*  to text and back -- takes forever. *)
    
    (*
    let txt = printer Format.str_formatter str_item; Format.flush_str_formatter () in
    let lb = Lexing.from_string txt in
    let phr = !Toploop.parse_toplevel_phrase lb in
    let _ = print_string (">>"^txt^"\n") in
    ignore(Toploop.execute_phrase false Format.std_formatter phr);
    *)
    ignore(Toploop.execute_phrase false Format.std_formatter (Obj.magic (Ast2pt.phrase str_item)));
    Toploop.getvalue "__vtemp"

  let stage_stritem str_item =
    
    (*
    let txt = printer Format.str_formatter str_item; Format.flush_str_formatter () in
    let lb = Lexing.from_string txt in
    let phr = !Toploop.parse_toplevel_phrase lb in
    let _ = print_string (">>"^txt^"\n") in 
    ignore(Toploop.execute_phrase false Format.std_formatter phr)
    *)
    ignore(Toploop.execute_phrase false Format.std_formatter (Obj.magic (Ast2pt.phrase str_item)))

  let stage_string txt =
    let lb = Lexing.from_string txt in
    let phr = !Toploop.parse_toplevel_phrase lb in
    (* let _ = print_string (">>"^txt^"\n") in *)
    ignore(Toploop.execute_phrase false Format.std_formatter phr)

end ;;

let stage_definition stritem = if Config.staging () then Staging.stage_stritem stritem ;;
let stage_expr    = Staging.stage_expr;;


let typedef_rec origname args constrs _loc =

  let constrs = List.map (fun (s,typ) -> let typ = typ _loc in
					 let s   = name_to_constr s in
					 <:ctyp< $uid:s$ of $typ$ >>) constrs in
  let typ  = list_pairing ( <:ctyp< >> ) ( fun cur elm -> Ast.TyOr(_loc, cur, elm) ) constrs in
  let name = name_to_type origname in
  let decl = Ast.TyDcl(_loc, name,
		             List.map (fun s -> let s = name_to_tyvar s in <:ctyp< '$lid:s$ >>) (List.rev args),
		             Ast.TySum(_loc, typ ) , []) in
  let main_part = <:str_item< type $decl$ >> in
  let print = if !Config.interactive && !Config.print_defs then <:str_item< let _ = Comp_defs.print_compdef $str:origname$ >> else <:str_item< >> in
  let _ = stage_definition main_part in
  <:str_item< $main_part$ ;; $print$ >>
      
let typedef_synonym origname args typ _loc =
  let typ = typ _loc in
  let name = name_to_type origname in
  let decl = Ast.TyDcl(_loc, name,
		             List.map (fun s -> let s = name_to_tyvar s in <:ctyp< '$lid:s$ >>) (List.rev args),
		             typ, []) in
  let main_part = <:str_item< type $decl$ >> in
  let print = if !Config.interactive && !Config.print_defs then <:str_item< let _ = Comp_defs.print_compdef $str:origname$ >> else <:str_item< >> in
  let _ = stage_definition main_part in
  <:str_item< $main_part$ ;; $print$ >>

let expr_def origname expr _loc =
  let expr = expr _loc in
  let name = name_to_expr origname in

  let main_part = <:str_item< let $lid:name$ = $expr$ >> in
  let _ = stage_definition main_part in

  let print = if !Config.interactive && !Config.print_defs then <:str_item< let _ = Comp_defs.print_compdef $str:origname$ >> else <:str_item< >> in

  <:str_item< $main_part$ ;; $print$ >>



let typ_int             _loc = <:ctyp< int >>
let typ_bool            _loc = <:ctyp< bool >>
let typ_string          _loc = <:ctyp< string >>
let typ_unit            _loc = <:ctyp< unit >>
let typ_tuple t1 t2     _loc = let t1 = t1 _loc in let t2 = t2 _loc in
                               <:ctyp< ( $t1$ * $t2$ ) >>
let typ_ref   t         _loc = let t = t _loc in
                               <:ctyp< $t$ ref >>
let typ_array t         _loc = let t = t _loc in
                               <:ctyp< $t$ array >>
let typ_const s         _loc = let x = name_to_type s in <:ctyp< $lid:x$ >>
let typ_lib_const s     _loc = <:ctyp< $lid:s$ >>
let typ_var   s         _loc = let x = name_to_tyvar s in <:ctyp< '$lid:x$ >>
let typ_logicterm       _loc = failwith "no logic terms yet"
let typ_ctxterm         _loc = failwith "no context terms yet"
let typ_arrow t1 t2     _loc = let t1 = t1 _loc in let t2 = t2 _loc in
                               <:ctyp< $t1$ -> $t2$ >>
let typ_app hd tl       _loc = let hd = hd _loc in let tl = List.map (fun elm -> elm _loc) tl in
                               List.fold_left (fun cur elm -> <:ctyp< $elm$ $cur$ >>) <:ctyp< $hd$ >> tl


let expr_fun s t        _loc = let t = t _loc in let s = name_to_evar s in <:expr< fun $lid:s$ -> $t$ >>
let expr_app t1 t2      _loc = let t1 = t1 _loc in let t2 = t2 _loc in <:expr< $t1$ $t2$ >>
let expr_var s          _loc = let s = name_to_evar s in <:expr< $lid:s$ >>
let expr_const s        _loc = let s = name_to_expr s in <:expr< $lid:s$ >>
let expr_unit           _loc = <:expr< () >>
let expr_tuple t1 t2    _loc = let t1 = t1 _loc in let t2 = t2 _loc in <:expr< ( $t1$ , $t2$ ) >>
let expr_constr s t     _loc = let t = t _loc in let s = name_to_constr s in <:expr< $uid:s$($t$) >>;;
let expr_match t br     _loc = 
  let t = t _loc in
  let br = List.map (fun b -> b _loc) br in
    <:expr< match $t$ with $list:br$ >>;;
let expr_fst t          _loc = let t = t _loc in <:expr< fst $t$ >>
let expr_snd t          _loc = let t = t _loc in <:expr< snd $t$ >>
let expr_let p d e      _loc = let p = p _loc in let d = d _loc in let e = e _loc in
                               <:expr< let $p$ = $d$ in $e$ >>
let expr_letrec defs e  _loc = let e = e _loc in
  let defs =
    List.map (fun (p,d) -> let p = p _loc in let d = d _loc in
		  <:binding< $p$ = $d$ >>) defs
  in
    <:expr< let rec $list:defs$ in $e$ >>

let expr_mkref e        _loc = let e = e _loc in <:expr< ref $e$ >>
let expr_assign e e'    _loc = let e = e _loc in let e' = e' _loc in <:expr< $e$ := $e'$ >>
let expr_readref e      _loc = let e = e _loc in <:expr< ! $e$ >>
let expr_seq e e'       _loc = let e = e _loc in let e' = e' _loc in <:expr< $e$ ; $e'$ >>

let expr_arraylit l     _loc =
  let l = List.map (fun f -> f _loc) l in
  let l' = list_pairing ( Ast.ExNil(_loc) ) ( fun cur elm -> Ast.ExSem(_loc, cur, elm) ) l in
    Ast.ExArr( _loc, l' );;
let expr_mkarray i e    _loc = let i = i _loc in let e = e _loc in
                               <:expr< Array.make $i$ $e$ >>;;
let expr_arrayget e i   _loc = let i = i _loc in let e = e _loc in
                               <:expr< $e$ . ( $i$ ) >>;;
let expr_arrayset e i e' _loc = let i = i _loc in let e = e _loc in let e' = e' _loc in
                               <:expr< $e$ . ( $i$ ) <- $e'$ >>;;
let expr_arraylen e      _loc = let e = e _loc in <:expr< Array.length $e$ >>

let expr_intconst i     _loc = let i = string_of_int i in <:expr< $int:i$ >>
let expr_int_plus e1 e2 _loc = let e1 = e1 _loc in let e2 = e2 _loc in
                               <:expr< $e1$ + $e2$ >>
let expr_int_minus e1 e2 _loc = let e1 = e1 _loc in let e2 = e2 _loc in
                               <:expr< $e1$ - $e2$ >>
let expr_int_times e1 e2 _loc = let e1 = e1 _loc in let e2 = e2 _loc in
                               <:expr< $e1$ * $e2$ >>
let expr_int_mod e1 e2 _loc = let e1 = e1 _loc in let e2 = e2 _loc in
                               <:expr< $e1$ mod $e2$ >>

let expr_int_lt e1 e2 _loc = let e1 = e1 _loc in let e2 = e2 _loc in
                             <:expr< $e1$ < $e2$ >>
let expr_int_le e1 e2 _loc = let e1 = e1 _loc in let e2 = e2 _loc in
                             <:expr< $e1$ <= $e2$ >>
let expr_int_gt e1 e2 _loc = let e1 = e1 _loc in let e2 = e2 _loc in
                             <:expr< $e1$ > $e2$ >>
let expr_int_ge e1 e2 _loc = let e1 = e1 _loc in let e2 = e2 _loc in
                             <:expr< $e1$ >= $e2$ >>
let expr_int_eq e1 e2 _loc = let e1 = e1 _loc in let e2 = e2 _loc in
                             <:expr< $e1$ = $e2$ >>

let expr_boolconst b  _loc = if b then <:expr< true >> else <:expr< false >>
let expr_bool_and b1 b2 _loc = let b1 = b1 _loc in let b2 = b2 _loc in
                               <:expr< $b1$ && $b2$ >>
let expr_bool_or b1 b2 _loc  = let b1 = b1 _loc in let b2 = b2 _loc in
                               <:expr< $b1$ || $b2$ >>
let expr_if_then_else e1 e2 e3 _loc = let e1 = e1 _loc in let e2 = e2 _loc in let e3 = e3 _loc in
                                      <:expr< if $e1$ then $e2$ else $e3$ >>


let expr_stringconst s _loc = Ast.ExStr(_loc, s)

let expr_many  ts      _loc = let ts = List.map (fun t -> t _loc) ts in list_pairing <:expr< () >> (fun p1 p2 -> <:expr< $p1$, $p2$ >> ) ts
let expr_hash  t       _loc = let t = t _loc in <:expr< Hashtbl.hash_param 100 200 $t$ >>
let expr_fail          _loc = <:expr< failwith "VeriML bottom" >>;;
let expr_type_assign  e tp _loc = let e = e _loc in let tp = tp _loc in <:expr< ( $e$ : $tp$ ) >>
(* let expr_tr_expr       _loc = <:expr< Comp_translate.tr_expr_main >>;; *)


let pat_constr constr x    _loc =
    let constr = name_to_constr constr in
    let x = name_to_evar x in
    <:patt< $uid:constr$($lid:x$) >>
let pat_unused             _loc = <:patt< _ >>
let pat_var x             _loc = let x = name_to_evar x in <:patt< $lid:x$ >>
let pat_tuple t1 t2       _loc = let t1 = t1 _loc in let t2 = t2 _loc in <:patt< ( $t1$ , $t2$ ) >> ;;

let match_case x t        _loc = let x = x _loc in let t = t _loc in <:match_case< $x$ -> $t$ >>;;


let expr_print fmt t _loc =
  let fmt = fmt _loc in
  let t = t _loc in
  <:expr< Format.fprintf !Logic_print.conditional_formatter "%a@." $fmt$ $t$ ;  >>


let fmt_unit  _loc = <:expr< Logic_print.fmt_unit >>;;
let fmt_tuple f1 f2 _loc = let f1 = f1 _loc in let f2 = f2 _loc in
			   <:expr< Logic_print.fmt_tuple $f1$ $f2$ >>;;
let fmt_hol _loc = <:expr< Logic_print.fmt_hol >>;;
let fmt_ctx _loc = <:expr< Logic_print.fmt_ctx >>;;
let fmt_ref t _loc = let t = t _loc in <:expr< Logic_print.fmt_ref $t$ >>;;
let fmt_int   _loc = <:expr< Logic_print.fmt_int >>;;
let fmt_bool  _loc = <:expr< Logic_print.fmt_bool >>;;
let fmt_str   _loc = <:expr< Logic_print.fmt_str >>;;

let stritems l _loc = 
  List.fold_right (fun cd cur -> <:str_item< $cd$ ;; $cur$ >> ) l <:str_item< >>


