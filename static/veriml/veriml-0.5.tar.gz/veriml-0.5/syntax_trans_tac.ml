open Camlp4.PreCast
module CAst = Comp_ast
module CCst = Comp_cst
module LCst = Logic_cst
module CTyp = Comp_typing
module LAst = Logic_ast

module CompGram = Syntax_trans_logic.LogicGram

let ident = Syntax_trans_logic.ident
let modalterm = Syntax_trans_logic.modalterm
let context = Syntax_trans_logic.context
let logicdef = Syntax_trans_logic.logicdef
let lterm    = Syntax_trans_logic.term

let ctxterm = Syntax_trans_comp.ctxterm
let cterm = Syntax_trans_comp.cterm
let cterm_eoi = Syntax_trans_comp.cterm_eoi
let compdef = Syntax_trans_comp.compdef

let ghost = Loc.ghost

EXTEND CompGram
(*  lterm: LAST
  [
    "mult" LEFTA
     [ e1 = lterm ; "*"; e2 = lterm -> <:expr< <:logic< mult/[] ( $e1$ ) ( $e2$ ) >> >> ]
  | "plus" LEFTA
     [ e1 = lterm ; "+"; e2 = lterm -> <:expr< <:logic< plus/[] ( $e1$ ) ( $e2$ ) >> >>
     | e1 = lterm ; "++"; e2 = lterm -> <:expr< <:logic< append/[??] ( $e1$ ) ( $e2$ ) >> >> ]
  | "cons" LEFTA
     [ e1 = lterm ; ".."; e2 = lterm -> <:expr< <:logic< cons/[??] ( $e1$ ) ( $e2$ ) >> >> ]
  | "rest" NONA
     [ "List_" -> <:expr< <:logic< List/[??] >> >>
     | "Nil_" -> <:expr< <:logic< nil/[??] >> >> ] ]; *)

cterm: FIRST
  [  "tactics" LEFTA
      [
	"ReqEqual" ->
	  <:vmlcst< req_iseq #@ @?? @?? @?? >>
      | "Exact"; e = cterm ->
	  <:vmlcst< eq_change #@ ( @ ?? ) ( @ ?? ) ( $e$ ) {{ req_iseq #@ @?? @?? @?? }} >>
      | "Exact"; e = cterm; "by"; e2 = cterm ->
          <:vmlcst< eq_change #@ ( @ ?? ) ( @ ?? ) ( $e$ ) ( $e2$ ) >>
      | "Reflexivity" ->
	  <:vmlcst< eq_refl #@ ( @ ?? ) ( @ ?? ) >>
      | "Intro"; x = ident; "in"; e = cterm ->  
          <:vmlcst< intro #@ ( @ ?? ) ( nu $id:x$ : ?? in @?? ) (nu $id:x$ : ?? in $e$ ) >>
      | "Intro"; x = ident; ":"; l = lterm; "in"; e = cterm ->
          <:vmlcst< intro #@ ( @ $l$ ) ( nu $id:x$ : $l$ in @?? ) (nu $id:x$ : $l$ in $e$ ) >>
      | "Assume"; x = ident; ":"; l = lterm; "in"; e' = cterm ->
          <:vmlcst< assume #@ ( @ ( $l$ ) ) (nu $id:x$ : $l$ in @ ?? ) (nu $id:x$ : $l$ in $e'$ ) >>
      | "Assume"; x = ident; "in"; e' = cterm ->
          <:vmlcst< assume #@ ( @ ?? ) ( nu $id:x$ : ?? in @ ?? ) (nu $id:x$ : ?? in $e'$ ) >>
      | "Auto" ->
	  <:vmlcst< def_auto #@ @?? >>
      | "ChangeGoal"; l = lterm; e = cterm ->
          <:vmlcst< eq_change #@ ( @ $l$ ) ( @ ?? ) ( $e$ ) {{ req_iseq #@ @?? @?? @?? }} >>
      | "ChangeInGoal"; x = ident; "."; l = lterm;
	"from"; a = modalterm; "to"; b = modalterm;
	"by"; pf = cterm ->
        <:vmlcst< change_leibn_goal #@ ( @ ?? ) ( @ ?? )
	  ( nu $id:x$ : ?? in @ $l$ ) ( $mt:b$ ) ( $mt:a$ )
	  ( $pf$ ) {{ req_iseq #@ @?? @?? @?? }} {{ req_iseq #@ @?? @?? @?? }} >>
      |	"NatInduction"; "for"; x = ident; "."; l = lterm;
	"base"; "case"; "by"; b = cterm;
	"inductive"; "case"; "by"; c = cterm ->
        <:vmlcst< nat_induction #@ ( nu $id:x$ : Nat in @ $l$ ) ( $b$ ) ( $c$ )
	               {{ req_iseq #@ ( @ ?? ) ( @ ?? )  ( @ ?? ) }}
	               {{ req_iseq #@ ( @ ?? ) ( @ ?? )  ( @ ?? ) }}
	               {{ req_iseq #@ ( @ ?? ) ( @ ?? )  ( @ ?? ) }} >>
      |	"NatInduction";
	"base"; "case"; "by"; b = cterm;
	"inductive"; "case"; "by"; c = cterm ->
        <:vmlcst< nat_induction #@ ( [ @ , x : Nat]. ?? )  
	               ( $b$ ) ( $c$ ) 
	               {{ req_iseq #@ ( @ ?? ) ( @ ?? )  ( @ ?? ) }} 
	               {{ req_iseq #@ ( @ ?? ) ( @ ?? )  ( @ ?? ) }} 
	               {{ req_iseq #@ ( @ ?? ) ( @ ?? )  ( @ ?? ) }} >>
      | "Trivial" -> 
        <:vmlcst< eq_change #@ ( @ ?? ) ( @ ?? ) <| @trueIntro |> {{ req_iseq #@ @?? @?? @?? }} >>
      | "Instantiate"; pf = cterm; "with"; m = modalterm ->
        <:vmlcst< instantiate #@ ( @ ?? ) ( [ @ , x : ?? ].?? ) ( $mt:m$ ) ( $pf$ ) >>
      | "Cut"; x = ident; ":"; l = lterm; "by"; e = cterm; "for"; e2 = SELF ->
        <:vmlcst< cutpf #@ ( @ ?? ) ( @ $l$ ) ( nu $id:x$ : $l$ in $e2$ ) ( $e$ ) >>
      | "Apply"; e = cterm; "by"; e' = cterm ->
        <:vmlcst< apply #@ ( @ ?? ) ( @ ?? ) ( $e$ ) ( $e'$ ) >>
      | "Temporary"; "Rewriter"; r = cterm; "in"; e = cterm ->
        <:vmlcst< (global_rewriter_add_top ( $r$ ) ) ; 
 	            ( let res = $e$ in ( global_rewriter_remove_top unit ) ; res ) >>
      | "Rewrite"; r = cterm; "in"; e = cterm ->
        <:vmlcst< cutpf #@ ( @ ?? ) ( @ ?? ) ( nu tmprewr : ?? in $e$ ) ( tac_rewrite_left #@ @?? $r$ ) >>
      ]
  ];
END;;

