open Utils
open Logic_ast

exception LTermsNotEqual

let lbvar i = LVar (LBVar i)
let lfvar i = LVar (LFVar i)

exception MetaAxiom
let get_metadef_term name dict = match ExtDict.getsnd name dict with None -> raise MetaAxiom | Some mt -> mt
let get_metadef_type name dict = ExtDict.getfst name dict
let get_metadef_isaxiom name dict = match ExtDict.getsnd name dict with None -> true | Some mt -> false
  

let ctx_to_fenv ctx =
  List.map (fun (_,hd,_,pol) -> hd, pol) (List.rev ctx)

let demote_polarities   f fenv   = List.map (fun (hd,pol) -> (hd,f pol)) fenv
let demote_polarities_pos fenv   = demote_polarities (function LPPos -> LPStrictPos | LPStrictPos -> LPNone | p -> p) fenv
let demote_polarities_fully fenv = demote_polarities (function LPAny -> LPAny | _ -> LPNone) fenv


(* invariant that needs to be maintained: all terms should have flattened contexts! *)
    
let whnf (defenv : lterm_defenv) =
  let rec whnf e =
    match e with
(*
	LApp(e1, t, e2) -> LApp(whnf e1, t, e2)
      | LModal(LTermInCtx(_,_) as modal, subst) -> whnf (modal_apply_subst modal subst)
*)
      | LInfer(l,f) -> (match !(match_lunif l) with Inst(t,_) -> whnf ((lunif_function_full l f) t) | _ -> e)
      | e -> e
  in
    whnf
	     
let fullnf_term (defenv : lterm_defenv) t =
  lterm_map
    ~llambda:(fun s t1 t2 rt1 rt2 -> LLambda(None, rt1, rt2))
    ~lpi:(fun s k t1 t2 rk rt1 rt2 -> LPi(None, rk, rt1, rt2))
    ~lterminctx:(fun ctx lt rctx rlt ->
		   LTermInCtx(rctx, whnf defenv rlt))
    ~lctxelem:(fun s t sort pos rt rsort -> [(None, whnf defenv rt, option_do (whnf defenv) rsort, pos)])
    t

let fullnf_modal (defenv : lterm_defenv) mt =
  nowarn let LModal(mt,_) = fullnf_term defenv (LModal(mt,[])) in
    mt
      
let fullnf_ctx (defenv : lterm_defenv) ctx = 
  nowarn let LTermList(ctx) = fullnf_term defenv (LTermList(ctx)) in
    ctx

let lterm_unified (t : lterm * lterm * lterm) = ()

let equal_checks (defenv : lterm_defenv) =
  let rec aux n e1 e2 =
    let e1', e2' = whnf defenv e1, whnf defenv e2 in
    match e1', e2' with
	LSort(s1), LSort(s2) -> s1 = s2
      | LVar(v1), LVar(v2) when v1 = v2 -> true
      | LLambda(_, a1, b1), LLambda(_, a2, b2) -> aux n a1 a2 && aux (n+1) (BindLterm.open_up n b1) (BindLterm.open_up n b2)
      | LPi(_, k1, a1, b1), LPi(_, k2, a2, b2) -> aux n k1 k2 && aux n a1 a2 && aux (n+1) (BindLterm.open_up n b1) (BindLterm.open_up n b2)
      | LApp(a1,t1,b1), LApp(a2,t2,b2) when aux n a1 a2 && aux n b1 b2 (* && optaux n t1 t2 *) -> true
      | LEq(t1,a1,b1), LEq(t2,a2,b2) when aux n a1 a2 && aux n b1 b2 (* && optaux n t1 t2 *) -> true
      | LModal(m1,s1), LModal(m2,s2) -> modalaux n m1 m2 && (* changed 8/31/2010 *) ExtList.min_for_all2 (aux n) s1 s2
      | LTermList(l1), LTermList(l2) -> ctxdescaux l1 l2
      | LInfer(l1,f1), LInfer(l2,f2) when (match_lunif l1) == (match_lunif l2) ->
	  true
      | LInfer(l1,f1), LInfer(l2,f2) ->
	  (let l1 = match_lunif l1 in
	   let l2 = match_lunif l2 in
	     (* lunifvar_type_unify (aux n) l1 f1 l2 f2; *)
	     match !l1, !l2 with
	       Inst(t1,otyp1), _ -> aux n ((lunif_function f1) t1) e2'
	     | _, Inst(t2,otyp2) -> aux n e1' ((lunif_function f2) t2)
	     | (Uninst(_,otyp1)) , (Uninst(_,otyp2)) ->
	         lterm_unified (LInfer(l1,f1), LInfer(l2,f2), LInfer(l2,f2));
		 l1 := Inst(LInfer(l2,f2),otyp2); true)
      | LInfer(l,f), e
      | e, LInfer(l,f) ->
	   (match !l with
	       Inst(t,_) -> aux n ((lunif_function f) t) e
	     | Uninst(i,otyp) ->
		 (let e = whnf defenv e in
		  let finv = composemany (snd (lunif_gather_funcs l f)) in
		  lterm_unified (LInfer(l,f), e, finv e);
		  l := Inst(finv e, otyp);
		  aux n e1' e2'
		  (* (try aux n e1' e2' *)
		  (*  with _ -> failwith "can't unify") *)
		 ))
      | e1', e2' -> false
(*  and optaux n t1 t2 =
    match t1, t2 with
	Some t1, Some t2 -> aux n t1 t2 
      | _ -> true *)
  and modalaux n e1 e2 =
      match e1, e2 with
	  LFMeta(i1), LFMeta(i2) -> i1 = i2
	| LBMeta(i1), LBMeta(i2) -> i1 = i2
	| LNMeta(s1), LNMeta(s2) when s1 = s2 -> true
(*
	| LNMeta(s1), e2 when not (get_metadef_isaxiom s1 defenv) -> modalaux n (get_metadef_term s1 defenv) e2
	| e1, LNMeta(s2) when not (get_metadef_isaxiom s2 defenv) -> modalaux n e1 (get_metadef_term s2 defenv)
*)

	| LTermInCtx(ct1,t1), LTermInCtx(ct2,t2) when List.length ct1 = List.length ct2 ->
	    let n = List.length ct1 in
	    ctxdescaux (LCtxAsList(ct1)) (LCtxAsList(ct2)) && aux n t1 t2
	| LTermInCtx(ct1,LModal(t1,s1)), t2 when modalaux (max n (List.length ct1)) t1 t2 && ExtList.is_prefix s1 (freelist (List.length ct1)) -> true
	| t2, LTermInCtx(ct1,LModal(t1,s1)) when modalaux (max n (List.length ct1)) t1 t2 && ExtList.is_prefix s1 (freelist (List.length ct1)) -> true
	| _, _ -> false
  and ctxdescaux c1 c2 =
    match c1, c2 with
	LFCtx(i1), LFCtx(i2) -> i1 = i2
      | LBCtx(i1), LBCtx(i2) -> i1 = i2
      | LCtxAsList(l1), LCtxAsList(l2) when (List.length l1) = (List.length l2) ->
	    ExtList.foldindex (fun i ((_,a,_,_),(_,b,_,_)) res -> res && (aux i a b)) true (List.combine l1 l2)
      | _, _ -> false
    
  in
    (aux, modalaux, ctxdescaux);;

let lterm_equal d n e1 e2  = let (f,_,_) = equal_checks d in f n e1 e2
let lmodal_equal d n e1 e2 = let (_,f,_) = equal_checks d in f n e1 e2
let lctxdesc_equal d e1 e2 = let (_,_,f) = equal_checks d in f e1 e2

