(* Temporary workaround to create notations for commonly-needed
   functions (e.g. rewriters for inductive folds). In the future
   some meta-n-variable support should take care of this. *)

open Utils
open Logic_cst
open Comp_cst

let ghost = Syntax_trans_tac.ghost
let gatherapp = Logic_ind.gatherapp
let gatherpi t =
  let rec aux resargs t =
    match t with
	Logic_ast.LPi(s, _, _, t2) -> aux (s :: resargs) t2
      | _ -> List.rev resargs, t
  in
    aux [] t

let get_metadef_arity defs s = match ExtDict.getfst s defs with Logic_ast.LTermInCtx(ctx, _) -> List.length ctx | _ -> failwith "metadef is not a term in context"
let anyhol = CHolTerm(LTermInCtx(LCurctx, LAny(0)))

let make_pattern patvars s tp =
  nowarn let Logic_ast.LTermInCtx(ctx, body) = tp in

  (* does each argument show up in the type or not? *)
  let patvars = ExtList.mapi (fun i s -> Logic_ast.BindLterm.has_free_var i body, s) patvars in

  let typvars = List.map (fun (_,s) -> (aqstr s,CAst.CHol), anyhol) (List.filter fst patvars) in
  let typpat = typvars, anyhol in
  
  let mainvars = List.map (fun (_,s) -> (aqstr s,CAst.CHol), anyhol) (List.filter (compose not fst) patvars) in
  let subst = LModal( LMeta(aqstr s), List.map (fun (_,s) -> LModalOmitSubst(LMeta(aqstr s))) patvars ) in
  let mainpat = mainvars, CHolTerm(LTermInCtx(LCurctx, subst)) in

  [ typpat ; mainpat ]




let gen_unfolder app_type defs env args =

  (* pat   := ( t1 : @?? , ... , tn : @?? ). @t *)
  (* subst := t/[t1,...,tn] *)


  match args with
      [ CVar(s) ] when Dict.mem (str_remove_anti s) defs && not(Logic_core.get_metadef_isaxiom (str_remove_anti s) defs) ->
      let s = str_remove_anti s in
      let arity = get_metadef_arity defs s in
      let patvars = List.map (fun i -> "tmpUnfolderVara" ^ (string_of_int i)) (increasing arity) in
      let pat = make_pattern patvars s (Logic_core.get_metadef_type s defs) in
      let subst = LModal( LMeta(aqstr s), List.map (fun s -> LModalOmitSubst(LMeta(aqstr s))) patvars) in

      let cst = <:vmlcst<
	fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>
	holcase @T, @e as t, x return < e' : @t >hol( @x = e' ) with
        $pat$ |->
            < @?? , <| @ (metaunfold $subst$ ) |> >
      | (T : @Set).@T , (t : @T).@t |-> < @t, <| @refl t |> >  >>
      in	  
      comp_ast_of_cst ~app_type:app_type ~defs:defs ~env:([],[],[],[],[],[],[]) cst

    | _ -> failwith ("unfolder notation used with non-definition argument")

let _ = register_notation "Unfolder" 1 gen_unfolder


let gen_pmatch scrutinee scrutinee_name ret patvarnames pat body default =
  
  let pat = [ List.map (fun s -> (aqstr s, CAst.CHol), anyhol) patvarnames, pat ] in
    <:vmlcst< holcase $scrutinee$ as ? $nid:scrutinee_name$ return $ret$ with
	$pat$ |-> $body$
      | ( ? $nid:scrutinee_name$ : @?? ). @ ( ? $nid:scrutinee_name$ ) |-> $default$ >>


let introduce_patvars f varsintro patvars =
  let newly_introduced = varsintro ++ (ExtList.filtermapi (fun i (b,s) -> if not b && f i then Some s else None) patvars) in
  let new_patvars = ExtList.mapi (fun i (b,s) -> b || (f i), s) patvars in
  newly_introduced, new_patvars



let gen_rewriter_aux defs trm =
  
  nowarn let Logic_ast.LTermInCtx(ctx, theorem) = trm in
  let quant, theorem = gatherpi theorem in
  let tp, lhs, rhs = match theorem with Logic_ast.LEq(Some tp, lhs, rhs) -> tp, lhs, rhs | _ -> failwith "using rewriter generation with a theorem that is not suitable" in

  let namecounter = ref 0 in
  let gen_name () = namecounter := !namecounter + 1; ("tmpRewriterVar"^(string_of_int !namecounter)) in

  let ctx = List.map (fun (s,_,_,_) -> match s with Some s -> s | None -> gen_name()) ctx in
  let quant = List.map (fun s -> match s with Some s -> s | None -> gen_name()) quant in

  let cst_of_ast ast = 
    let env =
      { curctx = [] ; cursubst = [] ; benv = List.rev quant ; fenv = ctx ; metabenv = [] ; ctxbenv = [] ; defs = defs }
    in
    Logic_cst.cst_of_ast ~env:env ast
  in

  let patvars = List.map (fun s -> false, s) (ctx ++ quant) in
  let lhs_cst = cst_of_ast lhs in
  let rhs_cst = cst_of_ast rhs in

  let bvar_to_patvarI i = List.length ctx + List.length quant - i - 1 in

  let mainpart body = <:vmlcst< fun recursive : rewriter_t, phi : ctx, T : @Set => $body$ >> in


  let gentypmatch scrutineename ast patvars = 
    
    let varsintro, patvars = introduce_patvars (fun i -> Logic_ast.BindLterm.has_free_var i ast) [] patvars in
    let pattern = cst_of_ast ast in
    let genbody body =
      gen_pmatch <:vmlcst< @ ? $nid:scrutineename$ >> scrutineename <:vmlcst< { e : @T }< e' : @T >hol( @e = e' ) >>
	varsintro (CHolTerm(LTermInCtx(LCurctx, pattern))) <:vmlcst< fun e : @ $pattern$ => $body$ >> <:vmlcst< fun e : @ $nid:scrutineename$ => < @e , <| @refl e |> > >>
    in
    patvars, pattern, genbody

  in


  let rec genmatch scrutineename scrutineename_in_ret scrutineetype ast patvars ret_type ret_expr =

    let head, args = gatherapp ast in
    let _ = match head with Logic_ast.LModal(Logic_ast.LNMeta(s), params) -> () | _ -> failwith "using rewriter generation with a theorem that is not suitable" in
  
    let varsintro, patvars = introduce_patvars (fun i -> Logic_ast.BindLterm.has_free_var i head) [] patvars in
    let pattern = cst_of_ast head in

    let pattern, newvars = 
      List.fold_left
	(fun (pattern, newvars) arg ->
	  match arg with
	      Logic_ast.LVar(Logic_ast.LFVar(i)) -> 
		let pattern' = LApp(pattern, LModalOmitSubst(LMeta(aqstr (snd (List.nth patvars i))))) in
		pattern', newvars
	    | Logic_ast.LVar(Logic_ast.LBVar(i)) -> 
  	        let patvarI = bvar_to_patvarI i in
	        let pattern' = LApp(pattern, LModalOmitSubst(LMeta(aqstr (snd (List.nth patvars patvarI))))) in
		pattern', newvars
	    | _ ->
  	        let newname = gen_name () in 
		let pattern' = LApp(pattern, LModalOmitSubst(LMeta(aqstr newname))) in
		pattern', newvars ++ [ newname ])
	(pattern, []) args
    in

    let rec subst_scrutinee scrutinee where what =
      match where with
	  LApp( t1, t2 ) -> LApp( subst_scrutinee scrutinee t1 what, subst_scrutinee scrutinee t2 what )
	| LModalOmitSubst( LMeta(s) ) when (str_remove_anti s) = scrutinee -> what
	| LModal( m, subst ) -> LModal( m, List.map (fun t -> subst_scrutinee scrutinee t what) subst )
	| t -> t
    in

    (* let ret_type' = subst_scrutinee scrutineename_in_ret ret_type pattern in *)
    let ret_type' = ret_type in
    let ret_expr' = subst_scrutinee scrutineename_in_ret ret_expr pattern in
    let ret_expr  = subst_scrutinee scrutineename_in_ret ret_expr (LModalOmitSubst(LMeta(aqstr scrutineename))) in

    let _, varsintro, patvars, genbody, _, _ = 
      List.fold_left
	(fun (newvar_i, varsintro, patvars, genbody, ret_type, ret_expr) arg ->
	  match arg with
	      Logic_ast.LVar(Logic_ast.LFVar(i)) ->
		                let varsintro', patvars' = introduce_patvars ((=) i) varsintro patvars in
				newvar_i, varsintro', patvars', genbody, ret_type, ret_expr
	    | Logic_ast.LVar(Logic_ast.LBVar(i)) ->
  	                        let patvarI = bvar_to_patvarI i in
		                let varsintro', patvars' = introduce_patvars ((=) patvarI) varsintro patvars in
				newvar_i, varsintro', patvars', genbody, ret_type, ret_expr
	    | _ -> let newname = List.nth newvars newvar_i in
		   let varsintro' = varsintro ++ [ newname ] in
		   let newname' = newname ^ "'" in
		   let newname_prf' = newname ^ "prf" in
		   let newname_u = newname ^ "Unused" in
		   let genbody' body = <:vmlcst< unpack < $nid:newname'$, $nid:newname_prf'$ , $nid:newname_u$ > = recursive #@ @?? ( @ ? $nid:newname$ ) in $body$ >> in
		   let patvars', genbody'', ret_type', ret_expr' = genmatch newname' newname scrutineetype arg patvars ret_type ret_expr in
		   newvar_i+1, varsintro', patvars', compose genbody (compose genbody' genbody''), ret_type', ret_expr')
	(0, varsintro, patvars, (fun x -> x), ret_type', ret_expr')
	args
    in

    let genbody' body =     
      gen_pmatch <:vmlcst< @ ? $nid:scrutineename$ >> scrutineename <:vmlcst< < e' : @ $scrutineetype$ >hol( @ $ret_type$ = e' ) >>
	varsintro (CHolTerm(LTermInCtx(LCurctx, pattern))) (genbody body)
        <:vmlcst< < @ $ret_expr$ , preeval( ReqEqual ) > >>
    in
    patvars, genbody', ret_type', ret_expr'
  in

  let mainbody prf_cst =
    <:vmlcst< < @ $rhs_cst$ , preeval( Cut Hrewriterstemp : $lhs_cst$ = $rhs_cst$ by $prf_cst$ for ReqEqual ) > >>
  in
  let (patvars', scrtype, genbodyT) = gentypmatch "T" tp patvars in
  let (_,        genbodyE, _, _)    = genmatch "e" "e" scrtype lhs patvars' (LModalOmitSubst(LMeta(aqstr "e"))) (LModalOmitSubst(LMeta(aqstr "e"))) in
  ctx, quant, fun prf_cst -> mainpart (genbodyT (genbodyE (mainbody prf_cst)))


let gen_rewriter app_type defs env args =

  (* pat   := ( t1 : @?? , ... , tn : @?? ). @t *)
  (* subst := t/[t1,...,tn] *)

  match args with
    [ CVar(s) ] when Dict.mem (str_remove_anti s) defs ->

      let s = str_remove_anti s in
      let trm = Logic_core.get_metadef_type s defs in
      let ctx, quant, cst_hole = gen_rewriter_aux defs trm in
      let conv_to_var l = List.map (fun s -> LVar(aqstr s)) l in
      let prf = appmany (LModal( LMeta(aqstr s), conv_to_var ctx)) (conv_to_var quant) in
      let cst = cst_hole <:vmlcst< <| @ $prf$ |> >> in
      comp_ast_of_cst ~app_type:app_type ~defs:defs ~env:([],[],[],[],[],[],[]) cst

    | _ -> failwith ("rewriter notation used with non-definition argument")

let _ = register_notation "GenerateRewriter" 1 gen_rewriter




(*

model after:

<<

let rewriter_plus_Z_x_test : rewriter_module_t = 

  fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>
  holcase @T as T return < e' : @T >hol( @e = e' ) with
      (). @Nat |-> 
	(holcase @e as e return < e' : @T >hol( @e = e' ) with
	    ( x' : @?? , y : @?? ). @plus x' y |->
	      (unpack < x'', pfx'' , unused > = recursive #@ @Nat @x' in
	       holcase @x'' as x'' return < e' : @T >hol( @e = e' ) with
		   (). @zero |-> < @y , preeval( Cut H : plus zero y = y by Temporary Rewriter unfolder_plus in ReqEqual for ReqEqual ) >
		 | (x''' : @??).@x''' |-> < @e , preeval( ReqEqual ) > )
	  | ( e : @?? ). @e |-> < @e, preeval( ReqEqual ) > )
    | ( T : @?? ). @T |-> < @e , preeval( ReqEqual ) >

let _ = global_rewriter_add rewriter_plus_Z_x_test

>>;;

<< let rewriter_plus_Z_x_test : rewriter_module_t = 

  fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>
  holcase @T , @e as T, e return < e' : @T >hol( @e = e' ) with
      (). @Nat, ( x' : @Nat , y : @Nat ). @plus x' y |->
	(unpack < x'' , pfx'' , unused > = recursive #@ @Nat @x' in
	 holcase @x'' as x''
	       return < e' : @T >hol( @e = e' )
	     with
		 (). @zero |->
		   < @y , preeval( Cut H : plus zero y = y by Temporary Rewriter unfolder_plus in ReqEqual for ReqEqual ) >
	       | (x''' : @??).@x''' |-> < @e , preeval( ReqEqual ) >)

    | ( T : @Set ). @T, ( e : @T ). @e |-> 
       < @e , preeval( ReqEqual ) >

>>;;


  
let rewriter app_type defs env tm pf condition =

  let body =
    unpack < y, pfy, ~unused > = recursive #@ @?? ... in
    pmatch y ~ t(y) with
	... .... |-> if cond then < @t' , <| @pf/... |> > else <| 
    ...
    
      
  let mainpart =
    fun recursive : rewriter_t , phi : ctx, T : @Set, e : @T =>
    holcase @T, @e as t, x return < e' : @t >hol( @x = e' ) with
	$mainpat$ |-> $body$
      | (T : @Set).@T , (t : @T).@t |-> < @t, <| @refl t |> >
  in
	  
*)


(* model default rewriters for folds:
   << ExtDefinition plusz : [].forall x : nat, forall y : nat, plus zero y = ?? := Intro x : nat in Intro y : nat in (Temporary Rewriter (Unfolder plus) in def_rewr #@ @?? ( @plus zero y ) ) . >>;;
   ok this doesn't work because the return type is only known at runtime.
*)

