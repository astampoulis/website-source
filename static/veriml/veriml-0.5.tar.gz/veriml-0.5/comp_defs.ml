open Utils
open Logic_ast
open Comp_ast

let print_definitions = Logic_defs.print_definitions
let remove_infer_cterm = Comp_typing.remove_infer_cterm

(* global environment *)

include Comp_env

(* typing *)

let do_typing_phase typechecker msg1 msg2 env tm tp kind =
  let tp', tm' = typechecker env msg1 tp tm in
  let kind', tp'' = typechecker env msg2 kind tp' in
  tm', tp'', kind'

let combine_phases chk1 chk2 = fun env msg tp tm -> uncurry (chk2 env msg) (chk1 env msg tp tm)
let (>>>) = combine_phases

let comp_typecheck_phase envref msg tp tm =
  let env = !(fst envref), !(snd envref), [], [], [] in
  ignore (Comp_typing.type_of_cterm_expected env ~expected:(Some (tp,msg)) tm);
  (tp, tm)

let comp_typeinfer_phase envref msg tp tm =
  let env = !(fst envref), !(snd envref), [], [], [] in
  ignore (Comp_typinf.type_of_cterm env ~expected:(Some (tp,msg)) tm);
  (tp, tm)

let comp_removeinfer_phase envref msg tp tm =
  (remove_infer_cterm tp, remove_infer_cterm tm)

let comp_hoist_static_phase envref msg tp tm =
  let tm' = Comp_opteval.comp_hoist_staticdo_and_annotate_prfobj envref tm in
  (tp, tm')

(*
merged together with hoist static for a slight speedup

let comp_annotate_proofobj_phase envref msg tp tm =
  (tp, Comp_opteval.comp_annotate_proofobjects envref tm)
*)

let comp_identity_phase envref msg tp tm =
  (tp, tm)

let comp_print_phase ?name ?opt envref msg tp tm =
  (match opt with
      Some r ->
  	if !r then (
	  (match name with Some name -> Format.printf "Phase: %s\n" name | _ -> ());
	  Comp_print.print_cterm tm
    	)
    | _ -> ());
  (tp, tm)

let comp_fullcheck_phase =
  comp_print_phase ~name:"after syntax" ~opt:Config.print_after_syntax >>>
  comp_typeinfer_phase >>> 
  comp_print_phase ~name:"after type inference1" ~opt:Config.print_after_typeinf1 >>>
  comp_typeinfer_phase >>> comp_removeinfer_phase >>>
  comp_print_phase ~name:"after type inference2" ~opt:Config.print_after_typeinf2 >>>
  comp_hoist_static_phase >>>
  comp_print_phase ~name:"after hoisting" ~opt:Config.print_after_hoist >>>
  comp_typecheck_phase >>> comp_removeinfer_phase >>>
  comp_print_phase ~name:"after final checking" ~opt:Config.print_after_everything


(* eval *)

let evaluator_both envref tm =
  let tm_erased  = Comp_opteval.comp_discard_proofobjects envref tm in
  let res_normal = Comp_eval.eval ~erasure:false !(fst envref) !(snd envref) tm in
  let res_erased = Comp_eval.eval ~erasure:true  !(fst envref) !(snd envref) tm_erased in
  (res_normal, res_erased, false)

let evaluator_normal envref tm =
  let res_normal = Comp_eval.eval ~erasure:false !(fst envref) !(snd envref) tm in
  (res_normal, res_normal, false)

let evaluator_erasure envref tm =
  let tm_erased  = Comp_opteval.comp_discard_proofobjects envref tm in
  let res_erased = Comp_eval.eval ~erasure:true  !(fst envref) !(snd envref) tm_erased in
  (res_erased, res_erased, true)

let evaluator_dummy _ tm =
  (CNVar("MLeval"), CNVar("MLeval"), false)


(* definitions *)

let compdict_add name what dict =
  if name = "_" then dict else ExtDict.addnew name what dict

let comp_definition ?(typechecker=comp_fullcheck_phase) ?(evaluator=evaluator_both) ?(print=true)
                    name tm tp kind =
  let envref = (logic_global_env, comp_global_env) in
  let tm', tp', kind' = do_typing_phase typechecker ("in comp definition for " ^ name ^ " term's type does not match expected one")
                                                    ("in comp definition for " ^ name ^ " term's kind does not match expected one")
						    envref tm tp kind
  in
  let res_tm, res_tm_opt, res_erased = evaluator envref tm' in
  (if print && !print_definitions && name <> "_" then
      (Format.fprintf Format.std_formatter "compdefin %s : %a.@." name Comp_print.pr_cterm tp'));
  comp_global_env := compdict_add name (tp', res_tm, res_tm_opt, res_erased) !comp_global_env;
  (tm', tp') (* return the transformed terms after typechecking *)

let comp_expr_definition ?(typechecker=comp_fullcheck_phase) ?(evaluator=evaluator_both) ?(print=true) name tp_opt tm =
  let tp = match tp_opt with Some tp -> tp | None -> mk_cinfer 0 0 0 0 0 0 in
  comp_definition ~typechecker:typechecker ~evaluator:evaluator ~print:print name tm tp (CSort(CType))

let comp_type_definition ?(typechecker=comp_fullcheck_phase) ?(evaluator=evaluator_both) ?(print=true) name tp_opt tm =
  let tp = match tp_opt with Some tp -> tp | None -> mk_cinfer 0 0 0 0 0 0 in
  comp_definition ~typechecker:typechecker ~evaluator:evaluator ~print:print name tm tp (CSort(CKind))


let comp_logic_definition ?(typechecker=comp_fullcheck_phase) ?(logicchecker=Logic_defs.lmodal_typeinfer_trusted_phase)
                          ?(evaluator=evaluator_normal) ?(print=true) ?(asaxiom=false)
                          name tm modaltp =
  let envref = (logic_global_env, comp_global_env) in
  let tp = CSigma( (None,CHol), CHolTerm(modaltp), CUnitType) in
  let tm', tp', kind' = do_typing_phase typechecker ("in comp definition for " ^ name ^ " term's type does not match expected one")
                                                    ("in comp definition for " ^ name ^ " term's kind does not match expected one")
						    envref tm tp (CSort(CType))
  in
  let res_tm, _, _ = evaluator envref tm' in
  let _ =
    match res_tm with
	_ when asaxiom ->
	  (if print && !print_definitions then
	     Format.fprintf Format.std_formatter "Metadef by eval %s : %a.@." name Logic_print.pr_modal modaltp);
	  Logic_defs.new_logic_metadef ~phase:logicchecker ~print:false name None (Some modaltp) logic_global_env

	    
      | CPack(CHolTerm(modaltm), _, _, _) ->
	(if print && !print_definitions then
	    Format.fprintf Format.std_formatter "Metadef by eval %s : %a.@." name Logic_print.pr_modal modaltp);
  	Logic_defs.new_logic_metadef ~phase:logicchecker ~print:false name (Some modaltm) (Some modaltp) logic_global_env

	  
      | _ -> failwith ("normal form of " ^ name ^ " is not an existential package")
  in
  (tm', tp')


let print_compdef name =
  if name <> "_" then
    (let tp, _, _, _ = ExtDict.find name !comp_global_env in
       Format.fprintf Format.std_formatter "Compdef %s : %a.@." name Comp_print.pr_cterm tp)
