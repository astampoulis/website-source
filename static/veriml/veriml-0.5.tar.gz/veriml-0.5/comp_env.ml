open Utils
open Logic_ast
open Comp_ast

let logic_notations  = Logic_cst.logic_notations
let logic_global_env = Logic_defs.logic_global_env
let comp_global_env : cterm_defenv ref = ref Dict.empty
let dynamic_logic_env : lterm_defenv ref = ref Logic_defs.ltermdefenv_empty


let create_output_directory () =
  if not (Sys.file_exists "_compiled" && Sys.is_directory "_compiled") then
    Unix.mkdir "_compiled" 0o755

let _ = create_output_directory ()

let env_save logicenv logicnot compenv s =
  let f = open_out_bin ("_compiled/" ^ s ^ ".veriml.types") in
    Marshal.to_channel f (logicenv, logicnot, compenv) [ (* Marshal.Closures *) ];
    close_out f

let env_import logicenv logicnotcur compenv s =
  let f = open_in_bin ("_compiled/" ^ s ^ ".veriml.types") in
  let (logic, logicnot, comp) = (Marshal.from_channel f : (Logic_ast.lterm_defenv * Logic_cst.logic_notations_t * Comp_ast.cterm_defenv)) in
  let newlogic = ExtDict.merge logicenv logic in
  let newlogicnot = ExtDict.merge logicnotcur logicnot in
  let newcomp  = ExtDict.merge compenv comp in
    close_in f;
    (newlogic, newlogicnot, newcomp)

let env_logic_import logicenv s =
  let f = open_in_bin ("_compiled/" ^ s ^ ".veriml.types") in
  let (logic, _, _) = (Marshal.from_channel f : (Logic_ast.lterm_defenv * Logic_cst.logic_notations_t * Comp_ast.cterm_defenv)) in
  let newlogic = ExtDict.merge logicenv logic in
    close_in f;
    newlogic

let dynamic_env_reset () = 
  dynamic_logic_env := Logic_defs.ltermdefenv_empty

let logic_global_delete s =
  logic_global_env := Dict.remove s !logic_global_env

let comp_global_reset () =
    comp_global_env := Dict.empty;
    logic_global_env := Dict.empty;
    logic_notations := Dict.empty

let comp_global_delete l =
  comp_global_env := (List.fold_left (fun d elm -> if Dict.mem elm d then Dict.remove elm d else d) !comp_global_env l)

let comp_global_save s = env_save !logic_global_env !logic_notations !comp_global_env s

let comp_global_import s =
  let (logic, logicnot, comp) = env_import (* !logic_global_env !comp_global_env *) Dict.empty Dict.empty Dict.empty s in
  logic_global_env := logic;
  logic_notations := logicnot;
  comp_global_env := comp

  
