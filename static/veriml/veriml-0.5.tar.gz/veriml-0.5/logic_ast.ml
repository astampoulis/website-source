open Utils
open Binding

type 
  lsort =  LType
	  |LSet
	  |LProp
and
  lterm =  LSort of lsort
	  |LVar of lvar
	  |LLambda of string option * lterm * lterm
	  |LPi of string option * lterm (* sort *) * lterm * lterm
	  |LApp of lterm * lterm option * lterm
	  |LEq of lterm option * lterm * lterm
	  |LEqAxiom of string * lterm list

	  (* added for meta variables *)
	  |LModal of lmodalterm * lsubst

	  (* added for term lists (contexts and substitutions) *)
	  |LTermList of lctxdesc

	  |LInfer of lunifvar ref * ((lterm -> lterm) list * (lterm -> lterm) list)
and
  lvar =    LBVar of int  (* bound variables: deBruijn indexes *)
          | LFVar of int  (* free variables: deBruijn levels *)
and
  lmodalterm =   LTermInCtx of lctx * lterm
	       | LFMeta of int
	       | LBMeta of int 
	       | LNMeta of string
and
  lctxdesc =     LFCtx of int
	       | LBCtx of int
	       | LCtxAsList of lctx
and
  lsubst = lterm list
and
  lctx = (string option * lterm * lterm option * lpolarity) list
and
  lunifvar = lterm unifvar
and
  lpolarity = LPNone | LPStrictPos | LPPos | LPAny

let _lunifcount    = ref 0
let _lifinfer      = function LInfer(l,_) -> fun y n -> y l | _ -> fun y n -> n
let _linject  l fl = LInfer(l,fl)
let mk_lunifvar () = mk_unifvar _lunifcount
let match_lunif    = match_unif _lifinfer
(* let lunifvar_type_unify unification = unifvar_type_unify unification _lifinfer (fun l fl -> _linject l ([fl],[id])) _lunifcount *)
let lunif_gather_funcs l (fs, finvs) =
  let rec aux l (fs, finvs) =
    match !l with
	Inst(LInfer(l,(fs',finvs')),_) -> aux l (fs ++ fs', finvs' ++ finvs)
      | _ -> (fs, finvs)
  in
  aux l (fs, finvs)
  
let lunif_function (fs,finvs) = composemany fs
let lunif_function_full l ffinv = composemany (fst (lunif_gather_funcs l ffinv))
let addinvfunction f finv (fs,finvs) = (f :: fs, finvs ++ [finv])

type lterm_env = (lterm * lpolarity) list (* free variables *) * lterm_defenv (* def. environment *) * lmodalterm list (* meta variables *) * unit list (* ctx variables *)
and  lterm_defenv = (lmodalterm (* type *) * lmodalterm option (*term *)) dict


let boundlist ?(start=0) (n : int) = List.map (fun n -> LVar (LBVar (n+start))) (decreasing n)
let freelist  (n : int) = List.map (fun n -> LVar (LFVar n)) (increasing n)


(* Map *)

let rec lterm_map ?(lsort=fun s -> LSort(s))
              ?(lbvar=fun i -> LVar(LBVar i))
	      ?(lfvar=fun i -> LVar(LFVar i))
	      ?(llambda=fun s t1 t2 rt1 rt2 -> LLambda(s, rt1, rt2))
	      ?(lpi=fun s k t1 t2 rk rt1 rt2 -> LPi(s, rk, rt1, rt2))
	      ?(lapp=fun t1 t1t t2 rt1 rt1t rt2 -> LApp(rt1, rt1t, rt2))
	      ?(leq=fun t t1 t2 rt rt1 rt2 -> LEq(rt, rt1, rt2))
	      ?(leqax=fun s l rl -> LEqAxiom(s, rl))
	      ?(lsubstelem=fun t1 rt1 -> [rt1])
	      ?(lfctx=fun i1 -> LFCtx(i1))
	      ?(lbctx=fun i1 -> LBCtx(i1))
	      ?(lfmeta=fun i1 -> LFMeta(i1))
	      ?(lbmeta=fun i1 -> LBMeta(i1))
	      ?(lnmeta=fun s -> LNMeta(s))
	      ?(lctxelem=fun s t1 sort pol rt1 rsort -> [(s,rt1,rsort,pol)])
	      ?(lmodal=fun mt1 t2s rmt1 rt2s -> LModal(rmt1, rt2s))
	      ?(lterminctx=fun ctx lt rctx rlt -> LTermInCtx(rctx, rlt))
	      ?(lctxaslist=fun ctx rctx -> LCtxAsList(rctx))
	      ?(linfer=fun l f rf -> LInfer(l,rf))
    =

  let rec ltrec = function
      LSort(s) -> lsort s
    | LVar(LBVar i) -> lbvar i
    | LVar(LFVar i) -> lfvar i
    | LLambda(s1, t1, t2) -> llambda s1 t1 t2 (ltrec t1) (ltrec t2)
    | LPi(s1, k, t1, t2) -> lpi s1 k t1 t2 (ltrec k) (ltrec t1) (ltrec t2)
    | LApp(t1, t1t, t2) -> lapp t1 t1t t2 (ltrec t1) (option_do ltrec t1t) (ltrec t2)
    | LEq(t, t1, t2) -> leq t t1 t2 (option_do ltrec t) (ltrec t1) (ltrec t2)
    | LEqAxiom(s, l) -> leqax s l (List.map ltrec l)
    | LModal(mt1,t2s) -> lmodal mt1 t2s (modrec mt1) (List.concat (List.map substelemrec t2s))
    | LTermList(ct1) -> LTermList(ltermlist ct1)
    | LInfer(l, f) -> linfer l f (addinvfunction ltrec id f)
  and substelemrec t1 = lsubstelem t1 (ltrec t1)
  and ctxelemrec (s, t1, sort, pol) =
    lctxelem s t1 sort pol (ltrec t1) (option_do ltrec sort)
  and modrec = function
      LFMeta(i) -> lfmeta i
    | LBMeta(i) -> lbmeta i
    | LNMeta(s) -> lnmeta s
    | LTermInCtx(ct1,t1) -> lterminctx ct1 t1 (List.concat (List.map ctxelemrec ct1)) (ltrec t1)
  and ltermlist = function
      LFCtx(i) -> lfctx i
    | LBCtx(i) -> lbctx i
    | LCtxAsList(l) -> lctxaslist l (List.concat (List.map ctxelemrec l))
  in
    ltrec


let lterm_map_envlen
              ?(lsort=fun s -> LSort(s))
              ?(lbvar=fun env i -> LVar(LBVar i))
	      ?(lfvar=fun env i -> LVar(LFVar i))
	      ?(llambda=fun env s t1 t2 rt1 rt2 -> LLambda(s, rt1, rt2))
	      ?(lpi=fun env s k t1 t2 rk rt1 rt2 -> LPi(s, rk, rt1, rt2))
	      ?(lapp=fun env t1 t1t t2 rt1 rt1t rt2 -> LApp(rt1, rt1t, rt2))
	      ?(leq=fun env t t1 t2 rt rt1 rt2 -> LEq(rt, rt1, rt2))
	      ?(leqax=fun s l rl -> LEqAxiom(s, rl))
	      ?(lsubstelem=fun t1 rt1 -> [rt1])
	      ?(lfctx=fun i1 -> LFCtx(i1))
	      ?(lbctx=fun i1 -> LBCtx(i1))
	      ?(lfmeta=fun i1 -> LFMeta(i1))
	      ?(lbmeta=fun i1 -> LBMeta(i1))
	      ?(lnmeta=fun s -> LNMeta(s))
	      ?(lctxelem=fun s t1 sort pol rt1 rsort -> [(s,rt1,rsort,pol)])
	      ?(lmodal=fun env mt1 t2s rmt1 rt2s -> LModal(rmt1, rt2s))
	      ?(lterminctx=fun ctx lt rctx_rlt -> let rctx, rlt = Lazy.force rctx_rlt in LTermInCtx(rctx, rlt))
	      ?(lctxaslist=fun ctx rctx -> LCtxAsList(Lazy.force rctx))
	      ?(linfer=fun env l f rf -> LInfer(l,rf))
    =

  let rec ltrecfull env t =
    let ltrec t = ltrecfull env t in
    let new_bvar (fenv,benv) = (fenv,benv+1) in
    match t with
      LSort(s) -> lsort s
    | LVar(LBVar i) -> lbvar env i
    | LVar(LFVar i) -> lfvar env i
    | LLambda(s1, t1, t2) -> llambda env s1 t1 t2 (ltrec t1) (ltrecfull (new_bvar env) t2)
    | LPi(s1, k, t1, t2) -> lpi env s1 k t1 t2 (ltrec k) (ltrec t1) (ltrecfull (new_bvar env) t2)
    | LApp(t1, t1t, t2) -> lapp env t1 t1t t2 (ltrec t1) (option_do ltrec t1t) (ltrec t2)
    | LEq(t, t1, t2) -> leq env t t1 t2 (option_do ltrec t) (ltrec t1) (ltrec t2)
    | LEqAxiom(s, l) -> leqax s l (List.map ltrec l)
    | LModal(mt1,t2s) -> lmodal env mt1 t2s (modrec mt1) (List.concat (List.map (substelemrec env) t2s))
    | LTermList(ct1) -> LTermList(ltermlist ct1)
    | LInfer(l, f) -> linfer env l f (addinvfunction ltrec id f)
  and substelemrec env t1 = lsubstelem t1 (ltrecfull env t1)
  and ctxelemrec env (s, t1, sort, pol) =
    lctxelem s t1 sort pol (ltrecfull env t1) (option_do (ltrecfull env) sort)
  and ctxrec l =
    let res, fenv = 
      List.fold_left
	(fun (res,fenv) elm ->
	  let res' = ctxelemrec (fenv,0) elm in
	  (res ++ res', fenv + List.length res'))
	([], 0)
	l
    in
    res, (fenv,0)
  and modrec = function
      LFMeta(i) -> lfmeta i
    | LBMeta(i) -> lbmeta i
    | LNMeta(s) -> lnmeta s
    | LTermInCtx(ct1,t1) ->
      lterminctx ct1 t1 (lazy (let rct, env' = ctxrec ct1 in (rct, ltrecfull env' t1)))
  and ltermlist = function
      LFCtx(i) -> lfctx i
    | LBCtx(i) -> lbctx i
    | LCtxAsList(l) -> lctxaslist l (lazy(fst (ctxrec l)))
  in
    ltrecfull


let remove_infer t =
  let fixoptionalarg_aux recurse t =
    match t with 
	None -> None
      | Some (LInfer(l,fl)) ->
	(match !(match_lunif l) with
	     Inst(t,_) -> Some (recurse ((lunif_function_full l fl) t))
	   | _ -> None)
      | Some t -> Some t
  in
  let rec fixoptionalarg t =
    lterm_map ~lapp:(fun _ _ _ rt1 rt1t rt2 -> LApp(rt1, fixoptionalarg_aux fixoptionalarg rt1t, rt2))
              ~leq:(fun _ _ _ rt rt1 rt2 -> LEq(fixoptionalarg_aux fixoptionalarg rt, rt1, rt2))
              ~lctxelem:(fun name _ _ pol rt1 rsort -> [ name, rt1, fixoptionalarg_aux fixoptionalarg rsort , pol ])
      t
  in
      
  let t' = fixoptionalarg t in
  let t'' =
    lterm_map ~linfer:(fun l f rf -> (match !(match_lunif l) with
					  Inst(t,_) -> (lunif_function_full l rf) t
					| _ -> failwith "couldn't infer this variable!")) t'
  in
    t''
      
let remove_infer_lmodal mt = 
  match remove_infer (LModal(mt,[])) with
      LModal(mt,_) -> mt
    | _ -> failwith "remove_infer_lmodal"

let remove_infer_lctxdesc ctx = 
  match remove_infer (LTermList(ctx)) with
    LTermList(ctx) -> ctx
    | _ -> failwith "remove_infer_lctxdesc"


(* Binding *)

(* this can be used to apply a varmap to a list of
   terms, each of which is a binder *)
		
let list_varmap f_varmap fextend start list =
  let rec list_varmap_aux i start (list : 'b list) =
    match list with
	[] -> []
      | hd :: tl -> (f_varmap (fextend start i) hd) :: list_varmap_aux (i+1) start tl
  in
    list_varmap_aux 0 start list

(* this is to be used when the number of binders cannot be
   known beforehand *)
let list_varmap' f_varmap fextend start list =
  let rec list_varmap_aux start (list : 'b list) =
    match list with
	[] -> [], start
      | hd :: tl -> 
	  let hd', s' = f_varmap start hd in
	  let tl', s'' = list_varmap_aux s' tl in
	    (hd' :: tl'), s''
  in
    list_varmap_aux start list

let varmaps fbound ffree =
  let fextend s i = s + i in
  let rec lterm_varmap start (t : lterm) =
    match t with
	LVar (LBVar i) -> fbound start i
      | LVar (LFVar i) -> ffree start i
      | LLambda (s, lt1, lt2)     -> LLambda(s, lterm_varmap start lt1, lterm_varmap (fextend start 1) lt2)
      | LPi (s, k, lt1, lt2)      -> LPi(s, lterm_varmap start k, lterm_varmap start lt1, lterm_varmap (fextend start 1) lt2)
      | LApp (lt1, lt1t, lt2)     -> LApp(lterm_varmap start lt1, optlterm_varmap start lt1t, lterm_varmap start lt2)
      | LEq (lt, lt1, lt2)        -> LEq(optlterm_varmap start lt, lterm_varmap start lt1, lterm_varmap start lt2)
      | LEqAxiom (s, l)           -> LEqAxiom(s, List.map (lterm_varmap start) l)
      | LModal(lt, subst)      -> LModal(modal_varmap start lt, List.map (lterm_varmap start) subst)
      | LTermList(tmlist)      -> LTermList(tmlist_varmap start tmlist)
      | LInfer(l,f)            -> 
	  (match !(match_lunif l) with
	       Inst(t,_) -> lterm_varmap start ((lunif_function_full l f) t)
	     | _ -> LInfer(l, addinvfunction (lterm_varmap start) id f))
      | t -> t
  and optlterm_varmap start (t : lterm option) = 
    match t with
	Some t -> Some (lterm_varmap start t)
      | None   -> None
  and modal_varmap start (t : lmodalterm) = t
  and tmlist_varmap start (t : lctxdesc) = t
  in
    (lterm_varmap, modal_varmap, tmlist_varmap)
                                            
let lterm_varmap fbound ffree   = let (a,_,_) = varmaps fbound ffree in a
let modal_varmap fbound ffree   = let (_,a,_) = varmaps fbound ffree in a
let tmlist_varmap fbound ffree  = let (_,_,a) = varmaps fbound ffree in a

(*
module BindLterm = Binding(struct
			     type tvar = lterm
			     type t = lterm
			     type tenv = int
			     let  bound i = i
			     let  varmap f1 f2 =
			       lterm_map_envlen ~lbvar:(fun (_,benv) i -> f1 benv i)
				                ~lfvar:(fun (_,benv) i -> f2 benv i)
				                ~lterminctx:(fun ctx lt _ -> LTermInCtx(ctx,lt))
				                ~lctxaslist:(fun ctx _ -> LCtxAsList(ctx))
				                ~linfer:(fun _ l _ rf -> match !(match_lunif l) with
						    Inst(t,_) -> (lunif_function rf) t
						  | _ -> LInfer(l, rf)) 
				                (0,0)
			     let  bvar   i = LVar (LBVar i)
			     let  fvar   i = LVar (LFVar i)
			   end)
module BindLtermS = (struct
		       let subst_bound_list = BindLterm.subst_bound_list_given_shift BindLterm.shift_bound
		       let subst_bound      = BindLterm.subst_bound_given_list subst_bound_list
		       let subst_free_list  = BindLterm.subst_free_list_given_shift BindLterm.shift_bound
		     end)
*)


module BindLterm =
  struct

    let rec open_up ?(howmany=1) ?(start=0) envlen t =
      lterm_map_envlen
	~lbvar:(fun (fenv,benv) i ->
	  if (i >= benv + howmany) then failwith "open_up on something with more than one floating bound variable"
	  else if (i >= benv) then LVar(LFVar(fenv + howmany - (i - benv) - 1))
	  else LVar(LBVar(i)))
	~lfvar:(fun (fenv,benv) i ->
	  if (i >= fenv) then failwith "open_up with wrong envlen!"
	  else LVar(LFVar(i)))
	~lterminctx:(fun ctx lt _ -> LTermInCtx(ctx,lt))
	~lctxaslist:(fun ctx _ -> LCtxAsList(ctx))
	~linfer:(fun (_,benv) l f rf ->
	  match !(match_lunif l) with
	    Inst(t,_) -> (lunif_function_full l rf) t
	  | _ -> (let f' =
		    addinvfunction
		      (open_up ~howmany:howmany ~start:benv envlen)
		      (close_down ~howmany:howmany ~start:benv (envlen+howmany))
		      f (* TODO: this is not the updated f *)
		  in
		  LInfer(l, f')))
	(envlen, start)
	t

    and close_down ?(howmany=1) ?(start=0) envlen t =
      lterm_map_envlen
	~lbvar:(fun (_,benv) i ->
	  if (i >= benv) then failwith "close_down on something with floating bound variables"
	  else LVar(LBVar(i)))
	~lfvar:(fun (fenv,benv) i ->
	  if (i >= fenv) then failwith "close_down with wrong envlen!"
	  else if (i >= fenv - howmany) then LVar(LBVar((fenv-i-1) + benv))
	  else LVar(LFVar(i)))
	~lterminctx:(fun ctx lt _ -> LTermInCtx(ctx,lt))
	~lctxaslist:(fun ctx _ -> LCtxAsList(ctx))
	~linfer:(fun (_,benv) l f rf ->
	  match !(match_lunif l) with
	    Inst(t,_) -> (lunif_function_full l rf) t
	  | _ -> (let f' =
		    addinvfunction
		      (close_down ~howmany:howmany ~start:benv envlen)
		      (open_up ~howmany:howmany ~start:benv (envlen-howmany))
		      f
		  in
		  LInfer(l, f')))
	(envlen, start)
	t;;

    let rec shift_bound ?(start=0) add t =
      lterm_map_envlen
	~lbvar:(fun (_,benv) i -> if i >= benv + start then LVar(LBVar(i+add)) else LVar(LBVar(i)))
	~lterminctx:(fun ctx lt _ -> LTermInCtx(ctx,lt))
	~lctxaslist:(fun ctx _ -> LCtxAsList(ctx))
	~linfer:(fun (_,benv) l f rf ->
	  match !(match_lunif l) with
	    Inst(t,_) -> (lunif_function_full l rf) t
	  | _ -> (let f' =
		    addinvfunction
		      (shift_bound ~start:benv add)
		      (shift_bound ~start:benv (-add))
		      f
		  in
		  LInfer(l, f')))
	(0,start)
	t

    exception HasBoundVar
    let has_bound_var which t =
      try
	let _ =
	  lterm_map_envlen
	    ~lbvar:(fun (_,benv) i -> if i = which + benv then raise HasBoundVar else LVar(LBVar(i)))
	    ~lterminctx:(fun ctx lt _ -> LTermInCtx(ctx,lt))
	    ~lctxaslist:(fun ctx _ -> LCtxAsList(ctx))
	    ~linfer:(fun _ l f rf -> 
	      match !(match_lunif l) with
		Inst(t,_) -> (lunif_function_full l rf) t
	      | _ -> LInfer(l,rf))
	    (0,0)
	    t
	in false
      with HasBoundVar -> true

    exception HasFreeVar
    let has_free_var which t =
      try
	let _ =
	  lterm_map_envlen
	    ~lfvar:(fun (_,_) i -> if i = which then raise HasFreeVar else LVar(LFVar(i)))
	    ~lterminctx:(fun ctx lt _ -> LTermInCtx(ctx,lt))
	    ~lctxaslist:(fun ctx _ -> LCtxAsList(ctx))
	    ~linfer:(fun _ l f rf -> 
	      match !(match_lunif l) with
		Inst(t,_) -> (lunif_function_full l rf) t
	      | _ -> LInfer(l,rf))
	    (0,0)
	    t
	in false
      with HasFreeVar -> true

  end;;

module BindLtermS = struct

  let subst_any freemap boundmap metamap startbenv term =
    let lookup_and_shift benv default i map =
      try
	BindLterm.shift_bound benv (IMap.find i map)
      with Not_found -> default
    in
    lterm_map_envlen
      ~lfvar:(fun (_,benv) i -> lookup_and_shift benv (LVar(LFVar(i))) i freemap)
      ~lbvar:(fun (_,benv) i -> 
	if i >= benv then
	  lookup_and_shift benv (LVar(LBVar(i))) (i - benv) boundmap
	else
	  LVar(LBVar(i)))
      ~lmodal:(fun (_,benv) mt1 subst rmt rsubst ->
	match mt1 with
	    LFMeta(i) -> lookup_and_shift benv (LModal(rmt,rsubst)) i metamap
	  | _ -> LModal(rmt,rsubst))
      ~lterminctx:(fun ctx lt _ -> LTermInCtx(ctx,lt))
      ~lctxaslist:(fun ctx _ -> LCtxAsList(ctx))
      ~linfer:(fun _ l f rf -> 
	  match !(match_lunif l) with
	  Inst(t,_) -> (lunif_function_full l rf) t
	| _ -> LInfer(l,rf))
      (0,startbenv)
      term

  exception InvNotPossible
  let attempt_inv_subst startbenv what bywhat =
    let is_idsubst benv subst = 
      let freevars, boundvars =
	try
	  let (freevars, hd, tl), _ = ExtList.find_partition_index (function LVar(LFVar(_)) -> false | _ -> true) subst in
	  freevars, hd :: tl
	with ExtList.NotFoundPartition ->
	  subst, []
      in
      if ExtList.is_prefix freevars  (freelist (List.length freevars)) &&
	 ExtList.is_prefix boundvars (boundlist benv) then
	true
      else
	false
    in
    try
      let (freemap, boundmap, metamap) =
	List.fold_left
	  (fun (freemap, boundmap, metamap) (what,bywhat) ->
	    match bywhat with
		LVar(LFVar(i)) -> (ExtIMap.addnew i what freemap, boundmap, metamap)
	      | LVar(LBVar(i)) -> (freemap, ExtIMap.addnew i what boundmap, metamap)
	      | LModal(LFMeta(i), subst) when is_idsubst startbenv subst ->
		(freemap, boundmap, ExtIMap.addnew i what metamap)
	      | _ -> raise InvNotPossible)
	  (IMap.empty, IMap.empty, IMap.empty)
	  (List.combine what bywhat)
      in
      subst_any freemap boundmap metamap startbenv
    with _ -> id

  let rec subst_free_list ?(start=0) bywhat term =
    lterm_map_envlen
      ~lfvar:(fun (_,benv) i -> 
	(* if i < List.length bywhat then *)
	  BindLterm.shift_bound benv (List.nth bywhat i)
	(* else *)
	(*   LVar(LFVar(i)) *))
      ~lterminctx:(fun ctx lt _ -> LTermInCtx(ctx,lt))
      ~lctxaslist:(fun ctx _ -> LCtxAsList(ctx))
      ~linfer:(fun (_,benv) l f rf -> 
	  match !(match_lunif l) with
	  Inst(t,_) -> (lunif_function_full l rf) t
	| _ -> let f' = 
		 addinvfunction 
		   (subst_free_list ~start:benv bywhat)
		   (let freevars = List.map (fun i -> LVar(LFVar(i))) (increasing (List.length bywhat)) in
		    attempt_inv_subst benv freevars bywhat)
		   f
	       in
	       LInfer(l,f'))
      (0,start)
      term

  let rec subst_bound ?(start=0) bywhat term = 
    lterm_map_envlen
      ~lbvar:(fun (_,benv) i ->
	if i = benv then
	  (BindLterm.shift_bound benv bywhat)
	else if i > benv then failwith "floating bound vars in subst_bound"
	else LVar(LBVar(i)))
      ~lterminctx:(fun ctx lt _ -> LTermInCtx(ctx,lt))
      ~lctxaslist:(fun ctx _ -> LCtxAsList(ctx))
      ~linfer:(fun (_,benv) l f rf -> 
	  match !(match_lunif l) with
	  Inst(t,_) -> (lunif_function_full l rf) t
	| _ -> 
	  let f' =
	    addinvfunction
	      (subst_bound ~start:benv bywhat)
	      (attempt_inv_subst benv [LVar(LBVar(0))] [bywhat])
	      f
	  in
	  LInfer(l,f'))
      (0,start)
      term

end;;


(* flattenings *)
let modal_apply_subst modal subst = 
    match modal with
	LTermInCtx(ctx,lt) -> BindLtermS.subst_free_list subst lt
      | meta -> LModal(meta, subst)

let open_terminctx modal =
  match modal with
      LTermInCtx(_,lt) -> lt
    | _ -> failwith "expected term in ctx"

let rec replace_fN_in_substs n m t =
  lterm_map ~lfvar:(fun i -> LVar (LFVar (if i > n then i + (m - 1) else i)))
            ~lsubstelem:(fun tm res ->
			   match tm with
			       LVar(LFVar n') when n = n' -> List.map (fun i -> LVar(LFVar (i+n))) (increasing m)
			     | _ -> [res])
            ~lmodal:(fun mt subst rmt rsubst -> LModal(mt,rsubst))
            ~lctxaslist:(fun ctx rctx -> LCtxAsList(ctx))
            ~linfer:(fun l f rf -> 
	      match !(match_lunif l) with
		Inst(t,_) -> (lunif_function_full l rf) t
	      | _ -> (let f' =
			addinvfunction
			  (replace_fN_in_substs n m)
			  (replace_list_in_substs n m)
			  f
		      in
		      LInfer(l, f')))
  t

and replace_list_in_substs n m t =
 lterm_map ~lfvar:(fun i -> LVar (LFVar (if i >= n - 1 && i < n + m - 1 then failwith "not parametric" else if i >= n + m - 1 then i - m + 1 else i)))
            ~lmodal:(fun mt subst rmt rsubst -> LModal(mt,rsubst))
            ~lctxaslist:(fun ctx rctx -> LCtxAsList(ctx))
            ~linfer:(fun l f rf -> 
	      match !(match_lunif l) with
		Inst(t,_) -> (lunif_function_full l rf) t
	      | _ -> LInfer(l,rf))
    t

let rec flatten_term_in_context ctx t =
  try
    nowarn let (before, (_, LTermList(LCtxAsList(l)), _, _), after), index = ExtList.find_partition_index (function (_, LTermList(LCtxAsList(_)),_, _) -> true | _ -> false) ctx in
    let m = List.length l in
    let after', t' = List.map (fun (s,t,t',pol) -> (s,replace_fN_in_substs index m t,t',pol)) after, replace_fN_in_substs index m t in
      flatten_term_in_context (List.append before (List.append l after')) t'
  with ExtList.NotFoundPartition -> (ctx, t)

let flatten_context ctx =
  let ctx', _ = flatten_term_in_context ctx (LSort(LSet)) in ctx'



exception ModalVarmap of lmodalterm * lterm list
exception ModalVarmapHandle of lterm

(* I have started implementing a hack using resumable exceptions in order to
   flatten modal substitutions as soon as they happen. I changed the code
   so that this happens always; but with the resumable exceptions it would
   be simpler to only flatten when needed (when a substitution takes place) *)

let metamaps fbound ffree =
  let rec lterm_varmap start (t : lterm) =
    match t with
      | LLambda (s, lt1, lt2)     -> LLambda(s, lterm_varmap start lt1, lterm_varmap start lt2)
      | LPi (s, k, lt1, lt2)      -> LPi(s, lterm_varmap start k, lterm_varmap start lt1, lterm_varmap start lt2) 
      | LApp (lt1, lt1t, lt2)     -> LApp(lterm_varmap start lt1, optlterm_varmap start lt1t, lterm_varmap start lt2)
      | LEq (lt, lt1, lt2)        -> LEq(optlterm_varmap start lt, lterm_varmap start lt1, lterm_varmap start lt2)
      | LEqAxiom (s, l)           -> LEqAxiom(s, List.map (lterm_varmap start) l)
      | LModal(lt, subst)      -> 
	 (let lt' = modal_varmap start lt in
	  let subst' = List.map (lterm_varmap start) subst in
	  modal_apply_subst lt' subst'
	  (* rraise (ModalVarmap (lt', subst')) *)
	  (* (fun e -> try raise e with ModalVarmapHandle(lt'') -> lt'') *)
	  (* LModal(lt',subst') *)
	 )
      | LTermList(ctxdesc)     -> LTermList(ctxdesc_varmap start ctxdesc)
      | LInfer(l,f) ->
	  (match !(match_lunif l) with
	       Inst(t,_) -> lterm_varmap start ((lunif_function_full l f) t)
	     | _ -> LInfer(l, addinvfunction (lterm_varmap start) id f))
      | t -> t
  and optlterm_varmap start (t : lterm option) = 
    match t with
	Some t -> Some (lterm_varmap start t)
      | None   -> None
  and modal_varmap start (t : lmodalterm) =
    match t with
	LTermInCtx(ctx, lt) ->
	  (LTermInCtx(ctx_varmap start ctx, lterm_varmap start lt))
      | LFMeta(i) -> ffree start i
      | LBMeta(i) -> fbound start i
      | LNMeta(s) -> LNMeta(s)
  and ctxdesc_varmap start (t : lctxdesc) =
    match t with
	LCtxAsList(l) -> LCtxAsList(ctx_varmap start l)
      | t -> t
  and ctx_varmap start (t : lctx) =
    List.map (fun (name,tm,sort,pol) -> (name, lterm_varmap start tm, optlterm_varmap start sort, pol)) t
  in
    (lterm_varmap, modal_varmap, ctxdesc_varmap)

let lterm_metamap fbound ffree   = let (a,_,_) = metamaps fbound ffree in a
let modal_metamap fbound ffree   = let (_,a,_) = metamaps fbound ffree in a
let ctxdesc_metamap fbound ffree = let (_,_,a) = metamaps fbound ffree in a


exception CtxVarmap1 of lctx
exception CtxVarmap2 of lctx * lterm
exception CtxVarmap1Handle of lctxdesc
exception CtxVarmap2Handle of lctx * lterm

let ctxmaps fbound ffree =
  let rec lterm_varmap start (t : lterm) =
    match t with
      | LLambda (s, lt1, lt2)     -> LLambda(s, lterm_varmap start lt1, lterm_varmap start lt2)
      | LPi (s, k, lt1, lt2)      -> LPi(s, k, lterm_varmap start lt1, lterm_varmap start lt2)
      | LApp (lt1, lt1t, lt2)     -> LApp(lterm_varmap start lt1, optlterm_varmap start lt1t, lterm_varmap start lt2)
      | LEq (lt, lt1, lt2)        -> LEq(optlterm_varmap start lt, lterm_varmap start lt1, lterm_varmap start lt2)
      | LEqAxiom (s, l)           -> LEqAxiom(s, List.map (lterm_varmap start) l)
      | LModal(lt, subst)      -> LModal(modal_varmap start lt, List.map (lterm_varmap start) subst)
      | LTermList(tmlist)      -> LTermList(tmlist_varmap start tmlist)
      | LInfer(l,f) ->
	  (match !(match_lunif l) with
	       Inst(t,_) -> lterm_varmap start ((lunif_function_full l f) t)
	     | _ -> LInfer(l, addinvfunction (lterm_varmap start) id f))
      | t -> t
  and optlterm_varmap start (t : lterm option) = 
    match t with
	Some t -> Some (lterm_varmap start t)
      | None   -> None
  and modal_varmap start (t : lmodalterm) =
    match t with
	LTermInCtx(ctx, lt) ->
	  let ctx' = ctx_varmap start ctx in
	  let lt' = lterm_varmap start lt in
	  let ctx'', lt'' = flatten_term_in_context ctx' lt' in
	  LTermInCtx(ctx'', lt'')
	  (* rraise (CtxVarmap2 (ctx',lt')) *)
	  (* (fun e -> try raise e with CtxVarmap2Handle(ctx'',lt'') -> LTermInCtx(ctx'',lt'')) *)
	  (* LTermInCtx(ctx', lt') *)
      | t -> t
  and tmlist_varmap start (t : lctxdesc) =
    match t with
	LFCtx(i) -> ffree start i
      | LBCtx(i) -> fbound start i
      | LCtxAsList(lt) ->
	let lctx' = ctx_varmap start lt in
	LCtxAsList(flatten_context lctx')
	(* rraise (CtxVarmap1 (lctx')) *)
	(* (fun e -> try raise e with CtxVarmap1Handle(lctxdesc') -> lctxdesc') *)
	(* LCtxAsList(lctx') *)
  and ctx_varmap start (t : lctx) = 
    List.map (fun (name,tm,sort,pol) -> (name, lterm_varmap start tm, optlterm_varmap start sort,pol)) t
  in
    (lterm_varmap, modal_varmap, tmlist_varmap)

let lterm_ctxmap fbound ffree  = let (a,_,_) = ctxmaps fbound ffree in a
let modal_ctxmap fbound ffree  = let (_,a,_) = ctxmaps fbound ffree in a
let tmlist_ctxmap fbound ffree = let (_,_,a) = ctxmaps fbound ffree in a


(* handling the exceptions now *)

(*
let default_varmap_handler f =
  rhandle (function v ->
    try raise v
    with 
	ModalVarmap(lt,subst) -> resume (ModalVarmapHandle(LModal(lt,subst)))
      | CtxVarmap1(ctx) -> resume (CtxVarmap1Handle(LCtxAsList(ctx)))
      | CtxVarmap2(ctx,lt) -> resume (CtxVarmap2Handle(ctx,lt)))
    f

let default_varmap_handler f =
  rhandle (function v ->
    try raise v
    with 
	ModalVarmap(lt,subst) ->
	  resume (ModalVarmapHandle(modal_apply_subst lt subst))
      | CtxVarmap1(ctx) ->
	  resume (CtxVarmap1Handle(LCtxAsList(flatten_context ctx)))
      | CtxVarmap2(ctx,lt) -> 
	let ctx', lt' = flatten_term_in_context ctx lt in
	resume(CtxVarmap2Handle(ctx',lt')))
    f

(* we could still enable the full maps here, so that they are used only
   when needed *)
let modal_metamap a b c d = default_varmap_handler (fun () -> modal_metamap a b c d)
let lterm_metamap a b c d = default_varmap_handler (fun () -> lterm_metamap a b c d)
let ctxdesc_metamap a b c d = default_varmap_handler (fun () -> ctxdesc_metamap a b c d)

let lterm_ctxmap a b c d = default_varmap_handler (fun () -> lterm_ctxmap a b c d)
let modal_ctxmap a b c d = default_varmap_handler (fun () -> modal_ctxmap a b c d)
let tmlist_ctxmap a b c d = default_varmap_handler (fun () -> tmlist_ctxmap a b c d)

let default_varmap_handler f = f ()
*)

module MetabindLterm = Binding(struct
				 type tvar = lmodalterm
				 type t = lterm
				 type tenv = int
				 let  bound  i = i
				 let  varmap f1 f2 = lterm_metamap f1 f2 0
				 let  bvar   i = LBMeta i
				 let  fvar   i = LFMeta i
			       end)

module MetabindModal = Binding(struct
			     type t = lmodalterm
			     type tvar = lmodalterm
			     type tenv = int
			     let  bound i = i
			     let varmap f1 f2 = modal_metamap f1 f2 0
			     let bvar i = LBMeta i
			     let fvar i = LFMeta i
			   end)

module MetabindCtxdesc = Binding(struct
			     type t = lctxdesc
			     type tvar = lmodalterm
			     type tenv = int
			     let  bound i = i
			     let varmap f1 f2 = ctxdesc_metamap f1 f2 0
			     let bvar i = LBMeta i
			     let fvar i = LFMeta i
			   end)


module CtxbindLterm = Binding(struct
				type tvar = lctxdesc
				type t = lterm
				type tenv = int
				let  bound  i = i
				let  varmap f1 f2 = lterm_ctxmap f1 f2 0
				let  bvar   i = LBCtx i
				let  fvar   i = LFCtx i
			      end)

module CtxbindModal = Binding(struct
				type t = lmodalterm
				type tvar = lctxdesc
				type tenv = int
				let  bound  i = i
				let varmap f1 f2 = modal_ctxmap f1 f2 0
				let bvar i = LBCtx i
				let fvar i = LFCtx i
			      end)

module CtxbindCtxdesc = Binding(struct  type tvar = lctxdesc
				type t = lctxdesc
				type tenv = int
				let  bound  i = i
				let  varmap f1 f2 = tmlist_ctxmap f1 f2 0
				let  bvar   i = LBCtx i
				let  fvar   i = LFCtx i
			end)

module CtxbindLtermS =  (struct
  module Base = CtxbindLterm;; (* Binding(struct
				type tvar = lctxdesc
				type t = lterm
				type tenv = int
				let  bound  i = i
				let  varmap f1 f2 = lterm_ctxmap_subst f1 f2 0
				let  bvar   i = LBCtx i
				let  fvar   i = LFCtx i
			      end);; *)
  let subst_bound_list = Base.subst_bound_list_given_shift CtxbindCtxdesc.shift_bound
  let subst_bound      = Base.subst_bound_given_list subst_bound_list
  let subst_free_list  = Base.subst_free_list_given_shift CtxbindCtxdesc.shift_bound
end)

module CtxbindModalS =  (struct
  module Base = CtxbindModal;; (* Binding(struct
				type t = lmodalterm
				type tvar = lctxdesc
				type tenv = int
				let  bound  i = i
				let varmap f1 f2 = modal_ctxmap_subst f1 f2 0
				let bvar i = LBCtx i
				let fvar i = LFCtx i
			      end);; *)
  
  let subst_bound_list = Base.subst_bound_list_given_shift CtxbindCtxdesc.shift_bound
  let subst_bound      = Base.subst_bound_given_list subst_bound_list
  let subst_free_list  = Base.subst_free_list_given_shift CtxbindCtxdesc.shift_bound
end)

module CtxbindCtxdescS =  (struct
  module Base = CtxbindCtxdesc;; (* Binding(struct  type tvar = lctxdesc
					  type t = lctxdesc
					  type tenv = int
					  let  bound  i = i
					  let  varmap f1 f2 = tmlist_ctxmap_subst f1 f2 0
					  let  bvar   i = LBCtx i
					  let  fvar   i = LFCtx i
  end);; *)

  let subst_bound_list = Base.subst_bound_list_given_shift CtxbindCtxdesc.shift_bound
  let subst_bound      = Base.subst_bound_given_list subst_bound_list
  let subst_free_list  = Base.subst_free_list_given_shift CtxbindCtxdesc.shift_bound
end)


let mk_infer free bound metafree metabound ctxfree ctxbound =
  let closef free bound cl =
    let envlen = free + bound in
    cl ?howmany:(Some bound) envlen
  in
  let mtop = closef metafree metabound MetabindLterm.close_down in
  let ctop = closef ctxfree  ctxbound  CtxbindLterm.close_down in
  LInfer(mk_lunifvar (), ( [compose mtop ctop], [] ) )




(* new code used from logic_ind, but could be utilized more in existing code *)


(* code used for optimized translation *)

type lfastctx = lctx * int * lsubst
let mk_fctx     (ctx : lctx) length subst = ctx, length, subst
let fctx_ctx    (ctx,_,_)    = ctx
let fctx_length (_,length,_) = length
let fctx_subst  (_,_,subst)  = subst
let fctx_split_last (ctx,length,subst) =
  try
    let ctx', (_,lasttm,lastsort,_) = ExtList.last ctx in
    let length'          = length - 1 in
    let subst', _        = ExtList.last subst in
    Some( (mk_fctx ctx' length' subst', lasttm, lastsort) )
  with ExtList.LastOnEmpty ->
    None

let check_type t = ()

let check_free_vars t fctx bctx substlen =
  let maxv = ref (-1) in
  let t = BindLterm.open_up ~howmany:bctx fctx t in
  let _ = lterm_map
    ~lfvar:(fun i -> (if i > !maxv then maxv := i); LVar(LFVar(i)))
    ~lterminctx:(fun _ -> failwith "did not expect nested modal at this point")
    ~lctxaslist:(fun _ -> failwith "did not expect nested context at this point")
    t
  in
    !maxv < substlen


let erasure_mode = ref false

let cond_emit_prf pf = 
  if !erasure_mode then LModal( LNMeta("~trusted"), [] ) else pf

let under_erasure thunk =
  let prevmode = !erasure_mode in
  erasure_mode := true;
  let res = Lazy.force thunk in
  erasure_mode := prevmode;
  res
