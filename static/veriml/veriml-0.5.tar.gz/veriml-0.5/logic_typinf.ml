open Utils
open Logic_ast
open Logic_core
open Logic_print

let impredicative_set = Logic_typing.impredicative_set
let add_to_env = Logic_typing.add_to_env
let add_to_env_full = Logic_typing.add_to_env_full


let ctx_is_prefix defenv l1 l2 =
    if (List.length l1 > List.length l2) then false
    else ExtList.foldindex (fun i ((_,a),(_,b)) res -> res && (lterm_equal defenv i a b)) true
      (List.combine l1 (ExtList.take (List.length l1) l2))

let require_lterm_equal ((fenv, defenv, metaenv, ctxenv) : lterm_env) t t' =
  if lterm_equal defenv (List.length fenv) t t' then
    ()
  else
    raise LTermsNotEqual

let require_lmodal_equal ((fenv, defenv, metaenv, ctxenv) : lterm_env) t t' =
  if lmodal_equal defenv (List.length metaenv) t t' then
    ()
  else
    raise LTermsNotEqual

let rec type_of_lterm ((realfenv, defenv, metaenv, ctxenv) as realenv : lterm_env) ?(trusted = false) ?(expected = None) (e : lterm) =

  let fenv = demote_polarities_fully realfenv in
  let env = (fenv, defenv, metaenv, ctxenv) in

  let type_of_lterm env ?expected e = type_of_lterm env ~trusted:trusted ?expected:expected e in
  let return t =
    match expected with
	Some t' -> require_lterm_equal env t t'; t
      | _ -> t
  in
  let n = List.length fenv in
  let metan = List.length metaenv in
  let ctxn = List.length ctxenv in
  match e with
      LSort(LSet)  -> return (LSort(LType))
    | LSort(LProp) -> return (LSort(LSet))
    | LSort(LType) -> failwith "LType has no type"
    | LVar(LBVar i) -> failwith "accessing type of bound var -- shouldn't happen!"
    | LVar(LFVar i) ->
      let tp, pol = List.nth realfenv (List.length realfenv - i - 1) in
      if pol = LPNone then failwith "polarity condition violated" else return tp

(* special handling of equality *)
    | LEq(t,t1,t2) ->
        let uv = mk_infer n 0 metan 0 ctxn 0 in
	let _ = try type_of_lterm env ~expected:(Some uv) t1 with LTermsNotEqual -> failwith "in eq, first argument's type does not match equality's type" in
	let _ = try type_of_lterm env ~expected:(Some uv) t2 with LTermsNotEqual -> failwith "in eq, second argument's type does not match equality's type" in
	let _ = match t with Some t -> if not (lterm_equal defenv n t uv) then failwith "type in eq is not what is should be" | None -> () in
	let ts = type_of_lterm env uv in
	let thistp = LPi(None,ts,uv,LSort(LProp)) in
	let _ = type_of_lterm env thistp in
	  return (LSort(LProp))

    | LEqAxiom( refl, [ t ] ) when refl = "refl" ->
        let uv = mk_infer n 0 metan 0 ctxn 0 in
	let thistp = LEq(Some uv, t, t) in
	let _ = type_of_lterm env thistp in
	  return thistp

    | LEqAxiom( symm, [ t ] ) when symm = "symm" ->
        begin
        let uvtp = mk_infer n 0 metan 0 ctxn 0 in
	let uv1 = mk_infer n 0 metan 0 ctxn 0 in
	let uv2 = mk_infer n 0 metan 0 ctxn 0 in
	let exp = LEq(Some uvtp, uv1, uv2) in
	let _ = try type_of_lterm env ~expected:(Some exp) t with LTermsNotEqual -> failwith "in symm, first argument of incorrect type" in
	return (LEq(Some uvtp, uv2, uv1))
	end

    | LEqAxiom( trans, [ t1 ; t2 ] ) when trans = "trans" ->
        begin
        let uvtp = mk_infer n 0 metan 0 ctxn 0 in
	let uv1 = mk_infer n 0 metan 0 ctxn 0 in
	let uv2 = mk_infer n 0 metan 0 ctxn 0 in
	let uv3 = mk_infer n 0 metan 0 ctxn 0 in
	let exp1 = LEq(Some uvtp, uv1, uv2) in
	let exp2 = LEq(Some uvtp, uv2, uv3) in
	let _ = try type_of_lterm env ~expected:(Some exp1) t1 with LTermsNotEqual -> failwith "in trans, first argument of incorrect type" in
	let _ = try type_of_lterm env ~expected:(Some exp2) t2 with LTermsNotEqual -> failwith "in trans, second argument of incorrect type" in
	return (LEq(Some uvtp, uv1, uv3))
	end

    | LEqAxiom( leibn, [ (LLambda(_,tp,tm) as e) ; pf' ; pf ] ) when leibn = "leibn" ->
	begin
	let ewf = type_of_lterm env e in
	let uv = mk_infer n 0 metan 0 ctxn 0 in
	let _ = if lterm_equal defenv n ewf (LPi(None,uv,tp,LSort(LProp))) then () else failwith "in leibniz, the P argument should be a one-place predicate" in
	let uvtp = mk_infer n 0 metan 0 ctxn 0 in
	let uv1 = mk_infer n 0 metan 0 ctxn 0 in
	let uv2 = mk_infer n 0 metan 0 ctxn 0 in
	let exp' = LEq(Some uvtp, uv1, uv2) in
	let exp  = BindLtermS.subst_bound uv1 tm in
	let _ = try type_of_lterm env ~expected:(Some exp') pf' with LTermsNotEqual -> failwith "in leibniz, equality term of wrong type" in
	let _ = try type_of_lterm env ~expected:(Some exp) pf with LTermsNotEqual -> failwith "in leibniz, terms or proof object of incorrect type" in
	return (BindLtermS.subst_bound uv2 tm)

	end

    | LEqAxiom( lameq, [ pf ] ) when lameq = "lameq" ->
        begin
  	  let _ = match pf with LLambda(_,_,_) -> () | _ -> failwith "proof must be lambda in lameq" in

	  let utp = mk_infer n 0 metan 0 ctxn 0 in
	  let utps = mk_infer n 0 metan 0 ctxn 0 in
	  let uv1 = mk_infer n 1 metan 0 ctxn 0 in
	  let uv2 = mk_infer n 1 metan 0 ctxn 0 in
	  let utp' = mk_infer n 1 metan 0 ctxn 0 in
	  let exp = LPi(None,utps,utp,LEq(Some utp',uv1,uv2)) in

	  let pftp = try type_of_lterm env ~expected:(Some exp) pf with LTermsNotEqual -> failwith "in lameq, wrong type for proof" in
	  let _ = try type_of_lterm env ~expected:(Some (LSort(LProp))) pftp with LTermsNotEqual -> failwith "wrong term applied to lameq -- need forall proposition" in
	  let var,k = (match pftp with LPi(var,k,_,_) -> var,k | _ -> failwith "oops!") in
	  
	  return (LEq(Some (LPi(var,k,utp,utp')), LLambda(var,utp,uv1), LLambda(var,utp,uv2) ))
	end

    | LEqAxiom( foralleq, [ pf ] ) when foralleq = "foralleq" ->
	begin
  	  let _ = match pf with LLambda(_,_,_) -> () | _ -> failwith "proof must be lambda in foralleq" in

	  let utps = mk_infer n 0 metan 0 ctxn 0 in
	  let utp = mk_infer n 0 metan 0 ctxn 0 in
	  let utp' = mk_infer n 1 metan 0 ctxn 0 in
	  let uv1 = mk_infer n 1 metan 0 ctxn 0 in
	  let uv2 = mk_infer n 1 metan 0 ctxn 0 in
	  let exp = LPi(None,utps,utp,LEq(Some utp',uv1,uv2)) in

	  let pftp = try type_of_lterm env ~expected:(Some exp) pf with LTermsNotEqual -> failwith "wrong type for proof in foralleq application" in
	  let _ = try type_of_lterm env ~expected:(Some (LSort(LProp))) pftp with LTermsNotEqual -> failwith "wrong term applied to foralleq -- need forall proposition" in
	  let var, k = (match pftp with LPi(var,k,_,_) -> var,k | _ -> failwith "oops!") in

	  return (LEq(Some (LSort(LProp)), LPi(var,k,utp,uv1), LPi(var,k,utp,uv2) ))
	end		

    | LEqAxiom( beta , [ (LLambda(_, tp, tm) as e) ; e2 ] ) when beta = "beta" ->
	begin
	  let etp = type_of_lterm env e in
	  let uv = mk_infer n 0 metan 0 ctxn 0 in
	  let thistp = LEq(Some uv, LApp(e,Some etp,e2), BindLtermS.subst_bound e2 tm) in
	  let _ = type_of_lterm env thistp in
	    return thistp
	end

    | LEqAxiom( metaunfold , [ LModal(LNMeta(s), subst) as e ] )
	when (metaunfold = "metaunfold" && not (get_metadef_isaxiom s defenv)) ->
	begin
	  let tp = type_of_lterm env e in
	  let _ = type_of_lterm env (LEq(Some tp,e,e)) in
	  let unfolded = modal_apply_subst (get_metadef_term s defenv) subst in
	    return (LEq(Some tp, e, unfolded))
	end

    | LEqAxiom( _ , _ ) -> failwith "wrong use of equality axiom"	

    | LModal(LNMeta(erasable), [pf]) when erasable = "~erasable" ->
        (type_of_lterm env ~expected:expected pf)

(* unsafe feature *)
    | LModal(LNMeta(s), []) when s = "~trusted" && trusted ->
      let uv = mk_infer n 0 metan 0 ctxn 0 in
      return uv

(* ok, equality done *)

    | LPi(var, k, t1, t2) ->
        let env1 = (demote_polarities_pos realfenv, defenv, metaenv, ctxenv) in
	let t1_t = type_of_lterm env1 ~expected:(Some k) t1 in
	let env' = add_to_env realenv t1 in
	let t2' = BindLterm.open_up n t2 in
	let t2_t = type_of_lterm env' t2' in
	  begin
	    match whnf defenv t1_t, whnf defenv t2_t with
	    	LSort(LProp), LSort(LProp) -> return (LSort(LProp))
	      | LSort(LSet), LSort(LSet) -> return (LSort(LSet))
	      | LSort(LSet), LSort(LProp) -> return (LSort(LProp))
	    	  (* impredicative Set? *)
	      | LSort(LType), LSort(LType) when !impredicative_set -> return(LSort(LType))
	      | LSort(LType), LSort(LSet)  when !impredicative_set -> return(LSort(LSet))
	      | LSort(LType), LSort(LProp) when !impredicative_set -> return(LSort(LProp))
	      | LInfer(l,_), LSort(LProp) -> return(LSort(LProp))
	      | LInfer(_,_), LSort(LSet) -> (let _ = lterm_equal defenv n t1_t (LSort(LSet)) in return (LSort(LSet)))
	      | LSort(LProp), LInfer(_,_) -> (let _ = lterm_equal defenv n t2_t (LSort(LProp)) in return (LSort(LProp)))
	      | LSort(LSet), LInfer(_,_) -> return t2_t
	      | LInfer(_,_), LInfer(_,_) -> return t2_t
		  
	      | _ -> failwith ("invalid type " ^ (string_of_lterm e))
	  end
    | LLambda(var, t1, e2) ->
	let uv  = mk_infer n 0 metan 0 ctxn 0 in
	let uv2 = mk_infer n 1 metan 0 ctxn 0 in
	let realexp = LPi(var, uv, t1, uv2) in
	let _ = return realexp in
	let exp2 = BindLterm.open_up n uv2 in
	let env' = add_to_env env t1 in
	let _ = try type_of_lterm env' ~expected:(Some exp2) (BindLterm.open_up n e2) with LTermsNotEqual -> failwith "body of lambda not of the right type" in 
	let _ = type_of_lterm env realexp in
	  return realexp
    | LApp(e1, t, e2) ->
        let uva = mk_infer n 0 metan 0 ctxn 0 in
        let uvb = mk_infer n 1 metan 0 ctxn 0 in
	let uv = mk_infer n 0 metan 0 ctxn 0 in
        let exp1 = (LPi(None, uv, uva, uvb)) in
	let exp2 = uva in
	let _  = try type_of_lterm env ~expected:(Some exp2) e2 with LTermsNotEqual -> failwith "in application, argument not of the right type" in
	let t1 = try type_of_lterm realenv ~expected:(Some exp1) e1 with LTermsNotEqual -> failwith "in application, function not of the right type" in
	let _ =
	  match t with
	      Some t when type_of_lterm env t1 <> LSort(LProp) ->
		require_lterm_equal env t exp1
	    | _ -> ()
	in
	(* let _ = require_lterm_equal env t1 exp1 (\* TODO: is this needed? *\) in *)
	begin
	  return (BindLtermS.subst_bound e2 uvb)
	end
    | LModal(mt, subst) ->
	(let mt_t = type_of_modal realenv ~trusted:trusted mt in
	 let rec getctx mt_t =
	   match mt_t with
	       LTermInCtx(ctx, _) -> ctx
	     | _ -> getctx (type_of_modal realenv ~trusted:trusted mt_t)
	 in
	 let ctx = getctx mt_t in
	 let _ = type_of_subst_is realenv subst ctx in
	   return (modal_apply_subst mt_t subst))
    | LTermList(ctx) ->
	failwith "asking type of context inside type_of_lterm!"
    | LInfer(el, f) ->
	(match !(match_lunif el) with
	     Inst(ei,ti) ->
	       (let t' = type_of_lterm env ~expected:expected (try (lunif_function_full el f) ei with _ -> failwith "can't unify! -- problem while applying f^-1!") in
		  if (match !ti with Some ot -> lterm_equal defenv n t' (LInfer(ot,f)) | _ -> true) then
		    return t'
		  else
		    failwith "instantiation of inferred term with wrong type!")
	   | Uninst(i,otyp) ->
	       (match !otyp with
		    None -> (let uv = mk_lunifvar () in otyp := (Some uv); return(LInfer(uv, f)))
		  | Some ti -> return (LInfer(ti, f))))
	
and type_of_modal ((fenv, defenv, metaenv, ctxenv) as env : lterm_env) ?(trusted = false) ?(expected = None) (mt : lmodalterm) =
  let return t =
    match expected with
	Some t' -> require_lmodal_equal env t t'; t
      | _ -> t
  in
  match mt with
      LTermInCtx(ctx,lt) ->
	(* TODO: take expected more into account (e.g. even for context) *)
	(let _ = ctx_wf ([], defenv, metaenv, ctxenv) (LCtxAsList(ctx)) in
	 let newfenv = ctx_to_fenv ctx in
	 let expected =
	   match expected with
	    (*   Some(LTermInCtx(ctx',lt')) ->
		 (if ctx_is_prefix defenv ctx ctx' then
		     (let _, openlt' = terminctx_open_up ctx' lt' in Some (openlt'))
		  else
		     failwith "context does not match expected one!")
	     |*) _ -> None
	 in
	 let tp = type_of_lterm (newfenv, defenv, metaenv, ctxenv) ~trusted:trusted ~expected:expected lt in
	   return (LTermInCtx(ctx,tp)))
    | LFMeta(i) -> return (List.nth metaenv (List.length metaenv - i - 1))
    | LBMeta(i) -> failwith ("accessing bound meta variable while type checking -- shouldn't happen")
    | LNMeta(s) -> return (get_metadef_type s defenv)

and type_of_subst_is ((fenv, defenv, metaenv, ctxenv) : lterm_env) (subst : lsubst) (ctx : lctx) =

  (if List.length subst <> List.length ctx then failwith "subst and context do not match in size");
  List.for_all2
    (fun selm (v,celm,_,pol) ->
      let fenv' = match pol with LPAny -> demote_polarities_fully fenv | LPPos -> fenv | _ -> failwith "unexpected polarity" in
      let env'  = (fenv', defenv, metaenv, ctxenv) in
      let chd_t = BindLtermS.subst_free_list subst celm in
      let _ =
	try type_of_lterm env' ~expected:(Some chd_t) selm
	with LTermsNotEqual -> failwith ("subst and ctx do not match in type for " ^(match v with None -> "?" | Some s -> s))
      in
      true)
    subst ctx

and ctx_wf ((fenv, defenv, metaenv, ctxenv) as env : lterm_env) (ctx : lctxdesc) =
  match ctx with
      LFCtx(i) -> List.nth ctxenv (List.length ctxenv - i - 1)
    | LBCtx(i) -> failwith "getting type of bound context variable"
    | LCtxAsList(l) ->
	ignore
	  (List.fold_left (fun ((fenv, _, _, _) as curenv,n) (_,elm,sort,pol) ->
			     valid_ctxelem curenv elm sort;
			     (add_to_env_full curenv elm pol, n+1))
	     (env,0) l)

and valid_ctxelem ((fenv, defenv, metaenv, ctxenv) as env) (ctxelem : lterm) (sort : lterm option) =
  match ctxelem with
      LTermList(LCtxAsList(_)) -> failwith "nested context lists are not allowed!"
    | LTermList(ctx) -> ctx_wf env ctx
    | t ->
      (let sort' = type_of_lterm env t in
       let _ = match sort with Some(sort) -> if not (lterm_equal defenv (List.length fenv) sort sort') then failwith "unexpected sort in context" | None -> () in
       ())

let type_of_lterm a ?(expected = None) ?(trusted = false) tm =
                         repeatmany 1 (fun () -> type_of_lterm a ~expected:expected ~trusted:trusted tm)
let type_of_modal a ?(expected = None) ?(trusted = false) tm = repeatmany 1 (fun () -> type_of_modal a ~expected:expected ~trusted:trusted tm)
let ctx_wf a tm        = repeatmany 1 (fun () -> ctx_wf a tm)


