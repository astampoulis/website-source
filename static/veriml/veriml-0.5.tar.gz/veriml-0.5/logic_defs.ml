open Utils
open Logic_ast
open Logic_core
open Logic_print
module LTyp = Logic_typing
module LTyf = Logic_typinf

let print_definitions = ref true

let ltermenv_empty def = ([], def, [], [])
let ltermdefenv_empty = Dict.empty
let logic_global_env : LAst.lterm_defenv ref = ref ltermdefenv_empty


let wrap_phase msg lazyf =
  try Lazy.force lazyf with LTermsNotEqual -> failwith msg

let do_typing_phase trusted typechecker msg1 msg2 env tm tp kind  =
  let tp', tm' =
    match tm with
	Some tm -> let tp', tm' =
		     if not trusted then
		       wrap_phase msg1 (lazy(typechecker env tp tm))
		     else
		       (tp, tm)
		   in
                   (tp', Some tm')
      | None -> (tp, None)
  in
  let kind', tp'' = wrap_phase msg2 (lazy(typechecker env kind tp')) in
  tm', tp'', kind'

let combine_phases chk1 chk2 = fun env tp tm -> uncurry (chk2 env) (chk1 env tp tm)


let lmodal_typecheck_phase env tp tm =
  ignore (LTyp.type_of_modal_expected env ~expected:(Some tp) tm); (remove_infer_lmodal tp, remove_infer_lmodal tm)
let lmodal_typeinfer_phase env tp tm =
  ignore (LTyf.type_of_modal env ~expected:(Some tp) tm); (remove_infer_lmodal tp, remove_infer_lmodal tm)
let lmodal_typeinfer_trusted_phase env tp tm =
  ignore (LTyf.type_of_modal env ~expected:(Some tp) ~trusted:true tm); (remove_infer_lmodal tp, remove_infer_lmodal tm)
let lmodal_infercheck_phase =
  combine_phases lmodal_typeinfer_phase lmodal_typecheck_phase


let new_logic_metadef ?(phase=lmodal_typecheck_phase) ?(print=true) ?(trusted=false) name tm_opt tp_opt defenvref =
  let env = ([], !defenvref, [], []) in
  let ctx =
    match tm_opt, tp_opt with 
	None, None -> failwith "cannot define an axiom with no type!"
      | Some (LTermInCtx(ctx,_)), _
      | _, Some (LTermInCtx(ctx,_)) -> ctx
      | _ -> failwith "in metadef, no explicitly defined context!"
  in
  let tp   = match tp_opt with None -> LTermInCtx(ctx, mk_infer 0 (List.length ctx) 0 0 0 0) | Some tp -> tp in
  let sort = mk_infer 0 (List.length ctx) 0 0 0 0 in
  let kind = LTermInCtx(ctx, sort) in
  let tm_opt', tp', _ = do_typing_phase trusted phase
                                 ("type of modal does not match the expected one in def of " ^ name)
				 ("kind of modal does not match the expected one in def of " ^ name)
				 env tm_opt tp kind
  in
  let _ = match remove_infer sort with LSort(_) -> () | _ -> failwith ("type of metadef is not a sort in def of " ^ name) in
  defenvref := ExtDict.addnew name (tp', tm_opt') !defenvref;
  (if print && !print_definitions then
      match tm_opt' with
	  Some tm' -> 
	    Format.fprintf Format.std_formatter "Logicdef %s@ :@ %a.@." name pr_modal tp'
	| _ ->
	  Format.fprintf Format.std_formatter "Axiom %s@ :@ %a.@." name pr_modal tp');  
  (tm_opt', tp') (* return the transformed terms after typechecking *)



let print_metadef isaxiom name =
  let deftype = if isaxiom then "Axiom" else "Logicdef" in
  let tp = Logic_core.get_metadef_type name !logic_global_env in
  Format.fprintf Format.std_formatter "%s %s@ :@ %a.@." deftype name pr_modal tp

  


let add_notation name tm =
  Logic_cst.logic_notations := (Dict.add name tm (!Logic_cst.logic_notations))
