module CompGram = Syntax_trans_comp.CompGram;;
open Camlp4.PreCast;;

let _ = Config.interactive := false;;

module ExportAst = struct
  open Camlp4_import.Parsetree;;
  open Lexing;;
  open Camlp4;;
  open PreCast;;
  open Camlp4.Sig;;
  module Ast2pt = Camlp4.Struct.Camlp4Ast2OCamlAst.Make(Ast);;
  module Lexer = Camlp4.Struct.Lexer.Make(Token);;
  module Printer = Camlp4.Printers.OCaml.Make(Camlp4.PreCast.Syntax);;
  module Dumper = Camlp4.Printers.DumpOCamlAst.Make(Camlp4.PreCast.Syntax);;
  
  let printer = (new Printer.printer ())#implem
  let dumper = Dumper.print_implem
end;;

let ocaml_printer str_item =
  ExportAst.printer Format.str_formatter str_item;
  print_string (Format.flush_str_formatter ())

let ocaml_dumper str_item =
  ExportAst.dumper str_item

let dep_file = ref None

let output_dep s =
  match !dep_file with
      Some f -> output_string f (s ^ "\n")
    | None -> ()

let open_dep () =
  match !Config.byte_dependencies with
    | Some filename -> dep_file := Some (open_out filename)
    | _ -> ()

let close_dep () = 
  match !dep_file with
      Some f -> close_out f
    | _ -> ()


let rec veriml_parser loc cs =
  let main_parse = CompGram.parse Syntax_trans_comp.veriml_file in
  let rec loop loc =
    match main_parse loc cs with
	( l, None ) ->
	  
	  let _loc = loc in
	  List.fold_left
	    (fun stritem phrase ->
		let s = Comp_translate.translate_phrase phrase in
		<:str_item< $stritem$ ;; $s$ >> )
	     <:str_item< >>
	    l

      | ( [ Phrases.PhrNeed(s, _) ] , Some loc' ) ->

	  let bytefile = "_compiled/" ^ s ^ ".cma" in
	  (if Sys.file_exists bytefile then

	      let _loc = loc in
	      let _ = Comp_translate.translate_phrase (Phrases.PhrNeed(s, loc)) in
	      let bytename = s ^ ".cma" in
	      let modulename = String.capitalize s in
	      let _ =
		if !Config.real_staging then
		  (Comp_ocamlast.Staging.stage_stritem
		     ( <:str_item< let _ = Comp_env.dynamic_env_reset () >> );
		   (* the above assumes that the loaded bytecode reinstates the full dynamic environment.
		      this means that compilation of a program B.veriml should link that bytecode from A.veriml
		      if B requires A. same thing in verimltoploop *)
		   Comp_ocamlast.Staging.stage_stritem
		     ( <:str_item< let _ = Logic_defs.logic_global_env := Comp_env.env_logic_import !Logic_defs.logic_global_env $str:s$ >> ) ;
		   Comp_ocamlast.Staging.stage_stritem
		     ( <:str_item< let _ = Topdirs.dir_load Format.std_formatter $str:bytename$ >> ) ;
		   Comp_ocamlast.Staging.stage_stritem
		     ( <:str_item< include $uid:modulename$ >> ) )
	      in
	      let next = loop loc' in
	      let _loc = loc in
	      let _ = output_dep bytename in
	      <:str_item< include $uid:modulename$ ;; $next$ >> 
	      
	   else
	      
	      let channel = open_in_bin ( s ^ ".veriml" ) in
	      let locnew = Loc.mk s in
	      let stritem = veriml_parser locnew (Stream.of_channel channel) in
	      let next = loop loc' in
	      let _loc = loc in
	      <:str_item< $stritem$ ;; $next$ >> )
	    
      | _ -> failwith "not handled yet"
  in
  loop loc

let handle_file s =
  open_dep ();
  let channel = if s = "-" then stdin else open_in_bin s in
  let cs = Stream.of_channel channel in
  let loc = Loc.mk s in
  let phr = try veriml_parser loc cs with Loc.Exc_located(_,e) -> raise e in
  if not !Config.just_typecheck then
    (if !Config.dump_text_ast then ocaml_printer phr else ocaml_dumper phr);
  close_dep ()

let main () =
  let usage_msg =
"\
Usage: veriml [options]
Options:
<file>.veriml     Parse this VeriML file
"
  in
  Arg.parse Config.arg_spec handle_file usage_msg

let initialize_hidden_toplevel () =
  Toploop.initialize_toplevel_env () ;
  Topdirs.dir_directory "_build" ;
  Topdirs.dir_directory "_compiled" ;
  Topdirs.dir_load Format.std_formatter "veriml-runtime.cma";
  Comp_ocamlast.Staging.stage_string "#warnings \"a\";;";
  Comp_ocamlast.Staging.stage_string "Logic_print.conditional_formatter := (Format.formatter_of_buffer (Buffer.create 500));;";
  Camlp4.Register.enable_dump_ocaml_ast_printer ()


let _ = initialize_hidden_toplevel () ; main ()


