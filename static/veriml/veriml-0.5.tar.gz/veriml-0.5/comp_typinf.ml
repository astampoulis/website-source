open Utils
open Logic_ast
open Comp_ast
open Logic_core
open Logic_typing
open Comp_typing


(* HACK: ok, this should be a module really.
   anyway, this is meant to be a drop-in replacement for Comp_typing *)

let case_kind = case_kind
let elim_inst_cunif = elim_inst_cunif
let remove_infer_cterm = remove_infer_cterm
let subst_bound_ctx = subst_bound_ctx
let subst_bound = subst_bound
let get_cdef_term = get_cdef_term
let get_cdef_type = get_cdef_type
let flatten_closure = flatten_closure
let ctype_whnf = ctype_whnf
let ctype_whdelta = ctype_whdelta
let ctype_fullwhdelta = ctype_fullwhdelta
let add_to_metaenv = add_to_metaenv
let add_to_ctxenv = add_to_ctxenv
let add_to_compenv = add_to_compenv
let add_to_env = add_to_env
let env_len = env_len
let open_up = open_up
let close_down = close_down
let has_bound_var = has_bound_var
let open_up_2 = open_up_2
let close_down_2 = close_down_2
let ctype_equal = ctype_equal
let ctx_is_prefix = ctx_is_prefix
let ctype_sub = ctype_sub
let ctype_appmany_open = ctype_appmany_open
let ctype_appmany = ctype_appmany
let subst_fmeta = subst_fmeta
let subst_fmeta_in_env = subst_fmeta_in_env
let subst_fctx = subst_fctx
let subst_fctx_in_env = subst_fctx_in_env
let is_idsubst = is_idsubst
let many_add_to_env = many_add_to_env
let check_static = check_static
let check_env_static = check_env_static
let reifiable = reifiable

let guess_var t =
  match t with
      CHolTerm(_) -> (None, CHol)
    | CCtxTerm(_) | CSort(CCtx) -> (None, CCtx)
    | _ -> (None, CType)

let return env ?errmsg t expected =
  match expected with
      Some (t', errmsg') ->
	if ctype_sub env t t' then
	  t
	else 
	  (let err = match errmsg with None -> errmsg' | Some errmsg -> errmsg in
	   failwith err)
    | _ -> t


let rec type_of_cterm ((defenv, cdefenv, metaenv, ctxenv, compenv) as env) ?(expected=None) (e : cterm) =
  let return ?errmsg t = return env ?errmsg t expected in
  let mk_infer_under_binders vs =
    let (metan, ctxn, compn) = List.length metaenv, List.length ctxenv, List.length compenv in
    let (metabn, ctxbn, compbn) =
      List.fold_left
	(fun (metabn, ctxbn, compbn) v ->
	  case_kind ~case:v (metabn+1, ctxbn, compbn) (metabn, ctxbn+1, compbn) (metabn, ctxbn, compbn+1)) (0,0,0) vs
    in
    mk_cinfer compn compbn metan metabn ctxn ctxbn
  in
  match e with
      CSort(CType) -> return (CSort(CKind))
    | CSort(CKind) -> failwith "Kind does not have a classifier"
    | CSort(CCtx)  -> failwith "ctx is not part of the cterm language"
    | CSort(CHol)  -> failwith "HOL is not part of the cterm language"
    | CApp(CNVar(magic), t) when magic="magic" ->
	(match type_of_HOL env t with
	     CHolTerm(LTermInCtx(_, LSort(LProp))) -> return (CSigma((None,CHol), t, CUnitType))
	   | _ -> failwith "magic used wrongly")
    | CPi(var, t1, t2) ->
	(let t1_s = csort_of ~case:var env t1 in
	 let env' = add_to_env ~case:var t1 env in
	 let t2'  = open_up ~case:var env t2 in
	 let t2_s = csort_of_cterm env' t2' in
	   if List.mem (t1_s, t2_s) ctype_spec_abstractions then
	     return (CSort(t2_s))
	   else
	     failwith "non-allowed abstraction used")
    | CLambda(var, t1, e2) ->
        (let uv2 = mk_infer_under_binders [var] in
	 let realexp = CPi(var, t1, uv2) in
	 let _ = return ~errmsg:"was not expecting lambda function" realexp in
	 let exp2 = open_up ~case:var env uv2 in
	   
	 let _    = type_of_cterm env realexp in
	 let env' = add_to_env ~case:var t1 env in
	 let e2'  = open_up ~case:var env e2 in
	 let _   = type_of_cterm env' e2' ~expected:(Some (exp2, "body of lambda not of the right type")) in
	   return realexp)
    | CApp(e1, e2) ->
      (let var = guess_var e2 in
       let uva = mk_infer_under_binders [] in
       let uvb = mk_infer_under_binders [var] in
       let exp1 = (CPi(var, uva, uvb)) in
       let exp2 = uva in
       (* TODO: match uvb with expected if possible -- if we can figure out that Pi is just an arrow before hand *)

       let _ = type_of_cterm env e1 ~expected:(Some (exp1, "applying something to a non-functional type")) in
       let _ = type_of ~case:var env e2 ~expected:(Some (exp2, "types don't match in application")) in
       return (subst_bound ~case:var ~term:uvb ~subst:e2))

    | CHolTerm(t) ->
	failwith "HOL terms are not part of the cterm language"
    | CCtxTerm(t) ->
	failwith "ctx terms are not part of the cterm language"
    | CUnitType -> return (CSort(CType))
    | CUnitExpr -> return CUnitType
    | CSigma(var, t1, t2) ->
	(let t1_s = csort_of ~case:var env t1 in
	 let env' = add_to_env ~case:var t1 env in
	 let t2'  = open_up ~case:var env t2 in
	 let t2_s = csort_of_cterm env' t2' in
	   if List.mem (t1_s, t2_s) ctype_spec_existentials then
	     return (CSort(t2_s))
	   else
	     failwith "non-allowed existential type used")
    | CPack(t1, var, ret, e) ->
        (let uva = mk_infer_under_binders [] in
	 let uvb = mk_infer_under_binders [var] in
	 let realexp = return (CSigma(var, uva, uvb)) in
	 
	 let t1_t = type_of ~case:var env t1 ~expected:(Some (uva, "witness in existential of the wrong type")) in
	 let env' = add_to_env ~case:var t1_t env in
	 let _ = if not(ctype_equal env' (open_up ~case:var env ret)
			                 (open_up ~case:var env uvb)) then failwith "return type does not match the expected one" in
	 let _ = type_of_cterm env realexp in

	 let e_expected = subst_bound ~case:var ~term:uvb ~subst:t1 in
	 let _ = type_of_cterm env e ~expected:(Some (e_expected, "body of existential doesn't have expected type")) in
	 return realexp)

    | CUnpack(t1, var1, var2, e) ->
        (let uva = mk_infer_under_binders [] in
	 let uvb = mk_infer_under_binders [var1] in
	 let t1exp = CSigma(var1, uva, uvb) in
	 
	 let _ = type_of_cterm env t1 ~expected:(Some (t1exp, "unpacking a non-existential term")) in
	 let env' = add_to_env ~case:var1 uva env in
	 let tt2' = open_up ~case:var1 env uvb in
	 let env'' = add_to_env ~case:var2 tt2' env' in
	 let e' = open_up_2 ~case1:var1 ~case2:var2 env e in

	 let expected' = match expected with
	                  Some(t,s) -> Some(open_up_2 ~case1:var1 ~case2:var2 env t, s)
	                | None -> None
	 in
	 let e_t = close_down_2 ~case1:var1 ~case2:var2 env'' (type_of_cterm env'' e' ~expected:expected') in
	 if has_bound_var ~case:var1 0 e_t then
	   failwith "witness should not escape from existential unpacking"
	 else if csort_of_cterm env e_t = CType then
	   return e_t
	 else
	   failwith "unpacking inside non-computational term")
    | CBVar(i) -> failwith "type_of_cterm on a bound variable!"
    | CFVar(i) -> return (fst (List.nth compenv (List.length compenv - i - 1)))
    | CNVar(s) -> return (get_cdef_type s cdefenv)

    | CHolCase(ts,vars,ret,branches) ->
	(let check_one_scrutinee t =
	   let t_t = type_of_HOL env t in
	   let _ =
	     match t_t with
		 CHolTerm(LTermInCtx(_, LSort(_))) -> ()
	       | _ -> (match type_of_HOL env t_t with
			   CHolTerm(LTermInCtx(_, LSort(_))) -> ()
			 | _ ->failwith "cannot pattern match on proof objects!")
	   in
	     t_t
	 in
	
	 let ts_t = List.map check_one_scrutinee ts in
	 let env' = many_add_to_env vars ts_t env in
	 let open_in_env' = open_up ~case:(None, CHol) ~howmany:(List.length ts) env in

	 let ret' = open_in_env' ret in
	 let scrutinees = ts in

	 let env'' =
	   List.fold_left
	     (fun env' (i, scrutinee) ->
		subst_fmeta_in_env env' (open_in_env' scrutinee) (CHolTerm(LFMeta(List.length metaenv + i))))
	     env' (List.combine (increasing (List.length ts)) scrutinees)
	 in

	 let ret_s = csort_of_cterm env'' ret' in
	 let ret_f ts = MetabindCtermS.subst_bound_list (List.map (function CHolTerm(t) -> t | _ -> failwith "ret_f") ts) ret in

	 let _ = return ~errmsg:"holcase return type does not match the expected one" (ret_f ts) in

	   if ret_s = CType then
	     (let _ = List.iter (check_branch env ts_t scrutinees ret_f) branches in
		return (ret_f ts))
	   else
	     failwith "matching on HOL terms is only allowed for computational terms")

    | CCtxCase(t,var,ret,branches) ->
	(let t_t = type_of_ctx env t in
	 let env' = add_to_env ~case:var t_t env in
	 let ret' = open_up ~case:var env ret in

	 let scrutineevar = t in
	 let env'' = subst_fctx_in_env env' (open_up ~case:var env scrutineevar) (CCtxTerm(LFCtx(env_len ~case:var env))) in

	 let ret_s = csort_of_cterm env'' ret' in
	 let ret_f t = subst_bound ~case:var ~term:ret ~subst:t in
	 let _ = return ~errmsg:"ctxcase return type does not match the expected one" (ret_f t) in

	   if ret_s = CType then
	     (let _ = List.iter (check_ctxbranch env scrutineevar ret_f) branches in
		return (ret_f t))
	   else
	     failwith "matching on context terms is only allowed for computational terms")

    | CProdType(t1,t2) ->
	(if ctype_equal env (type_of_cterm env t1) (CSort(CType)) &&
	    ctype_equal env (type_of_cterm env t2) (CSort(CType)) then
	   return (CSort(CType))
	 else
	   failwith "product type with non-product terms")
    | CTuple(e1,e2) ->
        (let uv1 = mk_infer_under_binders [] in
	 let uv2 = mk_infer_under_binders [] in
	 let exp' = CProdType(uv1, uv2) in
	 let _ = return exp' ~errmsg:"was not expecting tuple!" in

	 let _ = type_of_cterm env e1 ~expected:(Some (uv1, "first term in tuple of wrong type")) in
	 let _ = type_of_cterm env e2 ~expected:(Some (uv2, "second term in tuple of wrong type")) in
	 let _ = type_of_cterm env exp' in
	   return exp')
    | CProj(i,e) ->
	(let uv1 = mk_infer_under_binders [] in
	 let uv2 = mk_infer_under_binders [] in
	 let exp' = CProdType(uv1, uv2) in
	 let _ = type_of_cterm env e ~expected:(Some (exp', "proj on non-tuple")) in
	 (if i = 1 then return uv1
	  else if i = 2 then return uv2
	  else failwith "proj with invalid index"))

    | CRecType(var, k, t, _) ->
	(let _ = if csort_of_cterm env k = CKind then () else failwith "recursive type's kind is not CKind" in
	 let env' = add_to_env ~case:var k env in
	 let t' = open_up ~case:var env t in

	 let _ = return k ~errmsg:"was not expecting this kind" in
	 let _ = type_of_cterm env' t' ~expected:(Some (open_up ~case:var env k, "recursive type's definition does not match expected kind")) in
	 return k)
    | CFold(e1, t2) ->
        (let _ = return t2 ~errmsg:"was expecting other type!" in
         let _ = type_of_cterm env t2 in
	 let t2base, t2args = ctype_appmany_open (ctype_fullwhdelta cdefenv t2) in
	 
	   match t2base with
	     CRecType(var, k, t, _) ->
	       (let t1exp = ctype_appmany (subst_bound ~case:var ~subst:t2base ~term:t) t2args in
	       let _ = type_of_cterm env e1 ~expected:(Some (t1exp, "fold applied to invalid instantiation of recursive type")) in
	       return t2)
	     | _ ->
		 failwith "fold with non-recursive type")
    | CUnfold(e1) ->
	(let t1 = type_of_cterm env e1 in
	 let t1base, t1args = ctype_appmany_open (ctype_fullwhdelta cdefenv t1) in
	   match t1base with
	       CRecType(var, k, t, _) ->
		 return (ctype_appmany (subst_bound ~case:var ~subst:t1base ~term:t) t1args)
	     | _ ->
		 failwith "unfold with non-recursive type argument")

    | CSumType(branches, _) ->
	(let checkbranch branch = ctype_equal env (type_of_cterm env branch) (CSort CType) in
	   if List.for_all checkbranch branches then
	     return (CSort(CType))
	   else
	     failwith "there is a branch with non-computational type")
    | CCtor(i,t,par) ->
	(let _ = return t ~errmsg:"wrong type!" in
	 let t' = ctype_fullwhdelta cdefenv t in
	   match t' with
	       CSumType(branches, _) ->
		 let branch_t = List.nth branches i in
		 let _ = type_of_cterm env par ~expected:(Some (branch_t, "parameter of constructor is not of the right type")) in
		 return t
	     | _ -> failwith "constructor used with non-sum type")
    | CMatch(e,branches) ->
        (let uvconstr = List.map (fun _ -> mk_infer_under_binders []) branches in
	 let e_exp = CSumType(uvconstr, ref None) in
	 let uv = mk_infer_under_binders [(None,CType)] in
	 let _ = return uv in
	 
	 let _ = type_of_cterm env e ~expected:(Some (e_exp, "match on term of non-sum type")) in

	 let checkbranch (var,body) constr_t =
	   let env' = add_to_env ~case:var constr_t env in
	   let body' = open_up ~case:var env body in
	   let _ = type_of_cterm env' body' ~expected:(Some (uv, "branch does not match expected type")) in
	   ()
	 in
	 let _ = List.iter2 checkbranch branches uvconstr in
	 let env' = add_to_env ~case:(None,CType) (CSort(CType)) env in
	 let uv' = close_down ~case:(None,CType) env' uv in
	 let _ = if not (ctype_equal env (type_of_cterm env uv') (CSort(CType))) then failwith "match with non-computational type as result" in
	   return uv')

    | CLetRec(defs, e) ->
	(let n = List.length defs in
	 let envlen = List.length compenv in
	 let envlen' = n + envlen in
	 let check_def_type (_,t,_) = if not (ctype_equal env (type_of_cterm env t) (CSort(CType))) then failwith "letrec with non-computational type of definition" in
	 let _ = List.iter check_def_type defs in
	 let env' = List.fold_left (fun env (var,t,_) -> add_to_env ~case:var t env) env defs in
	 let check_def (_,t,e) =
	   let e' = CbindCterm.open_up ~howmany:n envlen e in
	   let t' = CbindCterm.open_up ~howmany:n envlen t in
	   let _ = type_of_cterm env' e' ~expected:(Some (t', "definition in letrec has wrong type!")) in
	   ()
	 in
	 let _ = List.iter check_def defs in

	 let uv = mk_infer_under_binders (List.map (fun _ -> (None,CType)) defs) in
	 let _ = return uv ~errmsg:"!! error in typechecker" in
	 let uv' = CbindCterm.open_up ~howmany:n envlen uv in

	 let e_t = CbindCterm.close_down ~howmany:n envlen' (type_of_cterm env' (CbindCterm.open_up ~howmany:n envlen e) ~expected:(Some (uv', "expecting different type in letrec body!"))) in
	   if ctype_equal env (type_of_cterm env e_t) (CSort CType) then
	     return e_t
	   else
	     failwith "letrec returning non-computational term")
    | CLet(v,d,e) ->
	(let d_t = type_of ~case:v env d in
	 let e_t = 
	   if ctype_equal env (type_of_cterm env d_t) (CSort(CType)) then
	     (let env' = add_to_env ~case:v d_t env in
	      let uv = mk_infer_under_binders [v] in
	      let _  = return uv ~errmsg:"!! error in typechecker" in
	      let uv' = open_up ~case:v env uv in
		close_down ~case:v env' (type_of_cterm env' (open_up ~case:v env e) ~expected:(Some (uv', "body of let does not match expected type"))))
	   else
	     (type_of_cterm env (subst_bound ~case:v ~subst:d ~term:e) ~expected:expected)
	 in
	      if ctype_equal env (type_of_cterm env e_t) (CSort CType) then
		return e_t
	      else
		failwith "let returning non-computational term")

    | CRefType(t) ->
	(let _ = check_computational env t in return (CSort(CType)))
    | CMkRef(e,t') ->
        (let uv = mk_infer_under_binders [] in
	 let _  = return (CRefType(uv)) ~errmsg:"was not expecting a reference" in
	 let t = type_of_cterm env e ~expected:(Some (uv, "wrong type in reference")) in
	 let _ = check_computational env t in
	   if ctype_equal env t t' then
	     return (CRefType(t))
	   else
	     failwith "designated ref type doesn't match the value")
    | CAssign(e1,e2) ->
	(let uv = mk_infer_under_binders [] in
	 let _ = type_of_cterm env e1 ~expected:(Some (CRefType(uv), "expected reference type")) in
	 let _ = type_of_cterm env e2 ~expected:(Some (uv, "in reference assignment, assigned term does not match reference type")) in
	 return CUnitType)
    | CReadRef(e) ->
	(let t = ctype_fullwhdelta cdefenv (type_of_cterm env e) in
	   match t with
	       CRefType(t) -> return t
	     | _ -> failwith "dereferencing a non-reference")
    | CLoc(l,t) -> return (CRefType(t))
    | CSeq(e1,e2) ->
	(let _ = type_of_cterm env e1 ~expected:(Some (CUnitType, "sequencing non unit-typed expression")) in
	 let t2 = type_of_cterm env e2 in
	 let _ = check_computational env t2 in
	   return t2)

    | CIntType -> return (CSort(CType))
    | CIntConst(i) -> return CIntType
    | CStringType -> return (CSort(CType))
    | CStringConst(s) -> return CStringType
    | CIntOp(o,e1,e2) ->
	(ensure_type_is env CIntType e1;
	 ensure_type_is env CIntType e2;
	 return CIntType)
    | CIntTest(o,e1,e2) ->
	(ensure_type_is env CIntType e1;
	 ensure_type_is env CIntType e2;
	 return CBoolType)
    | CBoolType -> return (CSort(CType))
    | CBoolConst(b) -> return CBoolType
    | CBoolOp(o,e1,e2) ->
	(ensure_type_is env CBoolType e1;
	 ensure_type_is env CBoolType e2;
	 return CBoolType)
    | CIfThenElse(e1,e2,e3) ->
	(ensure_type_is env CBoolType e1;
	 let t2 = type_of_cterm env e2 ~expected:expected in
	 let t3 = type_of_cterm env e3 ~expected:expected in
	   check_computational env t2;
	   if ctype_equal env t2 t3 then
	     return t2
	   else
	     failwith "types of if-branches do not match")

    | CArrayType(t) ->
	check_computational env t;
	return (CSort(CType))

    | CArrayLit(ts,t) ->
	(let _ = List.iter (fun e -> if not (ctype_equal env (type_of_cterm env e) t) then failwith "array literal's members do not agree on type") ts in
	   return (CArrayType(t)))

    | CMkArray(e1,e2,t_exp) ->
	  ensure_type_is env CIntType e1;
	  check_computational env t_exp;
	  ensure_type_is env t_exp e2;
	  return (CArrayType(t_exp))

    | CArrayGet(e1,e2) ->
	(let t1 = ctype_fullwhdelta cdefenv (type_of_cterm env e1) in
	  ensure_type_is env CIntType e2;
	  match t1 with
	      CArrayType(t) -> return t
	    | _ -> failwith "array type expected when indexing array")

    | CArraySet(e1,e2,e3) ->
	(let t1 = ctype_fullwhdelta cdefenv (type_of_cterm env e1) in
	  ensure_type_is env CIntType e2;
	  match t1 with
	      CArrayType(t) ->
		let _ = type_of_cterm env e3 ~expected:(Some (t, "assigning different-type value to array index")) in
		return CUnitType
	    | _ -> failwith "array type expected when indexing array")

    | CArrayLen(e) ->
	(let t = ctype_fullwhdelta cdefenv (type_of_cterm env e) in
	  match t with
	      CArrayType(_) -> return CIntType
	    | _ -> failwith "array type expected when using arraylen")

    | CArrayLoc(_,t) -> return (CArrayType(t))

    | CHolHash(e) ->
	(let t = type_of_cterm env e in
	   check_computational env t;
	   return CIntType)

    | CPrint(e) ->
	(let t = type_of_cterm env e in
	   check_computational env t;
	   return CUnitType)

    | CClosure(subst, e) ->
	(let (_,_,metaenv',ctxenv',compenv') as env' = env_from_subst defenv cdefenv subst in
	 let (<.>) = compose in
	 let e' = ((MetabindCterm.open_up ~howmany:(List.length metaenv') 0) <.>
	            (CtxbindCterm.open_up ~howmany:(List.length ctxenv') 0) <.>
		    (CbindCterm.open_up ~howmany:(List.length compenv') 0)) e in
	  return (type_of_cterm env' e'))

    | CTypeAscribe(e, t) ->
        (let _ = return t in
	 let _ = type_of_cterm env t in
	 let _ = type_of_cterm env e ~expected:(Some (t, "type ascription does not match type")) in
	 return t)

(*
    | CPiStatic(var, t1, t2) ->
	(let _ = check_static env t1 in
	 let t1_s = csort_of ~case:var env t1 in
	 let env' = add_to_env ~case:var ~static:true t1 env in
	 let t2'  = open_up ~case:var env t2 in
	 let _ = check_static env' t2' in
	 let t2_s = csort_of_cterm env' t2' in
	   if reifiable cdefenv t1 && t1_s = CType && t2_s = CType then
	     CSort(t2_s)
	   else
	     failwith "non-allowed static abstraction used")

    | CLambdaStatic(var, t1, e2) ->
	(let _ = check_env_static compenv ; check_env_static metaenv ; check_env_static ctxenv in
         let uv2 = mk_infer_under_binders [var] in
	 let realexp = CPiStatic(var, t1, uv2) in
	 let _ = return ~errmsg:"was not expecting static lambda function" realexp in
	 let exp2 = open_up ~case:var env uv2 in
	   
	 let _    = type_of_cterm env realexp in
	 let env' = add_to_env ~case:var ~static:true t1 env in
	 let e2'  = open_up ~case:var env e2 in
 	 let _    = check_static env' e2' in
	 let _    = type_of_cterm env' e2' ~expected:(Some (exp2, "body of static lambda not of the right type")) in
	   return realexp)

    | CApplyStatic(e1, e2) ->
      (let var = guess_var e2 in
       let uva = mk_infer_under_binders [] in
       let uvb = mk_infer_under_binders [var] in
       let exp1 = (CPiStatic(var, uva, uvb)) in
       let exp2 = uva in

       let _ = type_of_cterm env e1 ~expected:(Some (exp1, "applying something to a non static functional type")) in
       let _ = check_static env e2 in
       let _ = type_of ~case:var env e2 ~expected:(Some (exp2, "types don't match in static application")) in
       return (subst_bound ~case:var ~term:uvb ~subst:e2))
*)

    | CStaticDo(e) ->
      (let _ = check_static env e in
       let tp = type_of_cterm env ~expected:expected e in
       let _ = type_of_cterm env ~expected:(Some (CSort(CType), "static used with non-computational term")) tp in
       if reifiable cdefenv tp then
	 (check_computational env tp; return tp)
       else
	 failwith "static do with non reifiable type")

    | CPrfErase(e) ->
      (let tp = type_of_cterm env ~expected:expected e in
       check_computational env tp; tp)

    | CInfer(el, f) ->
	(match !(match_cunif el) with
	     Inst(ei,ti) ->
	       (let t' = type_of_cterm env (f ei) in
		  if (match !ti with Some ot -> ctype_equal env t' (CInfer(ot,f)) | _ -> true) then
		    return t'
		  else
		    failwith "instantiation of inferred term with wrong type!")
	   | Uninst(i,otyp) ->
	       (match !otyp with
		    None -> (let uv = mk_cunifvar () in otyp := (Some uv); CInfer(uv, f))
		  | Some ti -> return (CInfer(ti, f))))
	               
	
and ensure_type_is ((defenv,cdefenv,_,_,_) as env) t e = 
  ignore (type_of_cterm env e ~expected:(Some (t,"expected another type")))
    
and check_computational ((defenv,cdefenv,_,_,_) as env) t =

  if not (ctype_equal env (type_of_cterm env t) (CSort(CType))) then failwith "computational type expected"

and check_pattern (defenv, _, _, _, _) metas t =

  (let ctx, tm = match t with CHolTerm(LTermInCtx(ctx,tm)) -> ctx, tm | _ -> failwith "patterns should be terms-in-context" in
     Logic_typing.check_pattern defenv ctx (List.length metas) tm)
	 
and check_branch ((defenv, cdefenv, metaenv, ctxenv, compenv) as env) typs scrutinees ret_f (pats, e) =
  
  let open_up_meta n = MetabindCterm.open_up ~howmany:n (List.length metaenv) in

  let replace_scrutinees_in_env open_up env scrutinees ts =
    List.fold_left
      (fun env (scrutinee, t) -> subst_fmeta_in_env env (open_up scrutinee) t)
      env (List.combine scrutinees ts)
  in

  let replace_scrutinees_in_tm open_up scrutinees ts tm =
    List.fold_left
      (fun tm (scrutinee, t) -> subst_fmeta (open_up scrutinee) t tm)
      tm (List.combine scrutinees ts)
  in

  let check_branchpattern env scrutinees typs pats = 
    ExtList.midfold
      (fun scrutinees_typs_pats (scrutinee,(typ,(metas,t))) (env, ncur, ts) ->
	 let nmetas = List.length metas in
	 let scrutinees, typs_pats = List.split scrutinees_typs_pats in
	 let env', _ = List.fold_left
	   (fun (env, i) (var,typ) ->
	      let open_up_in_env = open_up_meta (ncur + i) in
	      let typ' = open_up_in_env typ in
	      let _ = type_of_HOL env typ' in
	      let env' = add_to_env ~case:var typ' env in
		(env', i + 1))
	   (env, 0) metas
	 in
	 let open_up_in_env' = open_up_meta (ncur + nmetas) in
	 let t' = open_up_in_env' t in
	 let env'' = replace_scrutinees_in_env open_up_in_env' env' scrutinees ts in
	 let t_typ = type_of_HOL env'' t' in
	 let _ = check_pattern env' metas t in
	 let typ' = replace_scrutinees_in_tm open_up_in_env' scrutinees ts typ in
	   (if ctype_equal env' t_typ typ' then
	      ()
	    else
	      failwith "type of pattern is not the expected one");
	   (env', ncur + nmetas, List.append ts [open_up_in_env' t]))
      (List.combine scrutinees (List.combine typs pats))
      (env, 0, [])
  in

  let env', ncur, ts = check_branchpattern env scrutinees typs pats in
  let open_up_in_env' = open_up_meta ncur in
  let env'' = replace_scrutinees_in_env open_up_in_env' env' scrutinees ts in

  let e' = replace_scrutinees_in_tm open_up_in_env' scrutinees ts (open_up_in_env' e) in
  let _ = type_of_cterm env'' e' ~expected:(Some (ret_f ts, "type of body of branch is not the expected one")) in
  ()


and check_ctxbranch ((defenv, cdefenv, metaenv, ctxenv, compenv) as env) scrutineevar ret_f (ctxvs, metas, t, e) =

  let open_up_ctx  n = CtxbindCterm.open_up ~howmany:n (List.length ctxenv) in
  let open_up_meta n = MetabindCterm.open_up ~howmany:n (List.length metaenv) in

  let env' = List.fold_left (fun env v -> add_to_env ~case:v (CSort(CCtx)) env) env ctxvs in
  let cn = List.length ctxvs in
  let metas' = ExtList.sndmap (open_up_ctx cn) metas in

  let env', n = List.fold_left (fun (env, n) (var, typ) ->
				  let typ' = open_up_meta n typ in
				  let _ = type_of_HOL env typ' in
				  let env' = add_to_env ~case:var typ' env in
				    (env', n+1)) (env',0) metas' in
  let t' = open_up_meta n (open_up_ctx cn t) in
  let _ = type_of_ctx env' t' in
  let _ = match t with CCtxTerm(LCtxAsList(l)) -> check_context_pattern env (List.length ctxenv) ctxvs metas l | _ -> failwith "only context lists allowed in context branches" in
  let e' = open_up_meta n (open_up_ctx cn e) in

  let env'' = subst_fctx_in_env env' (open_up_ctx cn scrutineevar) t' in
  let e'' = subst_fctx (open_up_ctx cn scrutineevar) t' e' in

  let e_exp = open_up_meta n (open_up_ctx cn (ret_f t)) in
  let _ = type_of_cterm env'' e'' ~expected:(Some (e_exp,"type of body of branch is not the expected one"))  in
  ()

and env_from_subst defenv cdefenv (metasubst,ctxsubst,compsubst) =
  let metaenv = List.map (fun t -> type_of_modal ([], defenv, [], []) t, false) metasubst in
  let ctxenv  = List.map (fun t -> ctx_wf ([], defenv, [], []) t, false) ctxsubst in
  let compenv = List.map (fun t -> type_of_cterm (defenv, cdefenv, [], [], []) t, false) compsubst in
    (defenv, cdefenv, metaenv, ctxenv, compenv)

and type_of_HOL ((defenv, cdefenv, metaenv, ctxenv, compenv) as env) ?(expected=None) (e : cterm) =
  let return t = return env t expected in
  let errmsg, expected = match expected with 
                           Some(CHolTerm(t),s) -> s, (Some t)
			 | Some(CInfer(_,_),_) -> "", None
                         | Some(_,_) -> failwith "expected non-HOL type from HOL term"
			 | _ -> "", None
  in
  match elim_inst_cunif e with
      CHolTerm(t) ->
	(let metaenv = List.map fst metaenv in
	 let ctxenv = List.map fst ctxenv in
	 let tp =
	   try
	     Logic_typinf.type_of_modal ([], defenv, metaenv, ctxenv) ~expected:expected t 
	   with LTermsNotEqual -> failwith errmsg
	 in
	 return (CHolTerm(tp)))
    | _ -> failwith "non-HOL term in HOL position"

and csort_of_HOL (defenv, cdefenv, metaenv, ctxenv, compenv) (e : cterm) =
  match elim_inst_cunif e with
      CHolTerm(LTermInCtx(_,_) as t) ->
	(let metaenv = List.map fst metaenv in
	 let ctxenv = List.map fst ctxenv in
	 nowarn let LTermInCtx(_, s) = Logic_typinf.type_of_modal ([], defenv, metaenv, ctxenv) t in
	 let _ = match whnf defenv s with LSort(_) -> () | LInfer(_,_) -> () | _ -> failwith "type of modal in abstractor is not a sort" in
	 CHol)
    | CHolTerm(_) -> failwith "metavariables are not allowed as types of metavariables"
    | _ -> failwith "non-HOL term in HOL abstractor position"
and type_of_ctx (defenv, cdefenv, metaenv, ctxenv, compenv) ?(expected=None) (e : cterm) =
  match elim_inst_cunif e with
      CCtxTerm(t) -> (let metaenv = List.map fst metaenv in
	 let ctxenv = List.map fst ctxenv in
	 let _ = Logic_typinf.ctx_wf ([], defenv, metaenv, ctxenv) t in CSort(CCtx))
    | _ -> failwith "non-context term in context position"
and csort_of_ctx (defenv, cdefenv, metaenv, ctxenv, compenv) (e : cterm) =
  match elim_inst_cunif e with
    | CSort(CCtx) -> CCtx
    | CInfer(l,f) ->
      (let l = match_cunif l in
       match !(match_cunif l) with
	  Inst(CSort(CCtx), _) -> CCtx
	| Uninst(_,otyp) -> l := Inst( CSort(CCtx) , otyp ); CCtx
	| _ -> failwith "non-context term in context abstractor position")
    | _ -> failwith "non-context term in context abstractor position"
and csort_of_cterm ((defenv, cdefenv, metaenv, ctxenv, compenv) as env) (e : cterm) =
  let t = type_of_cterm env e in
  if ctype_equal env t (CSort(CType)) then
    CType
  else if ctype_equal env t (CSort(CKind)) then
    CKind
  else
  (* match ctype_fullwhdelta cdefenv (type_of_cterm env e) with *)
  (*     CSort(CType) -> CType *)
  (*   | CSort(CKind) -> CKind *)
  (*   | _ -> let _ = ctype_equal  *)
  (*   | _ -> *) failwith "non-allowed classifier in computational abstractor position"
and csort_of ~case:s env t = case_kind csort_of_HOL csort_of_ctx csort_of_cterm ~case:s env t
and type_of  ~case:s env ?expected t = case_kind type_of_HOL type_of_ctx type_of_cterm ~case:s env ?expected:expected t

(*
let type_of ~case:a b ?expected c = repeatmany 2 (fun () -> type_of ~case:a b ?expected:expected c)

let type_of_cterm_expected 
*)

(*
let cterm_def_add = cterm_def_add
let cterm_def_add_trusted = cterm_def_add_trusted
let comp_print_type = comp_print_type
let comp_global_env = comp_global_env
let comp_global_reset = comp_global_reset
let comp_global_reset_all = comp_global_reset_all
let comp_global_delete = comp_global_delete
let comp_global_save = comp_global_save
let comp_global_import = comp_global_import
let comp_print = comp_print
let comp_print_type = comp_print_type

let comp_gettype ?(expected=None) tm =
  let case = match tm with CHolTerm(_) -> (None, CHol) | CCtxTerm(_) -> (None, CCtx) | _ -> (None, CType) in
  let expected = match expected with Some e -> Some (e, "Type of computational term is not the expected one!") | _ -> None in
  let tp = type_of ~case:case (!Logic_main.logic_global_env, !comp_global_env, [], [], []) ~expected:expected tm in
  let tp = remove_infer_cterm tp in
  let tm = remove_infer_cterm tm in
  (tp, tm)

*)
