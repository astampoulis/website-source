(* This file is a modification of the camlp4 toploop code shipped with
   OCaml. The original file was under the LGPL license version 2; we
   have changed the license to GPL v3, which is permissible under the
   terms of LGPL v2 (clause 3).  -Antonis *)

(****************************************************************************)
(*                                                                          *)
(*                              Objective Caml                              *)
(*                                                                          *)
(*                            INRIA Rocquencourt                            *)
(*                                                                          *)
(*  Copyright 2002-2006 Institut National de Recherche en Informatique et   *)
(*  en Automatique.  All rights reserved.  This file is distributed under   *)
(*  the terms of the GNU General Public License version 3.                  *)
(*                                                                          *)
(****************************************************************************)

(* Authors:
 * - Daniel de Rauglaudre: initial version
 * - Nicolas Pouillard: refactoring
 * - Antonis Stampoulis: adaptation to VeriML
 *)

module CompGram = Syntax_trans_comp.CompGram

let _ = Config.interactive := true ;;

let _ =
  let current_printer = !Toploop.print_out_phrase in
  let new_printer ppf out =
    match out with
	Outcometree.Ophr_exception _ -> current_printer ppf out
      | _ -> if !Config.suppress_ocaml_replies then () else current_printer ppf out
  in
  Toploop.print_out_phrase := new_printer
;;

module Toploop : sig
  val print_location :
    Format.formatter -> Camlp4_import.Location.t -> unit
  val print_warning :
    Camlp4_import.Location.t -> Format.formatter -> Camlp4_import.Warnings.t -> unit
  val parse_toplevel_phrase :
    (Lexing.lexbuf -> Camlp4_import.Parsetree.toplevel_phrase) ref
  val parse_use_file :
    (Lexing.lexbuf -> Camlp4_import.Parsetree.toplevel_phrase list) ref
end = struct
  let print_location fmt loc =
    Toploop.print_location fmt (Obj.magic loc);;
  let parse_toplevel_phrase =
    Obj.magic Toploop.parse_toplevel_phrase;;
  let parse_use_file =
    Obj.magic Toploop.parse_use_file;;
  let print_warning loc fmt w =
    Toploop.print_warning (Obj.magic loc) fmt (Obj.magic w);;
end;;

open Camlp4_import.Parsetree;;
open Lexing;;
open Camlp4;;
open PreCast;;
open Syntax;;
open Camlp4.Sig;;
module Ast2pt = Camlp4.Struct.Camlp4Ast2OCamlAst.Make(Ast);;
module Lexer = Camlp4.Struct.Lexer.Make(CompGram.Token);;

external not_filtered : 'a -> 'a CompGram.not_filtered = "%identity";;


let initialization = lazy begin
  if !Sys.interactive
    then Format.printf "\tVeriML version 0.5\n@."
    else ()
end;;


let lookup x xs = try Some (List.assq x xs) with Not_found -> None ;;

let wrap parse_fun =
  let token_streams = ref [] in
  let cleanup lb =
    try token_streams := List.remove_assq lb (!token_streams)
    with Not_found -> ()
  in
  fun lb ->
    let () = Lazy.force initialization in
    let () = Register.iter_and_take_callbacks (fun (_, f) -> f ()) in
    let token_stream =
      match lookup lb !token_streams with
        None ->
        let not_filtered_token_stream = Lexer.from_lexbuf lb in
        let token_stream = CompGram.filter (not_filtered not_filtered_token_stream) in
        begin token_streams := (lb,token_stream) :: !token_streams ; token_stream end
      | Some token_stream -> token_stream
    in try
      match token_stream with parser
        [< '(EOI, _) >] -> raise End_of_file
      | [< >] -> parse_fun token_stream 
    with
      End_of_file | Sys.Break | Loc.Exc_located (_, End_of_file) | Loc.Exc_located(_, Sys.Break)
        as x -> (cleanup lb; raise x)
    | x ->
        let x =
          match x with
          Loc.Exc_located(loc, x) -> begin 
            Toploop.print_location Format.err_formatter
              (Loc.to_ocaml_location loc);
            x end
          | x -> x 
        in
        begin
          cleanup lb;
          Format.eprintf "@[<0>%a@]@." Camlp4.ErrorHandler.print x;
          raise Exit
        end  ;;



let rec veriml_use_file loc s =
  let main_parse = CompGram.parse Syntax_trans_comp.veriml_file in
  let rec loop loc cs =
    match main_parse loc cs with
	( l, None ) ->
	  
	  let _loc = loc in
	  List.fold_left
	    (fun stritem phrase ->
	       let s = Comp_translate.translate_phrase phrase in
		<:str_item< $stritem$ ;; $s$ >> )
	     <:str_item< >>
	    l

      | ( [ Phrases.PhrNeed(s', _) ] , Some loc' ) ->

	  (let stritem = veriml_use_file loc' s' in
	   let next = loop loc' cs in
	   let _loc = loc in
	     <:str_item< $stritem$ ;; $next$ >> )

      | _ -> failwith "not handled yet"
  in

  let bytefile = "_compiled/" ^ s ^ ".cma" in

  if Sys.file_exists bytefile then

    let str_item = Comp_translate.translate_phrase (Phrases.PhrNeed(s, loc)) in
    let _loc = loc in
    let bytename = s ^ ".cma" in
    let modulename = String.capitalize s in
    let _ = Comp_env.dynamic_env_reset () in
    Topdirs.dir_load Format.std_formatter bytename ;
    <:str_item< $str_item$ ;; include $uid:modulename$ >> 

  else if Utils.Dict.mem s !Config.loaded_files then

    let str_item = Comp_translate.translate_phrase (Phrases.PhrGlobalImport(s, loc)) in
    str_item

  else
    (let channel = open_in_bin ( s ^ ".veriml" ) in
     let locnew = Loc.mk s in
     let cs = Stream.of_channel channel in
     let _loc = loc in
     let stritem = loop locnew cs in
     <:str_item< $stritem$ ;;
                 let _ = Config.loaded_files := Utils.Dict.add $str:s$ () (!Config.loaded_files) >> )


let emit str_item =
  let str_item = AstFilters.fold_topphrase_filters (fun t filter -> filter t) str_item in
  Ast2pt.phrase str_item

module Printer = struct
  open Camlp4_import.Parsetree;;
  open Lexing;;
  open Camlp4;;
  open PreCast;;
  open Camlp4.Sig;;
  module Ast2pt = Camlp4.Struct.Camlp4Ast2OCamlAst.Make(Ast);;
  module Lexer = Camlp4.Struct.Lexer.Make(Token);;
  module Printer = Camlp4.Printers.OCaml.Make(Camlp4.PreCast.Syntax);;

  let printer = (new Printer.printer ())#implem
end;;

let ocaml_printer str_item =
  Printer.printer Format.str_formatter str_item;
  Format.flush_str_formatter ()


let veriml_phrase token_stream =
  match CompGram.parse_tokens_after_filter Syntax_trans_comp.veriml_phrase token_stream with

    | Some (Phrases.PhrNeed(s,loc)) ->

      let str_item = veriml_use_file loc s in
      (* let ocaml_ast = ocaml_printer str_item in *)
      (* let str_item = let _loc = loc in <:str_item< let _ = Format.printf "%s@." $str:ocaml_ast$ ;; $str_item$ >> in *)
      emit str_item

    | Some (Phrases.PhrFullReset(loc) as phrase) ->
      (let str_item1 = Comp_translate.translate_phrase phrase in
       let str_item = let _loc = loc in <:str_item< $str_item1$ ;; Config.loaded_files := Utils.Dict.empty >> in
       emit str_item)

    | Some phr ->
      let str_item = Comp_translate.translate_phrase phr in

      (* let stritemprint = ocaml_printer str_item in *)
      (* let _loc = Loc.ghost in *)
      (* let str_item = <:str_item< let _ = Format.printf "%s@." $str:stritemprint$ ;;  >> in *)
      emit str_item

    | None -> raise End_of_file ;;


let _ = Topdirs.dir_directory "_build";;
let _ = Topdirs.dir_directory "_compiled";;
let _ = (let _loc = Loc.ghost in Comp_ocamlast.Staging.stage_string "#warnings \"a\";;")
let _ = Toploop.parse_toplevel_phrase := wrap veriml_phrase;;


let parse_cmdline () =
  Arg.parse Config.arg_spec (fun _ -> ()) ""

let _ = parse_cmdline (); Topmain.main (); exit 0
