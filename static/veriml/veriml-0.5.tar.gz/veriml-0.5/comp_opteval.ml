open Utils
open Binding
open Logic_ast
open Comp_ast
open Comp_typing (* this was Comp_typinf *)
open Format
open Comp_print

let openin (_,_,metaenv,ctxenv,compenv) t =
  MetabindCterm.open_up ~howmany:(List.length metaenv) 0
    (CtxbindCterm.open_up ~howmany:(List.length ctxenv) 0
       (CbindCterm.open_up ~howmany:(List.length compenv) 0 t))

let closedown (_,_,metaenv,ctxenv,compenv) t =
  MetabindCterm.close_down ~howmany:(List.length metaenv) (List.length metaenv)
    (CtxbindCterm.close_down ~howmany:(List.length ctxenv) (List.length ctxenv)
       (CbindCterm.close_down ~howmany:(List.length compenv) (List.length compenv) t))

let withtype v t ((_,cdefenv,_,_,_) as env) f =
  case_kind ~case:v
    (fun () -> f (ctype_fullwhdelta cdefenv (type_of_HOL env (openin env t))))
    (fun () -> f (ctype_fullwhdelta cdefenv (type_of_ctx env (openin env t))))
    (fun () -> f (ctype_fullwhdelta cdefenv (type_of_cterm env (openin env t))))
    ()

let
    cterm_map_env
              ?(csort   = fun s -> CSort(s))
              ?(cpi     = fun env v t1 t2 rt1 rt2 -> CPi(v,rt1,rt2))
	      ?(clambda = fun env v t1 t2 rt1 rt2 -> CLambda(v,rt1,rt2))
	      ?(capp    = fun env t1 t2 rt1 rt2 -> CApp(rt1,rt2))
	      ?(cholterm = fun _ t -> CHolTerm(t))
	      ?(cctxterm = fun t -> CCtxTerm(t))
	      ?(cbvar    = fun env i -> CBVar(i))
	      ?(cfvar    = fun i -> CFVar(i))
	      ?(cnvar    = fun i -> CNVar(i))
	      ?(cunitexpr = fun () -> CUnitExpr)
	      ?(cunittype = fun () -> CUnitType)
	      ?(csigma    = fun v t1 t2 rt1 rt2 -> CSigma(v,rt1,rt2))
	      ?(cpack     = fun t1 v t2 t3 rt1 rt2 rt3 -> CPack(rt1,v,rt2,rt3))
	      ?(cunpack   = fun t1 v1 v2 t2 rt1 rt2 -> CUnpack(rt1,v1,v2,rt2))
              ?(cholcase  = fun t1 v1 t2 branches rt1 rt2 rtbranches -> CHolCase(rt1,v1,rt2,rtbranches))
              ?(cctxcase  = fun t1 v1 t2 branches rt1 rt2 rtbranches -> CCtxCase(rt1,v1,rt2,rtbranches))
              ?(cprodtype = fun t1 t2 rt1 rt2 -> CProdType(rt1,rt2))
              ?(ctuple    = fun t1 t2 rt1 rt2 -> CTuple(rt1,rt2))
              ?(cproj     = fun i t1 rt1 -> CProj(i,rt1))
              ?(crectype  = fun v t1 t2 rt1 rt2 s -> CRecType(v,rt1,rt2,s))
              ?(csumtype  = fun ts rts s -> CSumType(rts,s))
              ?(cfold     = fun t1 t2 rt1 rt2 -> CFold(rt1,rt2))
              ?(cunfold   = fun env t1 rt1 -> CUnfold(rt1))
              ?(cctor     = fun env i t p rt rp -> CCtor(i,rt,rp))
              ?(cmatch    = fun env t branches rt rtbranches -> CMatch(rt,rtbranches))
              ?(cletrec   = fun defs t rdefs rt -> CLetRec(rdefs, rt))
              ?(clet      = fun v t1 t2 rt1 rt2 -> CLet(v,rt1,rt2))
              ?(cstaticdo = fun env e re -> CStaticDo(Lazy.force re))
              ?(cprferase = fun env e re -> CPrfErase(Lazy.force re))
              ?(creftype  = fun t rt -> CRefType(rt))
              ?(cmkref    = fun t t' rt rt' -> CMkRef(rt, rt'))
              ?(creadref  = fun t rt -> CReadRef(rt))
              ?(cassign   = fun t1 t2 rt1 rt2 -> CAssign(rt1,rt2))
              ?(cloc      = fun l t rt -> CLoc(l, rt))
              ?(cseq      = fun t1 t2 rt1 rt2 -> CSeq(rt1, rt2))
              ?(cinttype  = CIntType)
              ?(cintconst = fun i -> CIntConst(i))
              ?(cintop    = fun o t1 t2 rt1 rt2 -> CIntOp(o, rt1, rt2))
              ?(cinttest  = fun o t1 t2 rt1 rt2 -> CIntTest(o, rt1, rt2))
              ?(cbooltype = CBoolType)
              ?(cboolconst = fun b -> CBoolConst(b))
              ?(cboolop   = fun o t1 t2 rt1 rt2 -> CBoolOp(o, rt1, rt2))
              ?(cstringtype = CStringType)
              ?(cstringconst = fun s -> CStringConst(s))
              ?(cifthenelse = fun t1 t2 t3 rt1 rt2 rt3 -> CIfThenElse(rt1,rt2,rt3))
              ?(carraytype = fun t rt -> CArrayType(rt))
              ?(cmkarray   = fun t1 t2 t3 rt1 rt2 rt3 -> CMkArray(rt1,rt2,rt3))
              ?(carrayget  = fun t1 t2 rt1 rt2 -> CArrayGet(rt1, rt2))
              ?(carrayset  = fun t1 t2 t3 rt1 rt2 rt3 -> CArraySet(rt1, rt2, rt3))
              ?(carrayloc  = fun l t rt -> CArrayLoc(l, rt))
              ?(carraylen  = fun t rt -> CArrayLen(rt))
              ?(carraylit  = fun ts t rts rt -> CArrayLit(rts, rt))
              ?(cholhash   = fun t rt -> CHolHash(rt))
              ?(cprint     = fun env t rt -> CPrint(rt))
              ?(ctypeascribe = fun e t re rt -> CTypeAscribe(re, Lazy.force rt))
      env
      e =
  
  let rec aux1 ((defenv, cdefenv, metaenv, ctxenv, compenv) as env) =
    let aux e = aux1 env e in
    let add v t env = add_to_env ~case:v (openin env t) env in
    function
      CSort(s) -> csort s
    | CPi(v,t1,t2) -> cpi env v t1 t2 (aux t1) (aux1 (add v t1 env) t2)
    | CLambda(v,t1,t2) -> clambda env v t1 t2 (aux t1) (aux1 (add v t1 env) t2)
    | CApp(t1,t2) -> capp env t1 t2 (aux t1) (aux t2)
    | CHolTerm(t) -> cholterm env t
    | CCtxTerm(t) -> cctxterm t
    | CBVar(i)    -> cbvar env i
    | CFVar(i)    -> cfvar i
    | CNVar(s)    -> cnvar s
    | CUnitExpr   -> cunitexpr ()
    | CUnitType   -> cunittype ()
    | CSigma(v,t1,t2) -> csigma v t1 t2 (aux t1) (aux1 (add v t1 env) t2)
    | CPack(t1,v,t2,t3) -> cpack t1 v t2 t3 (aux t1) (aux1 (withtype v t1 env (fun t1_t -> add_to_env ~case:v t1_t env)) t2) (aux t3)
    | CUnpack(t1,v1,v2,t2) ->
	let env' = withtype (None, CType) t1 env
	  (function CSigma(_,ta,tb) ->
	     let env' = add_to_env ~case:v1 ta env in
	     let tb' = open_up ~case:v1 env tb in
	       add_to_env ~case:v2 tb' env'
	     | _ -> failwith "typechecker is erroneous probably for sigma...")
	in
	cunpack t1 v1 v2 t2 (aux t1) (aux1 env' t2)
    | CHolCase(t1,v,t2,branches) ->
	(let origenv = env in

	 let patconv (env, output, patout) (scrutinee,(metas,t)) =
	   let env', outputhd = 
	     List.fold_left (fun (env,out) (v,mt) ->
			       add v mt env, ((v,aux1 env mt) :: out)) (env,[]) metas
	   in
	   let env'' = subst_fmeta_in_env env' (openin origenv scrutinee) (openin env' t) in
	     (env'', ((List.rev outputhd, aux1 env'' t) :: output), openin env' t :: patout)
	 in
	 let branchconv ts (pats,e) =
	   let env', pats', openpatts = List.fold_left patconv (env,[],[]) (List.combine ts pats) in
	   let pats' = List.rev pats' in
	   let openpatts = List.rev openpatts in
	   let e' = List.fold_left (fun e (scrutinee, t) -> subst_fmeta (openin origenv scrutinee) t e) (openin env' e) (List.combine ts openpatts) in
	   let e'' = closedown env' e' in
	   (pats',aux1 env' e'')
	 in

	 let t2env = List.fold_left (fun env' (v,t1) -> withtype v t1 env (fun t_t -> add_to_env ~case:v t_t env')) env (List.combine v t1) in
	 let t2env' = List.fold_left 
	   (fun env (scrutinee, i) -> subst_fmeta_in_env env (openin origenv scrutinee) (CHolTerm(LFMeta(List.length metaenv + i))))
	   t2env (List.combine t1 (increasing (List.length t1)))
	 in

	   cholcase t1 v t2 branches (List.map aux t1) (aux1 t2env' t2) (List.map (branchconv t1) branches))
    | CCtxCase(t1,v,t2,branches) ->

	(let origenv = env in
	 let branchconv scrutinee (ctxvs, metavs, ctxpat, body) =
	   let env' = List.fold_left (fun env v -> add v (CSort(CCtx)) env) env ctxvs in

	   let ctxvs' = ctxvs in
	   let env'', metavs'rev = List.fold_left
	     (fun (env, out) (v,meta) ->
		add v meta env, ((v, aux1 env meta) :: out))
	     (env', []) metavs
	   in
	   let metavs' = List.rev metavs'rev in

  	   let ctxpat' = aux1 env'' ctxpat in
	   let env''' = subst_fctx_in_env env'' (openin origenv scrutinee) (openin env'' ctxpat) in
	   let body' = subst_fctx (openin origenv scrutinee) (openin env''' ctxpat') (openin env''' body) in
	   let body'' = closedown env''' body' in
	     (ctxvs', metavs', ctxpat', aux1 env''' body'')

	 in
	 let t2env = withtype v t1 env (fun t_t -> add_to_env ~case:v t_t env) in
	 let t2env' = subst_fctx_in_env t2env (openin origenv t1) (CCtxTerm(LFCtx(List.length ctxenv))) in

	   cctxcase t1 v t2 branches (aux t1) (aux1 t2env' t2) (List.map (branchconv t1) branches))

    | CProdType(t1,t2) -> cprodtype t1 t2 (aux t1) (aux t2)
    | CTuple(t1,t2) -> ctuple t1 t2 (aux t1) (aux t2)
    | CProj(i,t1) -> cproj i t1 (aux t1)
    | CRecType(v,t1,t2,s) -> crectype v t1 t2 (aux t1) (aux1 (add v t1 env) t2) s
    | CSumType(ts,s) -> csumtype ts (List.map aux ts) s
    | CFold(t1,t2) -> cfold t1 t2 (aux t1) (aux t2)
    | CUnfold(t1) -> cunfold env t1 (aux t1)
    | CCtor(i,t,p) -> cctor env i t p (aux t) (aux p)
    | CMatch(t,branches) ->
	(let arglist = withtype (None, CType) t env
	   (function CSumType(l,_) -> l
	      | _ -> failwith "expected sum type") in
	 let branches' = List.map (fun (argt,(v,t)) -> v, aux1 (add_to_env ~case:v argt env) t)
	                 (List.combine arglist branches) in
	   cmatch env t branches (aux t) branches')
    | CLetRec(defs,t) ->
	(let env' = List.fold_left (fun env' (v,t,tm) -> add_to_env ~case:v (openin env t) env') env defs in
	cletrec defs t (List.map (fun (v,t1,t2)->(v,aux t1,aux1 env' t2)) defs) (aux1 env' t))
    | CLet(v,t1,t2) -> clet v t1 t2 (aux t1) (aux1 (withtype v t1 env (fun t1_t -> add_to_env ~case:v t1_t env)) t2)
	(* BUG warning:: let of type doesn't work *)
    | CRefType(t) -> creftype t (aux t)
    | CMkRef(t,t') -> cmkref t t' (aux t) (aux t')
    | CReadRef(t) -> creadref t (aux t)
    | CAssign(t1,t2) -> cassign t1 t2 (aux t1) (aux t2)
    | CLoc(l,t) -> cloc l t (aux t)
    | CSeq(t1,t2) -> cseq t1 t2 (aux t1) (aux t2)
    | CIntType -> cinttype
    | CIntConst(i) -> cintconst i
    | CIntOp(o,t1,t2) -> cintop o t1 t2 (aux t1) (aux t2)
    | CIntTest(o,t1,t2) -> cinttest o t1 t2 (aux t1) (aux t2)
    | CBoolType -> cbooltype
    | CBoolConst(b) -> cboolconst b
    | CBoolOp(o,t1,t2) -> cboolop o t1 t2 (aux t1) (aux t2) 
    | CStringType -> cstringtype
    | CStringConst(s) -> cstringconst s
    | CIfThenElse(t1,t2,t3) -> cifthenelse t1 t2 t3 (aux t1) (aux t2) (aux t3) 
    | CArrayType(t) -> carraytype t (aux t)
    | CMkArray(t1,t2,t3) -> cmkarray t1 t2 t3 (aux t1) (aux t2) (aux t3)
    | CArrayGet(t1,t2) -> carrayget t1 t2 (aux t1) (aux t2)
    | CArraySet(t1,t2,t3) -> carrayset t1 t2 t3 (aux t1) (aux t2) (aux t3)
    | CArrayLoc(l,t) -> carrayloc l t (aux t)
    | CArrayLen(t) -> carraylen t (aux t)
    | CArrayLit(ts,t) -> carraylit ts t (List.map aux ts) (aux t)
    | CHolHash(t) -> cholhash t (aux t)
    | CPrint(t) -> cprint env t (aux t)
    | CClosure(subst, t) -> failwith "closure not handled"
    | CTypeAscribe(e,t) -> ctypeascribe e t (aux e) (lazy (aux t))
    | CStaticDo(e) -> cstaticdo env e (lazy (aux e))
    | CPrfErase(e) -> cprferase env e (lazy (aux e))
    | CInfer(_,_) -> failwith "unifvar found post-typechecking!!" 
  in
    aux1 env e

let is_proof_object env t = 
  let t_t = type_of_HOL env (openin env t) in
    match t_t with
	CHolTerm(LTermInCtx(_, LSort(_))) -> false
	| _ -> (match type_of_HOL env t_t with
		    CHolTerm(LTermInCtx(_, LSort(LProp))) -> true
		  | _ -> false)

let is_prop env t =
  let t_t = type_of_HOL env (openin env t) in
    match t_t with
	CHolTerm(LTermInCtx(_, LSort(LProp))) -> true
	| _ -> false

let comp_discard_proofobjects (ldefenv,cdefenv) e =
  cterm_map_env ~cholterm:(fun ((_,cdefenv,_,_,_) as env) t ->
  			     let t = CHolTerm(t) in
  			     if is_proof_object env t then
  			       CHolTerm(LTermInCtx([],LModal(LNMeta("~trusted"),[])))
  			     else
  			       t)
(*
                ~capp:(fun env t1 t2 rt1 rt2 ->
			 match rt1, rt2 with
			     CNVar("magic"), CHolTerm(t) when is_prop env rt2 ->
			       CPack(
				 CHolTerm(LTermInCtx([],LModal(LNVar("~magic")))),
				 (None, CHol),
				 CUnitType,
				 CUnitExpr)
			   | _, _ -> CApp(rt1,rt2))
*)
    (!ldefenv,!cdefenv,[],[],[])
    e




(*

  slam . slam . C[static<e>] ~~>
  slam . slam . (slam (x : t).C^1[x]) (v(env-senv) e)

  slam . slam . C[ C1[static<e1>] , C2[static<e2>] ] ~~>
  slam . slam . (slam x1 : t1.slam x2 : t2.C^2 [ C1^2[x1], C2^2[x2] ]) (v(env1-senv) e1) (v(env2-senv) e2)

*)

(*    normal lam                 slam
   |---------------------|-------------------------|
	 0          ...    compenv - slamenvn - 1     compenv - 1 

	    ~~>
      normal lam                        newslam               slam
	 |---------------------|----------------------------|------------------------------|
	 0              compenv - slamenvn - 1   compenv + staticcount - slamenvn - 1   compenv + staticcount - 1
*)


let comp_hoist_staticdo_and_annotate_prfobj (ldefenv, cdefenv) e =

  let cletstaticmany ls e =
    let lets = List.fold_left (fun cur statice -> CLet((None,CType),CStaticDo(statice),cur)) e ls in
    lets
  in

  let annotate_prf_obj env e =
    cterm_map_env 
      ~cholterm:(fun ((_,cdefenv,_,_,_) as env) t ->
                     match t with
			 LTermInCtx(ctx, mt) when is_proof_object env (CHolTerm(t)) -> CHolTerm(LTermInCtx(ctx, LModal(LNMeta("~erasable"),[mt])))
		       | _ -> CHolTerm(t))
      env e
  in

  let rec hoist ((_,_,_,_,compenv) as slamenv) e =

    let statics = ref [] in
    let staticcount = 
      let n = ref 0 in
      let _ = cterm_map_env ~cstaticdo:(fun _ e _ -> n := !n + 1; CStaticDo(e)) slamenv e in
      !n
    in
    let slamenvn = List.length compenv in

    let e =
      cterm_map_env
	~cstaticdo:(fun ((_,_,_,_,compenv) as env) e _ ->
	  let envn = List.length compenv in
	  let lamenvn = envn - slamenvn in
	  let staticn = List.length !statics in
	  let e' = hoist slamenv (CbindCterm.shift_bound ~start:lamenvn (-lamenvn) e) in
	  let e' = annotate_prf_obj env e' in
	  statics := e' :: !statics;
	  (CBVar(lamenvn + staticcount - staticn - 1)))

	~cholterm:(fun env t -> annotate_prf_obj env (CHolTerm(t)))

	slamenv e
    in
    cletstaticmany !statics e
  in
  let env = (!ldefenv, !cdefenv, [], [], []) in
  hoist env e

let comp_remove_static (ldefenv, cdefenv) e =
    cterm_map_env
      ~cstaticdo:(fun env _ re -> Lazy.force re)
      (!ldefenv, !cdefenv, [], [], [])
      e
