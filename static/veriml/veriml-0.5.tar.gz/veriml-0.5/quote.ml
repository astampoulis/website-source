open Camlp4.PreCast;;

module Ast =
struct 
open Logic_ast;;
open Comp_ast;;
					    
let quotations _loc =
  let rec qlist q e = match e with [] -> <:expr< [] >> | hd :: tl -> let hd = q hd in let tl = qlist q tl in <:expr< $hd$ :: $tl$ >> in
  let qpair q1 q2 (e1,e2) = let e1 = q1 e1 in let e2 = q2 e2 in <:expr< ($e1$, $e2$) >> in
  let qtriple q1 q2 q3 (e1,e2,e3) = let e1 = q1 e1 in let e2 = q2 e2 in let e3 = q3 e3 in <:expr< ($e1$, $e2$, $e3$) >> in
  let qref q e = let e = q !e in <:expr< ref $e$ >> in
  let qoption q e = match e with None -> <:expr< None >> | Some e -> let e = q e in <:expr< Some $e$ >> in
  let qstring s = <:expr< $str:s$ >> in
  let qint i = let i = string_of_int i in <:expr< $int:i$ >> in

  let qcs s = match s with CType -> <:expr< Comp_ast.CType >> | CKind -> <:expr< Comp_ast.CKind >> | CCtx -> <:expr< Comp_ast.CCtx >> | CHol -> <:expr< Comp_ast.CHol >> in
  let qcv v = qpair (qoption qstring) qcs v in

  let rec qc e =
    match e with
	CSort(s) -> let s = qcs s in <:expr< Comp_ast.CSort($s$) >>
      | CPi(v,t,t') -> let v = qcv v in let t = qc t in let t' = qc t' in <:expr< Comp_ast.CPi($v$, $t$, $t'$) >>
      | CSigma(v,t,t') -> let v = qcv v in let t = qc t in let t' = qc t' in <:expr< Comp_ast.CSigma($v$, $t$, $t'$) >>
      | CLambda(v,t,t') -> let v = qcv v in let t = qc t in let t' = qc t' in <:expr< Comp_ast.CLambda($v$, $t$, $t'$) >>
      | CApp(t,t') -> let t = qc t in let t' = qc t' in <:expr< Comp_ast.CApp($t$, $t'$) >>
      | CHolTerm(t) -> let t = qm t in <:expr< Comp_ast.CHolTerm($t$) >>
      | CCtxTerm(t) -> let t = qxd t in <:expr< Comp_ast.CCtxTerm($t$) >>
      | CBVar(i) -> let i = qint i in <:expr< Comp_ast.CBVar($i$) >>
      | CFVar(i) -> let i = qint i in <:expr< Comp_ast.CFVar($i$) >>
      | CNVar(s) -> <:expr< Comp_ast.CNVar($str:s$) >>
      | CUnitExpr -> <:expr< Comp_ast.CUnitExpr >>
      | CUnitType -> <:expr< Comp_ast.CUnitType >>
      | CPack(t,v,t',e) -> let t = qc t in let v = qcv v in let t' = qc t' in let e = qc e in <:expr< Comp_ast.CPack($t$, $v$, $t'$, $e$) >>
      | CUnpack(t,v1,v2,t') -> let t = qc t in let v1 = qcv v1 in let v2 = qcv v2 in let t' = qc t' in <:expr< Comp_ast.CUnpack($t$, $v1$, $v2$, $t'$) >>
      | CHolCase(ts,vs,ret,branches) ->
	let quotepat (metas, pat) =
	  let metas = qlist (qpair qcv qc) metas in
	  let pat = qc pat in
	  <:expr< ($metas$, $pat$) >>
	in
	let quotebranch (metaspats, body) = 
	  let metaspats = qlist quotepat metaspats in
	  let body = qc body in
	  <:expr< ($metaspats$, $body$) >>
	in
	let ts = qlist qc ts in let vs = qlist qcv vs in let ret = qc ret in let branches = qlist quotebranch branches in <:expr< Comp_ast.CHolCase($ts$, $vs$, $ret$, $branches$) >>
      | CCtxCase(t,v,ret,branches) ->
	let quotebranch (ctxunifs, patunifs, pat, body) =
	  let ctxunifs = qlist qcv ctxunifs in
	  let patunifs = qlist (qpair qcv qc) patunifs in
	  let pat = qc pat in
	  let body = qc body in
	  <:expr< ($ctxunifs$, $patunifs$, $pat$, $body$) >>
	in
	let t = qc t in let v = qcv v in let ret = qc ret in let branches = qlist quotebranch branches in <:expr< Comp_ast.CCtxCase($t$, $v$, $ret$, $branches$) >>

      | CProdType(t,t') -> let t = qc t in let t' = qc t' in <:expr< Comp_ast.CProdType($t$, $t'$) >>
      | CTuple(t,t') -> let t = qc t in let t' = qc t' in <:expr< Comp_ast.CTuple($t$, $t'$) >>
      | CProj(i,t) -> let i = qint i in let t = qc t in <:expr< Comp_ast.CProj($i$, $t$) >>
      | CRecType(v,t,t',s) -> let v = qcv v in let t = qc t in let t' = qc t' in let s = qref (qoption qstring) s in <:expr< Comp_ast.CRecType($v$, $t$, $t'$, $s$) >>
      | CFold(t,t') -> let t = qc t in let t' = qc t' in <:expr< Comp_ast.CFold($t$, $t'$) >>
      | CUnfold(t) -> let t = qc t in <:expr< Comp_ast.CUnfold($t$) >>
      | CSumType(ts,s) -> let ts = qlist qc ts in let s = qref (qoption qstring) s in <:expr< Comp_ast.CSumType($ts$, $s$) >>
      | CCtor(i,t,t') -> let i = qint i in let t = qc t in let t' = qc t' in <:expr< Comp_ast.CCtor($i$, $t$, $t'$) >>
      | CMatch(e,branches) -> let e = qc e in let branches = qlist (qpair qcv qc) branches in <:expr< Comp_ast.CMatch($e$, $branches$) >>
      | CLetRec(defs,e) -> let defs = qlist (qtriple qcv qc qc) defs in let e = qc e in <:expr< Comp_ast.CLetRec($defs$, $e$) >>
      | CLet(v,d,e) -> let v = qcv v in let d = qc d in let e = qc e in <:expr< Comp_ast.CLet($v$,$d$,$e$) >>

      | CRefType(t) -> let t = qc t in <:expr< Comp_ast.CRefType($t$) >>
      | CMkRef(t,t') -> let t = qc t in let t' = qc t' in <:expr< Comp_ast.CMkRef($t$, $t'$) >>
      | CAssign(t,t') -> let t = qc t in let t' = qc t' in <:expr< Comp_ast.CAssign($t$, $t'$) >>
      | CReadRef(t) -> let t = qc t in <:expr< Comp_ast.CReadRef($t$) >>
      | CLoc(_) -> failwith "can't quote locations"
      | CSeq(e,e') -> let e = qc e in let e' = qc e' in <:expr< Comp_ast.CSeq($e$, $e'$) >>
      
      | CArrayType(t) -> let t = qc t in <:expr< Comp_ast.CArrayType($t$) >>
      | CArrayLit(ts,t) -> let ts = qlist qc ts in let t = qc t in <:expr< Comp_ast.CArrayLit($ts$, $t$) >>
      | CMkArray(t,t',t'') -> let t = qc t in let t' = qc t' in let t'' = qc t'' in <:expr< Comp_ast.CMkArray($t$, $t'$, $t''$) >>
      | CArrayGet(t,t') -> let t = qc t in let t' = qc t' in <:expr< Comp_ast.CArrayGet($t$, $t'$) >>
      | CArraySet(t,t',t'') -> let t = qc t in let t' = qc t' in let t'' = qc t'' in <:expr< Comp_ast.CArraySet($t$, $t'$, $t''$) >>
      | CArrayLoc(_) -> failwith "can't quote array locations"
      | CArrayLen(e) -> let e = qc e in <:expr< Comp_ast.CArrayLen($e$) >>
				     
      | CIntType -> <:expr< Comp_ast.CIntType >>
      | CIntConst(i) -> let i = qint i in <:expr< Comp_ast.CIntConst($i$) >>
      | CIntOp(op,e,e') -> 
	let op = match op with Plus -> <:expr< Comp_ast.Plus >> | Minus -> <:expr< Comp_ast.Minus >> | Times -> <:expr< Comp_ast.Times >> | Mod -> <:expr< Comp_ast.Mod >> in
	let e = qc e in let e' = qc e' in <:expr< Comp_ast.CIntOp($op$, $e$, $e'$) >>
      | CIntTest(test,e,e') ->
	let test = match test with LT -> <:expr< Comp_ast.LT >> | LE -> <:expr< Comp_ast.LE >> | GT -> <:expr< Comp_ast.GT >> | GE -> <:expr< Comp_ast.GE >> | EQ -> <:expr< Comp_ast.EQ >> in
	let e = qc e in let e' = qc e' in <:expr< Comp_ast.CIntTest($test$, $e$, $e'$) >>

      | CBoolType -> <:expr< Comp_ast.CBoolType >>
      | CBoolConst(b) -> if b then <:expr< Comp_ast.CBoolConst(true) >> else <:expr< Comp_ast.CBoolConst(false) >>
      | CBoolOp(op,e,e') -> 
	let op = match op with BAnd -> <:expr< Comp_ast.BAnd >> | BOr -> <:expr< Comp_ast.BOr >> in
	let e = qc e in let e' = qc e' in <:expr< Comp_ast.CBoolOp($op$, $e$, $e'$) >>
      | CIfThenElse(t,t',t'') -> let t = qc t in let t' = qc t' in let t'' = qc t'' in <:expr< Comp_ast.CIfThenElse($t$, $t'$, $t''$) >>

      | CHolHash(t) -> let t = qc t in <:expr< Comp_ast.CHolHash($t$) >>
      | CPrint(t) -> let t = qc t in <:expr< Comp_ast.CPrint($t$) >>
      | CStringConst(s) -> <:expr< Comp_ast.CStringConst($str:s$) >>
      | CStringType -> <:expr< Comp_ast.CStringType >>

      | CStaticDo(t) -> let t = qc t in <:expr< Comp_ast.CStaticDo($t$) >>
      | CPrfErase(t) -> let t = qc t in <:expr< Comp_ast.CPrfErase($t$) >>
      | CTypeAscribe(e,t) -> let e = qc e in let t = qc t in <:expr< Comp_ast.CTypeAscribe($e$, $t$) >>
      | CInfer(_) -> failwith "cinfer is not quotable"
      | CClosure(_) -> failwith "closures are not quotable"

  and qm modal =
    match modal with
	LTermInCtx(ctx,t) -> let ctx = qx ctx in let t = ql t in <:expr< Logic_ast.LTermInCtx($ctx$, $t$) >>
      | LFMeta(i) -> let i = qint i in <:expr< Logic_ast.LFMeta($i$) >>
      | LBMeta(i) -> let i = qint i in <:expr< Logic_ast.LBMeta($i$) >>
      | LNMeta(s) -> <:expr< Logic_ast.LNMeta($str:s$) >>
  and qx lctx = 
    qlist (fun (s,t,t',pol) -> let s = qoption qstring s in let t = ql t in let t' = qoption ql t' in let pol = qpol pol in <:expr< ($s$,$t$,$t'$,$pol$) >>) lctx
  and qpol pol =
    match pol with
	LPNone -> <:expr< Logic_ast.LPNone >>
      | LPStrictPos -> <:expr< Logic_ast.LPStrictPos >>
      | LPPos -> <:expr< Logic_ast.LPPos >>
      | LPAny -> <:expr< Logic_ast.LPAny >>
  and qxd lctxdesc = 
    match lctxdesc with
	LFCtx(i) -> let i = qint i in <:expr< Logic_ast.LFCtx($i$) >>
      | LBCtx(i) -> let i = qint i in <:expr< Logic_ast.LBCtx($i$) >>
      | LCtxAsList(ctx) -> let ctx = qx ctx in <:expr< Logic_ast.LCtxAsList($ctx$) >>
  and ql t =
    match t with
	LSort(LType) -> <:expr< Logic_ast.LSort(Logic_ast.LType) >>
      | LSort(LSet) -> <:expr< Logic_ast.LSort(Logic_ast.LSet) >>
      | LSort(LProp) -> <:expr< Logic_ast.LSort(Logic_ast.LProp) >>
      | LVar(LBVar(i)) -> let i = qint i in <:expr< Logic_ast.LVar(Logic_ast.LBVar($i$)) >>
      | LVar(LFVar(i)) -> let i = qint i in <:expr< Logic_ast.LVar(Logic_ast.LFVar($i$)) >>
      | LLambda(s,t,t') -> let s = qoption qstring s in let t = ql t in let t' = ql t' in <:expr< Logic_ast.LLambda($s$, $t$, $t'$) >>
      | LPi(s,t,t',t'') -> let s = qoption qstring s in let t = ql t in let t' = ql t' in let t'' = ql t'' in <:expr< Logic_ast.LPi($s$, $t$, $t'$, $t''$) >>
      | LApp(t,tt,t') -> let t = ql t in let tt = qoption ql tt in let t' = ql t' in <:expr< Logic_ast.LApp($t$, $tt$, $t'$) >>
      | LEq(tt,t,t') -> let t = ql t in let tt = qoption ql tt in let t' = ql t' in <:expr< Logic_ast.LEq($tt$, $t$, $t'$) >>
      | LEqAxiom(s,ts) -> let ts = qlist ql ts in <:expr< Logic_ast.LEqAxiom($str:s$, $ts$) >>
      | LModal(m,subst) -> let m = qm m in let subst = qlist ql subst in <:expr< Logic_ast.LModal($m$, $subst$) >>
      | LTermList(ctxdesc) -> let ctxdesc = qxd ctxdesc in <:expr< Logic_ast.LTermList($ctxdesc$) >>
      | LInfer(_,_) -> failwith "infer should not be visible when quoting!"
  in
  (qc, qx)

let quote_comp e _loc = let (qc,_) = quotations _loc in qc e
let quote_ctx  e _loc = let (_,qx) = quotations _loc in qx e

let reify_hol ctx _loc =
  let c = quote_ctx ctx _loc in
  <:expr< fun t -> Comp_ast.CHolTerm(Logic_ast.LTermInCtx($c$, t)) >>
let reify_ctx _loc = <:expr< fun t -> Comp_ast.CCtxTerm(Logic_ast.fctx_ctx t) >>
let reify_sigma v ret reify1 reify2 _loc = 
  let quotecvar _loc (s,k) =
    let s' = (match s with Some s -> <:expr< Some $str:s$ >> | None -> <:expr< None >>) in
    let k' =
      match k with
	  Comp_ast.CType -> <:expr< Comp_ast.CType >>
	| Comp_ast.CKind -> <:expr< Comp_ast.CKind >>
	| Comp_ast.CCtx -> <:expr< Comp_ast.CCtx >>
	| Comp_ast.CHol -> <:expr< Comp_ast.CHol >>
    in
    <:expr< ($s'$, $k'$) >>
  in
  let v = quotecvar _loc v in
  let reify1 = reify1 _loc in 
  let reify2 = reify2 _loc in
  let ret = quote_comp ret _loc in
  <:expr< fun (w,e) -> Comp_ast.CPack($reify1$ w, $v$, $ret$, $reify2$ e) >> ;;
let reify_prod reify1 reify2 _loc = 
  let reify1 = reify1 _loc in
  let reify2 = reify2 _loc in
  <:expr< fun (e1,e2) -> Comp_ast.CTuple($reify1$ e1, $reify2$ e2) >>;;
let reify_int _loc =
  <:expr< fun x -> Comp_ast.CIntConst(x) >> ;;
let reify_unit _loc =
  <:expr< fun () -> Comp_ast.CUnitExpr >>;;

end;;


module Cst = 
struct

open Camlp4.PreCast;;
open Logic_cst;;
open Comp_cst;;
module LAst = Logic_ast;;
module CAst = Comp_ast;;
					    
let quote_comp e _loc =
  let rec qlist q e = match e with [] -> <:expr< [] >> | hd :: tl -> let hd = q hd in let tl = qlist q tl in <:expr< $hd$ :: $tl$ >> in
  let qpair q1 q2 (e1,e2) = let e1 = q1 e1 in let e2 = q2 e2 in <:expr< ($e1$, $e2$) >> in
  let qtriple q1 q2 q3 (e1,e2,e3) = let e1 = q1 e1 in let e2 = q2 e2 in let e3 = q3 e3 in <:expr< ($e1$, $e2$, $e3$) >> in
  let qint i = let i = string_of_int i in <:expr< $int:i$ >> in

  let qcs s = match s with CAst.CType -> <:expr< Comp_ast.CType >> | CAst.CKind -> <:expr< Comp_ast.CKind >> | CAst.CCtx -> <:expr< Comp_ast.CCtx >> | CAst.CHol -> <:expr< Comp_ast.CHol >> in
  let qaqstr s = match s with StrId(s) -> <:expr< Logic_cst.StrId($str:s$) >> | StrAnt(_loc,s) -> Ast.ExAnt(_loc, s) in
  let qcv v = qpair qaqstr qcs v in

  let rec qc e =
    match e with
	CSort(s) -> let s = qcs s in <:expr< Comp_cst.CSort($s$) >>
      | CPi(v,t,t') -> let v = qcv v in let t = qc t in let t' = qc t' in <:expr< Comp_cst.CPi($v$, $t$, $t'$) >>
      | CLambda(v,t,t') -> let v = qcv v in let t = qc t in let t' = qc t' in <:expr< Comp_cst.CLambda($v$, $t$, $t'$) >>
      | CArrow(t,t') -> let t = qc t in let t' = qc t' in <:expr< Comp_cst.CArrow($t$, $t'$) >>
      | CApp(t,t') -> let t = qc t in let t' = qc t' in <:expr< Comp_cst.CApp($t$, $t'$) >>
      | CHolTerm(t) -> let t = qm t in <:expr< Comp_cst.CHolTerm($t$) >>
      | CCtxTerm(t) -> let t = qxd t in <:expr< Comp_cst.CCtxTerm($t$) >>
      | CSigma(v,t,t') -> let v = qcv v in let t = qc t in let t' = qc t' in <:expr< Comp_cst.CSigma($v$, $t$, $t'$) >>
      | CSigmaUnit(t) -> let t = qc t in <:expr< Comp_cst.CSigmaUnit($t$) >>
      | CVar(s) -> let s = qaqstr s in <:expr< Comp_cst.CVar($s$) >>
      | CUnitExpr -> <:expr< Comp_cst.CUnitExpr >>
      | CUnitType -> <:expr< Comp_cst.CUnitType >>
      | CPack(t,v,t',e) -> let t = qc t in let v = qcv v in let t' = qc t' in let e = qc e in <:expr< Comp_cst.CPack($t$, $v$, $t'$, $e$) >>
      | CPackUnit(t) -> let t = qc t in <:expr< Comp_cst.CPackUnit($t$) >>
      | CUnpack(t,v1,v2,t') -> let t = qc t in let v1 = qcv v1 in let v2 = qcv v2 in let t' = qc t' in <:expr< Comp_cst.CUnpack($t$, $v1$, $v2$, $t'$) >>
      | CHolCase(ts,vs,ret,branches) ->
	let quotepat (metas, pat) =
	  let metas = qlist (qpair qcv qc) metas in
	  let pat = qc pat in
	  <:expr< ($metas$, $pat$) >>
	in
	let quotepats pats = 
	  match pats with
	      CHPatNested(normalpat) -> let pat = qlist quotepat normalpat in <:expr< Comp_cst.CHPatNested($pat$) >>
	    | CHPatAnt(_loc, s) -> Ast.ExAnt(_loc, s)
	in
	let quotebranch (metaspats, body) = 
	  let metaspats = qlist quotepats metaspats in
	  let body = qc body in
	  <:expr< ($metaspats$, $body$) >>
	in
	let ts = qlist qc ts in let vs = qlist qcv vs in let ret = qc ret in let branches = qlist quotebranch branches in <:expr< Comp_cst.CHolCase($ts$, $vs$, $ret$, $branches$) >>
      | CCtxCase(t,v,ret,branches) ->
	let quotebranch (ctxunifs, patunifs, pat, body) =
	  let ctxunifs = qlist qcv ctxunifs in
	  let patunifs = qlist (qpair qcv qc) patunifs in
	  let pat = qc pat in
	  let body = qc body in
	  <:expr< ($ctxunifs$, $patunifs$, $pat$, $body$) >>
	in
	let t = qc t in let v = qcv v in let ret = qc ret in let branches = qlist quotebranch branches in <:expr< Comp_cst.CCtxCase($t$, $v$, $ret$, $branches$) >>

      | CProdType(t,t') -> let t = qc t in let t' = qc t' in <:expr< Comp_cst.CProdType($t$, $t'$) >>
      | CTuple(t,t') -> let t = qc t in let t' = qc t' in <:expr< Comp_cst.CTuple($t$, $t'$) >>
      | CProj(i,t) -> let i = qint i in let t = qc t in <:expr< Comp_cst.CProj($i$, $t$) >>
      | CRecType(v,t,t') -> let v = qcv v in let t = qc t in let t' = qc t' in <:expr< Comp_cst.CRecType($v$, $t$, $t'$) >>
      | CFold(t,t') -> let t = qc t in let t' = qc t' in <:expr< Comp_cst.CFold($t$, $t'$) >>
      | CUnfold(t) -> let t = qc t in <:expr< Comp_cst.CUnfold($t$) >>
      | CSumType(ts) -> let ts = qlist qc ts in <:expr< Comp_cst.CSumType($ts$) >>
      | CCtor(i,t,t') -> let i = qint i in let t = qc t in let t' = qc t' in <:expr< Comp_cst.CCtor($i$, $t$, $t'$) >>
      | CMatch(e,branches) -> let e = qc e in let branches = qlist (qpair qcv qc) branches in <:expr< Comp_cst.CMatch($e$, $branches$) >>
      | CLetRec(defs,e) -> let defs = qlist (qtriple qcv qc qc) defs in let e = qc e in <:expr< Comp_cst.CLetRec($defs$, $e$) >>
      | CLet(v,d,e) -> let v = qcv v in let d = qc d in let e = qc e in <:expr< Comp_cst.CLet($v$,$d$,$e$) >>

      | CRefType(t) -> let t = qc t in <:expr< Comp_cst.CRefType($t$) >>
      | CMkRef(t,t') -> let t = qc t in let t' = qc t' in <:expr< Comp_cst.CMkRef($t$, $t'$) >>
      | CAssign(t,t') -> let t = qc t in let t' = qc t' in <:expr< Comp_cst.CAssign($t$, $t'$) >>
      | CReadRef(t) -> let t = qc t in <:expr< Comp_cst.CReadRef($t$) >>
      | CLoc(_) -> failwith "can't quote locations"
      | CSeq(e,e') -> let e = qc e in let e' = qc e' in <:expr< Comp_cst.CSeq($e$, $e'$) >>
      
      | CArrayType(t) -> let t = qc t in <:expr< Comp_cst.CArrayType($t$) >>
      | CArrayLit(ts,t) -> let ts = qlist qc ts in let t = qc t in <:expr< Comp_cst.CArrayLit($ts$, $t$) >>
      | CMkArray(t,t',t'') -> let t = qc t in let t' = qc t' in let t'' = qc t'' in <:expr< Comp_cst.CMkArray($t$, $t'$, $t''$) >>
      | CArrayGet(t,t') -> let t = qc t in let t' = qc t' in <:expr< Comp_cst.CArrayGet($t$, $t'$) >>
      | CArraySet(t,t',t'') -> let t = qc t in let t' = qc t' in let t'' = qc t'' in <:expr< Comp_cst.CArraySet($t$, $t'$, $t''$) >>
      | CArrayLoc(_) -> failwith "can't quote array locations"
      | CArrayLen(e) -> let e = qc e in <:expr< Comp_cst.CArrayLen($e$) >>
				     
      | CIntType -> <:expr< Comp_cst.CIntType >>
      | CIntConst(i) -> let i = qint i in <:expr< Comp_cst.CIntConst($i$) >>
      | CIntOp(op,e,e') -> 
	let op = match op with CAst.Plus -> <:expr< Comp_ast.Plus >> | CAst.Minus -> <:expr< Comp_ast.Minus >> | CAst.Times -> <:expr< Comp_ast.Times >> | CAst.Mod -> <:expr< Comp_ast.Mod >> in
	let e = qc e in let e' = qc e' in <:expr< Comp_cst.CIntOp($op$, $e$, $e'$) >>
      | CIntTest(test,e,e') ->
	let test = match test with CAst.LT -> <:expr< Comp_ast.LT >> | CAst.LE -> <:expr< Comp_ast.LE >> | CAst.GT -> <:expr< Comp_ast.GT >> | CAst.GE -> <:expr< Comp_ast.GE >> | CAst.EQ -> <:expr< Comp_ast.EQ >> in
	let e = qc e in let e' = qc e' in <:expr< Comp_cst.CIntTest($test$, $e$, $e'$) >>

      | CBoolType -> <:expr< Comp_cst.CBoolType >>
      | CBoolConst(b) -> if b then <:expr< Comp_cst.CBoolConst(true) >> else <:expr< Comp_cst.CBoolConst(false) >>
      | CBoolOp(op,e,e') -> 
	let op = match op with CAst.BAnd -> <:expr< Comp_ast.BAnd >> | CAst.BOr -> <:expr< Comp_ast.BOr >> in
	let e = qc e in let e' = qc e' in <:expr< Comp_cst.CBoolOp($op$, $e$, $e'$) >>
      | CIfThenElse(t,t',t'') -> let t = qc t in let t' = qc t' in let t'' = qc t'' in <:expr< Comp_cst.CIfThenElse($t$, $t'$, $t''$) >>

      | CHolHash(t) -> let t = qc t in <:expr< Comp_cst.CHolHash($t$) >>
      | CPrint(t) -> let t = qc t in <:expr< Comp_cst.CPrint($t$) >>
      | CStringConst(s) -> <:expr< Comp_cst.CStringConst($str:s$) >>
      | CStringType -> <:expr< Comp_cst.CStringType >>

      | CStaticDo(t) -> let t = qc t in <:expr< Comp_cst.CStaticDo($t$) >>
      | CPrfErase(t) -> let t = qc t in <:expr< Comp_cst.CPrfErase($t$) >>
      | CTypeAscribe(e,t) -> let e = qc e in let t = qc t in <:expr< Comp_cst.CTypeAscribe($e$, $t$) >>

      | CSetContext(ctx,t) -> let ctx = qxd ctx in let t = qc t in <:expr< Comp_cst.CSetContext($ctx$, $t$) >>
      | CNuContext(s,lt,t) -> let s = qaqstr s in let lt = ql lt in let t = qc t in <:expr< Comp_cst.CNuContext($s$, $lt$, $t$) >>
      | CUseMetaContext(t) -> let t = qc t in <:expr< Comp_cst.CUseMetaContext($t$) >>
      | CAny(i) -> let i = qint i in <:expr< Comp_cst.CAny($i$) >>
      | CAnt(_loc,s) -> Ast.ExAnt(_loc, s)

  and qm modal =
    match modal with
	LTermInCtx(ctx,t) -> let ctx = qxd ctx in let t = ql t in <:expr< Logic_cst.LTermInCtx($ctx$, $t$) >>
      | LMeta(s) -> let s = qaqstr s in <:expr< Logic_cst.LMeta($s$) >>
      | LMetaAnt(_loc, s) -> Ast.ExAnt(_loc, s)
  and qx lctx = 
    qlist (fun (s,t,pol) -> let s = qaqstr s in let t = ql t in let pol = qpol pol in <:expr< ($s$,$t$,$pol$) >>) lctx
  and qpol pol =
    match pol with
	LAst.LPNone -> <:expr< Logic_ast.LPNone >>
      | LAst.LPStrictPos -> <:expr< Logic_ast.LPStrictPos >>
      | LAst.LPPos -> <:expr< Logic_ast.LPPos >>
      | LAst.LPAny -> <:expr< Logic_ast.LPAny >>
  and qxd lctxdesc = 
    match lctxdesc with
	LCtxVar(s) -> let s = qaqstr s in <:expr< Logic_cst.LCtxVar($s$) >>
      | LCtxAsList(ctx) -> let ctx = qx ctx in <:expr< Logic_cst.LCtxAsList($ctx$) >>
      | LCurctx -> <:expr< Logic_cst.LCurctx >>
  and ql t =
    match t with
	LSort(LAst.LType) -> <:expr< Logic_cst.LSort(Logic_ast.LType) >>
      | LSort(LAst.LSet) -> <:expr< Logic_cst.LSort(Logic_ast.LSet) >>
      | LSort(LAst.LProp) -> <:expr< Logic_cst.LSort(Logic_ast.LProp) >>
      | LVar(s) -> let s = qaqstr s in <:expr< Logic_cst.LVar($s$) >>
      | LLambda(s,t,t') -> let s = qaqstr s in let t = ql t in let t' = ql t' in <:expr< Logic_cst.LLambda($s$, $t$, $t'$) >>
      | LPi(s,t,t') -> let s = qaqstr s in let t = ql t in let t' = ql t' in <:expr< Logic_cst.LPi($s$, $t$, $t'$) >>
      | LArrow(t,t') -> let t = ql t in let t' = ql t' in <:expr< Logic_cst.LArrow($t$, $t'$) >>
      | LApp(t,t') -> let t = ql t in let t' = ql t' in <:expr< Logic_cst.LApp($t$, $t'$) >>
      | LEq(t,t') -> let t = ql t in let t' = ql t' in <:expr< Logic_cst.LEq($t$, $t'$) >>
      | LModal(m,subst) -> let m = qm m in let subst = qlist ql subst in <:expr< Logic_cst.LModal($m$, $subst$) >>
      | LModalOmitSubst(m) -> let m = qm m in <:expr< Logic_cst.LModalOmitSubst($m$) >>
      | LTermList(ctxdesc) -> let ctxdesc = qxd ctxdesc in <:expr< Logic_cst.LTermList($ctxdesc$) >>
      | LAny(i) -> let i = qint i in <:expr< Logic_cst.LAny($i$) >>
      | LAnt(_loc, s) -> Ast.ExAnt(_loc, s)
  in
  qc e

end;;

