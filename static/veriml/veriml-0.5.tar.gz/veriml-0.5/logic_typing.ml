open Utils
open Logic_ast
open Logic_core
open Logic_print

let impredicative_set = ref false

let add_to_env (fenv, defenv, metaenv, ctxenv) tp =
  let fenv' = (tp, LPAny) :: fenv in (fenv', defenv, metaenv, ctxenv)

let add_to_env_full (fenv, defenv, metaenv, ctxenv) tp pol =
  let fenv' = (tp, pol) :: fenv in (fenv', defenv, metaenv, ctxenv)
	  
let rec type_of_lterm ((realfenv, defenv, metaenv, ctxenv) as realenv : lterm_env) (e : lterm) =
  let fenv = demote_polarities_fully realfenv in
  let env = (fenv, defenv, metaenv, ctxenv) in
  let n = List.length fenv in
  match e with
      LSort(LSet)  -> LSort(LType)
    | LSort(LProp) -> LSort(LSet)
    | LSort(LType) -> failwith "LType has no type"
    | LVar(LBVar i) -> failwith "accessing type of bound var -- shouldn't happen!"
    | LVar(LFVar i) -> 
      let tp, pol = List.nth realfenv (List.length realfenv - i - 1) in
      if pol = LPNone then failwith "polarity condition violated" else tp

(* special handling of equality *)
    | LEq(t,t1,t2) ->
	let t1t = type_of_lterm env t1 in
	let t2t = type_of_lterm env t2 in
	let s = type_of_lterm env t1t in
	let _   = match t with Some t -> if not (lterm_equal defenv n t1t t) then failwith "first arg to equality does not have the expected type" | None -> () in
	let thistp = LPi(None,s,t1t,LSort(LProp)) in
	let _ = type_of_lterm env thistp in
	  if lterm_equal defenv n t1t t2t then
	    LSort(LProp)
	  else
	    failwith "equality used with incompatible types"

    | LEqAxiom( refl, [ t ] ) when refl = "refl" ->
	let tp = type_of_lterm env t in
	let thistp = LEq(Some tp, t, t) in
	let _ = type_of_lterm env thistp in
	  thistp

    | LEqAxiom( symm, [ t ] ) when symm = "symm" ->
	begin
	let tp = type_of_lterm env t in
	  match whnf defenv tp with
	      LEq(tp', t1, t2) ->
		LEq(tp', t2, t1)
	    | _ -> failwith "symmetricity used on wrong term"
	end

    | LEqAxiom( trans, [ t1 ; t2 ] ) when trans = "trans" ->
	begin
	let tp1 = type_of_lterm env t1 in
	let tp2 = type_of_lterm env t2 in
	  match whnf defenv tp1, whnf defenv tp2 with
	      LEq(tp, t1, t2), LEq(_, t2', t3) when lterm_equal defenv n t2 t2' ->
		LEq(tp, t1, t3)
	    | _ -> failwith "transitivity used on wrong terms"
	end

    | LEqAxiom( leibn, [ (LLambda(_,tp,tm) as e) ; pf' ; pf ] ) when leibn = "leibn" ->
	begin
	let ewf = type_of_lterm env e in
	let uv = mk_infer n 0 (List.length metaenv) 0 (List.length ctxenv) 0 in
	let _ = if lterm_equal defenv n ewf (LPi(None, uv, tp, LSort(LProp))) then () else failwith "in leibniz, the P argument should be a one-place predicate" in
	let pftp = type_of_lterm env pf in
	let pftp' = type_of_lterm env pf' in
	  match whnf defenv pftp' with
	      LEq(_, t1, t2) ->
		(if lterm_equal defenv n pftp (BindLtermS.subst_bound t1 tm) then
		   BindLtermS.subst_bound t2 tm
		 else
		   failwith "in leibniz, terms or proof object of incorrect type")
	    | _ -> failwith "in leibniz, equality term of wrong type"
	end

    | LEqAxiom( lameq, [ pf ] ) when lameq = "lameq" ->
      begin
  	  let _ = match pf with LLambda(_,_,_) -> () | _ -> failwith "proof must be lambda in lameq" in

	  let pftp = type_of_lterm env pf in
	  let pfk = type_of_lterm env pftp in
	    match whnf defenv pfk with
		LSort(LProp) ->
		  (match whnf defenv pftp with
		       LPi(var,k,tp,LEq(Some tp',t1,t2)) ->
			 LEq(Some (LPi(var,k,tp,tp')), LLambda(var,tp,t1), LLambda(var,tp,t2))
		     | _ -> failwith "wrong type for proof in lameq application")
	      | _ -> failwith "wrong term applied to lameq -- need forall proposition"
	end

    | LEqAxiom( foralleq, [ pf ] ) when foralleq = "foralleq" ->
      begin
  	  let _ = match pf with LLambda(_,_,_) -> () | _ -> failwith "proof must be lambda in foralleq" in

	  let pftp = type_of_lterm env pf in
	  let pfk = type_of_lterm env pftp in
	    match whnf defenv pfk with
		LSort(LProp) ->
		  (match whnf defenv pftp with
		       LPi(var,k,tp,LEq(tp',t1,t2)) ->
			 (let thistp = LEq(Some (LSort(LProp)), LPi(var,k,tp,t1), LPi(var,k,tp,t2)) in
			  let _ = type_of_lterm env thistp in
			    thistp)
		     | _ -> failwith "wrong type for proof in foralleq application")
	      | _ -> failwith "wrong term applied to foralleq -- need forall proposition"
	end		

    | LEqAxiom( beta , [ (LLambda(_, tp, tm) as e) ; e2 ] ) when beta = "beta" ->
      begin
   	  let etp = type_of_lterm env e in
	  let restp = match etp with LPi(_,_,_,bodytp) -> BindLtermS.subst_bound e2 bodytp | _ -> failwith "type of lambda is not pi?" in
	  let thistp = LEq(Some restp, LApp(e, Some etp, e2), BindLtermS.subst_bound e2 tm) in
	  let _ = type_of_lterm env thistp in
	    thistp
	end

    | LEqAxiom( metaunfold , [ LModal(LNMeta(s), subst) as e ] )
	when (metaunfold = "metaunfold" && not (get_metadef_isaxiom s defenv)) ->
      begin
  	  let tp = type_of_lterm env e in
	  let _  = type_of_lterm env (LEq(Some tp,e,e)) in
	  let unfolded = modal_apply_subst (get_metadef_term s defenv) subst in
	    LEq(Some tp,e, unfolded)
	end

    | LEqAxiom( _ , _ ) -> failwith "wrong use of equality axiom"

(* ok, equality done *)

    | LPi(var, k, t1, t2) ->
        let env1 = (demote_polarities_pos realfenv, defenv, metaenv, ctxenv) in
	let t1_t = type_of_lterm env1 t1 in
	let _ = if lterm_equal defenv n t1_t k then () else failwith "kind of forall doesn't match kind of quantified type" in
	let env' = add_to_env realenv t1 in
	let t2' = BindLterm.open_up n t2 in
	let t2_t = type_of_lterm env' t2' in
	  begin
	    match whnf defenv t1_t, whnf defenv t2_t with
	    	LSort(LProp), LSort(LProp) -> LSort(LProp)
	      | LSort(LSet), LSort(LSet) ->   LSort(LSet)
	      | LSort(LSet), LSort(LProp) ->  LSort(LProp)
	    	  (* impredicative Set? *)
	      | LSort(LType), LSort(LType) when !impredicative_set -> LSort(LType)
	      | LSort(LType), LSort(LSet)  when !impredicative_set -> LSort(LSet)
	      | LSort(LType), LSort(LProp) when !impredicative_set -> LSort(LProp)
		  
	      | _ -> failwith ("invalid type " ^ (string_of_lterm e))
	  end
    | LLambda(var, t1, e2) ->
	let k = type_of_lterm env t1 in
	let env' = add_to_env env t1 in
	let t2 = type_of_lterm env' (BindLterm.open_up n e2) in 
	let tp = LPi(var, k, t1, BindLterm.close_down (n+1) t2) in
	let _ = type_of_lterm env tp in
	  (LPi(var, whnf defenv k, t1, BindLterm.close_down (n+1) t2))

    | LApp(e1, t, e2) ->
	let t1 = type_of_lterm realenv e1 in
	let t2 = type_of_lterm env e2 in
	let _  =
	  match t with
	      Some t when type_of_lterm env t2 <> LSort(LProp) ->
		if not (lterm_equal defenv n t1 t) then failwith "type of function doesn't match the expected type"
	    | _ -> ()
	in
	  begin
	    match whnf defenv t1 with
		LPi(_, _, t, t') ->
		  if lterm_equal defenv n t2 t then
		    BindLtermS.subst_bound e2 t'
		  else
		    failwith ("types don't match: " ^ (string_of_lterm t) ^ " and " ^ (string_of_lterm t2))
	      | _ ->
		  failwith ("expected Pi type, got " ^ (string_of_lterm t1))
	  end

    | LModal(LNMeta(erasable), [pf]) when erasable = "~erasable" ->
        (type_of_lterm env pf)

    | LModal(mt, subst) ->
	(let mt_t = type_of_modal realenv mt in
	 let rec getctx mt_t =
	   match mt_t with
	       LTermInCtx(ctx, _) -> ctx
	     | _ -> getctx (type_of_modal realenv mt_t)
	 in
	 let ctx = getctx mt_t in
	 let _ = type_of_subst_is realenv subst ctx in
	   modal_apply_subst mt_t subst)

    | LTermList(ctx) ->
	failwith "asking type of context inside type_of_lterm!"

    | LInfer(el, f) ->
	failwith "infer-placeholder shouldn't be visible at this point!"

and type_of_modal ((fenv, defenv, metaenv, ctxenv) : lterm_env) (mt : lmodalterm) =
  match mt with
      LTermInCtx(ctx,lt) ->
	(let _ = ctx_wf ([], defenv, metaenv, ctxenv) (LCtxAsList(ctx)) in
	 let newfenv = ctx_to_fenv ctx in
	 let tp = type_of_lterm (newfenv, defenv, metaenv, ctxenv) lt in
	   LTermInCtx(ctx, tp))
    | LFMeta(i) -> List.nth metaenv (List.length metaenv - i - 1)
    | LBMeta(i) -> failwith ("accessing bound meta variable while type checking -- shouldn't happen")
    | LNMeta(s) -> get_metadef_type s defenv

and type_of_subst_is ((fenv, defenv, metaenv, ctxenv) : lterm_env) (subst : lsubst) (ctx : lctx) =

  (if List.length subst <> List.length ctx then failwith "subst and context do not match in size");
  List.for_all2
    (fun selm (_,celm,_,pol) ->
      let fenv' = match pol with LPAny -> demote_polarities_fully fenv | LPPos -> fenv | _ -> failwith "unexpected polarity" in
      let env'  = (fenv', defenv, metaenv, ctxenv) in
      let shd_t = type_of_lterm env' selm in
      let chd_t = BindLtermS.subst_free_list subst celm in
      let res   = lterm_equal defenv (List.length fenv) shd_t chd_t in
      (if not res then failwith "subst and context do not match in type");
      res)
    subst ctx

and ctx_wf ((fenv, defenv, metaenv, ctxenv) as env : lterm_env) (ctx : lctxdesc) =
  match ctx with
      LFCtx(i) -> List.nth ctxenv (List.length ctxenv - i - 1)
    | LBCtx(i) -> failwith "getting type of bound context variable"
    | LCtxAsList(l) ->
	ignore
	  (List.fold_left (fun ((fenv, _, _, _) as curenv,n) (_,elm,sort,pol) ->
			     valid_ctxelem curenv elm sort;
			     (add_to_env_full curenv elm pol, n+1))
	     (env,0) l)
and valid_ctxelem ((fenv, defenv, metaenv, ctxenv) as env) (ctxelem : lterm) (sort : lterm option) =
  match ctxelem with
      LTermList(LCtxAsList(_)) -> failwith "nested context lists are not allowed!"
    | LTermList(ctx) -> ctx_wf env ctx
    | t -> 
      (let sort' = type_of_lterm env t in
       let _ = match whnf defenv sort' with LSort(_) -> () | _ -> failwith "context includes a variable whose type is not classified by a sort" in
       let _ = match sort with Some(sort) -> if not (lterm_equal defenv (List.length fenv) sort sort') then failwith "unexpected sort in context" | None -> () in
       ())


let type_of_lterm_expected ((fenv,defenv,_,_) as env) ?(expected = None) tm =
  let tp = type_of_lterm env tm in
  let check_eq = lterm_equal defenv (List.length fenv) tp in
  match expected with
      Some tp' when not (check_eq tp') -> raise LTermsNotEqual
    | _ -> tp

let type_of_modal_expected ((_,defenv,metaenv,_) as env) ?(expected = None) tm =
  let tp = type_of_modal env tm in
  let check_eq = lmodal_equal defenv (List.length metaenv) tp in
  match expected with
      Some tp' when not (check_eq tp') -> raise LTermsNotEqual
    | _ -> tp




let check_pattern defenv ctx patvars pat =

  let rec is_idsubst fenv benv subst =
    ExtList.is_prefix subst ( (freelist fenv) ++ (boundlist benv) ) 
  in
  let rec aux (fenv : int) (benv : int) (cur : int) (pat : lterm) =

    (* (require (is_whnf ctx pat) "pattern should be in normal form"); *)
    (match pat with
	 LModal(LBMeta(i), subst) ->
	   (* (require (i = cur - 1) "pattern variables should be used in increasing order"); *)
	   (require (is_idsubst fenv benv subst) "substitutions used in pattern variables should only mention free variables in increasing order");
	   cur - 1

       | LModal(LNMeta(s), subst) ->
	   List.fold_left (fun cur elm -> aux fenv benv cur elm) cur subst

       | LLambda(s, a, b) ->
	   (let cur'  = aux fenv benv cur a in
	    let cur'' = aux fenv (benv+1) cur' b in
	      cur'')

       | LPi(s, k, a, b) ->
	   (let cur'  = aux fenv benv cur a in
	    let cur'' = aux fenv (benv+1) cur' b in
	      cur'')

       | LApp(a, t, b) ->
	   (let cur' = aux fenv benv cur a in
	    let cur'' = aux fenv benv cur' b in
	    let cur''' = match t with Some t -> aux fenv benv cur'' t | None -> cur'' in
	      cur''')

       | LEq(t, a, b) ->
	   (let cur' = aux fenv benv cur a in
	    let cur'' = aux fenv benv cur' b in
	    let cur''' = match t with Some t -> aux fenv benv cur'' t | None -> cur'' in
	      cur''')

       | e ->
	   ignore (lterm_map ~lbmeta:(fun i -> failwith "invalid pattern -- pattern variable shows up where it shouldn't") e);
	   cur
    )
  in
  let _ = aux (List.length ctx) 0 patvars pat in
    (* require (^^ the above, if calculated properly ^^ patvars_unused = 0) "not all pattern variables are used" *)
    ()

(* metavars should be with ctxvars still bound *)
(* pat is a (string * lterm) list *)
let check_context_pattern defenv ctxfenv ctxvars metavars pat =
  match pat with
      [ (_, LTermList(LBCtx(0)), _, _); (_, typat, _, _) ] ->
	(  (require (List.length ctxvars = 1) "not right number of context pattern variables defined");
	   check_pattern defenv [ (None, LTermList(LFCtx(ctxfenv)), None) ] (List.length metavars) typat)

    | [ (_, LTermList(LBCtx(0)), _, _) ] ->
	(require (List.length ctxvars = 1) "not right number of context pattern variables defined");
        (require (List.length metavars = 0) "more context pattern variables defined than used")

    | [ (_, (LTermList(ctx) as t'), _, _ ) ] ->
        (require (not (CtxbindLterm.has_bound_var 0 t')) "pattern not allowed");
        (require (List.length ctxvars = 0) "more context pattern variables defined than used");
        (require (List.length metavars = 0) "more context pattern variables defined than used")

    | ctx' ->
        (require (not (CtxbindLterm.has_bound_var 0 (LTermList(LCtxAsList(ctx'))))) "pattern not allowed");
        (require (List.length ctxvars = 0) "more context pattern variables defined than used");
        (require (List.length metavars = 0) "more context pattern variables defined than used")

exception NoPatternMatch
let pattern_match_term defenv ?(ctx = []) ?(check = false) patvars pat e =

  (* bad patch before actually changing this to account for the new modal repr *)
  let pat = BindLterm.close_down ~howmany:(List.length ctx) (List.length ctx) pat in
  let e   = BindLterm.close_down ~howmany:(List.length ctx) (List.length ctx) e   in

  let remove_from_ctx n ctx =
    ExtList.updatenth n (None, LTermList(LCtxAsList([])), None, LPAny) ctx
  in

  let rec pattern_match_term (ctx : lctx) (assignment : lmodalterm map) (pat : lterm) (e : lterm) =

    let e' = whnf defenv e in

    let subst_assignment subst n assignment tm =
      List.fold_left
	(fun tm i ->
	   if (IMap.mem i assignment) then 
	     subst (IMap.find i assignment) (n - i - 1) tm
	   else
	     tm) tm (increasing n)
    in

    let typeof metaenv assignment ctx e =

      let metactx_to_metafenv ctx =
	let rec aux n ctx =
	  match ctx with
	      [] -> []
	    | hd :: tl ->
		(MetabindModal.open_up ~howmany:n 0 hd) :: (aux (n+1) tl)
	in
	  List.rev (aux 0 ctx)
      in

      let fenv = ctx_to_fenv ctx in
      let e' = BindLterm.open_up ~howmany:(List.length fenv) 0 e in
      let metafenv = metactx_to_metafenv metaenv in
      let metafenv = List.map (subst_assignment MetabindModal.subst_fvar (List.length metafenv) assignment) metafenv in
      let e'' = MetabindLterm.open_up ~howmany:(List.length metafenv) 0 e' in
      let typ = type_of_lterm (fenv,defenv,metafenv,[]) e'' in
	BindLterm.close_down ~howmany:(List.length fenv) (List.length fenv) typ
    in

    (* TODO:: fix this properly *)
    (* in order to fill in sorts we do a type checking. of course this is not needed,
       and should be removed once the logic_core is updated properly so that it generates
       proper inferred sorts for all lambda's and pi's. *)
    let _ = 
      if check then
	match e' with
	    LPi(_,_,_,_) | LLambda(_,_,_) -> ignore(typeof [] assignment ctx e')
	  | _ -> ()
    in

    let pat' =
      let patopen = MetabindLterm.open_up ~howmany:(List.length patvars) 0 pat in
      let patopen' = subst_assignment MetabindLterm.subst_fvar (List.length patvars) assignment patopen in
	MetabindLterm.close_down ~howmany:(List.length patvars) (List.length patvars) patopen'
    in

    let add_to_ctx ctx s a =
      ctx ++ [ s, BindLterm.open_up ~howmany:(List.length ctx) 0 a, None, LPAny ]
    in

      match pat', e' with

	  LModal(LBMeta(i), subst), e ->
	    let ty_pat, ty_e = typeof patvars assignment ctx pat', typeof [] assignment ctx e in
	    let assignment = pattern_match_term ctx assignment (MetabindLterm.close_down ~howmany:(List.length patvars) (List.length patvars) ty_pat) ty_e in 
	      
	    let n = List.length ctx in
	    let ctx' =
	      List.fold_left
		(fun ctx0 j ->
		   let unif_allows_it = List.exists ((=) (LVar (LBVar j))) subst in
		   let term_has_it = BindLterm.has_bound_var j e in
		     if not unif_allows_it then
		       (if not term_has_it then
			  remove_from_ctx (n-j-1) ctx0
			else
			  raise NoPatternMatch)
		     else
		       ctx0)
		ctx (increasing n)
	    in
	    let ctx', e' = flatten_term_in_context ctx' (BindLterm.open_up ~howmany:n 0 e) in
	      IMap.add i (LTermInCtx(ctx',e')) assignment
		  
	| LLambda(s1, a1, b1), LLambda(s2, a2, b2) ->
	    let assignment' = pattern_match_term ctx assignment a1 a2 in
	    let assignment'' = pattern_match_term (add_to_ctx ctx s2 a2) assignment' b1 b2 in
	      assignment''
(*
 (*
   new matching code, experimental (currently very slow for some reason).
   to enable: uncomment this
              comment allusions to typing above (from lbmeta(i) and the definition)
              change logic_cst so that the middle argument to LApp is always inferred
   *)
	| LPi(s1, k1, a1, b1), LPi(s2, k2, a2, b2) ->
            let assignment  = pattern_match_term ctx assignment k1 k2 in
	    let assignment' = pattern_match_term ctx assignment a1 a2 in
	    let assignment'' = pattern_match_term (add_to_ctx ctx s2 a2) assignment' b1 b2 in
	      assignment''


	| LEq(t1,a1,b1), LEq(t2,a2,b2) ->
	    let assignment =
	      match a1, b1 with
		  LModal(LBMeta(_),_), _
		| _, LModal(LBMeta(_),_) ->
		  (match t1, t2 with
		      Some t1, Some t2 -> pattern_match_term ctx assignment t1 t2
		    | _ -> failwith "expected eq type to be figured out")
		| _ -> assignment
	    in
	    let assignment'  = pattern_match_term ctx assignment a1 a2 in
	    let assignment'' = pattern_match_term ctx assignment' b1 b2 in
	      assignment''

	| LApp(a1,t1,b1), LApp(a2,t2,b2) ->
	    let assignment =
	      match a1 with
		  LModal(LBMeta(_),_) ->
		  (match t1, t2 with
		      Some t1, Some t2 -> pattern_match_term ctx assignment t1 t2
		    | _ -> failwith "expected app type to be figured out")
		| _ -> assignment
	    in
	    let assignment' = pattern_match_term ctx assignment a1 a2 in
	    let assignment'' = pattern_match_term ctx assignment' b1 b2 in
	      assignment''
*)
	| LPi(s1, k1, a1, b1), LPi(s2, k2, a2, b2) ->
	    let assignment' = pattern_match_term ctx assignment a1 a2 in
	    let assignment'' = pattern_match_term (add_to_ctx ctx s2 a2) assignment' b1 b2 in
	      assignment''

	| LEq(_,a1,b1), LEq(_,a2,b2) ->
	    let assignment'  = pattern_match_term ctx assignment a1 a2 in
	    let assignment'' = pattern_match_term ctx assignment' b1 b2 in
	      assignment''

	| LApp(a1,_,b1), LApp(a2,_,b2) ->
	    let assignment' = pattern_match_term ctx assignment a1 a2 in
	    let assignment'' = pattern_match_term ctx assignment' b1 b2 in
	      assignment''


 	| LModal(LNMeta(s), subst1), LModal(LNMeta(s'), subst2) when s = s' ->
 	    let assignment' = List.fold_left2 (fun asgn elm1 elm2 -> pattern_match_term ctx asgn elm1 elm2) assignment subst1 subst2 in
 	      assignment'

	| e1, e2 -> (let nctx = List.length ctx in
		       if lterm_equal defenv nctx
			 (BindLterm.open_up ~howmany:nctx 0 e1)
			 (BindLterm.open_up ~howmany:nctx 0 e2) then assignment else
			   raise NoPatternMatch)
  in
  let assignment = pattern_match_term ctx IMap.empty pat e in
  let subst =
    List.map
      (fun i -> try IMap.find i assignment with Not_found -> raise NoPatternMatch)
      (decreasing (List.length patvars))
  in
    subst


let context_match_term defenv metavars pat ctx =
  match pat with
      [ (_, LTermList(LBCtx(0)), _, _); (_, typat, _, _) ] ->
	(let ctx', (_, last, _, _) = try ExtList.last ctx with _ -> raise NoPatternMatch in
	 nowarn let LTermList(LCtxAsList(patctx)) = CtxbindLtermS.subst_bound (LCtxAsList(ctx')) (LTermList(LCtxAsList(pat))) in
	 let _, (_, typat', _, _) = ExtList.last patctx in
	 let metavars' = List.map
	   (fun m -> CtxbindModalS.subst_bound (LCtxAsList(ctx')) m) metavars in

	 let assignment = pattern_match_term ~ctx:ctx' ~check:true defenv metavars' typat' last in
	   ([LCtxAsList(ctx')], assignment))

    | [ (_, LTermList(LBCtx(0)), _, _) ] ->
        ( [LCtxAsList(ctx)], [] )

    | ctx' ->
        (if lctxdesc_equal defenv (LCtxAsList(ctx)) (LCtxAsList(ctx')) then
	    ( [], [] )
	 else
	    raise NoPatternMatch)
