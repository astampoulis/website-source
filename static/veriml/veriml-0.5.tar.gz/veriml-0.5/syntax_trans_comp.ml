open Camlp4.PreCast
module CAst = Comp_ast
module CCst = Comp_cst
module LAst = Logic_ast
module LCst = Logic_cst
module CTyp = Comp_typinf

module CompGram = Syntax_trans_logic.LogicGram

let ident = Syntax_trans_logic.ident
let modalterm = Syntax_trans_logic.modalterm
let modalterm_paren = Syntax_trans_logic.modalterm_paren
let context = Syntax_trans_logic.context
let logicdef = Syntax_trans_logic.logicdef
let lterm    = Syntax_trans_logic.term
let paramlist = Syntax_trans_logic.paramlist

let ctxterm = CompGram.Entry.mk "context term for comp"
let cterm = CompGram.Entry.mk "computational term"
let cterm_eoi = CompGram.Entry.mk "computational term (EOI)"
let cterm_ast = CompGram.Entry.mk "computational term (ast)"
let compdef = CompGram.Entry.mk "computational definition"
(* let compdef_eoi = CompGram.Entry.mk "computational definition (EOI)" *)
let veriml_phrase = CompGram.Entry.mk "VeriML toplevel phrase"
let veriml_file = CompGram.Entry.mk "VeriML file"

let cterm_of_string = CompGram.parse_string cterm_eoi;;

let phrase = Syntax.phrase;;

EXTEND CompGram
  GLOBAL: cterm cterm_eoi cterm_ast compdef ctxterm (* compdef_eoi *) veriml_phrase veriml_file;

  cterm_eoi: [ [ t = cterm; `EOI -> t  ] ];

  cterm:
    [
      "let" RIGHTA
	[ "letrec"; d = LIST1 def SEP "andrec"; "in"; e = cterm ->
	    CCst.CLetRec(d, e)
	| "let"; x = cident; "="; t = cterm; "in"; e = cterm ->
	    CCst.CLet(x, t, e)
	| "let"; "@"; "="; t = ctxterm; "in"; e = cterm ->
	    CCst.CSetContext(t, e)
	| "let"; "@"; "="; "@@"; "in"; e = cterm ->
	    CCst.CUseMetaContext(e)
	| "nu"; s = ident; ":"; t = lterm; "in"; e = cterm ->
	    CCst.CNuContext(s, t, e)
(*	| "guess"; l = modalsubst; "in"; e = cterm ->
  	    let l = exprlist _loc l in
	    <:expr< CCst.CGuessSubst($l$, $e$) >>*)
	]
    | "lambda" RIGHTA
	[ "fun"; v = cvars; "=>"; t = cterm ->
	      CCst.clammany v t ]
    | "sigma" RIGHTA
	[ "<"; v = cvars; ">"; t = cterm ->
	    CCst.csigmamany v t
	| "<"; t = cterm; ","; e = cterm; ">" ->
	    CCst.CPack(t, (LCst.StrId "x", CAst.CType), CCst.CAny(0), e) ]
    | "pi" RIGHTA
	[ "{"; v = cvars; "}"; t = cterm ->
	    CCst.cpimany v t ]
    | "arrow" RIGHTA
	[ t = cterm; "->"; t' = cterm ->
	    CCst.CArrow(t, t') ]
    | "packunpack" RIGHTA
	[ "pack"; t = cterm; "as"; x = cident; "return"; ret = cterm; "with"; e = cterm ->
	    CCst.CPack(t, x, ret, e)
	| "unpack"; "<"; strs = LIST1 unpackident SEP ","; ">"; "="; t = cterm; "in"; e = cterm ->
	    CCst.cunpackmany t strs e ]
    | "cases" RIGHTA
	[ "holcase"; t = LIST1 cterm SEP ","; "as"; v = LIST1 cident SEP ","; "return"; ret = cterm; "with"; b = LIST1 holbranch SEP "|" ->
	      CCst.CHolCase(t, v, ret, b)
	|  "ctxcase"; t = ctxterm; "as"; v = cident; "return"; ret = cterm; "with"; b = LIST1 ctxbranch SEP "|" ->
	     CCst.CCtxCase(CCst.CCtxTerm(t), v, ret, b)
	|  "match"; t = cterm; "with"; b = LIST1 matchbranch SEP "|" ->
	    CCst.CMatch(t, b)

	]
    | "seq" LEFTA
	[ t = cterm; ";"; t' = cterm ->  CCst.CSeq(t, t')  ]
    | "assign" NONA
	[ t = cterm; ":="; t' = cterm ->  CCst.CAssign(t, t')  ]
    | "intrel" NONA
	[ t = cterm; "LT"; t' = cterm ->  CCst.CIntTest(CAst.LT, t, t') 
	| t = cterm; "LE"; t' = cterm ->  CCst.CIntTest(CAst.LE, t, t') 
	| t = cterm; "GT"; t' = cterm ->  CCst.CIntTest(CAst.GT, t, t') 
	| t = cterm; "GE"; t' = cterm ->  CCst.CIntTest(CAst.GE, t, t') 
	| t = cterm; "EQ"; t' = cterm ->  CCst.CIntTest(CAst.EQ, t, t')   ]
    | "plusand" LEFTA
	[ t = cterm; "iplus"; t' = cterm ->  CCst.CIntOp(CAst.Plus, t, t') 
	| t = cterm; "iminus"; t' = cterm ->  CCst.CIntOp(CAst.Minus, t, t') 
	| t = cterm; "&&"; t' = cterm ->  CCst.CBoolOp(CAst.BAnd, t, t')  ]
    | "multor" LEFTA
	[ t = cterm; "itimes"; t' = cterm ->  CCst.CIntOp(CAst.Times, t, t') 
	| t = cterm; "imod"; t' = cterm ->  CCst.CIntOp(CAst.Mod, t, t') 
	| t = cterm; "||"; t' = cterm ->  CCst.CBoolOp(CAst.BOr, t, t')  ]
    | "app" LEFTA
	[ "fst"; t = cterm -> CCst.CProj(1, t)
	| "snd"; t = cterm -> CCst.CProj(2, t)
	| t = cterm; t' = cterm -> CCst.CApp(t, t') ]
    | "ascribe" NONA
	[ e = cterm; "::"; t = cterm -> CCst.CTypeAscribe(e, t) ]
    | "prodtype" LEFTA
	[ t1 = cterm; "*"; t2 = cterm -> CCst.CProdType(t1, t2) ]

    | "ifthenelse" LEFTA
	[ "if"; t1 = cterm; "then"; t2 = cterm; "else"; t3 = cterm ->
	    CCst.CIfThenElse(t1, t2, t3) ]
    | "simple" NONA
	[ "CType" -> CCst.CSort(CAst.CType)
	| "hol"; "(";  t = modalterm; ")" ->
	    CCst.CSigmaUnit(CCst.CHolTerm(t))
	| "tup"; "("; t1 = cterm; ","; t2 = cterm; ")" -> CCst.CTuple(t1, t2)
	| "<|"; t = modalterm; "|>" ->
	    CCst.CPackUnit(CCst.CHolTerm(t))
	| "static"; "{"; e = cterm; "}" ->
	    CCst.CStaticDo(e)
	| "trusted"; "{"; e = cterm; "}" ->
	    CCst.CPrfErase(e)
(*	| "preeval"; "("; t1 = ident; ctx = ctxterm; params = LIST1 modalterm_paren; ")" ->
	    let params' = List.fold_right (fun elm cur -> CCst.CHolTerm(elm) :: cur) params [] in
	    CCst.CPreEval(CCst.CVar(t1), CCst.CCtxTerm(ctx), params') *)
	| "preeval"; "("; e = cterm; ")" ->
	    CCst.cunpackmany
	      (CCst.CStaticDo(CCst.CUseMetaContext(e)))
	      [ ((LCst.aqstr "~pe", CAst.CHol), CCst.CUMetaCtx) ; ((LCst.aqstr "~unused", CAst.CType), CCst.CUNoCtx) ]
	      (CCst.CPackUnit(CCst.CHolTerm(LCst.LTermInCtx(LCst.LCurctx,LCst.LModalOmitSubst(LCst.LMeta(LCst.aqstr "~pe"))))))
	| "{"; "{"; e = cterm; "}"; "}" ->
	    CCst.cunpackmany
	      (CCst.CStaticDo(CCst.CUseMetaContext(e)))
	      [ ((LCst.aqstr "~pe", CAst.CHol), CCst.CUMetaCtx) ; ((LCst.aqstr "~unused", CAst.CType), CCst.CUNoCtx) ]
	      (CCst.CPackUnit(CCst.CHolTerm(LCst.LTermInCtx(LCst.LCurctx,LCst.LModalOmitSubst(LCst.LMeta(LCst.aqstr "~pe"))))))
	| "Kind" -> CCst.CSort(CAst.CKind)
	| "ctx" -> CCst.CSort(CAst.CCtx)
	| "Unit" -> CCst.CUnitType
	| "unit" -> CCst.CUnitExpr
	| "int" -> CCst.CIntType
	| i = INT -> CCst.CIntConst(int_of_string i)
	| s = STRING -> CCst.CStringConst(s)
	| "string" -> CCst.CStringType
	| "bool" -> CCst.CBoolType
	| "true" -> CCst.CBoolConst(true)
	| "false" -> CCst.CBoolConst(false)
	| x = ident -> CCst.CVar( x )
	| t = ctxterm -> CCst.CCtxTerm(t)
	| "_" -> CCst.CAny(0)
	| "rec"; x = cident; ":"; t1 = cterm; "=>"; t2 = cterm ->
	    CCst.CRecType( x, t1, t2)
	| "fold"; "("; t1 = cterm; ","; t2 = cterm; ")" ->  CCst.CFold(t1, t2)
	| "unfold"; t1 = cterm ->  CCst.CUnfold(t1)
	| "sum"; "("; ts = LIST1 cterm SEP "+"; ")" -> CCst.CSumType(ts)
	| "ctor"; "("; i = INT; ","; t = cterm; ","; p = cterm; ")" -> CCst.CCtor(int_of_string i, t, p)
	| "ref"; t = cterm -> CCst.CRefType(t)
	| "mkref"; "("; t1 = cterm; ","; t2 = cterm; ")" -> CCst.CMkRef(t1,t2)
	| "!"; t = cterm -> CCst.CReadRef(t)
	| "array"; t = cterm -> CCst.CArrayType(t)
	| "mkarray"; "("; t1 = cterm; ","; t2 = cterm; ","; t3 = cterm; ")" ->
	    CCst.CMkArray(t1,t2,t3)
	| "[|"; ts = LIST1 cterm SEP ","; "|]"; "of"; t = cterm ->
	    CCst.CArrayLit(ts,t)
	| "arraylen"; t = cterm -> CCst.CArrayLen(t)
	| t1 = cterm; "."; "("; t2 = cterm; ")"; "<-"; t3 = cterm ->
	    CCst.CArraySet(t1,t2,t3)
	| t1 = cterm; "."; "("; t2 = cterm; ")" ->
	    CCst.CArrayGet(t1,t2)
	| "hash"; t = cterm ->
	    CCst.CHolHash(t)
	| "print"; t = cterm ->
	    CCst.CPrint(t)
	| "do"; "return"; t = cterm; "{"; d = LIST1 docommand SEP ";;"; "}" ->
	    (let d', (_, last) = Utils.ExtList.last d in
	    List.fold_right
	      (fun (x,tm) cmd ->
		CCst.CMatch(tm, [ (x, cmd);
				  ( (LCst.aqstr "non", CAst.CType),
				    CCst.CApp(CCst.CVar(LCst.aqstr "none"), t)) ]) )
	      d'
	      ( CCst.CApp(CCst.CApp(CCst.CVar(LCst.aqstr "some"), t), last) ))
	| t = modalterm -> CCst.CHolTerm(t)
	| `ANTIQUOT("",s) -> CCst.CAnt(_loc, "ct:"^s)
	| "("; t = cterm; ")" -> t ] ];

  ctxterm:
    [ [ "#"; c = context -> c
      | "#"; "@" -> LCst.LCurctx  ] ];

  docommand:
    [ [ x = ident; "<-"; t = cterm -> ( (x, CAst.CType) , t )
      | "return"; t = cterm -> ( ( LCst.aqstr "", CAst.CType) , t ) ] ];

  modalident:
    [ [ "?"; x = ident -> (x, CAst.CHol)  ] ];

  modalbinder:
    [ [ x = cident; ":"; t = modalterm_paren -> (x, CCst.CHolTerm(t)) ] ];

  holbranchpat:
    [ [ "("; metas = LIST0 modalbinder SEP ","; ")"; "."; t = modalterm_paren ->
            CCst.CHPatNested( [ metas, CCst.CHolTerm(t) ] )
      | `ANTIQUOT("",s) -> CCst.CHPatAnt(_loc, "pat:"^s)  ] ];

  holbranch:
    [ [ pats = LIST1 holbranchpat SEP ","; "|->"; e = cterm ->
	  (pats, e)  ] ];

  ctxbranch:
    [ [ "("; ctxvs = LIST0 cident SEP ","; ")"; ".";
	"("; metas = LIST0 modalbinder SEP ","; ")"; ".";
	t = context; "|->"; e = cterm ->
	  (ctxvs, metas, CCst.CCtxTerm(t), e)  ] ];

  matchbranch:
    [ [ x = cident; "|->"; e = cterm -> (x, e) ] ];

(*
  modalsubst:
    [ [ l = LIST1 modalsubst1 SEP "," -> l ] ];
  modalsubst1:
    [ [ t = modalterm_paren; "~>"; t' = modalterm_paren -> <:expr< ( $t$, $t'$ ) >> ] ];
*)
  def:
    [ [ x = cident; ":"; t = cterm; "="; e = cterm -> (x, t, e) ] ];

  cident:
    [ [ x = modalident -> x 
      | "#"; x = ident -> (x, CAst.CCtx) 
      | x = ident -> (x, CAst.CType)
      (* | "^"; x = LIDENT -> (x, CAst.CType) *) ] ];

  unpackident:
    [ [ c = cident -> (c, CCst.CUNoCtx)
      | ctx = context; "."; x = ident -> ((x, CAst.CHol), CCst.CUCtx ctx)
      | "@@"; x = ident -> ((x, CAst.CHol), CCst.CUMetaCtx)
      | "@"; x = ident -> ((x, CAst.CHol), CCst.CUCtx(LCst.LCurctx) ) ] ];

  cvar:
    [ [ x = cident; ":"; t = cterm -> (x,t) ] ];

  cvars:
    [ [ xs = LIST1 cvar SEP "," -> xs ]];

  cterm_ast:
    [ [ t = cterm -> CCst.comp_ast_of_cst ~app_type:true ~defs:!Logic_defs.logic_global_env t ]];

  modalterm_ast:
    [ [ t = modalterm_paren -> LCst.ast_of_modal ~app_type:true ~defs:!Logic_defs.logic_global_env t ]];
  
  optsemi:
    [ [ ";;" -> () (* | -> () *) ] ];

  compdef:
    [ [ 
        t = logicdef -> t
      | "type"; x = ident; "="; t = cterm -> 
        (let x = LCst.str_remove_anti x in
	 Phrases.PhrTypDefinition(x, None, t, _loc))
      | "let"; x = ident; "="; t = cterm ->
        (let x = LCst.str_remove_anti x in
	 Phrases.PhrExpDefinition(x,None,t,_loc))
      | "let"; x = ident; ":"; tp = cterm; "="; t = cterm ->  
        (let x = LCst.str_remove_anti x in
	 Phrases.PhrExpDefinition(x,Some tp,t,_loc))
      | "let"; "_"; "="; t = cterm -> 
         Phrases.PhrExpDefinition("_",None,t,_loc)
      | "let"; "_"; ":"; tp = cterm; "="; t = cterm ->  
         Phrases.PhrExpDefinition("_",Some tp,t,_loc)

      | "ExtDefinition"; name = ident; ":"; tp = modalterm_paren; ":="; tm = cterm; optdot ->
          let name = LCst.str_remove_anti name in
	  Phrases.PhrComplogicDef(name,CCst.CStaticDo(tm),tp,_loc)
      | "ExtDefinition"; name = ident; params = paramlist; ":"; tp = lterm; ":="; tm = cterm; optdot ->
          let name = LCst.str_remove_anti name in
	  let tp' = LCst.LTermInCtx(params, tp) in
	  let tm' = CCst.CSetContext(params, tm) in
	  Phrases.PhrComplogicDef(name,CCst.CStaticDo(tm'),tp',_loc)

      | "reset"; optdot -> Phrases.PhrGlobalReset(_loc)
      | "import"; t = STRING; optdot -> Phrases.PhrGlobalImport(t,_loc)
      | "save"; t = STRING; optdot -> Phrases.PhrGlobalSave(t,_loc)
    ] ];

  optdot:
    [ [  -> () | "." -> () ] ] ;

(*
  compdef_eoi:
    [[ cds = LIST1 compdef; `EOI ->
	 let cdexpr = List.fold_right (fun cd cur -> <:str_item< $cd$ ;; $cur$>>) (List.map Comp_translate.translate_phrase cds) <:str_item< >> in
	   cdexpr ] ];
*)

  veriml_phrase:
    [ [
        d = directive; optsemi -> Some d
      | cd = compdef; optsemi -> Some cd 
      | optsemi -> Some (Phrases.PhrNone(_loc))
      | "need"; s = STRING; optsemi -> Some (Phrases.PhrNeed(s,_loc))
      | "fullreset"; optsemi -> Some (Phrases.PhrFullReset(_loc))
      | `EOI -> None ] ];

  veriml_file:
    [ [
      cd = compdef; optsemi; (l, stopped) = SELF -> ( cd :: l , stopped )
    | "fullreset"; optsemi; (l, stopped) = SELF -> ( (Phrases.PhrFullReset(_loc)) :: l , stopped )
    | "need"; s = STRING; optsemi -> ( [ Phrases.PhrNeed(s,_loc) ] , Some (Loc.move_line 1 _loc) )

    | `EOI -> ( [], None ) ] ];

  longident:
    [ [  i = UIDENT -> <:ident< $uid:i$ >>
      |  i = LIDENT -> <:ident< $lid:i$ >>
      |  i = UIDENT; "."; j = SELF -> <:ident< $uid:i$.$j$ >> ] ];

  directive:
    [ [ "#"; a = LIDENT; s = STRING -> Phrases.PhrDirective( <:str_item< # $a$ $str:s$ >> )
      | "#"; a = LIDENT; s = longident -> Phrases.PhrDirective( <:str_item< # $a$ $id:s$ >> )
      | "#"; a = LIDENT -> Phrases.PhrDirective( <:str_item< # $a$ >> )
      | "#"; "#"; "include"; s = longident -> Phrases.PhrDirective( <:str_item< include $id:s$ >> )
      ] ];

  END;;


module AQ = Syntax.AntiquotSyntax

let destruct_aq s = 
  let pos = String.index s ':' in 
  let len = String.length s in 
  let name = String.sub s 0 pos 
  and code = String.sub s (pos + 1) (len - pos - 1) in 
  name, code 
  
let expand_antiquotations = 
  object 
    inherit Ast.map as super 
    method expr = 
      function 
        | Ast.ExAnt (_loc, s) -> 
            let n, c = destruct_aq s in 
            let e = AQ.parse_expr _loc c in 
            begin match n with 
              | "nid" -> <:expr< Logic_cst.StrId($e$) >> 
              | "id" -> <:expr< $e$ >> 
	      | "lt" -> <:expr< $e$ >>
	      | "mt" -> <:expr< $e$ >>
	      | "ct" -> <:expr< $e$ >>
	      | "pat" -> <:expr< Comp_cst.CHPatNested($e$) >>
	      | _ -> e
	    end
        | e -> super#expr e 
  end 


let expand_comp_quot loc _loc_name_opt quotation_contents =
  let q = !Camlp4_config.antiquotations in 
  Camlp4_config.antiquotations := true; 
  let res = CompGram.parse_string cterm_eoi loc quotation_contents in 
  Camlp4_config.antiquotations := q; 
  expand_antiquotations#expr (Quote.Cst.quote_comp res loc);;

(*
let expand_compdef_eoi_quot loc _loc_name_opt quotation_contents = CompGram.parse_string compdef_eoi loc quotation_contents;;
*)

(* Syntax.Quotation.add "cc" Syntax.Quotation.DynAst.cterm_eoi_tag expand_comp_quot;; *)
(* Syntax.Quotation.add "veriml" Syntax.Quotation.DynAst.str_item_tag expand_compdef_eoi_quot;; *)
(* Syntax.Quotation.default := "veriml";; *)
Syntax.Quotation.add "vmlcst" Syntax.Quotation.DynAst.expr_tag expand_comp_quot;;

