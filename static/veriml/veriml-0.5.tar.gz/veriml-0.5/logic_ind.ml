open Utils
module LCst = Logic_cst
open Logic_ast
open Logic_core
open Logic_typinf
open Logic_defs

let str_remove_anti = LCst.str_remove_anti
let aqstr = LCst.aqstr

let gatherapp t =
  let rec aux resargs t =
    match t with
	LApp(t1, _, t2) -> aux (t2 :: resargs) t1
      | _ -> t, resargs
  in
    aux [] t

let gatherpi t =
  let rec aux resargs t =
    match t with
	LPi(_, _, t1, t2) -> aux (t1 :: resargs) t2
      | _ -> List.rev resargs, t
  in
    aux [] t

let get_res_head t = fst (gatherapp (snd (gatherpi t)))


let appmany t args =
  let rec aux res args =
    match args with
	[] -> res
      | hd :: tl -> aux (LApp(res, None, hd)) tl
  in
    aux t args

let pimany arrows t =
  let rec aux arrows =
    match arrows with
	[] -> t
      | hd :: tl -> LPi(None, (LSort(LSet)), hd, aux tl)
  in
    aux arrows

let lammany arrows t =
  let rec aux arrows =
    match arrows with
	[] -> t
      | hd :: tl -> LLambda(None, hd, aux tl)
  in
    aux arrows

let fix_ast mt =
  let mkinfer (fenv,benv) = mk_infer fenv benv 0 0 0 0 in
  nowarn let LTermInCtx(ctx,t) = mt in
  let t = 
    lterm_map_envlen
      ~lapp:(fun env _ _ _ rt1 _ rt2 -> LApp(rt1, Some (mkinfer env), rt2))
      ~lpi:(fun env s _ _ _ _ rt1 rt2 -> LPi(s, (mkinfer env), rt1, rt2))
      ~leq:(fun env _ _ _ _ rt1 rt2 -> LEq(Some (mkinfer env), rt1, rt2))
      (List.length ctx,0)
      t
  in
  LTermInCtx(ctx,t)


(* rules for positivity checks: *)
(* ---------------------------- *)
(* [ ctx, +name ].name  ok
   [ ctx, +name ].forall x : t1, t2] ok <= [ ctx, ++name ].t1 /\ [ ctx, +name ].t2
   [ ctx, +name ].t1 t2              ok <= [ ctx, +name  ].t1 /\ [ ctx ].t2
   
   [ ctx, ++name ].name      ok
   [ ctx, ++name ].t1 -> t2  ok <= [ctx].t1 /\ [ctx, ++name].t2
   [ ctx, ++name ].C/sigma   ok <= when C : [ctx']t , {i}[ ctx, ++name ].sigma_i when ctx'_i = +t'_i or [ctx].sigma_i when ctx'_i = t'_i *)
   

(* notes for generating folds *)   
(* -------------------------- *)
(* Inductive type name [ctx] : Set := {i}cname_i : [ctx, name +: Set].(constrs_i : Set).

   the iterator version would be:
   Axiom nameFold [ctx, T' : Set] : {i}(constrs_i/[id, T']) -> name/id -> T'.
   but we need the recursor version:
   Axiom nameFold [ctx, T' : Set] : {i}(mapType[constrs_i](T')) -> name/id -> T'.

   also we need rewriting axioms:
   {i}Axiom nameFoldCname_i [ctx, T' : Set].forall {i}(f_i : mapType[constrs_i]), forall {j}(x_j : args(constrs_j/[id, name])),
                                            nameFold f (cname_i x) = mapTerm[constrs_i](nameFold f; f_i)

   Last, we need an induction principle:
   Axiom nameInd [ctx] : forall P : name -> Prop, {i}(mapProp[constrs_i](P; cname_i)) -> forall n : name/id, P n *)

(* mapType[ [ctx, +name].name     ](T') = T'
   mapType[ [ctx, +name].t1 -> t2 ](T') = t1 -> mapType[ [ctx, +name].t2 ](T')       when name does not occur in t1
   mapType[ [ctx, +name].t1 -> t2 ](T') = t1/name -> t1/T' -> mapType[ [ctx, +name].t2 ](T')              otherwise *)
      
(* mapTerm[ [ctx, +name].name     ](rec : name -> T', t : name ) = t
   mapTerm[ [ctx, +name].t1 -> t2 ](rec, t : mapType[t1 -> t2])  = mapTerm[ [ctx, +name].t2 ](rec; t x_i : mapType[t2])
   mapTerm[ [ctx, +name].t1 -> t2 ](rec, t : mapType[t1 -> t2])  =
      let xr : t1/T' = mapTerm'[ [ctx,++name].t1 ](rec; x_i : t1/name) in
      mapTerm[ [ctx, +name].t2 ](rec; t x_i xr) )

   mapTerm'[ [ctx, ++name].name    ](rec; t : name) = rec t
   mapTerm'[ [ctx, ++name].t1 -> t2](rec; t : t1/n -> t2/n) = lam x : t1/n.mapTerm'[ [ctx, ++name].t2 ](rec; t x : t2/n)
   mapTerm'[ [ctx, ++name].c/sigma ](rec; t : c/(sigma/n))  = mapTermForC( ... )   -- for nested types, but not implemented yet:
                                                                                      when having something like list/[A := rose], A is a positive parameter,
                                                                                      so map could be define for it as well. *)

(* mapProp[ [ctx, +name].name     ](P; e : name    ) = P e
   mapProp[ [ctx, +name].t1 -> t2 ](P; e : t1/n -> t2/n) = forall x : t1/name, mapProp[ [ctx, +name].t2 ](P; e x : t2/n)  when name does not occur in t1
   mapProp[ [ctx, +name].t1 -> t2 ](P; e : t1/n -> t2/n) = forall x : t1/name, mapProp'[ [ctx, ++name].t1 ](P; x : t1/n) -> mapProp[ [ctx, +name].t2 ](P; e x : t2/n)
   
   mapProp'[ [ctx, ++name].name    ](P; e : name        ) = P e
   mapProp'[ [ctx, ++name].t1 -> t2](P; e : t1/n -> t2/n) = forall x : t1/n, mapProp[ [ctx, ++name].t2 ](P; e x : t2/n)
   mapProp'[ [ctx, ++name].c/sigma ](P; e : c/(sigma/n) ) = mapPropForC( ... ) *)


let mapType ctx name _T' substN substT' t = 

  let namefvar = List.length ctx - 1 in
  
  let args, res = gatherpi t in
  let _ = assert (res = LVar(LFVar(namefvar))) in
  let args' = List.flatten (List.map (fun t ->
		if not (BindLterm.has_free_var namefvar t) then
		  [ modal_apply_subst (LTermInCtx(ctx,t)) substN ]
		else
		  [ modal_apply_subst (LTermInCtx(ctx,t)) substN ;
		    modal_apply_subst (LTermInCtx(ctx,t)) substT' ]) args)
  in
  pimany args' _T'

let mapTerm ctx name argsn frec t e =
  (* actually, compared to the above, we assume that all of the t1's (args of t) are already abstracted over *)
  let namefvar = List.length ctx - 1 in

  let argsT, res = gatherpi t in
  let _ = assert (res = LVar(LFVar(namefvar))) in
  let mapTerm' t e =
    let strictargs, _ = gatherpi t in
    let strictN = List.length strictargs in
    let frec' = BindLterm.shift_bound strictN frec in
    let e' = BindLterm.shift_bound strictN e in
    lammany strictargs (appmany frec' [appmany e' (boundlist strictN)])
  in
  let args' = 
    List.flatten (ExtList.mapi (fun i t ->
        if not (BindLterm.has_free_var namefvar t) then
	  [ LVar(LBVar(argsn - i - 1)) ]
	else
	  [ LVar(LBVar(argsn - i - 1)); mapTerm' t (LVar(LBVar(argsn - i - 1))) ]) argsT)
  in
  appmany e args'

let mapProp ctx name _P substN t e = 
  let namefvar = List.length ctx - 1 in

  let argsT, res = gatherpi t in
  let _ = assert (res = LVar(LFVar(namefvar))) in
  let mapProp' t e =
    let strictargs, _ = gatherpi t in
    let strictN = List.length strictargs in
    let e' = BindLterm.shift_bound strictN e in
    pimany strictargs (appmany _P [appmany e' (boundlist strictN)])
  in
  let params, isvar =
    List.split (List.flatten (ExtList.mapi (fun i t ->
        if not (BindLterm.has_free_var namefvar t) then
	  [ modal_apply_subst (LTermInCtx(ctx,t)) substN, true ]
	else
	  [ modal_apply_subst (LTermInCtx(ctx,t)) substN, true; mapProp' t (LVar(LBVar(0))), false ]) argsT))
  in
  let l2i l = List.length params - l - 1 in
  let vars = ExtList.filtermapi (fun i b -> if b then Some (LVar(LBVar(l2i i))) else None) isvar in
  pimany params (appmany _P [appmany e vars])
  

let mapPropForProp ctx substT substN t = 
  let namefvar = List.length ctx - 1 in

  let argsT, res = gatherpi t in
  let ivar, params =
    List.fold_left
      (fun (i,l) t ->
	let t = BindLterm.shift_bound i t in
        if not (BindLterm.has_free_var namefvar t) then
	  ( i , l ++ [ modal_apply_subst (LTermInCtx(ctx,t)) substN ] )
	else
	  ( i + 1,
	    l ++ [ modal_apply_subst (LTermInCtx(ctx,t)) substN;
	      let t' = BindLterm.shift_bound 1 t in
	      modal_apply_subst (LTermInCtx(ctx,t')) substT ])) (0,[]) argsT
  in
  let res' = BindLterm.shift_bound ivar res in
  pimany params (modal_apply_subst (LTermInCtx(ctx,res')) substT)


let new_inductive_type (astconv : LCst.lmodalterm -> lmodalterm)
                       (typecheck : lterm_env -> lmodalterm -> lmodalterm -> lmodalterm * lmodalterm)
		       (new_axiom : string -> lmodalterm -> 'a)
		       name ctx tp constrs =

  (* 1. conversions from CST to AST. in the constructors, incorporate recursive type into context *)
  let ctx =
    match ctx with
	LCst.LCtxAsList(ctx) ->
	  let ctx' = List.map (fun (n,t,p) -> (n,t,LPAny (* for nested types: LPPos *) )) ctx in
	    LCst.LCtxAsList(ctx')
      | _ -> failwith "expected ctx as list"
  in
  let tp_cst = tp in
  let tp = astconv (LCst.LTermInCtx(ctx, tp)) in
  let constrs =
    let ctx' = match ctx with LCst.LCtxAsList(ctx) -> LCst.LCtxAsList(ctx ++ [ (aqstr name, tp_cst, LPPos) ] ) | _ -> failwith "expected ctx as list" in
      List.map (fun (name, tp) -> (name, astconv (LCst.LTermInCtx(ctx', tp)))) constrs
  in
  let ctx = match tp with LTermInCtx(ctx, _) -> ctx | _ -> failwith "expected term in ctx" in

  (* 2. typecheck resulting type to make sure that inductive definitions at its sort are allowed *)
  let env = ([], !Logic_defs.logic_global_env, [], []) in
  let kind = LTermInCtx(ctx, mk_infer 0 (List.length ctx) 0 0 0 0) in
  let _, ind_mt, _ = do_typing_phase false typecheck
          ("error in typechecking for inductive definition " ^ name)
          ("error in typechecking for inductive definition " ^ name)
          env None tp kind
  in
  nowarn let LTermInCtx(_, ind_tp) = ind_mt in
  let ind_sort = get_res_head ind_tp in
  let _ = match ind_sort with LSort(LProp) | LSort(LSet) -> () | _ -> failwith "inductive type definition in non-allowed sort" in
    

  (* 3. typecheck each constructor *)
  let constrs =
    List.map (fun (name, mt) ->
		match mt with
		    LTermInCtx(ctx', tp') ->

		      let ctx0, (indname,_,k,p) = ExtList.last ctx' in
		      let ctx' = ctx0 ++ [ indname,ind_tp,k,p ] in
		      let mt' = LTermInCtx(ctx', tp') in

		      let kind = LTermInCtx(ctx', ind_sort) in
		      let _, constr_tp, _ =
			do_typing_phase false typecheck
			  ("error in typechecking for inductive constructor " ^ name)
			  ("error in typechecking for inductive constructor " ^ name)
			  env None mt' kind
		      in
		      nowarn let LTermInCtx(_, constr_base) = constr_tp in
		      let _ =
			match get_res_head constr_base with
			    LVar(LFVar(i)) when i = List.length ctx0 -> () (* result is the recursive argument *)
			| _ -> failwith "constructor does not return a result in the recursive type"
		      in
			(name, constr_tp)
		  | _ -> failwith "expected term in ctx") constrs
  in

  (* 4. add axioms *)
  (* Axiom name [ctx] : ind_mt . *)
  let axiom_type = new_axiom name ind_mt in
  let axioms_constr =
    List.map (fun (cname, mt) ->
		match mt with
		    LTermInCtx(ctx, tp) ->
		      let ctx', _ = ExtList.last ctx in
		      let subst0 = freelist (List.length ctx') in
		      let subst = subst0 ++ [ LModal(LNMeta(name), subst0) ] in
		      let mt' = LTermInCtx(ctx', modal_apply_subst mt subst) in
			new_axiom cname mt'
		  | _ -> failwith "expected term in ctx") constrs
  in

  (* 5. construct folds *)
  let axioms_fold =

    match ind_sort with

	LSort(LProp) ->

	  (* Inductive predicate name [ctx] : args -> ind_sort := {i}cname_i : [ctx, name +: args->ind_sort].(constrs_i : ind_sort) .
	     ~~>
	     Axiom nameInd [ctx, T' : args->ind_sort] : {i}(constrs_i/[id_ctx, T']) -> forall {j}x_j:args_j. name/id_ctx x -> T' x. *)

	  (let ctx = List.map (fun (n,t,k,_) -> (n,t,k,LPAny)) ctx in
	   let ctx' = ctx ++ [ (Some "T'", ind_tp, Some (mk_infer 0 (List.length ctx) 0 0 0 0), LPAny ) ] in
	   let _T' = LVar(LFVar(List.length ctx)) in
	   
	   let subst0 = freelist (List.length ctx) in
	   let subst  = subst0 ++ [_T'] in
	   let substN  = subst0 ++ [ LModal(LNMeta(name), subst0) ] in
	   
	   let constr' =
	     (* also include constrs_i/[id_ctx, nameInd] in recursive arguments *)
	     (* we weren't including it, so the mapping function was:
		(fun (_, mt) -> modal_apply_subst mt subst) *)
	     List.map (fun (cname, mt) ->	         
	                  nowarn let LTermInCtx(_, ctyp) = mt in
			  mapPropForProp ctx' subst substN ctyp) constrs
	   in
	   let args = fst (gatherpi ind_tp) in

	   let inh = appmany (LModal(LNMeta(name), subst0)) (boundlist (List.length args)) in
	   let res = appmany _T' (boundlist ~start:1 (List.length args)) in

	   let mt_fold = LTermInCtx(ctx', pimany (constr' ++ (args ++ [inh])) res) in
	   let mt_fold = fix_ast mt_fold in

	   (* let _ = List.iter (fun t -> Format.printf "%a\n" Logic_print.pr_modal t) [ mt_fold ] in *)
	   
	   [ new_axiom (name^"Ind") mt_fold ] )

      | LSort(LSet) ->

	  (* in this case, ind_tp = Set ; args should be nil *)


	((* first: large elimination *)
	  let ctx = List.map (fun (n,t,k,_) -> (n,t,k,LPAny)) ctx in
	  let ctx' = ctx ++ [ (Some "T'", ind_tp, Some (mk_infer 0 (List.length ctx) 0 0 0 0), LPAny) ] in
	  let _T' = LVar(LFVar(List.length ctx)) in
	  
	  let subst0 = freelist (List.length ctx) in
	  let substN  = subst0 ++ [ LModal(LNMeta(name), subst0) ] in
	  let substT' = subst0 ++ [_T'] in
	  
	  let constrs' =
	    List.map (fun (_, mt) -> nowarn let LTermInCtx(_, ctyp) = mt in mapType ctx' name _T' substN substT' ctyp) constrs
	  in
	  
	  let args = fst (gatherpi ind_tp) in
	  let _ = assert (args = []) in
	  
	  let inh = LModal(LNMeta(name),subst0) in
	  let res = _T' in
	    
	  let mt_fold = LTermInCtx(ctx', pimany (constrs' ++ [inh]) res) in
	  let mt_fold = fix_ast mt_fold in
	  let axiom_fold = new_axiom (name ^ "Fold") mt_fold in

	  (* generate rewriting lemmas *)
	  
	  let mt_fold_rewriters =

	    let map_constructor i (cname,mt) =
	      nowarn let LTermInCtx(_, ctyp) = mt in
 	      let funcsT = constrs' in
 	      let argsT  = List.map (fun t -> modal_apply_subst (LTermInCtx(ctx',t)) substN) (fst (gatherpi ctyp)) in
	      let funcsV = boundlist ~start:(List.length argsT) (List.length funcsT) in
	      let argsV = boundlist (List.length argsT) in
	      let foldV = LModal(LNMeta(name^"Fold"), substT') in
	      let constructorV = LModal(LNMeta(cname), subst0) in

	      let recf = appmany foldV funcsV in
	      let bodylhs = appmany recf [ appmany constructorV argsV ]  in
	      let bodyrhs = 
		let f_i = List.nth funcsV i in
		mapTerm ctx' name (List.length argsT) recf ctyp f_i 
	      in

	      let fulltype = 
		pimany (funcsT ++ argsT) (LEq(None, bodylhs, bodyrhs))
	      in

	      name ^ "Fold" ^ cname , fix_ast (LTermInCtx(ctx', fulltype))
	    in
	    ExtList.mapi map_constructor constrs
	  in
	  (* let _ = List.iter (fun (_,t) -> Format.printf "%a\n" Logic_print.pr_modal t) mt_fold_rewriters in *)
	  let axioms_rewriters = List.map (uncurry new_axiom) mt_fold_rewriters in

	  let mt_ind =
	  (* last: induction principle *)
	    
	    let _P = LVar(LFVar(List.length ctx)) in
	    let indtp = LModal(LNMeta(name), subst0) in
	    let propType = pimany [ indtp ] (LSort(LProp)) in
	    let constrs' =
	      List.map
		(fun (cname, mt) ->
		  nowarn let LTermInCtx(_, ctyp) = mt in
		  mapProp ctx' name _P substN ctyp (LModal(LNMeta(cname), subst0)))
		constrs
	    in

	    let res = appmany _P [LVar(LBVar(0))] in
	    
	    let lt_ind = pimany (constrs' ++ [indtp]) res in
	    let lt_ind = BindLterm.close_down (List.length ctx') lt_ind in
	    let mt_ind = LTermInCtx(ctx, pimany [propType] lt_ind ) in

	    fix_ast mt_ind
	  in
	  let axiom_ind = new_axiom (name^"Ind") mt_ind in
	  
	   [ axiom_fold ] ++ axioms_rewriters ++ [ axiom_ind ] )

      | _ -> []

  in

    axiom_type :: (axioms_constr ++ axioms_fold )

    
