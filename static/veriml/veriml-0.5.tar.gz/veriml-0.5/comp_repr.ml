open Camlp4.PreCast
open Utils
open Binding
open Logic_ast
open Logic_core

module ML = Comp_ocamlast

(* limitations:
   1. context parameters should only appear as the first variable *)

let hol_typ _loc = <:ctyp< Logic_ast.lterm >>
let ctx_typ _loc = <:ctyp< Logic_ast.lfastctx >>


let exprlist _loc ls = List.fold_right (fun elm cur -> <:expr< $elm$ :: $cur$ >>) ls <:expr< [] >>

let is_idsubst fctx subst =
  (* the idsubst looks like: f0, f1, ..., f_(fctx-1) or prefixes thereoff *)
  (* I had this as: the above, b_(bctx-1), ... b_0 -- this is wrong since the modal term has been opened up fully *)
  let idsubst = List.map (fun i -> LVar(LFVar(i))) (increasing fctx) in
  ExtList.is_prefix subst idsubst
      

let quotevar _loc s = <:expr< None >> (* match s with Some s -> <:expr< Some $str:s$ >> | None -> <:expr< None >> *)
let quotecvar _loc (s,k) =
  let s' = (match s with Some s -> <:expr< Some $str:s$ >> | None -> <:expr< None >>) in
  let k' =
    match k with
	Comp_ast.CType -> <:expr< Comp_ast.CType >>
      | Comp_ast.CKind -> <:expr< Comp_ast.CKind >>
      | Comp_ast.CCtx -> <:expr< Comp_ast.CCtx >>
      | Comp_ast.CHol -> <:expr< Comp_ast.CHol >>
  in
  <:expr< ($s'$, $k'$) >>


let find_ctxparam _loc ctxnames ctx =
  match ctx with
      (_, LTermList( LBCtx( j ) ), _, _) :: tl ->
	(let _ = List.iter (fun (_, t, _, _) -> ignore (lterm_map ~lbctx:(fun _ -> failwith "can't handle context variables other than as heads") t)) tl in
	 let varname = ML.expr_var (List.nth ctxnames j) _loc in
	   Some <:expr< $varname$ >> )
    | _ -> None;;

let tr_lsort _loc s =
  match s with
      LType -> <:expr< Logic_ast.LType >>
    | LSet  -> <:expr< Logic_ast.LSet  >>
    | LProp -> <:expr< Logic_ast.LProp >>;;

let tr_lsort_pat _loc s =
  match s with
      LType -> <:patt< Logic_ast.LType >>
    | LSet  -> <:patt< Logic_ast.LSet  >>
    | LProp -> <:patt< Logic_ast.LProp >>;;

let rec tr_modal _loc ((metanames,ctxnames,erasure) as env) mt =
  match mt with
      LTermInCtx( ctx, t ) ->
	let ctxparam = find_ctxparam _loc ctxnames ctx in
	  tr_lterm' _loc env (List.length ctx) 0 ctxparam t
    | LBMeta( i ) -> ML.expr_var (List.nth metanames i) _loc
    | LNMeta( s ) -> failwith "should not have a named meta at this point"
    | _ -> failwith "not supported yet"

and tr_fvar_index _loc ctxparam i =
  match ctxparam with
      Some j ->
	(let i = string_of_int (i - 1) in
	   <:expr< Logic_ast.fctx_length $j$ + $int:i$ >>)
    | None ->
	(let i = string_of_int i in
	   <:expr< $int:i$ >>)

and tr_lterm' _loc env fctx bctx ctxparam lt =
  let tr_lterm = tr_lterm' _loc env fctx bctx ctxparam in
  let tr_opt_lterm t =
    match t with
	Some t -> let t' = tr_lterm t in <:expr< Some $t'$ >>
      | None   -> <:expr< None >>
  in
    match lt with
	LSort(s)       -> let s = tr_lsort _loc s in <:expr< Logic_ast.LSort($s$) >>
      | LVar(LBVar(i)) -> let i = string_of_int i in <:expr< Logic_ast.LVar(Logic_ast.LBVar($int:i$)) >>
      | LVar(LFVar(i)) -> 
	  let ind = tr_fvar_index _loc ctxparam i in
	    <:expr< Logic_ast.LVar( Logic_ast.LFVar( $ind$ ) ) >>
      | LLambda(s,t1,t2) ->
	let t1 = tr_lterm t1 in
	let t2 = tr_lterm' _loc env fctx (bctx+1) ctxparam t2 in
	let s = quotevar _loc s in
	  <:expr< Logic_ast.LLambda($s$, $t1$, $t2$) >>
      | LPi(s,k,t1,t2) -> 
	let t1 = tr_lterm t1 in
	let t2 = tr_lterm' _loc env fctx (bctx+1) ctxparam t2 in
	let k  = tr_lterm k in 
	let s = quotevar _loc s in
	  <:expr< Logic_ast.LPi($s$, $k$, $t1$, $t2$) >>
      | LApp(t1, t, t2) ->
	  let t1 = tr_lterm t1 in
	  let t  = tr_opt_lterm t in
	  let t2 = tr_lterm t2 in
	    <:expr< Logic_ast.LApp($t1$, $t$, $t2$) >>
      | LEq(t, t1, t2) ->
  	  let t = tr_opt_lterm t in
	  let t1 = tr_lterm t1 in
	  let t2 = tr_lterm t2 in
	    <:expr< Logic_ast.LEq($t$, $t1$, $t2$) >>

      | LModal(LNMeta(erasable), [pf]) when erasable = "~erasable" ->
	  let (_,_,erasure) = env in
  	  let res =
	    if erasure then
	      <:expr< Logic_ast.LModal( Logic_ast.LNMeta("~trusted"), [] ) >>
	    else
	      tr_lterm pf
	  in
	  <:expr< Logic_ast.cond_emit_prf $res$ >>
	      
      | LModal(LNMeta(s), subst) -> let subst = tr_subst _loc env fctx bctx ctxparam subst in
	  <:expr< Logic_ast.LModal( Logic_ast.LNMeta($str:s$), $subst$ ) >>
      | LModal(mt, subst) ->
	  (if is_idsubst fctx subst then
	     tr_modal _loc env mt
	   else
	     let lt = tr_modal _loc env mt in
	     let subst' = tr_subst _loc env fctx bctx ctxparam subst in
	       <:expr< Logic_ast.BindLtermS.subst_free_list $subst'$ $lt$  >> )

      | LEqAxiom(s, ts) ->
	  let ts = List.map tr_lterm ts in
	  let ts = exprlist _loc ts in
	    <:expr< Logic_ast.LEqAxiom($str:s$, $ts$) >>

      | _ -> failwith "not supported yet hol"
and tr_subst _loc env fctx bctx ctxparam subst =
  match ctxparam, subst with
      Some j, ( LVar(LFVar(0)) :: tl ) ->
	let tl = exprlist _loc (List.map (fun t -> tr_lterm' _loc env fctx bctx ctxparam t) tl) in
	  <:expr< List.append (Logic_ast.fctx_subst $j$) $tl$ >>
    | _ -> exprlist _loc (List.map (fun t -> tr_lterm' _loc env fctx bctx ctxparam t) subst)

(*
and tr_substlen _loc ctxparam subst = 
  match ctxparam, subst with
      Some j, ( LVar(LFVar(0)) :: tl ) ->
	let n = string_of_int (List.length tl) in
	  <:expr< (Logic_ast.fctx_length $j$) + $int:n$ >>
    | _ -> 
	let n = string_of_int (List.length subst) in
	  <:expr< $int:n$ >>
*)

and tr_ctx ?(nosorts=false) _loc ((_,ctxnames,_) as env) ctx =

  match ctx with
      LCtxAsList(ctx) ->
	(let ctxparam = find_ctxparam _loc ctxnames ctx in
	 let translate_nonparam_ctx start ctx =
	   let ctx, len = 
	     List.fold_left (fun (ctx,len) (s,lt,lsort,_) ->
			       let lt' = tr_lterm' _loc env len 0 ctxparam lt in
			       let lsort' =
				 match lsort with
				     Some lsort ->
				       let t = tr_lterm' _loc env len 0 ctxparam lsort in
				       <:expr< Some $t$ >>
				   | None when nosorts -> <:expr< None >>
				   | None -> failwith "sorts of contexts should have been figured out by now"
			       in
			       let s = quotevar _loc s in
				 ( <:expr< $s$, $lt'$, $lsort'$, Logic_ast.LPAny >> :: ctx, len + 1)) ([],start) ctx in
	   let ctxexpr = exprlist _loc (List.rev ctx) in
	   let lenstr  = string_of_int len in
	     ctxexpr, <:expr< $int:lenstr$ >>
	 in

	   match ctxparam, ctx with
	       Some j, (_, LTermList( LBCtx( _ ) ), _, _ ) :: tl ->
		 let rest, _ = translate_nonparam_ctx 1 tl in
		 let ctxexpr = <:expr< List.append (Logic_ast.fctx_ctx $j$) $rest$ >> in
		 let lenrest = string_of_int (List.length tl) in
		 let lenexpr = <:expr< (Logic_ast.fctx_length $j$) + $int:lenrest$ >> in
		 let subexpr = tr_subst _loc env (List.length ctx) 0 ctxparam
		   (List.map
		      (fun i -> LVar(LFVar(i)))
		      (increasing (List.length ctx)))
		 in
		   <:expr< Logic_ast.mk_fctx $ctxexpr$ $lenexpr$ $subexpr$ >>

	     | _ ->
		 let ctxexpr, lenexpr = translate_nonparam_ctx 0 ctx in
		 let subexpr = exprlist _loc
		   (List.map (fun i ->
				let i = string_of_int i in
				<:expr< Logic_ast.LVar(Logic_ast.LFVar($int:i$)) >>)
		      (increasing (List.length ctx)))
		 in
		   <:expr< Logic_ast.mk_fctx $ctxexpr$ $lenexpr$ $subexpr$ >> )

    | LBCtx(j) ->
	let varname = ML.expr_var (List.nth ctxnames j) _loc in
	<:expr< Logic_ast.mk_fctx (Logic_ast.fctx_ctx $varname$) (Logic_ast.fctx_length $varname$) (Logic_ast.fctx_subst $varname$) >>

    | LFCtx(_) -> failwith "free context var should not be visible at this point"


let rec tr_pat' _loc ((metanames,ctxnames) as env) unifvars fctx bctx ctxparam guard_var_count lt =
  (* returns a pattern, a list of guard expressions, and a list of (pat,expr) openup expressions *)

  let tr_pat = tr_pat' _loc env unifvars fctx bctx ctxparam guard_var_count in
  let tr_pat_under_binder = tr_pat' _loc env unifvars fctx (bctx+1) ctxparam guard_var_count in
  let gen_new_var () = (let n = !guard_var_count in guard_var_count := n + 1; "gv" ^ (string_of_int n)) in
  let contain_unifvar unifvars t = 
    try ignore(lterm_map ~lbmeta:(fun i -> if i < unifvars then raise BindLterm.HasBoundVar else LBMeta(i)) t);
	false
    with BindLterm.HasBoundVar -> true
  in
  let openterm t =
    let fctxlen = tr_fvar_index _loc ctxparam fctx in
    let bctxlen = string_of_int bctx in
      <:expr< Logic_ast.BindLterm.open_up ~howmany:$int:bctxlen$ $fctxlen$ $t$ >>
  in
  let equalterms t1 t2 =
    let t1' = openterm t1 in
    let t2' = openterm t2 in
    let fctxlen = tr_fvar_index _loc ctxparam fctx in
    let bctxlen = string_of_int bctx in
      <:expr< Logic_core.lterm_equal !Logic_defs.logic_global_env ( $fctxlen$ + $int:bctxlen$ )
	$t1'$ $t2'$ >>
  in
  let maxvar t v =
    let fctxlen = tr_fvar_index _loc ctxparam fctx in
    let bctxexpr = string_of_int bctx in
    let vexpr   = if v = 0 then <:expr< 0 >> else (if v < fctx then tr_fvar_index _loc ctxparam v else let b = string_of_int (v - fctx) in <:expr< $fctxlen$ + $int:b$ >> ) in
      <:expr< Logic_ast.check_free_vars $t$ $fctxlen$ $int:bctxexpr$ $vexpr$ >>
  in

    match lt with
      | LLambda(s,t1,t2) ->
	  let (p1, g1, n1) = tr_pat t1 in
	  let (p2, g2, n2) = tr_pat_under_binder t2 in
	  let p = <:patt< Logic_ast.LLambda(_, $p1$, $p2$) >> in
	    (p, List.append g1 g2, List.append n1 n2)

      | LPi(s,k,t1,t2) ->
	  let (p1, g1, n1) = tr_pat t1 in
	  let (p2, g2, n2) = tr_pat_under_binder t2 in
	  let k = match k with LSort(s) -> tr_lsort_pat _loc s | _ -> failwith "sort of Pi should be known at this point" in
	  let p = <:patt< Logic_ast.LPi(_, Logic_ast.LSort($k$), $p1$, $p2$) >> in
	    ( p , List.append g1 g2, List.append n1 n2 )

      | LApp(t1,Some t1t,t2) ->
	  let (pt,gt,nt) = tr_pat t1t in
	  let (p1,g1,n1) = tr_pat t1 in
 	  let (p2,g2,n2) = tr_pat t2 in
	  let p = <:patt< Logic_ast.LApp( $p1$, Some $pt$, $p2$ ) >> in
	    (p, List.append gt (List.append g1 g2), List.append nt (List.append n1 n2))

      | LApp(t1,None,t2) ->
	  failwith "expected type argument in app"

      | LEq(Some t,t1,t2) ->
	  let (pt,gt,nt) = tr_pat t  in
	  let (p1,g1,n1) = tr_pat t1 in
 	  let (p2,g2,n2) = tr_pat t2 in
	  let p = <:patt< Logic_ast.LEq( Some $pt$, $p1$, $p2$ ) >> in
	    (p, List.append gt (List.append g1 g2), List.append nt (List.append n1 n2))

      | LEq(None,t1,t2) ->
	  failwith "expected type argument in eq"

      | LModal(LNMeta(s) , subst) when List.exists (contain_unifvar (List.length unifvars)) subst ->
  	  let ps,gs,ns = 
	    List.fold_left
	      (fun (ps,gs,ns) t ->
		 let p, g, n = tr_pat t in
		   (List.append ps [ p ] , List.append gs g, List.append ns n))
	      ([],[],[]) subst
	  in
	  let psubst = List.fold_right (fun p cur -> <:patt< $p$ :: $cur$ >> ) ps <:patt< [] >> in
	  let s' = gen_new_var () in
	    ( <:patt< Logic_ast.LModal( Logic_ast.LNMeta($lid:s'$) , $psubst$ ) >>, <:expr< $lid:s'$ = $str:s$ >> :: gs, ns)

      | LModal(LBMeta(i) , subst) when i < List.length unifvars ->
	  
	  let name, foundyet = List.nth unifvars i in
	  let pvar, gvar, nvar =
	    if not (!foundyet) then
	      (let p = <:patt< $lid:name$ >> in
	       let n = if bctx > 0 then [ p, openterm <:expr< $lid:name$ >> ] else [] in
	       let g = (if List.length subst < fctx + bctx then
			  [ maxvar <:expr< $lid:name$ >> (List.length subst) ]
			else
			  [])
	       in
		 foundyet := true;
		 p , g , n )
	    else
	      (let v = gen_new_var () in <:patt< $lid:v$ >> , [ equalterms <:expr< $lid:v$ >> <:expr< $lid:name$ >>  ], [] )
	  in

	    pvar, gvar, nvar

      | e ->
	  let name = gen_new_var () in
	  let metanames' = List.append (List.map fst unifvars) metanames in
	  let expr = tr_lterm' _loc (metanames',ctxnames,false) fctx bctx ctxparam e in
	  let p = <:patt< $lid:name$ >> in
	  let g = [ equalterms <:expr< $lid:name$ >> expr ] in
	  let n = [] in
	    p, g, n


let tr_hol_patterns ((metanames,ctxnames) as env) pats =

  let guard_var_count = ref 0 in

  let matchcasefunction body _loc =

    let handle_pats (unifvars, plist, glist, nlist) (newunifvars, pattm) =
    
      let newnames = List.map (function ((Some s, _), _) -> ML.name_to_evar s | _ -> failwith "unif. variable with no name") (List.rev newunifvars) in
      let unifvars' = List.append (List.map (fun s -> (s, ref false)) newnames) unifvars in
      let pnew, gnew, nnew = 
	match pattm with 

	    Comp_ast.CHolTerm( LTermInCtx(ctx, t) ) ->
	      let ctxparam = find_ctxparam _loc ctxnames ctx in
		tr_pat' _loc env unifvars' (List.length ctx) 0 ctxparam guard_var_count t
	  | _ -> failwith "expected modal term"
      in
	(unifvars', List.append plist [ pnew ] , List.append glist gnew, List.append nlist nnew )
	  
    in
      
    let (_, plist, glist, nlist) =
      List.fold_left handle_pats ([], [], [], []) pats
    in
      
    let body  = body _loc in
    let p     = ML.list_pairing <:patt< () >>   (fun e1 e2 -> <:patt< $e1$, $e2$ >>) plist in
    let guard = ML.list_pairing <:expr< true >> (fun e1 e2 -> <:expr< $e1$ && $e2$ >>) glist in
    let norm  = List.fold_left (fun e (p,t) -> <:expr< let $p$ = $t$ in $e$ >> ) body nlist in
      if List.length glist = 0 then
	<:match_case< $p$ -> $norm$ >>
      else
	<:match_case< $p$ when $guard$ -> $norm$ >>
  in


  let metanames' =
    let handle_pats metanames' (newunifvars, _) =
      let newnames = List.map (function ((Some s, _), _) -> s | _ -> failwith "unif. variable with no name") (List.rev newunifvars) in
	List.append newnames metanames'
    in
      List.fold_left handle_pats metanames pats 
  in
    (metanames', matchcasefunction)
 

let tr_ctx_pattern (metanames,ctxnames) pat =

  let guard_var_count = ref 0 in
  let gen_new_var () = (let n = !guard_var_count in guard_var_count := n + 1; "gv" ^ (string_of_int n)) in
    
  let matchcasefunction body _loc =

    let handle_pat (ctxunifvars, metaunifvars, pattm) =
      (* expect that the scrutinee has been matched as: match fctx_split_last ctx, ctx with ... *)
      
      match pattm with

	  Comp_ast.CCtxTerm( LCtxAsList( [ (s, LTermList(LBCtx(0)), _, _) ;
					   (_, typat, sort, _) ] ) ) when List.length ctxunifvars = 1 ->

	    let unif = match List.hd ctxunifvars with (Some u, _) -> u | _ -> failwith "ctxunifvar with no name" in
	    let ctxname = ML.name_to_evar unif in
	    let ctxnames' = unif :: ctxnames in
	    let env' = (metanames, ctxnames') in
	    let ctx = [ (s, LTermList(LBCtx(0)), None, LPAny) ] in

	    let ctxparam = find_ctxparam _loc ctxnames' ctx in
	    let unifvars = List.map (function ((Some s, _), _) -> (ML.name_to_evar s, ref false) | _ -> failwith "unifvar with no name") (List.rev metaunifvars) in

	    let p1         = <:patt< $lid:ctxname$ >> in
	    let p2, g2, n2 = tr_pat' _loc env' unifvars (List.length ctx) 0 ctxparam guard_var_count typat in
	    let sort' = match sort with Some(LSort(s)) -> tr_lsort_pat _loc s | _ -> failwith "sorts should have been figured out by now" in
	      <:patt< Some( ($p1$, $p2$, Some (Logic_ast.LSort($sort'$))) as unused ), _ >> , g2, n2
	      

	| Comp_ast.CCtxTerm( LCtxAsList( [ _, LTermList(LBCtx(0)), _ , _] ) ) when List.length ctxunifvars = 1 ->

	    let ctxname = match List.hd ctxunifvars with Some u, _ -> ML.name_to_evar u | _ -> failwith "ctxunifvar with no name" in
	    let p = <:patt< _, $lid:ctxname$ >> in
	      p, [], []

	| Comp_ast.CCtxTerm( ctx ) ->

	    let ctxname = gen_new_var () in
	    let ctxexpr = tr_ctx _loc (metanames,ctxnames,false) ctx in
	    let p = <:patt< _, $lid:ctxname$ >> in
	    let g = [ <:expr< Logic_core.lctxdesc_equal !Logic_defs.logic_global_env (Logic_ast.LCtxAsList(Logic_ast.fctx_ctx $lid:ctxname$)) (Logic_ast.LCtxAsList(Logic_ast.fctx_ctx $ctxexpr$)) >> ] in
	    let n = [] in
	      p, g, n

	| _ -> failwith "can't do context pattern matching over the given pattern"

    in

    let p, g, n = handle_pat pat in
    let body = body _loc in
    let guard = ML.list_pairing <:expr< true >> (fun e1 e2 -> <:expr< $e1$ && $e2$ >>) g in
    let norm  = List.fold_left (fun e (p,t) -> <:expr< let $p$ = $t$ in $e$ >> ) body n in
      if List.length g = 0 then
	<:match_case< $p$ -> $norm$ >>
      else
	<:match_case< $p$ when $guard$ -> $norm$ >>

  in
    
  let env' = 
    
    let (ctxunifvars, metaunifvars, _) = pat in
    let metanames' =
      List.append
	(List.map (function ((Some s, _), _) -> s | _ -> failwith "unif. var with no name") (List.rev metaunifvars))
	metanames
    in
    let ctxnames' =
      List.append
	(List.map (function (Some s, _) -> s | _ -> failwith "ctx. unif. var with no name") ctxunifvars)
	ctxnames
    in

      (metanames', ctxnames')

  in

    (env', matchcasefunction)

let ctx_scrutinee t _loc = let t = t _loc in <:expr< Logic_ast.fctx_split_last $t$, $t$ >> 


let hol_expr env t _loc = tr_modal _loc env t
let ctx_expr env t _loc = tr_ctx _loc env t
let hol_patterns env t  = tr_hol_patterns env t
let ctx_pattern  env t  = tr_ctx_pattern  env t


(*
let subst_any v e subst _loc =
  let v = quotecvar _loc v in
  let e = e _loc in
  let subst = subst _loc in
  <:expr< Comp_typing.subst_bound ~case:$v$ ~term:$e$ ~subst:$subst$ >>
*)

let expr_under_erasure e _loc = let e = e _loc in <:expr< Logic_ast.under_erasure (lazy $e$) >>



(* Multiple cases here.
   1. If we're not using real staging, yet want to typecheck the result of extdefinitions (seeing them as the 'theorems we're interested in'),
      then logic definitions need to enter a dynamic environment, so that the (dynamic) result of extdefinitions can be typechecked.
   2. If we're using real staging and want to typecheck the result of extdefinitions,
      then logic definitions should enter the logical environment of the hidden toplevel (utilized for staging).
      This is done by 'staging' the logic definition itself.
   3. If we don't care to typecheck extdefinition results, then no logical definitions need to be registered *)
let tr_logic_def name tm_opt tp_opt _loc =
  let tropt t =
    match t with
	Some( (LTermInCtx(ctx,t) as mt) ) ->
	  let ctxexpr = tr_ctx ~nosorts:true _loc ([],[],false) (LCtxAsList(ctx)) in
	  let texpr   = tr_modal _loc ([],[],false) mt in
	  <:expr< Some (Logic_ast.LTermInCtx(Logic_ast.fctx_ctx $ctxexpr$, $texpr$)) >>
      | Some( _ ) -> failwith "was expecting a terminctx"
      | None -> <:expr< None >>
  in
  let tm_opt_expr = tropt tm_opt in
  let tp_opt_expr = tropt tp_opt in
  let static_checking = if !Config.typecheck_extdef_result then <:expr< ~trusted:false >> else <:expr< ~trusted:true >> in
  let dynamic_checking = if Config.staging () then <:expr< ~trusted:true >> else static_checking in
  let print = if !Config.interactive && !Config.print_defs then <:expr< ~print:true >> else <:expr< ~print:false >> in

  (* static part *)
  (if Config.staging () then
      ML.stage_definition
      <:str_item< let _ = ignore(Logic_defs.new_logic_metadef ~phase:Logic_defs.lmodal_typecheck_phase $static_checking$ ~print:false $str:name$ $tm_opt_expr$ $tp_opt_expr$ Logic_defs.logic_global_env) >> );

  (* dynamic part *)
  <:str_item< let _ = ignore(Logic_defs.new_logic_metadef ~phase:Logic_defs.lmodal_typecheck_phase $dynamic_checking$ $print$ $str:name$ $tm_opt_expr$ $tp_opt_expr$ Comp_env.dynamic_logic_env) >>


	
let tr_complogic_def name tm tp _loc =
  let tropt =
    match tp with
	LTermInCtx(ctx,_) ->
	  let ctxexpr = tr_ctx ~nosorts:true _loc ([],[],false) (LCtxAsList(ctx)) in
	  (fun x -> <:expr< Some (Logic_ast.LTermInCtx(Logic_ast.fctx_ctx $ctxexpr$, $x$)) >>)
      | _ -> failwith "was expecting a terminctx"
  in

  let tm = tm _loc in
  let tm = <:expr< fst $tm$ >> in
  let mlname = ML.name_to_evar name in
  let str_item1 = <:str_item< let $lid:mlname$ = try $tm$ with e -> Comp_env.logic_global_delete $str:name$; raise e >> in
  let tm_opt_expr = tropt <:expr< $lid:mlname$ >> in
  let tp_expr = tr_modal _loc ([],[],false) tp in
  let tp_opt_expr = tropt tp_expr in
  let static_checking = if !Config.typecheck_extdef_result then <:expr< ~trusted:false >> else <:expr< ~trusted:true >> in
  let dynamic_checking = if Config.staging () then <:expr< ~trusted:true >> else static_checking in
  let print = if !Config.interactive && !Config.print_defs then <:expr< ~print:true >> else <:expr< ~print:false >> in

  (if Config.staging () then
      
      ML.stage_definition str_item1;
      ML.stage_definition <:str_item< let _ = ignore(Logic_defs.new_logic_metadef ~phase:Logic_defs.lmodal_typeinfer_trusted_phase $static_checking$ ~print:false $str:name$ $tm_opt_expr$ $tp_opt_expr$ Logic_defs.logic_global_env) >> );

  <:str_item< $str_item1$;; let _ = ignore(Logic_defs.new_logic_metadef ~phase:Logic_defs.lmodal_typeinfer_trusted_phase $dynamic_checking$ $print$ $str:name$ $tm_opt_expr$ $tp_opt_expr$ Comp_env.dynamic_logic_env) >> 

  

let tr_global_reset u _loc =
  (if Config.staging () then
    ML.stage_definition <:str_item< let _ = Logic_defs.logic_global_env := Utils.Dict.empty >> );
  <:str_item< let _ = Comp_env.dynamic_logic_env := Utils.Dict.empty >>;;

let tr_global_import s _loc =
  (if Config.staging () then
    ML.stage_definition <:str_item< let _ = Logic_defs.logic_global_env := Comp_env.env_logic_import !Logic_defs.logic_global_env $str:s$ >> );
  <:str_item< let _ = Comp_env.dynamic_logic_env := Comp_env.env_logic_import !Comp_env.dynamic_logic_env $str:s$ >>;;

let tr_global_save s _loc =
  (* don't save again: theorem definitions aren't used anyway; and the following is a race condition *)
  (* <:str_item< let _ = Comp_defs.env_save !Comp_repr.dynamic_logic_env !Comp_defs.comp_global_env $str:s$ >> *)
  <:str_item< >>

