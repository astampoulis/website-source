open Utils
open Binding
open Logic_ast
open Comp_ast
open Comp_typing
open Format
open Comp_print
open Comp_opteval
open Phrases
module CEval = Comp_opteval

module ML = Comp_ocamlast
module Repr = Comp_repr



(* Limitations:
   1. let x = unfold l in match x with ... doesn't work -- match should directly use unfold l
   2. no type ascriptions at all *)

let name_constr_of_typ i typname = typname ^ (string_of_int i)
let name_typvar i = "t" ^ (string_of_int i)
let name_exprvar s varnames =
  match s with
      Some s -> s
    | _ -> "__x" ^ (string_of_int (List.length varnames) )
let name_holvar s metanames =
  match s with
      Some s -> s
    | _ -> "__l" ^ (string_of_int (List.length metanames) )
let name_ctxvar s ctxnames =
  match s with
      Some s -> s
    | _ -> "__c" ^ (string_of_int (List.length ctxnames) )


let translate_cleaned_typ varnames t = 
  let rec aux' varnames t =
    let rec split_app hd tl =
      match hd with
	  CApp(t1,t2) -> split_app t1 (t2 :: tl)
	| _ -> hd, tl
    in
    let aux = aux' varnames in
    match t with
  	CPi(_,t1,t2) -> ML.typ_arrow (aux t1) (aux' ( ("", false) ::varnames) t2)
      | CApp(t1,t2)  -> (let hd, args = split_app t1 [ t2 ] in
			 ML.typ_app (aux hd) (List.map aux args))
      | CHolTerm(t)  -> Repr.hol_typ
      | CSort(CCtx)  -> Repr.ctx_typ
      | CBVar(i)     -> 
	(match List.nth varnames i with
	    (s, true) -> (* this is an inductive type, so use ML.typ_const *)
	                 let args = (List.map (fun (s,_) -> ML.typ_var s) (ExtList.drop (i+1) varnames)) in
	                 ML.typ_app (ML.typ_const s) args
	  | (s, false) -> ML.typ_var s)
      | CNVar(s)     -> ML.typ_const s
      | CUnitType    -> ML.typ_unit
      | CSigma((_,CHol), t1, t2) -> ML.typ_tuple (aux t1) (aux t2)
      | CSigma((_,CCtx), t1, t2) -> ML.typ_tuple (aux t1) (aux t2)
      | CSigma(_, _, _)  -> failwith "computational existential types not supported yet"
      | CProdType(t1,t2) -> ML.typ_tuple (aux t1) (aux t2)
      | CRefType(t)      -> ML.typ_ref (aux t)
      | CArrayType(t)    -> ML.typ_array (aux t)
      | CIntType         -> ML.typ_int
      | CBoolType        -> ML.typ_bool
      | CStringType      -> ML.typ_string
      | _ -> failwith "type not supported yet"
  in
  aux' varnames t


let cleanup_type (defenv,cdefenv) t =

  let env = (defenv, cdefenv, [], [], []) in
  cterm_map_env

    ~clambda:(fun env v t1 t2 rt1 rt2 -> 
      match t1 with 
	  CHolTerm(_) | CCtxTerm(_) | CSort(CCtx) -> rt2
	| _ -> CLambda(v, rt1, rt2))
    
    ~cpi:(fun env v t1 t2 rt1 rt2 ->
      (let env' = add_to_env ~case:v (openin env t1) env in
       match csort_of_cterm env' (openin env' t2) with
	   CType -> CPi(v,rt1,rt2)
	 | CKind | _ -> rt2))

    ~capp:(fun env t1 t2 rt1 rt2 ->
      match rt2 with
	  CHolTerm(_) -> rt1
	| CCtxTerm(_) -> rt1
	| _ -> CApp(rt1, rt2))

    env
    t



let translate_typ_def env name t =

  let t = cleanup_type env t in
  let arity , body =
    let rec get_arity n t =
      match t with
	  CLambda(_,_,t') -> get_arity (n+1) t'
	| t -> n, t
    in
    get_arity 0 t 
  in
  let varnames = List.map (fun s -> (name_typvar s, false)) (decreasing arity) in

  let translate_constrs varnames name constrs =
    ExtList.mapi (fun i t -> ( name_constr_of_typ i name , translate_cleaned_typ varnames t ) ) constrs
  in

  let varnamesonly = List.map fst varnames in

  match body with
      CRecType(_,CSort(CType),CSumType(constrs,_),_) ->
	ML.typedef_rec name varnamesonly (translate_constrs ( ( name , true ) :: varnames) name constrs)
    | CSumType(constrs,_) ->
        ML.typedef_rec name varnamesonly (translate_constrs varnames name constrs)
    | _ -> ML.typedef_synonym name varnamesonly (translate_cleaned_typ varnames body)



let tr_typ (defenv,cdefenv) t =

  let env = (defenv,cdefenv,[],[],[]) in
  let arity, body =
    let art = ref 0 in
    let body = 
      cterm_map_env

	~clambda:(fun env v t1 t2 rt1 rt2 -> 
	  match t1 with 
	      CHolTerm(_) | CCtxTerm(_) | CSort(CCtx) -> rt2
	    | _ -> CLambda(v, rt1, rt2))
    
	~cpi:(fun env v t1 t2 rt1 rt2 ->
	  (match csort_of ~case:v env (openin env t1) with
	      CKind -> art := !art + 1; rt2
	    | _ -> 
	      (let env' = add_to_env ~case:v (openin env t1) env in
	       match csort_of_cterm env' (openin env' t2) with
		   CType -> CPi(v,rt1,rt2)
		 | _ -> rt2)))

	~capp:(fun env t1 t2 rt1 rt2 ->
	  match rt2 with
	      CHolTerm(_) -> rt1
	    | CCtxTerm(_) -> rt1
	    | _ -> CApp(rt1, rt2))

	env t
    in
    !art, body
  in
  let varnames = List.map (fun s -> (name_typvar s, false)) (decreasing arity) in
  translate_cleaned_typ varnames body


let tr_typ_to_format t = 
  let rec aux t =
    match t with
      | CHolTerm(t)  -> ML.fmt_hol
      | CSort(CCtx)  -> ML.fmt_ctx
      | CUnitType    -> ML.fmt_unit
      | CSigma((_,CHol), t1, t2) -> ML.fmt_tuple (aux t1) (aux t2)
      | CSigma((_,CCtx), t1, t2) -> ML.fmt_tuple (aux t1) (aux t2)
      | CProdType(t1,t2) -> ML.fmt_tuple (aux t1) (aux t2)
      | CRefType(t)      -> ML.fmt_ref (aux t)
      | CIntType         -> ML.fmt_int
      | CBoolType        -> ML.fmt_bool
      | CStringType      -> ML.fmt_str
      | _ -> failwith "type not supported yet for formatting"
  in
  aux t

let tr_typ_to_reify t =
  let rec aux t =
    match t with
      | CHolTerm(LTermInCtx(ctx,t)) -> Quote.Ast.reify_hol ctx
      | CCtxTerm(t) -> Quote.Ast.reify_ctx
      | CSigma(v,t1,t2) -> Quote.Ast.reify_sigma v t1 (aux t1) (aux t2)
      | CTuple(t1,t2)   -> Quote.Ast.reify_prod (aux t1) (aux t2)
      | CIntType  -> Quote.Ast.reify_int
      | CUnitType -> Quote.Ast.reify_unit
      | _ -> failwith "type not reifiable"
  in
  aux t

let tr_expr_main ?(names=([],[],[])) erasure e =

  let rec auxfull (varnames, metanames, ctxnames, erasure) e =

    let aux' varnames = auxfull (varnames, metanames, ctxnames, erasure) in
    let aux = aux' varnames in
    let get_sumrectype_name t = match t with CNVar(s) -> s | _ -> failwith "unexpected rec type" in

    match e with
	CLambda( (None, CKind), t1, t2 ) -> aux' ( "" :: varnames ) t2
      | CLambda( (s   , CType), t1, t2 ) -> let name = name_exprvar s varnames in ML.expr_fun name (aux' (name :: varnames) t2)

      | CApp( t1, t2 ) -> ML.expr_app (aux t1) (aux t2)
      | CBVar( i )     -> ML.expr_var (List.nth varnames i)
      | CNVar( bot ) when bot = "bot" -> ML.expr_fail
      | CNVar( s )     -> ML.expr_const s
      | CUnitExpr      -> ML.expr_unit

      | CPack( t1, (_, CHol), _, t2 ) 
      | CPack( t1, (_, CCtx), _, t2 ) -> ML.expr_tuple (aux t1) (aux t2)
      | CPack( _, _, _, _ ) -> failwith "existential over comp. not supported"

      | CTuple( t1, t2 ) -> ML.expr_tuple (aux t1) (aux t2)
      | CProj( i, t ) -> if i = 1 then ML.expr_fst (aux t) else ML.expr_snd (aux t)

      | CUnfold(t)    -> aux t
      | CFold( CCtor( i, _, e ), t ) -> let typname = get_sumrectype_name t in ML.expr_constr (name_constr_of_typ i typname) (aux e)
      | CCtor( i, t, e ) -> let typname = get_sumrectype_name t in ML.expr_constr (name_constr_of_typ i typname) (aux e)

      | CMatch( CTypeAscribe( e, t ), branches ) ->
	let typname = get_sumrectype_name t in
	let do_branch i (x, body) =
	  let x = name_exprvar (fst x) varnames in
	  let pat = ML.pat_constr (name_constr_of_typ i typname) x in
	  let t = aux' ( x :: varnames ) body in
	    ML.match_case pat t 
	in
	ML.expr_match (aux e) (ExtList.mapi do_branch branches)	
	
      | CMatch( _, _ ) -> failwith "match should have a named sumtype or named rectype as a scrutinee"

      | CLet( (s, CType), d, e) ->
	let name = name_exprvar s varnames in
	ML.expr_let (ML.pat_var name) (aux d) (aux' (name :: varnames) e)
      | CLet( _, _, _ ) -> failwith "let over non-computational expressions not supported yet"

      | CLetRec( defs, e ) ->
	let varnames', revdefs =
	  List.fold_left
	    (fun (varnames,revdefs) ( (s, _), _, e) ->
	      let name = name_exprvar s varnames in
	      name :: varnames , (name, e) :: revdefs) (varnames,[]) defs in
	let defs' = List.rev revdefs in
	let do_def (name, e) = ( ML.pat_var name , aux' varnames' e) in
	ML.expr_letrec (List.map do_def defs') (aux' varnames' e)


      | CMkRef( e, _ )   -> ML.expr_mkref (aux e)
      | CAssign( e, e' ) -> ML.expr_assign (aux e) (aux e')
      | CReadRef( e )    -> ML.expr_readref (aux e)
      | CLoc(_,_)        -> failwith "not supposed to receive locs"
      | CSeq(e, e')      -> ML.expr_seq (aux e) (aux e')

      | CArrayLit(l, _)  -> ML.expr_arraylit (List.map aux l)
      | CMkArray(i,e,_)  -> ML.expr_mkarray (aux i) (aux e)
      | CArrayGet(e,i)   -> ML.expr_arrayget (aux e) (aux i)
      | CArraySet(e,i,e') -> ML.expr_arrayset (aux e) (aux i) (aux e')
      | CArrayLoc(_,_)   -> failwith "not supposed to receive locs"
      | CArrayLen(e)     -> ML.expr_arraylen (aux e)

      | CIntConst(i)        -> ML.expr_intconst i
      | CIntOp(Plus,e1,e2)  -> ML.expr_int_plus  (aux e1) (aux e2)
      | CIntOp(Minus,e1,e2) -> ML.expr_int_minus (aux e1) (aux e2)
      | CIntOp(Times,e1,e2) -> ML.expr_int_times (aux e1) (aux e2)
      | CIntOp(Mod,e1,e2)   -> ML.expr_int_mod   (aux e1) (aux e2)

      | CIntTest(LT,e1,e2)  -> ML.expr_int_lt (aux e1) (aux e2)
      | CIntTest(LE,e1,e2)  -> ML.expr_int_le (aux e1) (aux e2)
      | CIntTest(GT,e1,e2)  -> ML.expr_int_gt (aux e1) (aux e2)
      | CIntTest(GE,e1,e2)  -> ML.expr_int_ge (aux e1) (aux e2)
      | CIntTest(EQ,e1,e2)  -> ML.expr_int_eq (aux e1) (aux e2)


      | CBoolConst(b)       -> ML.expr_boolconst b
      | CBoolOp(BAnd,e1,e2) -> ML.expr_bool_and (aux e1) (aux e2)
      | CBoolOp(BOr,e1,e2)  -> ML.expr_bool_or  (aux e1) (aux e2)
      | CIfThenElse(e1,e2,e3) -> ML.expr_if_then_else (aux e1) (aux e2) (aux e3)

      | CStringConst(s)     -> ML.expr_stringconst s
      | CTypeAscribe(e,_)   -> aux e
      | CHolHash(e)         -> ML.expr_hash (aux e)
      | CPrint(CTypeAscribe(e,t)) ->
	let fmt = tr_typ_to_format t in
	ML.expr_print fmt (aux e)

	(* OK, now let's move to the difficult stuff *)

      | CLambda( (s   , CHol),  t1, t2 ) ->
	let name = name_holvar s metanames in
	ML.expr_fun name (auxfull (varnames, name :: metanames, ctxnames, erasure) t2)
      | CLambda( (s   , CCtx),  t1, t2 ) ->
	let name = name_ctxvar s ctxnames in
	ML.expr_fun name (auxfull (varnames, metanames, name :: ctxnames, erasure) t2)

      | CUnpack( e1, (s1, CHol), (s2, _), e2) ->
	let name1 = name_holvar s1 metanames in
	let name2 = name_exprvar s2 varnames in
	ML.expr_let (ML.pat_tuple (ML.pat_var name1) (ML.pat_var name2))
	            (aux e1) (auxfull (name2 :: varnames, name1 :: metanames, ctxnames, erasure) e2)

      | CUnpack( e1, (s1, CCtx), (s2, _), e2) ->
	let name1 = name_ctxvar s1 ctxnames in
	let name2 = name_exprvar s2 varnames in
	ML.expr_let (ML.pat_tuple (ML.pat_var name1) (ML.pat_var name2))
	            (aux e1) (auxfull (name2 :: varnames, name1 :: metanames, ctxnames, erasure) e2)

      | CHolTerm( t ) -> Repr.hol_expr (metanames, ctxnames, erasure) t
      | CCtxTerm( t ) -> Repr.ctx_expr (metanames, ctxnames, erasure) t 

      | CHolCase( ts , _, _, branches ) ->
	  let ts' = List.map aux ts in
	  let branchconv (pats, body) =
	    let metanames', mcasefun = Repr.hol_patterns (metanames, ctxnames) pats in
	    let body                 = auxfull (varnames, metanames', ctxnames, erasure) body in
	      mcasefun body
	  in
	    ML.expr_match (ML.expr_many ts') (List.map branchconv branches)


      | CCtxCase( t, _, _, branches) ->
	  let t' = aux t in
	  let branchconv (ctxunifvars, metaunifvars, pattm, body) =
	    let (metanames',ctxnames'), mcasefun = Repr.ctx_pattern (metanames, ctxnames) (ctxunifvars, metaunifvars, pattm) in
	    let body = auxfull (varnames, metanames', ctxnames', erasure) body in
	      mcasefun body
	  in
	    ML.expr_match (Repr.ctx_scrutinee t') (List.map branchconv branches)

      | CPrfErase(e) ->
	let e = auxfull (varnames, metanames, ctxnames, not !Config.no_erasure_allowed) e in
	Repr.expr_under_erasure e

      | CStaticDo( CTypeAscribe( e , t ) ) ->
	if !Config.interactive || not (!Config.real_staging) then
	  aux e
	else
	  (let reify = tr_typ_to_reify t in
	   let result = ML.stage_expr (ML.expr_app reify (aux e)) in
	   aux (Obj.magic result))


      | _ -> failwith "not supported yet"
  in
  let (varnames,metanames,ctxnames) = names in
  auxfull (varnames,metanames,ctxnames,erasure) e


let translate_expr (defenv, cdefenv) e tp =

  let env = (defenv, cdefenv, [], [], []) in

  let transform_sumrectype (_, cdefenv, _, _, _) e =

    let rec gethd e =
      match e with
	  CApp(hd, tl) -> gethd hd
	| _ -> e
    in

    match gethd e with
	CSumType(_, r)
      | CRecType(_, _, _, r) ->
	  (match !r with
	       Some s -> CNVar(s)
	     | None -> e)
      | hd -> hd
  in

  let cleanup e =
    cterm_map_env
      ~capp:(fun env t1 t2 rt1 rt2 ->
	match t2 with
	    CHolTerm(_) | CCtxTerm(_) -> CApp(rt1, rt2)
	  | _ ->
	     if csort_of_cterm env (type_of_cterm env (openin env t2)) = CKind then
	       rt1
	     else
	       CApp(rt1, rt2))

      ~clambda:(fun env v t1 t2 rt1 rt2 ->
	match csort_of ~case:v env (openin env t1) with
	    CKind -> CLambda( (None, CKind), rt1, rt2 )
	  | _ -> CLambda( v, rt1, rt2) )

      ~cfold:(fun e t re rt ->
	CFold(re, transform_sumrectype env t))

      ~cunfold:(fun env t rt ->
	let typ = type_of_cterm env (openin env t) in
	let rectyp = transform_sumrectype env typ in
	CTypeAscribe( CUnfold(rt) , rectyp ) )

      ~cmatch:(fun env t branches rt rbranches ->
	match rt with
	    CTypeAscribe( _, CNVar(_) ) -> CMatch( rt, rbranches ) 
	  | _ -> (let typ = type_of_cterm env (openin env t) in
		  let sumtyp = transform_sumrectype env typ in
		  CMatch( CTypeAscribe( rt, sumtyp ), rbranches ) ))

      ~cctor:(fun env i t p rt rp ->
	CCtor(i, transform_sumrectype env t, rp))

      ~cprint:(fun env t rt ->
	let typ = type_of_cterm env (openin env t) in
	CPrint(CTypeAscribe( t, typ)))

      ~cstaticdo:(fun env e re ->
	let typ = type_of_cterm env (openin env e) in
	CStaticDo( CTypeAscribe( Lazy.force(re), typ ) ))

      env
      e
  in

  let e' = cleanup e in
  let e'' = tr_expr_main !Config.full_erasure e' in
  let tp' = tr_typ (defenv,cdefenv) tp in
  ML.expr_type_assign e'' tp'



let translate_def env name e tp =
  ML.expr_def name (translate_expr env e tp)



let comp_expr_definition ?(typechecker=Comp_defs.comp_fullcheck_phase) name tp_opt tm =
  let env = !Logic_defs.logic_global_env, !Comp_defs.comp_global_env in
  let tp_opt = option_do (Comp_cst.comp_ast_of_cst ~app_type:true ~defs:!Logic_defs.logic_global_env) tp_opt in
  let tm = Comp_cst.comp_ast_of_cst ~app_type:true ~defs:!Logic_defs.logic_global_env tm in
  let tm', tp'   =
    Comp_defs.comp_expr_definition
      ~typechecker:typechecker
      ~evaluator:Comp_defs.evaluator_dummy
      ~print:!Config.print_defs_tc name tp_opt tm
  in
  translate_def env name tm' tp'

let comp_type_definition ?(typechecker=Comp_defs.comp_fullcheck_phase) name tp_opt tm =
  let tp_opt = option_do (Comp_cst.comp_ast_of_cst ~app_type:true ~defs:!Logic_defs.logic_global_env) tp_opt in
  let tm = Comp_cst.comp_ast_of_cst ~app_type:true ~defs:!Logic_defs.logic_global_env tm in
  let tm = 
    cterm_map
      ~crectype:(fun v t1 t2 rt1 rt2 s -> (match !s with None -> s := Some name | _ -> ()); CRecType(v,rt1,rt2,s))
      ~csumtype:(fun ts rts s -> (match !s with None -> s := Some name | _ -> ()); CSumType(rts,s))
      tm
  in
  let env = !Logic_defs.logic_global_env, !Comp_defs.comp_global_env in
  let tm', _ =
    Comp_defs.comp_type_definition
      ~typechecker:typechecker
      ~evaluator:Comp_defs.evaluator_normal
      ~print:!Config.print_defs_tc name tp_opt tm in
  translate_typ_def env name tm'


(* For logic definitions, we maintain two environments: one statically, that is
   used during typechecking; and one dynamically, that is used for typechecking
   dynamically-produced terms. Thus every update to the static environment needs
   to produce a corresponding update to the dynamic environment upon execution. *)

let comp_global_reset  u =
  Comp_defs.comp_global_reset u;  Repr.tr_global_reset  u
let comp_global_import s =
  Comp_defs.comp_global_import s; Repr.tr_global_import s
let comp_global_save   s =
  Comp_defs.comp_global_save s;   Repr.tr_global_save   s

let new_logic_metadef_ast ?(phase=Logic_defs.lmodal_typeinfer_phase) ?(print=true) name tm_opt tp_opt =
  let tm_opt', tp' = Logic_defs.new_logic_metadef ~phase:phase ~print:print name tm_opt tp_opt Logic_defs.logic_global_env in
  Repr.tr_logic_def name tm_opt' (Some tp')

let new_logic_metadef ?(phase=Logic_defs.lmodal_typeinfer_phase) name tm_opt tp_opt =
  let tm_opt' = option_do (Logic_cst.ast_of_modal ~app_type:true ~defs:!Logic_defs.logic_global_env) tm_opt in
  let tp_opt' = option_do (Logic_cst.ast_of_modal ~app_type:true ~defs:!Logic_defs.logic_global_env) tp_opt in
  new_logic_metadef_ast ~phase:phase ~print:false name tm_opt' tp_opt'

let comp_logic_definition ?(typechecker=Comp_defs.comp_fullcheck_phase) name tm modaltp =
  let env = !Logic_defs.logic_global_env, !Comp_defs.comp_global_env in
  let modaltp = Logic_cst.ast_of_modal ~app_type:true ~defs:!Logic_defs.logic_global_env modaltp in
  let tm = Comp_cst.comp_ast_of_cst ~app_type:true ~defs:!Logic_defs.logic_global_env tm in
  let tm', tp' =
    Comp_defs.comp_logic_definition
      ~typechecker:typechecker
      ~logicchecker:Logic_defs.lmodal_typeinfer_phase
      ~evaluator:Comp_defs.evaluator_dummy
      ~print:!Config.print_defs_tc ~asaxiom:true name tm modaltp
  in
  let modaltp = match tp' with CSigma( _, CHolTerm(mt), CUnitType) -> mt | _ -> failwith "expected existential package of modal term" in
  Repr.tr_complogic_def name (translate_expr env tm' tp') modaltp



let rec translate_phrase p =
  match p with
      PhrExpDefinition(name, tp_opt, tm, loc) -> comp_expr_definition name tp_opt tm loc
    | PhrTypDefinition(name, tp_opt, tm, loc) -> comp_type_definition name tp_opt tm loc
    | PhrGlobalReset(loc) -> comp_global_reset () loc
    | PhrFullReset(loc) -> comp_global_reset () loc
    | PhrGlobalImport(s,loc) -> comp_global_import s loc
    | PhrGlobalSave(s,loc)   -> comp_global_save s loc
    | PhrLogicMetadef(name, tm_opt, tp_opt, loc) -> new_logic_metadef name tm_opt tp_opt loc
    | PhrComplogicDef(name, tm, modaltp, loc) -> comp_logic_definition name tm modaltp loc
    | PhrLogicInd(name, params, tp, constrs, loc) ->
      let defs =
	Logic_ind.new_inductive_type
	  (Logic_cst.ast_of_modal ~defs:!Logic_defs.logic_global_env ~app_type:true)
	  Logic_defs.lmodal_typecheck_phase
	  (fun name tp -> new_logic_metadef_ast ~print:false name None (Some tp) loc) name params tp constrs
      in
      ML.stritems defs loc
    | PhrLogicNotation(name, tm, loc) -> Logic_defs.add_notation name tm; ML.stritems [] loc
    | PhrNone(loc) -> ML.stritems [] loc
    | PhrDirective(s) -> s
    | PhrNeed(s,loc) -> Comp_defs.comp_global_import s; ML.stritems [] loc

