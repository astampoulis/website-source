open Utils
open Logic_typing
open Logic_cst
open Logic_print

(*
let logic_global_env = Logic_defs.logic_global_env
let logic_reset () = logic_global_env := Logic_defs.ltermdefenv_empty

let logic_getwhnf t = Logic_core.whnf !logic_global_env t

let logic_axiom ?(print=true) ?(app_type=false) name params tp = 
  let tp' = ast_of_cst ~app_type:app_type (lammany params tp) in
  Logic_defs.new_logic_axiom ~print:print name tp' logic_global_env

let logic_theorem ?(print=true) ?(app_type=false) name params tm tp =
  let tm' = ast_of_cst ~app_type:app_type (lammany params tm) in
  let tp' = ast_of_cst ~app_type:app_type (pimany params tp) in
  Logic_defs.new_logic_theorem ~print:print name tm' tp' logic_global_env

let logic_define_meta ?(print=true) ?(app_type=false) name tm tp_opt =
  let tm' = ast_of_modal ~app_type:app_type tm in
  let tp_opt' = match tp_opt with Some tp -> Some (ast_of_modal ~app_type:app_type tp) | None -> None in
  Logic_defs.new_logic_metadef ~print:print name (Some tm') tp_opt' logic_global_env

let logic_axiom_meta ?(print=true) ?(app_type=false) name tp =
  let tp' = ast_of_modal ~app_type:app_type tp in
  Logic_defs.new_logic_metadef ~print:print name None (Some tp') logic_global_env

open Logic_print

let logic_print (tm : lterm) =
  let tm' = ast_of_cst tm in
    Format.fprintf Format.std_formatter "%a.@\n" pr_lterm tm'

let logic_check (tm : lterm) =
  let tm' = ast_of_cst tm in
  let tp = type_of_lterm (Logic_defs.ltermenv_empty !logic_global_env) tm' in
    Format.fprintf Format.std_formatter "%a@ :@ %a.@\n" pr_lterm tm' pr_lterm tp

let logic_whnf (tm : lterm) =
  let tm' = ast_of_cst tm in
  let tm'' = Logic_core.whnf !logic_global_env tm' in
    Format.fprintf Format.std_formatter "%a@ -whnf->@ %a.@\n" pr_lterm tm' pr_lterm tm''

*)
