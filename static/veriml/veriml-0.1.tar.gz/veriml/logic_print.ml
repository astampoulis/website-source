open Logic_cst
module LAst = Logic_ast
open Format

let rec pr_list base sep ppf = function
    [] -> ()
  | t1 :: [] -> fprintf ppf "%a" base t1
  | t1 :: tl -> fprintf ppf "%a%s@ %a" base t1 sep (pr_list base sep) tl

let printers =
  let str ppf s = fprintf ppf "%s" s in
  let pint ppf i = fprintf ppf "%s" (string_of_int i) in
  let rec pr_lsort ppf = function
      LAst.LType -> fprintf ppf "%a" str "Type"
    | LAst.LSet  -> fprintf ppf "%a" str "Set"
    | LAst.LProp -> fprintf ppf "%a" str "Prop"
  and pr_lterm ppf = function
      LSort s -> fprintf ppf "%a" pr_lsort s
    | LVar v  -> fprintf ppf "%a" str v
    | LLambda(s,t1,t2) ->
	fprintf ppf "@[<1>%a@ %a%a%a%a@,%a@]" str "fun" str s str ":" pr_lterm t1 str "=>" pr_lterm t2
    | LPi(s,t1,t2) ->
	fprintf ppf "@[<1>%a@ %a%a%a%a@,%a@]" str "forall" str s str ":" pr_lterm t1 str "," pr_lterm t2
    | LArrow(t1,t2) ->
	fprintf ppf "@[<1>%a@ %a@ %a@]" pr_lterm_paren_app1 t1 str "->" pr_lterm t2
    | LApp(t1,t2) ->
	fprintf ppf "@[<2>%a@ %a@]" pr_lterm_paren_app1 t1 pr_lterm_paren_app2 t2
    | LCtor(t1,i) ->
	fprintf ppf "@[%a%a%a%a%a%a@]" str "Ctor" str "(" pr_lterm t1 str "," pint i str ")"
    | LElim(res,indterm,branches) ->
	fprintf ppf "@[Elim(%a,@ %a)@ {%a}@]" pr_lterm res pr_lterm indterm (pr_list pr_lterm "|") branches
    | LInd(LIndDef(s,arity,constrs)) ->
	fprintf ppf "@[Ind(%a : %a)@ {%a}@]" str s pr_lterm arity (pr_list pr_lterm "|") constrs
    | LModal(mtm, subst) ->
	fprintf ppf "@[%a/[%a]@]" pr_modal mtm (pr_list pr_lterm ",") subst
    | LTermList(ctxdesc) ->
	fprintf ppf "@[%a@]" pr_ctxdesc ctxdesc
  and pr_modal ppf = function
      LTermInCtx(ctx, lt) ->
	fprintf ppf "@[[%a].%a@]" (pr_list pr_ctxmem ",") ctx pr_lterm lt
    | LMeta(s) -> fprintf ppf "%a%a" str "?" str s
  and pr_ctxdesc ppf = function
      LCtxVar(s) -> fprintf ppf "%a%a" str "#" str s
    | LCtxAsList(l) -> fprintf ppf "@[%a%a%a@]" str "[" (pr_list pr_ctxmem ",") l str "]"
  and pr_ctxmem ppf = function
      (s, (LTermList(_) as t)) when s = "" -> fprintf ppf "%a" pr_lterm t
    | (s, t) -> fprintf ppf "%a@ :@ %a" str s pr_lterm t
  and pr_lterm_paren_app1 ppf e = match e with
      LSort _ | LVar _ | LCtor _ | LApp _ | LModal _ -> pr_lterm ppf e
    | _ -> fprintf ppf "(%a)" pr_lterm e
  and pr_lterm_paren_app2 ppf e = match e with
      LSort _ | LVar _ | LCtor _ | LModal _ -> pr_lterm ppf e
    | _ -> fprintf ppf "(%a)" pr_lterm e
  in
    (pr_lterm, pr_modal, pr_ctxdesc)

let pr_lterm_cst = let (a,_,_) = printers in a
let pr_modal_cst = let (_,a,_) = printers in a
let pr_ctxdesc_cst = let (_,_,a) = printers in a

let pr_lterm ppf e = pr_lterm_cst ppf (cst_of_ast e)
let pr_modal ppf e = pr_modal_cst ppf (cst_of_modal e)
let pr_ctxdesc ppf e = pr_ctxdesc_cst ppf (cst_of_ctxdesc e)

let print_lterm_cst (e : lterm) =
  fprintf std_formatter "%a" pr_lterm_cst e

let string_of_lterm_cst (e : lterm) =
  fprintf str_formatter "%a" pr_lterm_cst e; flush_str_formatter ()

let print_lterm (e : LAst.lterm) =
  fprintf std_formatter "%a" pr_lterm_cst (cst_of_ast e)

let string_of_lterm (e : LAst.lterm) =
  fprintf str_formatter "%a" pr_lterm_cst (cst_of_ast e); flush_str_formatter ()
