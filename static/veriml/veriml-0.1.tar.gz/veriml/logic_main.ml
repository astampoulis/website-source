open Utils
open Logic_typing
open Logic_cst
open Logic_print

let logic_global_env : LAst.lterm_defenv ref = ref ltermdefenv_empty

let logic_reset () = logic_global_env := ltermdefenv_empty

let logic_get n = Logic_core.get_def_term n !logic_global_env
let logic_getwhnf t = Logic_core.whnf !logic_global_env t

let logic_define name params tm = logic_global_env :=
  let tm' = ast_of_cst (lammany params tm) in
  ltermdefenv_add name tm' !logic_global_env

let logic_define_typed name params tm tp =
  let tm' = ast_of_cst (lammany params tm) in
  let tp' = ast_of_cst (pimany params tp) in
  logic_global_env := ltermdefenv_add name tm' ~expected_tp:(Some tp') !logic_global_env

let logic_define_meta name tm = logic_global_env :=
  let tm' = ast_of_modal tm in
    ltermdefenv_add_meta name tm' !logic_global_env

let logic_define_meta_typed name tm tp =
  let tm' = ast_of_modal tm in
  let tp' = ast_of_modal tp in
  logic_global_env := ltermdefenv_add_meta name tm' ~expected_tp:(Some tp') !logic_global_env

let logic_inductive (name : string) params (arity : lterm) (constrs : (string * lterm) list) =
  let inddef = LInd(LIndDef(name, arity, List.map snd constrs)) in
  let paramtms = List.map (fun (v,_) -> LVar(v)) params in
    logic_define name params inddef;
    ExtList.iteri 
      (fun i (str, _) ->
	 let constri = LCtor(appmany (LVar name) paramtms, i) in
	   logic_define str params constri)
      constrs

open Logic_print

let logic_print (tm : lterm) =
  let tm' = ast_of_cst tm in
  let tm'' = 
    match tm' with
	LAst.LVar (LAst.LNVar v) -> logic_get v
      | tm' -> tm'
  in
    Format.fprintf Format.std_formatter "%a@ :=@ %a.@\n" pr_lterm tm' pr_lterm tm''

let logic_check (tm : lterm) =
  let tm' = ast_of_cst tm in
  let tp = type_of_lterm (ltermenv_empty !logic_global_env) tm' in
    Format.fprintf Format.std_formatter "%a@ :@ %a.@\n" pr_lterm tm' pr_lterm tp

let logic_whnf (tm : lterm) =
  let tm' = ast_of_cst tm in
  let tm'' = Logic_core.whnf !logic_global_env tm' in
    Format.fprintf Format.std_formatter "%a@ -whnf->@ %a.@\n" pr_lterm tm' pr_lterm tm''

let logic_whdelta (tm : lterm) = 
  let tm' = ast_of_cst tm in
  let tm'' = Logic_core.fullwhdelta !logic_global_env tm' in
    Format.fprintf Format.std_formatter "%a@ -whdelta->@ %a.@\n" pr_lterm tm' pr_lterm tm''

