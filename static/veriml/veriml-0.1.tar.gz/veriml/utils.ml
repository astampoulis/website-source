module Dict = Map.Make(String)

module ExtDict =
  struct

    let getfst s dict =
      let (fst,snd) = Dict.find s dict in
	fst
	  
    let getsnd s dict = 
      let (fst,snd) = Dict.find s dict in
	snd
  end

type 'a dict = 'a Dict.t

let decreasing n = 
  let rec aux n = if n = 0 then [] else (n-1) :: aux (n-1) in
    aux n
let decreasing_start n start = 
  let rec aux n = if n = 0 then [] else (n-1+start) :: aux (n-1) in
    aux n
let increasing n = List.rev (decreasing n)

let uncurry f (a,b) = f a b

let option_ret  a = Some a
let option_bind e f = (match e with
			   Some e' -> f e'
			 | None -> None)
let option_monad = ( option_ret, option_bind )

let (^?) s1 s2 = match s1 with Some(s) -> Some(s ^ s2) | None -> None

let compose f g x = f (g x)

module ExtList =
  struct

    let findindex (f : 'a -> bool) (l : 'a list) =
      let rec aux i = function
	  [] -> raise Not_found
	| hd :: tl -> if f hd then i else aux (i+1) tl
      in
	aux 0 l

    let iteri (f : int -> 'a -> unit) (l : 'a list) =
      let rec aux i = function
	  [] -> ()
	| hd :: tl -> (f i hd; aux (i+1) tl)
      in
	aux 0 l

    let mapi (f : int -> 'a -> 'b) (l : 'a list) =
      let rec aux i = function
	  [] -> []
	| hd :: tl -> (f i hd) :: (aux (i+1) tl)
      in
	aux 0 l

    let updatenth (n : int) (what : 'a) (l : 'a list) =
      mapi (fun i elm -> if i = n then what else elm) l

    let filtermapi (f : int -> 'a -> 'b option) (l : 'a list) =
      let rec aux i = function
	  [] -> []
	| hd :: tl -> 
	    let rest = aux (i+1) tl in
	      (match f i hd with
		   Some b -> b :: rest
		 | None -> rest)
      in
	aux 0 l

    let rec sublist (n : int) (l : 'a list) =
      if n = 0 then l else
	(match l with
	     [] -> failwith "ExtList.sublist"
	   | hd :: tl -> sublist (n-1) tl)

    let foldindex (f : int -> 'a -> 'b -> 'b) (start : 'b) (l : 'a list) =
      let rec aux i = function
	  [] -> start
	| hd :: tl ->
	    f i hd (aux (i+1) tl)
      in
	aux 0 l

    let last (l : 'a list) =
      let rec aux res l = 
	match l with
	    t1 :: [] -> res, t1
	  | hd :: tl -> aux (hd :: res) tl
	  | _ -> failwith "ExtList.last"
      in
      let rest, last1 = aux [] l in
	List.rev rest, last1
	  
    let last_two (l : 'a list) =
      let rec aux res l = 
	match l with
	    t1 :: t2 :: [] -> res, t1, t2
	  | hd :: tl -> aux (hd :: res) tl
	  | _ -> failwith "ExtList.last_two"
      in
      let rest, last1, last2 = aux [] l in
	List.rev rest, last1, last2

    let fstmap (f : 'a -> 'b) (l : ('a * 'c) list) =
      List.map (fun (a,c) -> (f a,c)) l

    let sndmap (f : 'a -> 'b) (l : ('c * 'a) list) =
      List.map (fun (c,a) -> (c,f a)) l

    let rec make (n : int) (elm : 'a) =
      if n = 0 then [] else elm :: make (n-1) elm

    let rec take (n : int) (l : 'a list) =
      if n = 0 then [] else match l with hd :: tl -> hd :: take (n-1) l | [] -> failwith "take"

    let rec drop (n : int) (l : 'a list) =
      if n = 0 then l else match l with _ :: tl -> drop (n-1) l | [] -> failwith "drop"

    let is_prefix l1 l2 =
      if List.length l1 > List.length l2 then false
      else List.for_all2 (=) l1 (take (List.length l1) l2)

  end

let stringlist (f : 'a list -> 'res) (list : ('b * 'a) list)  =
  let strings, terms = List.split list in
  let terms' = f terms in
    List.combine strings terms'

exception AlreadyInferred
exception NotInferredYet
type 'a inferred = 'a option ref
let mk_inferred () = ref None
let inferred_is inf what = inf := Some what
let get_inferred inf = match !inf with None -> raise NotInferredYet | Some t -> t
