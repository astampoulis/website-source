open Utils
open Logic_ast
open Logic_core
open Logic_print

let impredicative_set = ref false

let add_to_env (fenv, defenv, metaenv, ctxenv) tp =
  let fenv' = tp :: fenv in
  let fenv'' = List.map (BindLterm.bumpup_fvar 1) fenv' in
    (fenv'', defenv, metaenv, ctxenv)  (* assuming meta-variables cannot refer to free variables. *)

let rec get_idef_args defenv tm =
  monadic option_monad in begin
    match gather_app tm with
	LAppMany(hd, args) when is_inddef defenv hd -> cmd { return (hd, args) }
      | _ -> cmd { x <- whdelta defenv tm then res <- get_idef_args defenv x then return res }
  end
	  
let rec type_of_lterm ((fenv, defenv, metaenv, ctxenv) as env : lterm_env) (e : lterm) =
  match e with
      LSort(LSet)  -> LSort(LType)
    | LSort(LProp) -> LSort(LSet)
    | LSort(LType) -> failwith "LType has no type"
    | LVar(LBVar i) -> failwith "accessing type of bound var -- shouldn't happen!"
    | LVar(LFVar i) -> List.nth fenv i
    | LVar(LNVar i) -> get_def_type i defenv
    | LPi(var, k, t1, t2) ->
	let t1_t = fullwhdelta defenv (type_of_lterm env t1) in
	let env' = add_to_env env t1 in
	let t2' = BindLterm.open_up t2 in
	let t2_t = fullwhdelta defenv (type_of_lterm env' t2') in
	  begin
	    match t1_t, t2_t with
		LSort(LProp), LSort(LProp) -> inferred_is k LProp; LSort(LProp)
	      | LSort(LSet), LSort(LSet) -> inferred_is k LSet; LSort(LSet)
	      | LSort(LSet), LSort(LProp) -> inferred_is k LSet; LSort(LProp)
		  (* impredicative Set? *)
	      | LSort(LType), LSort(LType) when !impredicative_set -> inferred_is k LType; LSort(LType)
	      | LSort(LType), LSort(LSet)  when !impredicative_set -> inferred_is k LType; LSort(LSet)
	      | LSort(LType), LSort(LProp) when !impredicative_set -> inferred_is k LType; LSort(LProp)
	      | _ -> failwith ("invalid type " ^ (string_of_lterm e))
	  end
    | LLambda(var, k, t1, e2) ->
	let env' = add_to_env env t1 in
	let t2 = type_of_lterm env' (BindLterm.open_up e2) in 
	let tp = LPi(var, k, t1, BindLterm.close_down t2) in
	let _ = type_of_lterm env tp in
	  tp
    | LApp(e1, e2) ->
	let t1 = fullwhdelta defenv (type_of_lterm env e1) in
	let t2 = type_of_lterm env e2 in
	  begin
	    match t1 with
		LPi(_, _, t, t') ->
		  if lterm_equal defenv t2 t then
		    BindLtermS.subst_bound e2 t'
		  else
		    failwith ("types don't match: " ^ (string_of_lterm t) ^ " and " ^ (string_of_lterm t2))
	      | _ ->
		  failwith ("expected Pi type, got " ^ (string_of_lterm t1))
	  end
    | LInd(idef) -> term_of_idef env idef
    | LCtor(id, i) ->
	let id' = fullwhdelta defenv id in
	if is_inddef defenv id' then
	  begin
	    let _ = type_of_lterm env id in
	    let LIndDef(_,arity, constrs) = get_inddef defenv id' in
	      constr_to_term id (List.nth constrs i)
	  end
	else
	  failwith ("constructor used on a non-inductive term" ^ (string_of_lterm id))
    | LModal(mt, subst) ->
	(let mt_t = type_of_modal env mt in
	 let _ =
	   match mt_t with
	       LTermInCtx(ctx, _) -> type_of_subst_is env subst ctx
	     | _ -> failwith ("can't handle metavariable-typed metavariables yet") in
	   modal_apply_subst mt_t subst)
    | LTermList(ctx) ->
	failwith "asking type of context inside type_of_lterm!"
    | LElim(res, idtm, branches) ->
	begin
	  match get_idef_args defenv (type_of_lterm env idtm) with
	      Some(idefterm, args) ->
		let LIndDef(_,LArity(params, sort), constrs) as idef = get_inddef defenv idefterm in
		let paramsnum = List.length params in
		let resf =
		  match sort with
		      LProp -> (* noDep(Prop, Prop) -- this could also be Dep(Prop, Prop) though that's not used often *)
			let rest = type_of_lterm env res in
			if lterm_equal defenv rest (pimany params (LSort(LProp))) then
			  (fun args tm -> appmany res args)
			else
			  failwith ("type for result of elimination is not correct " ^ (string_of_lterm rest))
		    | LSet ->
			let rest = type_of_lterm env res in
			(* noDep(Set,Set) *)
			if lterm_equal defenv rest (pimany params (LSort(LSet))) then
			  (fun args tm -> appmany res args)
			(* Dep(Set,Prop) *)
			else if lterm_equal defenv rest (pimany (List.append params [(None,appmany idefterm (boundlist paramsnum))])
							   (LSort(LProp))) then
			  (fun args tm -> LApp(appmany res args, tm))
			else
			  failwith ("type for result of elimination is not correct " ^ (string_of_lterm rest))
		    | _ -> failwith ("shouldn't happen")
		in
		let check_branch i = 
		  let branch_type = type_of_lterm env (List.nth branches i) in
		  let branch_expected = type_for_elim_branch idef idefterm (List.nth constrs i) resf (LCtor(idefterm, i)) in
		    lterm_equal defenv branch_type branch_expected
		in
		let n = List.length branches in
		  if List.length constrs = n then
		    (if List.for_all check_branch (increasing n) then
		       whnf defenv (resf args idtm)
		     else
		       failwith ("some branch with wrong type"))
		  else
		    failwith ("number of elimination cases and constructors do not match")
	    | None -> failwith ("elimination applied to non-inductive term "^ (string_of_lterm idtm))
	end
and term_of_idef ((fenv, defenv, metaenv, ctxenv) as env : lterm_env) (idef : linddef) =
  let LIndDef(s, (LArity(params, sort) as arity), constrs) = idef in
  let ideftp = arity_to_term arity in
  let _ = type_of_lterm env ideftp in
  let check_constr constr =
    let tp = constr_to_term (LVar (LFVar 0)) (BindConstr.bumpup_fvar 1 constr) in
    let sort' = type_of_lterm (add_to_env env ideftp) tp in
      lterm_equal defenv (LSort(sort)) sort'
  in
    if (List.for_all check_constr constrs) then
      ideftp
    else
      failwith ("some constructor is ill-typed for " ^ (string_of_lterm (LInd(idef))))
and type_of_modal ((fenv, defenv, metaenv, ctxenv) : lterm_env) (mt : lmodalterm) =
  match mt with
      LTermInCtx(ctx,lt) ->
	(let _ = ctx_wf ([], defenv, metaenv, ctxenv) (LCtxAsList(ctx)) in
	 let newfenv, openlt = terminctx_open_up ctx lt in
	 let tp = type_of_lterm (newfenv, defenv, metaenv, ctxenv) openlt in
	   terminctx_close_down ctx tp)
    | LFMeta(i) -> List.nth metaenv i
    | LBMeta(i) -> failwith ("accessing bound meta variable while type checking -- shouldn't happen")
    | LNMeta(s) -> get_metadef_type s defenv
and type_of_subst_is ((fenv, defenv, metaenv, ctxenv) as env: lterm_env) (subst : lsubst) (ctx : lctx) =
  match subst, ctx with
      [], [] -> true
    | (shd::stl), ((_,chd)::ctl) ->
	let shd_t = type_of_lterm env shd in
	let ctx' = BindCtxS.subst_bound shd ctl in
	let _ = if not (lterm_equal defenv shd_t chd) then
	  failwith ("subst and context do not match in type!") in
	  type_of_subst_is env stl ctx'
    | _, _ -> failwith ("subst and context do not match in size")
and ctx_wf ((fenv, defenv, metaenv, ctxenv) as env : lterm_env) (ctx : lctxdesc) =
  match ctx with
      LFCtx(i) -> List.nth ctxenv i
    | LBCtx(i) -> failwith "getting type of bound context variable"
    | LCtxAsList(l) ->
	ignore
	  (List.fold_left (fun (curenv,n) (_,elm) ->
			     let elm = BindLterm.open_up ~howmany:n elm in
			     valid_ctxelem curenv elm;
			     (add_to_env curenv elm, n+1))
	     (env,0) l)
and valid_ctxelem ((fenv, defenv, metaenv, ctxenv) as env) (ctxelem : lterm) =
  match ctxelem with
      LTermList(LCtxAsList(_)) -> failwith "nested context lists are not allowed!"
    | LTermList(ctx) -> ctx_wf env ctx
    | t -> ignore(type_of_lterm env t)


let ltermdefenv_empty = (Dict.empty, Dict.empty)

let ltermdefenv_add name tm ?(expected_tp=None) (defenv : lterm_defenv) =
  let tp = type_of_lterm ([],defenv,[],[]) tm in
  let add name what (defenv,d2) =
    (if Dict.mem name defenv then
       failwith ("definition " ^ name ^ " already exists")
     else
       (Dict.add name what defenv,d2))
  in    
    match expected_tp with
	Some(expected_tp) ->
	  if lterm_equal defenv tp expected_tp then
	    add name (expected_tp, tm) defenv
	  else
	    failwith ("the term's type doesn't match the definition type" ^ (string_of_lterm tm))
      | None ->
	  add name (tp, tm) defenv

let ltermdefenv_add_meta name tm ?(expected_tp=None) (defenv : lterm_defenv) =
  let tp = type_of_modal ([],defenv,[],[]) tm in
  let add name what (d1,defenv) =
    (if Dict.mem name defenv then
       failwith ("definition " ^ name ^ " already exists")
     else
       (d1,Dict.add name what defenv))
  in    
    match expected_tp with
	Some((LTermInCtx(_,_)) as expected_tp) ->
	  (if lmodal_equal defenv tp expected_tp then
	     add name (expected_tp, tm) defenv
	   else
	     failwith ("the term's type doesn't match the definition type"))
      | Some(_) -> failwith ("metavariables should have non-metavariable type")
      | None ->
	  add name (tp, tm) defenv

let ltermenv_empty def = ([], def, [], [])

let check_pattern defenv ctx patvars pat =

  let is_whnf ctx e = true (* let _, e' = terminctx_open_up ctx e in (whnf defenv e' = e') *) in
  let require e why = (if not e then failwith why else ()) in
  let rec is_decreasing_bound curmax subst =
    match subst with
	[] -> true
      | LVar (LBVar hd) :: tl -> hd = curmax - 1 && is_decreasing_bound hd tl
      | _ -> false
  in
  let rec aux (ctx : lctx) (cur : int) (pat : lterm) =

    (require (is_whnf ctx pat) "pattern should be in normal form");
    (match pat with
	 LModal(LBMeta(i), subst) ->
	   (require (i = cur - 1) "pattern variables should be used in increasing order");
	   (require (is_decreasing_bound (List.length ctx) subst) "substitutions used in pattern variables should only mention free variables in increasing order");
	   cur - 1

       | LLambda(s, k, a, b) ->
	   (let cur'  = aux ctx cur a in
	    let cur'' = aux (List.append ctx [(s,a)]) cur' b in
	      cur'')

       | LPi(s, k, a, b) ->
	   (let cur'  = aux ctx cur a in
	    let cur'' = aux (List.append ctx [(s,a)]) cur' b in
	      cur'')

       | LApp(a, b) ->
	   (let cur' = aux ctx cur a in
	    let cur'' = aux ctx cur' b in
	      cur'')

       | e ->
	   ignore (lterm_map ~lbmeta:(fun i -> failwith "invalid pattern -- pattern variable shows up where it shouldn't") e);
	   cur
    )
  in
  let patvars_unused = aux ctx patvars pat in
    require (patvars_unused = 0) "not all pattern variables are used"

exception NoPatternMatch
let pattern_match_term defenv ?(ctx = []) ?(check = false) patvars pat e =

  let remove_from_ctx n ctx =
    ExtList.updatenth n (None, LTermList(LCtxAsList([]))) ctx
  in

  let rec pattern_match_term (defenv : lterm_defenv) (ctx : lctx) (assignment : lmodalterm list) (patvars : int) (pat : lterm) (e : lterm) =
    let curvar = patvars - List.length assignment - 1 in
    let e' = whnf defenv e in

    (* TODO:: fix this properly *)
    (* in order to fill in sorts we do a type checking. of course this is not needed,
       and should be removed once the logic_core is updated properly so that it generates
       proper inferred sorts for all lambda's and pi's. *)
    let _ = 
      if check then
	match e' with
	    LPi(_,_,_,_) | LLambda(_,_,_,_) ->
	      let fenv, e'' = terminctx_open_up ctx e' in
	      ignore(type_of_lterm (fenv,defenv,[],[]) e'')
	  | _ -> ()
    in

      match pat, e' with
	  LModal(LBMeta(i), subst), e when i = curvar ->
	    let n = List.length ctx in
	    let ctx' =
	      List.fold_left
		(fun ctx0 j ->
		   let unif_allows_it = List.exists ((=) (LVar (LBVar j))) subst in
		   let term_has_it = BindLterm.has_bound_var j e in
		     if not unif_allows_it then
		       (if not term_has_it then
			  remove_from_ctx (n - j - 1) ctx0
			else
			  raise NoPatternMatch)
		     else
		       ctx0)
		ctx (increasing n)
	    in
	    let ctx', e' = flatten_term_in_context ctx' e in
	      (LTermInCtx(ctx',e')) :: assignment

	| LLambda(s1, k1, a1, b1), LLambda(s2, k2, a2, b2) when (get_inferred k1) = (get_inferred k2) ->
	    let assignment' = pattern_match_term defenv ctx assignment patvars a1 a2 in
	    let assignment'' = pattern_match_term defenv (List.append ctx [(s2,a2)]) assignment' patvars b1 b2 in
	      assignment''
	| LPi(s1, k1, a1, b1), LPi(s2, k2, a2, b2) when (get_inferred k1) = (get_inferred k2) ->
	    let assignment' = pattern_match_term defenv ctx assignment patvars a1 a2 in
	    let assignment'' = pattern_match_term defenv (List.append ctx [(s2,a2)]) assignment' patvars b1 b2 in
	      assignment''
	| LApp(a1,b1), LApp(a2,b2) ->
	    let assignment' = pattern_match_term defenv ctx assignment patvars a1 a2 in
	    let assignment'' = pattern_match_term defenv ctx assignment' patvars b1 b2 in
	      assignment''

(* 	| LCtor(a1, i1), LCtor(a2, i2) when i1 = i2 -> *)
(* 	    pattern_match_term defenv ctx assignment patvars a1 a2 *)
	| LElim(a1,b1,c1), LElim(a2,b2,c2) ->
	    let assignment' = pattern_match_term defenv ctx assignment patvars a1 a2 in
	    let assignment'' = pattern_match_term defenv ctx assignment' patvars b1 b2 in
	    let assignment''' = List.fold_left2 (fun asgn elm1 elm2 -> pattern_match_term defenv ctx asgn patvars elm1 elm2) assignment'' c1 c2 in
	      assignment'''
(* 	| LInd(LIndDef(s,ar1,constrs1)), LInd(LIndDef(_,ar2,constrs2)) -> *)
(* 	    let assignment' = pattern_match_term defenv ctx assignment patvars (arity_to_term ar1) (arity_to_term ar2) in *)
(* 	    List.fold_left2 (fun asgn elm1 elm2 -> *)
(* 			       let c1 = constr_to_term pat elm1 in *)
(* 			       let c2 = constr_to_term e' elm2 in *)
(* 			       pattern_match_term defenv ctx asgn patvars c1 c2) *)
(* 	      assignment' constrs1 constrs2 *)

	| e1, e2 -> if lterm_equal defenv (BindLterm.open_up ~howmany:(List.length ctx) e1)
	                                  (BindLterm.open_up ~howmany:(List.length ctx) e2) then assignment else
	    (match whdelta defenv e2 with
		 Some e2' -> pattern_match_term defenv ctx assignment patvars e1 e2'
	       | None -> raise NoPatternMatch)
  in
  let assignment = pattern_match_term defenv ctx [] patvars pat e in
    if List.length assignment = patvars then List.rev assignment else raise NoPatternMatch



