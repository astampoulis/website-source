open Syntax_logic;;
open Syntax_comp;;

open Prog_basis;;

<<

let STANDARD_HASH_SIZE = 10

(* Hash implementation *)

let nathash = fun #phi : ctx => fun res : ([#phi].Nat) -> CType =>
              array (option (< ?key : [#phi].Nat > res ?key))

let mkhash = fun #phi : ctx => fun res : (([#phi].Nat) -> CType) => fun i : int =>
             mkarray( i, (none (< ?key : [#phi].Nat > res ?key)) , option (< ?key : [#phi].Nat > res ?key)) 

let hashget = fun #phi : ctx => fun res : ([#phi].Nat) -> CType => fun h : nathash #[#phi] res =>
              fun ?n : [#phi].Nat =>
              let hn = arraylen h in
              letrec find : {?n : [#phi].Nat} (int -> (option (res ?n))) =
		fun ?n : [#phi].Nat => fun i : int => 
		  match h.(i) with
		      som |-> unpack < ?n', result > = som in
                              (holcase ?n as ?n return option (res ?n) with
				  ().[s:#phi].?n'/[s] |-> some (res ?n') result
				| ( ?n : [#phi].Nat ).[s:#phi].?n/[s] |-> find ?n ((i iplus 1) imod hn))
                    | non |-> none (res ?n)
              in
                find ?n ((hash <| ?n |>) imod hn)

let hashget_uns = fun #phi : ctx => fun res : ([#phi].Nat) -> CType => fun h : nathash #[#phi] res =>
              fun ?n : [#phi].Nat =>
              match hashget #[#phi] res h ?n with
		  som |-> som
		| non |-> bot (res ?n)

let hashset = fun #phi : ctx => fun res : ([#phi].Nat) -> CType => fun h : nathash #[#phi] res =>
              fun ?n : [#phi].Nat => fun r : res ?n =>
              let hn = arraylen h in
              letrec find : (int -> Unit) =
		fun i : int => 
		  match h.(i) with
		      som |-> unpack < ?n', result > = som in
                              (holcase ?n' as ?n' return Unit with
				  ().[s:#phi].?n/[s] |-> h.(i) <- (some (< ?key : [#phi].Nat > res ?key) (pack ?n as ?n return res ?n with r))
				| ( ?n : [#phi].Nat ).[s:#phi].?n/[s] |-> find ((i iplus 1) imod hn))
                    | non |-> h.(i) <- (some (< ?key : [#phi].Nat > res ?key) (pack ?n as ?n return res ?n with r))
              in
                find ((hash <| ?n |>) imod hn)

(* Set implementation *)

let natset = fun #phi : ctx => (nathash #[#phi] (fun ?n : [#phi].Nat => Unit)) * (list hol([#phi].Nat))
let mkset = fun #phi : ctx => fun i : int => tup( mkhash #[#phi] (fun ?n : [#phi].Nat => Unit) i,
						  nil hol([#phi].Nat) )
let setadd = fun #phi : ctx => fun s : natset #[#phi] => fun ?n : [#phi].Nat =>
             (match hashget #[#phi] (fun ?n : [#phi].Nat => Unit) (fst s) ?n with
		  som |-> s
		| non |-> ((hashset #[#phi] (fun ?n : [#phi].Nat => Unit) (fst s) ?n unit);
		           tup(fst s, cons hol([#phi].Nat) <| ?n |> (snd s))))
let setfold = fun a : CType => fun #phi : ctx =>  
              fun f : {?n : [#phi].Nat}(a -> a) => fun start : a => fun s : natset #[#phi] =>
              listfold (hol([#phi].Nat)) a
	      (fun st : a => fun n : hol([#phi].Nat) =>
		  unpack < ?n, unused > = n in
		  f ?n st)
	      start
	      (snd s)

let setiter = fun #phi : ctx =>
              fun f : ([#phi].Nat) -> Unit =>
              fun s : natset #[#phi] =>
              setfold Unit #[#phi] (fun ?n : [#phi].Nat => fun unused : Unit => f ?n) unit s

let setunion = fun #phi : ctx => fun s1 : natset #[#phi] => fun s2 : natset #[#phi] =>
               setfold (natset #[#phi]) #[#phi]
	       (fun ?n : [#phi].Nat => fun s : natset #[#phi] => setadd #[#phi] s ?n)
	       s1
	       s2

(* Union-find with congruence *)

let ufres = fun #phi : ctx => fun ?n : [#phi].Nat => (ref (< ?n' : [#phi].Nat >hol([s:#phi].eq ?n/[s] ?n'/[s]))) *
                                                     (ref (natset #[#phi]))

let ufempty = fun #phi : ctx => mkhash #[#phi] (ufres #[#phi]) STANDARD_HASH_SIZE

(* let ufdatabasetype = ({ #phi : ctx, ?n : [#phi].Nat } nathash #[#phi] (ufres #[#phi]) -> Unit) *)
(* let ufdatabase : ref (list ufdatabasetype) = mkref(nil ufdatabasetype, list ufdatabasetype) *)
(* let ufdatabase_register = fun f : ufdatabasetype => ufdatabase := cons ufdatabasetype f !ufdatabase  *)

let find = fun #phi : ctx => fun h : nathash #[#phi] (ufres #[#phi]) =>
  letrec find : { ?n : [#phi].Nat }(< ?n' : [#phi].Nat >hol([s:#phi].eq ?n/[s] ?n'/[s])) =
  fun ?n : [#phi].Nat =>
  match hashget #[#phi] (ufres #[#phi]) h ?n with
      som |-> (unpack < ?n', ?prf, unused > = !(fst som) in
              if nateq #[#phi] ?n ?n' then
		!(fst som)
	      else
		(let res = find ?n' in
		   unpack < ?n'', ?prf', unused > = res in
                   pack ?n'' as ?n'' return hol([s:#phi].eq ?n/[s] ?n''/[s]) with <| [s:#phi].eq_trans ?n/[s] ?n'/[s] ?n''/[s] ?prf/[s] ?prf'/[s] |>))
    | non |->
	let same = pack ?n as ?n' return hol([s:#phi].eq ?n/[s] ?n'/[s]) with <| [s:#phi].refl ?n/[s] |> in
	let ccpar = mkref (mkset #[#phi] STANDARD_HASH_SIZE, natset #[#phi]) in
	  ((hashset #[#phi] (ufres #[#phi]) h ?n tup(mkref (same, < ?n' : [#phi].Nat >hol([s:#phi].eq ?n/[s] ?n'/[s])), ccpar));
	  (* (let unused = listmap ufdatabasetype Unit *)
	  (*               (fun f : ufdatabasetype => f #[#phi] ?n h) !ufdatabase in unit); *)
	  (holcase ?n as ?n return Unit with

	       (* here we should add other cases for more parameters *)

		   (?f : [#phi].Nat -> Nat, ?n1 : [#phi].Nat).[s : #phi].?f/[s] ?n1/[s] |->
		     (let n1res = find ?n1 in
		      unpack < ?n1', unused > = n1res in
		      let n1rep = hashget_uns #[#phi] (ufres #[#phi]) h ?n1' in
		      let n1ccpar = snd n1rep in
			n1ccpar := setadd #[#phi] !n1ccpar ?n)
	       | (?n : [#phi].Nat).[s:#phi].?n/[s] |-> unit));
	  same
  in
  find

let union = fun #phi : ctx => fun h : nathash #[#phi] (ufres #[#phi]) =>
  fun ?n1 : [#phi].Nat => fun ?n2 : [#phi].Nat => fun ?prf : [s : #phi].eq ?n1/[s] ?n2/[s] =>
  (let n1res = find #[#phi] h ?n1 in
   let n2res = find #[#phi] h ?n2 in
   unpack < ?n1', ?prf1 (* n1 = n1' *), unused > = n1res in
   unpack < ?n2', ?prf2 (* n2 = n2' *), unused > = n2res in
   if (nateq #[#phi] ?n1' ?n2') then
     unit
   else
     (let new2 = pack ?n2' as ?n2' return hol([s:#phi].eq ?n1'/[s] ?n2'/[s]) with
			          <| [s:#phi].eq_repl2 ?n1/[s] ?n2/[s] ?n1'/[s] ?n2'/[s] ?prf/[s] ?prf1/[s] ?prf2/[s] |> in
      let n1entry = hashget_uns #[#phi] (ufres #[#phi]) h ?n1' in
      let n2entry = hashget_uns #[#phi] (ufres #[#phi]) h ?n2' in
      let n1ccpar = snd n1entry in
      let n2ccpar = snd n2entry in
      let n1rep = fst n1entry in
	(n1rep := new2);
	(n2ccpar := (setunion #[#phi] !n1ccpar !n2ccpar));
	(n1ccpar := (mkset #[#phi] STANDARD_HASH_SIZE))))

let already_eq = fun #phi : ctx => fun h : nathash #[#phi] (ufres #[#phi]) =>
                 fun ?n1 : [#phi].Nat => fun ?n2 : [#phi].Nat =>
  (let res1 = find #[#phi] h ?n1 in
   let res2 = find #[#phi] h ?n2 in
   unpack < ?n1', ?pf1, unused > = res1 in
   unpack < ?n2', ?pf2, unused > = res2 in
   (* by now we have: n1 = n1' and n2 = n2'. We need n1 = n2 *)
  (holcase ?n1' as ?n1' return {?pf : [s:#phi].eq ?n1/[s] ?n1'/[s]}option hol([s:#phi].eq ?n1/[s] ?n2/[s]) with
       ().[s:#phi].?n2'/[s] |-> (* n1 = n2' /\ n2 = n2' *)
	                    (fun ?pf : [s:#phi].eq ?n1/[s] ?n2'/[s] =>
                             some hol([s:#phi].eq ?n1/[s] ?n2/[s]) <|[s:#phi].eq_trans ?n1/[s] ?n2'/[s] ?n2/[s] ?pf/[s] (eq_symm ?n2/[s] ?n2'/[s] ?pf2/[s]) |>)
     | (?n11 : [#phi].Nat).[s:#phi].?n11/[s] |-> (fun ?pf : [s:#phi].eq ?n1/[s] ?n11/[s] => none hol([s:#phi].eq ?n1/[s] ?n2/[s])))
    ?pf1 )


let congruent = fun #phi : ctx => fun h : nathash #[#phi] (ufres #[#phi]) =>
                fun ?n1 : [#phi].Nat => fun ?n2 : [#phi].Nat =>
  let test1 = already_eq #[#phi] h ?n1 ?n2 in
  let test2 = holcase ?n1 as ?n1 return option(hol([s:#phi].eq ?n1/[s] ?n2/[s])) with
		    (?f : [#phi].Nat -> Nat, ?n0 : [#phi].Nat).[s:#phi].?f/[s] ?n0/[s] |->
		      (holcase ?n2 as ?n2 return option(hol([s:#phi].eq (?f/[s] ?n0/[s]) ?n2/[s])) with
			   (?n0' : [#phi].Nat).[s:#phi].?f/[s] ?n0'/[s] |->
			     (let argseq = already_eq #[#phi] h ?n0 ?n0' in
				match argseq with
				    som |-> unpack < ?pf0, unused > = som in
			                    some (hol([s:#phi].eq (?f/[s] ?n0/[s]) (?f/[s] ?n0'/[s])))
					      <| [s:#phi].f_equal ?f/[s] ?n0/[s] ?n0'/[s] ?pf0/[s] |>
			          | non |-> none (hol([s:#phi].eq (?f/[s] ?n0/[s]) (?f/[s] ?n0'/[s]))))
			 | (?n2 : [#phi].Nat).[s:#phi].?n2/[s] |->
			     none (hol([s:#phi].eq (?f/[s] ?n0/[s]) ?n2/[s])))
		  | (?n1 : [#phi].Nat).[s:#phi].?n1/[s] |->
		      none (hol([s:#phi].eq ?n1/[s] ?n2/[s])) in
    (match test1 with
	 som |-> test1
       | non |-> test2)


let merge = fun #phi : ctx => fun h : nathash #[#phi] (ufres #[#phi]) =>
  letrec merge : { ?n1 : [#phi].Nat, ?n2 : [#phi].Nat, ?prf : [s:#phi].eq ?n1/[s] ?n2/[s] } Unit =
  fun ?n1 : [#phi].Nat => fun ?n2 : [#phi].Nat => fun ?prf : [s:#phi].eq ?n1/[s] ?n2/[s] =>
  unpack < ?n1', unused > = find #[#phi] h ?n1 in
  unpack < ?n2', unused > = find #[#phi] h ?n2 in
  if nateq #[#phi] ?n1' ?n2' then
    unit
  else
    (let n1ccpar = !(snd (hashget_uns #[#phi] (ufres #[#phi]) h ?n1')) in
     let n2ccpar = !(snd (hashget_uns #[#phi] (ufres #[#phi]) h ?n2')) in
     let mergeifneeded = fun ?t1 : [#phi].Nat => fun ?t2 : [#phi].Nat =>
       unpack < ?t1', unused > = find #[#phi] h ?t1 in
       unpack < ?t2', unused > = find #[#phi] h ?t2 in
       if nateq #[#phi] ?t1' ?t2' then
	 unit
       else
	 (match congruent #[#phi] h ?t1 ?t2 with
	  som |-> unpack < ?pft, unused > = som in merge ?t1 ?t2 ?pft
	 |non |-> unit)
     in
      (union #[#phi] h ?n1 ?n2 ?prf);
      (setiter #[#phi] (fun ?t1 : [#phi].Nat =>
	   setiter #[#phi] (fun ?t2 : [#phi].Nat => mergeifneeded ?t1 ?t2) n2ccpar)
	 n1ccpar)
    )
  in
  merge


let ufhash = fun #phi : ctx => nathash #[#phi] (ufres #[#phi])

let check_props_up_to_euf : { #phi : ctx } (ufhash #[#phi]) -> ({ ?P1 : [#phi].Prop, ?prf : [s:#phi].?P1/[s], ?P2 : [#phi].Prop }option(hol([s:#phi].?P2/[s]))) =
  fun #phi : ctx => fun h : ufhash #[#phi] => fun ?P1 : [#phi].Prop =>
  holcase ?P1 as ?P1 return { ?prf : [s:#phi].?P1/[s], ?P2 : [#phi].Prop }option(hol([s:#phi].?P2/[s])) with
      (?R : [#phi].Nat -> Nat -> Prop, ?n1 : [#phi].Nat, ?n2 : [#phi].Nat).[s:#phi].?R/[s] ?n1/[s] ?n2/[s] |->
	(fun ?prf : [s:#phi].?R/[s] ?n1/[s] ?n2/[s], ?P2 : [#phi].Prop =>
	    holcase ?P2 as ?P2 return option(hol([s:#phi].?P2/[s])) with
		(?n1' : [#phi].Nat, ?n2' : [#phi].Nat).[s:#phi].?R/[s] ?n1'/[s] ?n2'/[s] |->
		  (match congruent #[#phi] h ?n1 ?n1' with
		       som1 |-> (match congruent #[#phi] h ?n2 ?n2' with
				     som2 |->
				       (unpack < ?pf1, unused > = som1 in
					unpack < ?pf2, unused > = som2 in
			                some (hol([s:#phi].?R/[s] ?n1'/[s] ?n2'/[s]))
			                <| [s:#phi].nat_leibniz_2 ?R/[s] ?n1/[s] ?n1'/[s] ?n2/[s] ?n2'/[s] ?pf1/[s] ?pf2/[s] ?prf/[s] |>)
				   | non2 |-> none (hol([s:#phi].?R/[s] ?n1'/[s] ?n2'/[s])))
		     | non1 |-> none (hol([s:#phi].?R/[s] ?n1'/[s] ?n2'/[s])))
	      | (?P2 : [#phi].Prop).[s:#phi].?P2/[s] |->
		  none (hol([s:#phi].?P2/[s])))
    | (?P1 : [#phi].Prop).[s:#phi].?P1/[s] |->
	(fun ?prf : [s:#phi].?P1/[s] => fun ?P2 : [#phi].Prop =>
	    holcase ?P2 as ?P2 return option(hol([s:#phi].?P2/[s])) with
		().[s:#phi].?P1/[s] |-> some (hol([s:#phi].?P1/[s])) <| ?prf |>
	      | (?P2:[#phi].Prop).[s:#phi].?P2/[s] |-> none (hol([s:#phi].?P2/[s])))
	    
  

(* EUF ends here. *)

(* Now we implement a simple autoprover that takes EUF-matching into account. *)


(* Hypotheses-list types *)

let hyptype = fun #phi : ctx => < ?P0 : [#phi].Prop >hol( [s:#phi].?P0/[s] )
let hyplist = fun #phi : ctx => list (hyptype #[#phi])
let hypnil  = fun #phi : ctx => nil (hyptype #[#phi])
let hypcons = fun #phi : ctx => cons (hyptype #[#phi])
let hypweaken : { #phi : ctx, ?x : [#phi].Set } hyptype #[#phi] -> hyptype #[s : #phi, y : ?x/[s]] =
  fun #phi : ctx, ?x : [#phi].Set, H : hyptype #[#phi] =>
  unpack < ?P0, ?prf, unused > = H in
  pack [s : #phi, y : ?x/[s]].?P0/[s] as ?P0' return hol( [s:#phi, y : ?x/[s]].?P0'/[s,y]) with
      <| [s : #phi, y : ?x/[s]].?prf/[s] |>

let hypweakenprop : { #phi : ctx, ?x : [#phi].Prop } hyptype #[#phi] -> hyptype #[s : #phi, y : ?x/[s]] =
  fun #phi : ctx, ?x : [#phi].Prop, H : hyptype #[#phi] =>
  unpack < ?P0, ?prf, unused > = H in
  pack [s : #phi, y : ?x/[s]].?P0/[s] as ?P0' return hol( [s:#phi, y : ?x/[s]].?P0'/[s,y]) with
      <| [s : #phi, y : ?x/[s]].?prf/[s] |>

let hyplistweaken : { #phi : ctx, ?x : [#phi].Set } hyplist #[#phi] -> hyplist #[s : #phi, y : ?x/[s]] =
  fun #phi : ctx, ?x : [#phi].Set, l : hyplist #[#phi] =>
  listmap (hyptype #[#phi]) (hyptype #[s : #phi, y : ?x/[s]]) (hypweaken #[#phi] ?x) l

let hyplistweakenprop : { #phi : ctx, ?x : [#phi].Prop } hyplist #[#phi] -> hyplist #[s : #phi, y : ?x/[s]] =
  fun #phi : ctx, ?x : [#phi].Prop, l : hyplist #[#phi] =>
  listmap (hyptype #[#phi]) (hyptype #[s : #phi, y : ?x/[s]]) (hypweakenprop #[#phi] ?x) l

let hyplistconsprf =
  fun #phi : ctx, ?x : [#phi].Prop, l : hyplist #[#phi] =>
  hypcons #[s : #phi, y : ?x/[s]] (pack [s : #phi, y : ?x/[s]].?x/[s] as ?x' return hol([s : #phi, y : ?x/[s]].?x'/[s,y]) with <| [s : #phi, y : ?x/[s]].y |>) (hyplistweakenprop #[#phi] (?x) l)


(* Find hypothesis up to EUF equivalence matching a goal *)

let findhyp : { #phi : ctx, l : hyplist #[#phi], h : ufhash #[#phi], ?P : [#phi].Prop }option (hol([s:#phi].?P/[s])) =
  fun #phi : ctx, l : hyplist #[#phi], h : ufhash #[#phi], ?P : [#phi].Prop =>
  listfold
    (hyptype #[#phi])
    (option (hol([s:#phi].?P/[s])))
    (fun s : option (hol([s:#phi].?P/[s])) => fun e : hyptype #[#phi] =>
	match s with
	    som |-> s
	  | non |-> unpack < ?P0, ?pf0, unused > = e in
                    check_props_up_to_euf #[#phi] h ?P0 ?pf0 ?P
    )
    (none (hol([s:#phi].?P/[s])))
    l
    

(* Create an EUF hash out of a list of hypotheses *)

let create_euf_hash : { #phi : ctx, l : hyplist #[#phi] } ufhash #[#phi] =
  fun #phi : ctx => fun l : hyplist #[#phi] =>
    let h = ufempty #[#phi] in
      (listiter
	 (hyptype #[#phi])
	 (fun a : hyptype #[#phi] =>
	     unpack < ?P, ?pfP, unused > = a in
	     (holcase ?P as ?P return { ?pf : [s:#phi].?P/[s] } Unit with
		  (?n1 : [#phi].Nat, ?n2 : [#phi].Nat).[s:#phi].eq ?n1/[s] ?n2/[s] |->
		    (fun ?pf : [s:#phi].eq ?n1/[s] ?n2/[s] => merge #[#phi] h ?n1 ?n2 ?pf)
		| (?P : [#phi].Prop).[s:#phi].?P/[s] |->
		    (fun ?pf : [s:#phi].?P/[s] => unit)
	     ) ?pfP
	 )
	 l);
      h
      
 
(* A simple version of an auto tactic. *)

let autoprove =
  letrec autoprove :
    { #phi : ctx, ?P : [#phi].Prop } hyplist #[#phi] -> hol([s : #phi].?P/[s]) =
    fun #phi : ctx => fun ?P : [#phi].Prop => fun hyps : hyplist #[#phi] =>
    holcase ?P as ?P return hol([s : #phi].?P/[s]) with
	(?A : [#phi].Set, ?P' : [s : #phi, x : ?A/[s]].Prop).[s:#phi].(forall x : ?A/[s], ?P'/[s,x]) |->
	  let prf = autoprove #[s : #phi, x : ?A/[s]]
	             ?P'
	             (hyplistweaken #[#phi] ([s : #phi].?A/[s]) hyps)
	  in
	  unpack < ?prf, unused > = prf in
          <| [s : #phi].fun x : ?A/[s] => ?prf/[s,x] |>
      | (?P1 : [#phi].Prop, ?P2 : [#phi].Prop).[s:#phi].(?P1/[s] -> ?P2/[s]) |->
	  let prf = autoprove #[s : #phi, pf : ?P1/[s]]
	            ([s : #phi, pf : ?P1/[s]].?P2/[s])
		    (hyplistconsprf #[#phi] ([s : #phi].?P1/[s]) hyps)
	  in
	  unpack < ?prf, unused > = prf in
          <| [s : #phi].fun x : ?P1/[s] => ?prf/[s,x] |>
      | (?P1 : [#phi].Prop, ?P2 : [#phi].Prop).[s:#phi].(and ?P1/[s] ?P2/[s]) |->
	  (let prf1 = autoprove #[#phi] ?P1 hyps in
	   let prf2 = autoprove #[#phi] ?P2 hyps in
	   unpack < ?prf1, unused > = prf1 in
           unpack < ?prf2, unused > = prf2 in
           <| [s:#phi].conj ?P1/[s] ?P2/[s] ?prf1/[s] ?prf2/[s] |>)
      | ().[s : #phi].True |->
	  <| [s : #phi].triv |>
      | ( ?n1 : [#phi].Nat, ?n2 : [#phi].Nat ).[s:#phi].(eq ?n1/[s] ?n2/[s]) |->
	  (let h = create_euf_hash #[#phi] hyps in
	   match congruent #[#phi] h ?n1 ?n2 with
	       som |-> som
	     | non |-> bot (hol([s:#phi].eq ?n1/[s] ?n2/[s])))
      | (?P : [#phi].Prop). [s:#phi].(?P/[s]) |->
	  (let h = create_euf_hash #[#phi] hyps in
	     match findhyp #[#phi] hyps h ?P with
		 som |-> som
	       | non |-> bot (hol([s : #phi].?P/[s])))
  in
  fun ?P : [].Prop => autoprove #[] ?P (hypnil #[])

let nat_induction =
  fun ?P : [a : Nat].Prop =>
  fun p1 : hol([].?P/[zero]) =>
  fun p2 : hol([].forall x : Nat, ?P/[x] -> ?P/[succ x]) =>
  unpack < ?pf1, unused > = p1 in
  unpack < ?pf2, unused > = p2 in
  <| [].fun x : Nat => Elim(fun x : Nat => ?P/[x], x) { ?pf1/[] | ?pf2/[] } |>

evalfast (autoprove ([].forall (x : Nat), eq (plus x 0) x -> eq (succ (plus x 0)) (succ x) )).

let test1 : hol([].forall x : Nat, eq (plus x 0) x) =
  nat_induction ([x : Nat].eq (plus x 0) x)
                (autoprove ([].eq (plus 0 0) 0))
                (autoprove ([].forall (x : Nat), eq (plus x 0) x -> eq (succ (plus x 0)) (succ x)))

evalfast (autoprove ([].forall (x y : Nat), eq x y -> le x y -> le y x)).

>>
