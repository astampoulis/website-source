open Ocamlbuild_plugin
open Ocamlbuild_pack

let run_and_read = Ocamlbuild_pack.My_unix.run_and_read

let split s ch =
  let x = ref [] in
  let rec go s =
    let pos = String.index s ch in
    x := (String.before s pos)::!x;
    go (String.after s (pos + 1))
  in
  try
    go s
  with Not_found -> !x
                                                                                                                                                                                                                                             
let split_nl s = split s '\n'

let before_ext s =
  try
    String.before s (String.index s '.')
  with Not_found -> s

let find_syntaxes () = List.map before_ext (split_nl & run_and_read "ls syntax_*.ml");;


dispatch begin function
 | After_rules ->
 
     List.iter begin fun syntax ->
       flag ["ocaml"; "pp"; syntax]       & A(syntax -.- "cma");
       dep  ["ocaml"; "ocamldep"; syntax] & [syntax -.- "cma"];
     end (find_syntaxes());

 | _ -> ()
end;;
