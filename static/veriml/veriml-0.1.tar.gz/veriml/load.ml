#directory "_build";;
#directory ".";;
open Logic_core;;
open Logic_typing;;
open Logic_cst;;
open Logic_print;;
open Utils;;
#load "camlp4o.cma";;
#load "syntax_logic.cmo";;
open Syntax_logic;;
open Comp_cst;;
open Comp_print;;
#load "syntax_comp.cmo";;
open Syntax_comp;;
open Comp_typing;;
#install_printer pr_lterm;;
#install_printer pr_modal;;
#install_printer pr_ctxdesc;;
#install_printer pr_cterm;;
(* #use "logic_tests_cst.ml";; *)

