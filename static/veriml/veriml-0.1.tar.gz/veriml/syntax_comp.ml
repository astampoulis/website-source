open Camlp4.PreCast
module CAst = Comp_ast
module CCst = Comp_cst
module LCst = Logic_cst
module LMain = Logic_main
module CTyp = Comp_typing

module CompGram = Syntax_logic.LogicGram

let ident = Syntax_logic.ident
let modalterm = Syntax_logic.modalterm
let context = Syntax_logic.context
let exprlist = Syntax_logic.exprlist
let logicdef = Syntax_logic.logicdef

let cterm = CompGram.Entry.mk "computational term"
let cterm_eoi = CompGram.Entry.mk "computational term quotation"
let cterm_ast_eoi = CompGram.Entry.mk "computational term quotation (ast)"
let compdef = CompGram.Entry.mk "computational definition"
let compdef_eoi = CompGram.Entry.mk "computational definition quotation"
let mk_anti ?(c = "") n s = "\\$"^n^c^":"^s


EXTEND CompGram
  GLOBAL: cterm cterm_eoi cterm_ast_eoi compdef compdef_eoi;

  cterm:
    [ "let" RIGHTA
	[ "letrec"; d = LIST1 def SEP "andrec"; "in"; e = cterm ->
	    let defs = exprlist _loc d in
	    <:expr< CCst.CLetRec($defs$, $e$) >>
	| "let"; x = cident; "="; t = cterm; "in"; e = cterm ->
	    <:expr< CCst.CLet($x$, $t$, $e$) >> ]
    | "lambda" RIGHTA
	[ "fun"; v = cvars; "=>"; t = cterm ->
	    <:expr< CCst.clammany $v$ $t$ >> ]
    | "sigma" RIGHTA
	[ "<"; v = cvars; ">"; t = cterm ->
	    <:expr< CCst.csigmamany $v$ $t$ >> ]
    | "pi" RIGHTA
	[ "{"; v = cvars; "}"; t = cterm ->
	    <:expr< CCst.cpimany $v$ $t$ >> ]
    | "arrow" RIGHTA
	[ t = cterm; "->"; t' = cterm ->
	    <:expr< CCst.CArrow($t$, $t'$) >> ]
    | "packunpack" RIGHTA
	[ "pack"; t = cterm; "as"; x = cident; "return"; ret = cterm; "with"; e = cterm ->
	    <:expr< CCst.CPack($t$, $x$, $ret$, $e$) >>
	| "unpack"; "<"; strs = LIST1 cident SEP ","; ">"; "="; t = cterm; "in"; e = cterm ->
	    let s = exprlist _loc strs in
	    <:expr< CCst.cunpackmany $t$ $s$ $e$ >> ]
    | "cases" RIGHTA
	[ "holcase"; t = modalterm; "as"; v = modalident; "return"; ret = cterm; "with"; b = LIST1 holbranch SEP "|" ->
	    let b = exprlist _loc b in
	      <:expr< CCst.CHolCase(CCst.CHolTerm($t$), $v$, $ret$, $b$) >>
	| "match"; t = cterm; "with"; b = LIST1 matchbranch SEP "|" ->
	    let b = exprlist _loc b in
	      <:expr< CCst.CMatch($t$, $b$) >>
	]
    | "seq" LEFTA
	[ t = cterm; ";"; t' = cterm -> <:expr< CCst.CSeq($t$, $t'$) >> ]
    | "assign" NONA
	[ t = cterm; ":="; t' = cterm -> <:expr< CCst.CAssign($t$, $t'$) >> ]
    | "intrel" NONA
	[ t = cterm; "LT"; t' = cterm -> <:expr< CCst.CIntTest(CAst.LT, $t$, $t'$) >>
	| t = cterm; "LE"; t' = cterm -> <:expr< CCst.CIntTest(CAst.LE, $t$, $t'$) >>
	| t = cterm; "GT"; t' = cterm -> <:expr< CCst.CIntTest(CAst.GT, $t$, $t'$) >>
	| t = cterm; "GE"; t' = cterm -> <:expr< CCst.CIntTest(CAst.GE, $t$, $t'$) >>
	| t = cterm; "EQ"; t' = cterm -> <:expr< CCst.CIntTest(CAst.EQ, $t$, $t'$) >>  ]
    | "plusand" LEFTA
	[ t = cterm; "iplus"; t' = cterm -> <:expr< CCst.CIntOp(CAst.Plus, $t$, $t'$) >>
	| t = cterm; "iminus"; t' = cterm -> <:expr< CCst.CIntOp(CAst.Minus, $t$, $t'$) >>
	| t = cterm; "&&"; t' = cterm -> <:expr< CCst.CBoolOp(CAst.BAnd, $t$, $t'$) >> ]
    | "multor" LEFTA
	[ t = cterm; "itimes"; t' = cterm -> <:expr< CCst.CIntOp(CAst.Times, $t$, $t'$) >>
	| t = cterm; "imod"; t' = cterm -> <:expr< CCst.CIntOp(CAst.Mod, $t$, $t'$) >>
	| t = cterm; "||"; t' = cterm -> <:expr< CCst.CBoolOp(CAst.BOr, $t$, $t'$) >> ]
	    
    | "app" LEFTA
	[ "fst"; t = cterm -> <:expr< CCst.CProj(1, $t$) >>
	| "snd"; t = cterm -> <:expr< CCst.CProj(2, $t$) >>
	| t = cterm; t' = cterm ->
	    <:expr< CCst.CApp($t$, $t'$) >> ]
    | "prodtype" LEFTA
	[ t1 = cterm; "*"; t2 = cterm ->
	    <:expr< CCst.CProdType($t1$, $t2$) >> ]
    | "ifthenelse" LEFTA
	[ "if"; t1 = cterm; "then"; t2 = cterm; "else"; t3 = cterm ->
	    <:expr< CCst.CIfThenElse($t1$, $t2$, $t3$) >> ]
    | "simple"
	[ "CType" -> <:expr< CCst.CSort(CAst.CType) >>
	| "hol"; "("; t = modalterm; ")" ->
	    <:expr< CCst.CSigmaUnit(CCst.CHolTerm($t$)) >>
	| "tup"; "("; t1 = cterm; ","; t2 = cterm; ")" -> <:expr< CCst.CTuple($t1$,$t2$) >> 
	| "<|"; t = modalterm; "|>" ->
	    <:expr< CCst.CPackUnit(CCst.CHolTerm($t$)) >>
	| "Kind" -> <:expr< CCst.CSort(CAst.CKind) >>
	| "ctx" -> <:expr< CCst.CSort(CAst.CCtx) >>
	| t = modalterm -> <:expr< CCst.CHolTerm($t$) >>
	| "#"; t = context -> <:expr< CCst.CCtxTerm(LCst.LCtxAsList($t$)) >>
	| "Unit" -> <:expr< CCst.CUnitType >>
	| "unit" -> <:expr< CCst.CUnitExpr >>
	| "int" -> <:expr< CCst.CIntType >>
	| i = INT -> <:expr< CCst.CIntConst($int:i$) >>
	| "bool" -> <:expr< CCst.CBoolType >>
	| "true" -> <:expr< CCst.CBoolConst(true) >>
	| "false" -> <:expr< CCst.CBoolConst(false) >>
	| x = ident -> <:expr< CCst.CVar($str:x$) >>
	| "_" -> <:expr< CCst.CAny >>
	| "rec"; x = cident; ":"; t1 = cterm; "=>"; t2 = cterm ->
	    <:expr< CCst.CRecType($x$, $t1$, $t2$) >>
	| "fold"; "("; t1 = cterm; ","; t2 = cterm; ")" ->
	    <:expr< CCst.CFold($t1$, $t2$) >>
	| "unfold"; t1 = cterm ->
	    <:expr< CCst.CUnfold($t1$) >>
	| "sum"; "("; ts = LIST1 cterm SEP "+"; ")" ->
	    let ts' = exprlist _loc ts in
	    <:expr< CCst.CSumType($ts'$) >>
	| "ctor"; "("; i = INT; ","; t = cterm; ","; p = cterm; ")" ->
	    <:expr< CCst.CCtor($int:i$, $t$, $p$) >>
	| "ref"; t = cterm -> <:expr< CCst.CRefType($t$) >>
	| "mkref"; "("; t1 = cterm; ","; t2 = cterm; ")" -> <:expr< CCst.CMkRef($t1$,$t2$) >>
	| "!"; t = cterm -> <:expr< CCst.CReadRef($t$) >>
	| "array"; t = cterm -> <:expr< CCst.CArrayType($t$) >>
	| "mkarray"; "("; t1 = cterm; ","; t2 = cterm; ","; t3 = cterm; ")" ->
	    <:expr< CCst.CMkArray($t1$,$t2$,$t3$) >>
	| "[|"; ts = LIST1 cterm SEP ","; "|]"; "of"; t = cterm ->
	    let ts' = exprlist _loc ts in
	    <:expr< CCst.CArrayLit($ts'$,$t$) >>
	| "arraylen"; t = cterm -> <:expr< CCst.CArrayLen($t$) >>
	| t1 = cterm; "."; "("; t2 = cterm; ")"; "<-"; t3 = cterm ->
	    <:expr< CCst.CArraySet($t1$,$t2$,$t3$) >>
	| t1 = cterm; "."; "("; t2 = cterm; ")" ->
	    <:expr< CCst.CArrayGet($t1$,$t2$) >>
	| "hash"; t = cterm ->
	    <:expr< CCst.CHolHash($t$) >>
	| "print"; t = cterm ->
	    <:expr< CCst.CPrint($t$) >>
	| "^"; x = LIDENT ->
	    <:expr< $lid:x$ >>
	| "do"; "return"; t = cterm; "{"; d = LIST1 docommand SEP ";;"; "}" ->
	    (let d', (_, last) = Utils.ExtList.last d in
	    List.fold_right
	      (fun (x,tm) cmd ->
		 <:expr< CCst.CMatch($tm$, [ ($x$, $cmd$);
							( ("non", CAst.CType),
							  CCst.CApp(CCst.CVar("none"), $t$)) ]) >>)
	      d'
	      <:expr< CCst.CApp(CCst.CApp(CCst.CVar("some"), $t$), $last$) >>)
	| "("; t = cterm; ")" -> t ] ];

  docommand:
    [ [ x = ident; "<-"; t = cterm -> (<:expr< ($str:x$, CAst.CType) >>, <:expr< $t$ >>)
      | "return"; t = cterm -> ( <:expr< ( "", CAst.CType) >>, <:expr< $t$ >> ) ] ];

  modalident:
    [ [ "?"; x = ident -> <:expr< ($str:x$, CAst.CHol) >>  ] ];

  modalbinder:
    [ [ x = modalident; ":"; t = modalterm -> <:expr< ($x$, CCst.CHolTerm($t$)) >> ] ];

  holbranch:
    [ [ "("; metas = LIST0 modalbinder SEP ","; ")"; "."; t = modalterm; "|->"; e = cterm ->
	  let metas = exprlist _loc metas in
	  <:expr< ($metas$, CCst.CHolTerm($t$), $e$) >> ] ];

  matchbranch:
    [ [ x = cident; "|->"; e = cterm -> <:expr< ($x$, $e$) >> ] ];

  def:
    [ [ x = cident; ":"; t = cterm; "="; e = cterm -> <:expr< ($x$, $t$, $e$) >> ] ];

  cident:
    [ [ x = modalident -> x
      | "#"; x = ident -> <:expr< ($str:x$, CAst.CCtx) >>
      | x = ident -> <:expr< ($str:x$, CAst.CType) >>
      | "^"; x = LIDENT ->
	    <:expr< ($str:x$, CAst.CType) >> ] ];

  cvar:
    [ [ x = cident; ":"; t = cterm -> <:expr< ($x$,$t$) >> ] ];

  cvars:
    [ [ xs = LIST1 cvar SEP "," -> exprlist _loc xs ]];

  cterm_eoi:
    [ [ t = cterm; `EOI -> t ]];

  cterm_ast_eoi:
    [ [ t = cterm; `EOI -> <:expr< CCst.comp_ast_of_cst $t$ >> ]];

  cterm_ast:
    [ [ t = cterm -> <:expr< CCst.comp_ast_of_cst $t$ >> ]];
  
  compdef:
    [ [ t = logicdef -> t
      | "let"; x = ident; "="; t = cterm_ast -> <:expr< Comp_eval.comp_define $str:x$ $t$ >>
      | "let"; x = ident; ":"; tp = cterm_ast; "="; t = cterm_ast -> <:expr< Comp_eval.comp_define_typed $str:x$ $t$ $tp$ >>
      | "print"; t = cterm_ast; "." -> <:expr< CTyp.comp_print $t$ >> 
      | "typeof"; t = cterm_ast; "." -> <:expr< CTyp.comp_print_type $t$ >>
      | "eval"; t = cterm_ast; "." -> <:expr< Comp_eval.comp_print_eval $t$ >>
      | "evalfast"; t = cterm_ast; "." -> <:expr< Comp_eval.comp_print_eval_fast $t$ >> ] ];

  compdef_eoi:
    [[ cds = LIST1 compdef; `EOI ->
	 let cdexpr = List.fold_right (fun cd cur -> <:expr< $cd$ ; $cur$>>) cds <:expr< () >> in
	 <:str_item< let _ = $cdexpr$ >> ]];

  END;;

let expand_comp_quot loc _loc_name_opt quotation_contents = CompGram.parse_string cterm_eoi loc quotation_contents;;
let expand_compast_quot loc _loc_name_opt quotation_contents = CompGram.parse_string cterm_ast_eoi loc quotation_contents;;
let expand_compdef_quot loc _loc_name_opt quotation_contents = CompGram.parse_string compdef_eoi loc quotation_contents;;

Syntax.Quotation.add "cc" Syntax.Quotation.DynAst.expr_tag expand_comp_quot;;
Syntax.Quotation.add "ca" Syntax.Quotation.DynAst.expr_tag expand_compast_quot;;
Syntax.Quotation.add "cd" Syntax.Quotation.DynAst.str_item_tag expand_compdef_quot;;
Syntax.Quotation.default := "cd";;

