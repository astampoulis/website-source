open Syntax_logic;;
open Syntax_comp;;

let _ = (Logic_main.logic_reset (); Comp_typing.comp_global_reset ());;

<<

(* Logic *)

Inductive and (A B : Prop) : Prop :=
  conj : A -> B -> and.

Definition andProj1 (A B : Prop) (pf : and A B) : A :=
  Elim(A, pf) { fun a : A => fun b : B => a }.

Definition andProj2 (A B : Prop) (pf : and A B) : B :=
  Elim(B, pf) { fun a : A => fun b : B => b }.

Inductive or (A B : Prop) : Prop :=
  injl : A -> or
| injr : B -> or.

Inductive True : Prop :=
  triv : True.

Inductive False : Prop := .

Definition not (A : Prop) := A -> False.

Definition equiv (A B : Prop) := and (A -> B) (B -> A).

Metadef exists := [A : Set].fun P : A -> Prop => Ind(X : Prop) { forall x : A, P x -> X }.
Metadef ex_intro := [A : Set].fun P : A -> Prop => Ctor(?exists/[A] P, 0).

typeof ?ex_intro.

Inductive Nat : Set :=
   zero : Nat
 | succ : Nat -> Nat.

Definition plus : Nat -> Nat -> Nat :=
   fun (x y : Nat) =>
    Elim(Nat, x) {
      y
    | fun (p r : Nat) => succ r
    }.

Inductive eq (x : Nat) : Nat -> Prop :=
  refl : eq x.

Inductive le : Nat -> Nat -> Prop :=
  leO : forall x : Nat, le zero x
 |leS : forall (x y : Nat), le x y -> le (succ x) (succ y).

Definition eq_trans : forall (x y z : Nat), eq x y -> eq y z -> eq x z :=
  fun (x y z : Nat) =>
    fun (pf : eq x y) =>
    Elim(fun y' : Nat => eq y' z -> eq x z, pf) {
      fun p : eq x z => p
    }
.

Definition eq_repl2 : forall (x y x' y' : Nat), eq x y -> eq x x' -> eq y y' -> eq x' y' :=
  fun (x y x' y' : Nat) =>
    fun (pf1 : eq x y) (pf2 : eq x x') (pf3 : eq y y') =>
    Elim(fun y : Nat => eq x' y, pf3)
    { Elim(fun x : Nat => eq x y, pf2) { pf1 } }
.

Definition eq_symm : forall (x y : Nat), eq x y -> eq y x :=
      fun (x y :Nat) (pf : eq x y) =>
      Elim(fun y : Nat => eq y x, pf)
      { refl x }
.

Definition f_equal : forall (f : Nat -> Nat) (x y : Nat), eq x y -> eq (f x) (f y) :=
      fun (f : Nat -> Nat) (x y : Nat) (pf : eq x y) =>
      Elim(fun y : Nat => eq (f x) (f y), pf)
      {refl (f x)}
.

Definition nat_leibniz_2 : forall (P : Nat -> Nat -> Prop) (x x' y y' : Nat), eq x x' -> eq y y' -> P x y -> P x' y' :=
    fun (P : Nat -> Nat -> Prop) (x x' y y' : Nat) (pf1 : eq x x') (pf2 : eq y y') (pfp : P x y) =>
    Elim(fun y : Nat => P x' y, pf2)
    { Elim(fun x : Nat => P x y, pf1) { pfp } }
.

Inductive Bool : Set :=
    ltrue : Bool
    | lfalse : Bool.

Definition land : Bool -> Bool -> Bool :=
    fun (x y : Bool) => Elim(Bool, x) { y | lfalse }.

Definition lor  : Bool -> Bool -> Bool :=
    fun (x y : Bool) => Elim(Bool, x) { ltrue | y }.

Definition lnot : Bool -> Bool :=
    fun x : Bool => Elim(Bool, x) { lfalse | ltrue }.

Definition limpl : Bool -> Bool -> Bool :=
    fun (x y : Bool) => Elim(Bool, x) { y | ltrue }.

(* Basic computational types *)


let list = fun a : CType => rec t : CType => sum(Unit + a * t)
let nil = fun a : CType => fold( ctor(0, sum(Unit + a * (list a) ), unit), list a )
let cons = fun a : CType => fun hd : a => fun tl : list a => fold( ctor(1, sum(Unit + a * (list a)), tup(hd, tl)), list a)

let listmap = fun a : CType => fun b : CType => fun f : a -> b => (
  letrec map : list a -> list b = 
    fun l : list a =>
    match unfold l with
	u |-> nil b
      | hdtl |-> cons b (f (fst hdtl)) (map (snd hdtl))
  in
    map)
let listfold = fun a : CType => fun b : CType => fun f : b -> a -> b => fun start : b => (
  letrec lfold : list a -> b =
    fun l : list a =>
    match unfold l with
	u |-> start
      | hdtl |-> f (lfold (snd hdtl)) (fst hdtl)
  in
    lfold)
let listiter = fun a : CType => fun f : a -> Unit => fun l : list a =>
  listfold a Unit (fun unused : Unit => f) unit l


let option = fun a : CType => sum(a + Unit)
let some   = fun a : CType => fun b : a => ctor(0, option a, b)
let none   = fun a : CType => ctor(1, option a, unit)
let optiondo = fun a : CType => fun b : CType => fun param : option a => fun f : a -> option b =>
               match param with som |-> f som | non |-> none b

(* Magic value! *)

let bot =
  letrec bot : {a : CType}a = fun a : CType => bot a in
  bot

let nateq = fun #phi : ctx => fun ?n1 : [#phi].Nat => fun ?n2 : [#phi].Nat =>
    holcase ?n1 as ?n1 return bool with ().[s:#phi].?n2/[s] |-> true | (?n1 : [#phi].Nat).[s:#phi].?n1/[s] |-> false



>>;;

