open Utils
open Binding

type 
  lsort =  LType
	  |LSet
	  |LProp
and
  lterm =  LSort of lsort
	  |LVar of lvar
	  |LLambda of string option * lsort inferred * lterm * lterm
	  |LPi of string option * lsort inferred * lterm * lterm
	  |LApp of lterm * lterm
	  |LInd of linddef
	  |LCtor of lterm * int
	  |LElim of lterm (* result *) * lterm (* ind. term *) * lterm list (* branches *)

	  (* added for meta variables *)
	  |LModal of lmodalterm * lsubst

	  (* added for term lists (contexts and substitutions) *)
	  |LTermList of lctxdesc
and
  lvar =    LBVar of int  (* bound variables: deBruijn indexes *)
          | LFVar of int  (* free variables: deBruijn levels *)
	  | LNVar of string (* named variables: names in definition environments (maps) *)
and
  lmodalterm =   LTermInCtx of lctx * lterm
	       | LFMeta of int
	       | LBMeta of int 
	       | LNMeta of string
and
  lctxdesc =     LFCtx of int
	       | LBCtx of int
	       | LCtxAsList of lctx
and
  linddef = LIndDef of string option * larity * lconstr list (* inddef := Ind(X : Arity) { Constr_0 | ... | Constr_n } *)
and
  larity = LArity of (string option * lterm) list * lsort      (* arity  := Pi x_0 : M_0. ... Pi x_n : M_n. s *)
and
  lconstr = LConstr of (string option * lcparam) list * lterm list  (* constr := Pi x_0 : Cparam_0. ... Pi x_n : Cparam_n.X m_0 ... m_n *)
and
  lcparam =   LParNonrec of lterm  (* nonrecursive parameter for constructor of X: Pi x : M. ... with X not in fv(M) *)
            | LParStrictPos of (string option * lterm) list * lterm list (* recursive parameter with strictly positive occurence of X:
							  (P -> ...) with P = Pi x_0 : M_0. ... Pi x_n : M_n. X m_0 ... m_n with X not in fv(M_i |_| m_i) *)
and
  lsubst = lterm list
and
  lctx = (string option * lterm) list

type lterm_env = lterm list (* free variables *) * lterm_defenv (* def. environment *) * lmodalterm list (* meta variables *) * unit list (* ctx variables *)
and  lterm_defenv = (lterm (* type *) * lterm (* def *)) dict * (lmodalterm * lmodalterm) dict


(* Map *)

let lterm_map ?(lsort=fun s -> LSort(s))
              ?(lbvar=fun i -> LVar(LBVar i))
	      ?(lfvar=fun i -> LVar(LFVar i))
	      ?(lnvar=fun s -> LVar(LNVar s))
	      ?(llambda=fun s k t1 t2 rt1 rt2 -> LLambda(s, k, rt1, rt2))
	      ?(lpi=fun s k t1 t2 rt1 rt2 -> LPi(s, k, rt1, rt2))
	      ?(lapp=fun t1 t2 rt1 rt2 -> LApp(rt1, rt2))
	      ?(lctor=fun t1 i1 rt1 -> LCtor(rt1, i1))
	      ?(lelim=fun t1 t2 t3s rt1 rt2 rt3s -> LElim(rt1,rt2,rt3s))
	      ?(lsubstelem=fun t1 rt1 -> [rt1])
	      ?(lfctx=fun i1 -> LFCtx(i1))
	      ?(lbctx=fun i1 -> LBCtx(i1))
	      ?(lfmeta=fun i1 -> LFMeta(i1))
	      ?(lbmeta=fun i1 -> LBMeta(i1))
	      ?(lctxelem=fun s t1 rt1 -> [(s,rt1)])
	      ?(lmodal=fun mt1 t2s rmt1 rt2s -> LModal(rmt1, rt2s))
	      ?(lterminctx=fun ctx lt rctx rlt -> LTermInCtx(rctx, rlt))
	      ?(lctxaslist=fun ctx rctx -> LCtxAsList(rctx))
    =

  let mapsnd f = List.map (fun (a,b) -> (a, f b)) in
  let rec ltrec = function
      LSort(s) -> lsort s
    | LVar(LBVar i) -> lbvar i
    | LVar(LFVar i) -> lfvar i
    | LVar(LNVar i) -> lnvar i
    | LLambda(s1, k, t1, t2) -> llambda s1 k t1 t2 (ltrec t1) (ltrec t2)
    | LPi(s1, k, t1, t2) -> lpi s1 k t1 t2 (ltrec t1) (ltrec t2)
    | LApp(t1, t2) -> lapp t1 t2 (ltrec t1) (ltrec t2)
    | LInd(i1) -> LInd(lind i1)
    | LCtor(t1,i1) -> lctor t1 i1 (ltrec t1)
    | LElim(t1,t2,t3s) -> lelim t1 t2 t3s (ltrec t1) (ltrec t2) (List.map ltrec t3s)
    | LModal(mt1,t2s) -> lmodal mt1 t2s (modrec mt1) (List.concat (List.map substelemrec t2s))
    | LTermList(ct1) -> LTermList(ltermlist ct1)
  and substelemrec t1 = lsubstelem t1 (ltrec t1)
  and ctxelemrec (s, t1) = lctxelem s t1 (ltrec t1)
  and modrec = function
      LFMeta(i) -> lfmeta i
    | LBMeta(i) -> lbmeta i
    | LNMeta(s) -> LNMeta(s)
    | LTermInCtx(ct1,t1) -> lterminctx ct1 t1 (List.concat (List.map ctxelemrec ct1)) (ltrec t1)
  and ltermlist = function
      LFCtx(i) -> lfctx i
    | LBCtx(i) -> lbctx i
    | LCtxAsList(l) -> lctxaslist l (List.concat (List.map ctxelemrec l))
  and lind = function
      LIndDef(name, LArity(l1, s2), constrlist) ->
	LIndDef(name, LArity(mapsnd ltrec l1, s2), List.map lconstr constrlist)
  and lconstr = function
      LConstr(l1, t2s) -> LConstr(mapsnd lcparam l1, List.map ltrec t2s)
  and lcparam = function
      LParNonrec(l1) -> LParNonrec(ltrec l1)
    | LParStrictPos(l1,l2) -> LParStrictPos(mapsnd ltrec l1, List.map ltrec l2)
  in
    ltrec


(* Binding *)

(* this can be used to apply a varmap to a list of
   terms, each of which is a binder *)
		
let list_varmap f_varmap fextend start list =
  let rec list_varmap_aux i start (list : 'b list) =
    match list with
	[] -> []
      | hd :: tl -> (f_varmap (fextend start i) hd) :: list_varmap_aux (i+1) start tl
  in
    list_varmap_aux 0 start list

let varmaps fbound ffree =
  let fextend s i = s + i in
  let rec lterm_varmap start (t : lterm) =
    match t with
	LVar (LBVar i) -> fbound start i
      | LVar (LFVar i) -> ffree start i
      | LLambda (s, k, lt1, lt2)  -> LLambda(s, k, lterm_varmap start lt1, lterm_varmap (fextend start 1) lt2)
      | LPi (s, k, lt1, lt2)      -> LPi(s, k, lterm_varmap start lt1, lterm_varmap (fextend start 1) lt2)
      | LApp (lt1, lt2)        -> LApp(lterm_varmap start lt1, lterm_varmap start lt2)
      | LInd (idef)            -> LInd(inddef_varmap start idef)
      | LCtor (lt1, i)         -> LCtor(lterm_varmap start lt1, i)
      | LElim(lt1,lt2,ltl)     -> LElim(lterm_varmap start lt1, lterm_varmap start lt2, List.map (lterm_varmap start) ltl)
      | LModal(lt, subst)      -> LModal(modal_varmap start lt, List.map (lterm_varmap start) subst)
      | LTermList(tmlist)      -> LTermList(tmlist_varmap start tmlist)
      | t -> t
  and inddef_varmap start (t : linddef) =
    match t with
	LIndDef(s, arity, constrlist) ->
	  LIndDef(s, arity_varmap start arity, List.map (constr_varmap start) constrlist)
  and arity_varmap start (t : larity) =
    match t with
	LArity(termlist, sort) ->
	  LArity(stringlist (list_varmap lterm_varmap fextend start) termlist, sort)
  and constr_varmap start (t : lconstr) =
    match t with
	LConstr(paramlist, arglist) ->
	  (let nparam = List.length paramlist in
	     LConstr(stringlist (list_varmap cparam_varmap fextend start) paramlist,
		     List.map (lterm_varmap (fextend start nparam)) arglist))
  and cparam_varmap start (t : lcparam) =
    match t with
	LParNonrec(lt) -> LParNonrec(lterm_varmap start lt)
      | LParStrictPos(paramlist, arglist) ->
	  (let nparam = List.length paramlist in
	     LParStrictPos(stringlist (list_varmap lterm_varmap fextend start) paramlist,
			   List.map (lterm_varmap (fextend start nparam)) arglist))
  and modal_varmap start (t : lmodalterm) =
    match t with
	LTermInCtx(ctx, lt) ->
	  (let n = List.length ctx in
	     LTermInCtx(stringlist (list_varmap lterm_varmap fextend start) ctx,
			lterm_varmap (fextend start n) lt))
      | LFMeta(i) -> LFMeta(i)
      | LBMeta(i) -> LBMeta(i)
      | LNMeta(s) -> LNMeta(s)
  and tmlist_varmap start (t : lctxdesc) =
    match t with
	LFCtx(i) -> t
      | LBCtx(i) -> t
      | LCtxAsList(l) -> LCtxAsList(stringlist (list_varmap lterm_varmap fextend start) l)
  and ctx_varmap start (t : lctx) =
    stringlist (list_varmap lterm_varmap fextend start) t
  in
    (lterm_varmap, inddef_varmap, arity_varmap, constr_varmap, cparam_varmap, modal_varmap, tmlist_varmap, ctx_varmap)

let lterm_varmap fbound ffree   = let (a,_,_,_,_,_,_,_) = varmaps fbound ffree in a
let inddef_varmap fbound ffree  = let (_,a,_,_,_,_,_,_) = varmaps fbound ffree in a
let arity_varmap fbound ffree   = let (_,_,a,_,_,_,_,_) = varmaps fbound ffree in a
let constr_varmap fbound ffree  = let (_,_,_,a,_,_,_,_) = varmaps fbound ffree in a
let cparam_varmap fbound ffree  = let (_,_,_,_,a,_,_,_) = varmaps fbound ffree in a
let modal_varmap fbound ffree   = let (_,_,_,_,_,a,_,_) = varmaps fbound ffree in a
let tmlist_varmap fbound ffree  = let (_,_,_,_,_,_,a,_) = varmaps fbound ffree in a
let ctx_varmap fbound ffree     = let (_,_,_,_,_,_,_,a) = varmaps fbound ffree in a

module BindLterm = Binding(struct
			     type tvar = lterm
			     type t = lterm
			     type tenv = int
			     let  bound i = i
			     let  varmap f1 f2 = lterm_varmap f1 f2 0
			     let  bvar   i = LVar (LBVar i)
			     let  fvar   i = LVar (LFVar i)
			   end)
module BindLtermS = (struct
		       let subst_bound_list = BindLterm.subst_bound_list_given_shift BindLterm.shift_bound
		       let subst_bound      = BindLterm.subst_bound_given_list subst_bound_list
		     end)

module BindInddef = Binding(struct
			     type t = linddef
			     type tvar = lterm
			     type tenv = int
			     let  bound i = i
			     let  varmap f1 f2 = inddef_varmap f1 f2 0
			     let  bvar   i = LVar (LBVar i)
			     let  fvar   i = LVar (LFVar i)
			   end)
module BindInddefS = (struct
			let subst_bound_list = BindInddef.subst_bound_list_given_shift BindLterm.shift_bound
			let subst_bound      = BindInddef.subst_bound_given_list subst_bound_list
		      end)

module BindArity = Binding(struct
			     type t = larity
			     type tvar = lterm
			     type tenv = int
			     let  bound i = i
			     let  varmap f1 f2 = arity_varmap f1 f2 0
			     let  bvar   i = LVar (LBVar i)
			     let  fvar   i = LVar (LFVar i)
			   end)

module BindConstr = Binding(struct
			     type t = lconstr
			     type tvar = lterm
			     type tenv = int
			     let  bound i = i
			     let  varmap f1 f2 = constr_varmap f1 f2 0
			     let  bvar   i = LVar (LBVar i)
			     let  fvar   i = LVar (LFVar i)
			   end)

module BindCparam = Binding(struct
			     type t = lcparam
			     type tvar = lterm
			     type tenv = int
			     let  bound i = i
			     let  varmap f1 f2 = cparam_varmap f1 f2 0
			     let  bvar   i = LVar (LBVar i)
			     let  fvar   i = LVar (LFVar i)
			   end)

module BindModal = Binding(struct
			     type t = lmodalterm
			     type tvar = lterm
			     type tenv = int
			     let  bound i = i
			     let varmap f1 f2 = modal_varmap f1 f2 0
			     let bvar i = LVar (LBVar i)
			     let fvar i = LVar (LFVar i)
			   end)

module BindCtx = Binding(struct
			   type t = lctx
			   type tvar = lterm
			   type tenv = int
			   let  bound i = i
			   let varmap f1 f2 = ctx_varmap f1 f2 0
			   let bvar i = LVar (LBVar i)
			   let fvar i = LVar (LFVar i)
			 end)
module BindCtxS = (struct
		     let subst_bound_list = BindCtx.subst_bound_list_given_shift BindLterm.shift_bound
		     let subst_bound      = BindCtx.subst_bound_given_list subst_bound_list
		   end)

module BindTermlist = Binding(struct
				type t = lctxdesc
				type tvar = lterm
				type tenv = int
				let  bound i = i
				let varmap f1 f2 = tmlist_varmap f1 f2 0
				let bvar i = LVar (LBVar i)
				let fvar i = LVar (LFVar i)
			      end)

let metamaps fbound ffree =
  let rec lterm_varmap start (t : lterm) =
    match t with
      | LLambda (s, k, lt1, lt2)  -> LLambda(s, k, lterm_varmap start lt1, lterm_varmap start lt2)
      | LPi (s, k, lt1, lt2)      -> LPi(s, k, lterm_varmap start lt1, lterm_varmap start lt2)
      | LApp (lt1, lt2)        -> LApp(lterm_varmap start lt1, lterm_varmap start lt2)
      | LInd (idef)            -> LInd(inddef_varmap start idef)
      | LCtor (lt1, i)         -> LCtor(lterm_varmap start lt1, i)
      | LElim(lt1,lt2,ltl)     -> LElim(lterm_varmap start lt1, lterm_varmap start lt2, List.map (lterm_varmap start) ltl)
      | LModal(lt, subst)      -> LModal(modal_varmap start lt, List.map (lterm_varmap start) subst)
      | LTermList(ctxdesc)     -> LTermList(ctxdesc_varmap start ctxdesc)
      | t -> t
  and inddef_varmap start (t : linddef) =
    match t with
	LIndDef(s, arity, constrlist) ->
	  LIndDef(s, arity_varmap start arity, List.map (constr_varmap start) constrlist)
  and arity_varmap start (t : larity) =
    match t with
	LArity(termlist, sort) ->
	  LArity(stringlist (List.map (lterm_varmap start)) termlist, sort)
  and constr_varmap start (t : lconstr) =
    match t with
	LConstr(paramlist, arglist) ->
	  (LConstr(stringlist (List.map (cparam_varmap start)) paramlist,
		     List.map (lterm_varmap start) arglist))
  and cparam_varmap start (t : lcparam) =
    match t with
	LParNonrec(lt) -> LParNonrec(lterm_varmap start lt)
      | LParStrictPos(paramlist, arglist) ->
	  (LParStrictPos(stringlist (List.map (lterm_varmap start)) paramlist,
			   List.map (lterm_varmap start) arglist))
  and modal_varmap start (t : lmodalterm) =
    match t with
	LTermInCtx(ctx, lt) ->
	  (LTermInCtx(stringlist (List.map (lterm_varmap start)) ctx,
		      lterm_varmap start lt))
      | LFMeta(i) -> ffree start i
      | LBMeta(i) -> fbound start i
      | LNMeta(s) -> LNMeta(s)
  and ctxdesc_varmap start (t : lctxdesc) =
    match t with
	LCtxAsList(l) -> LCtxAsList(stringlist (List.map (lterm_varmap start)) l)
      | t -> t
  in
    (lterm_varmap, inddef_varmap, arity_varmap, constr_varmap, cparam_varmap, modal_varmap, ctxdesc_varmap)

let lterm_metamap fbound ffree   = let (a,_,_,_,_,_,_) = metamaps fbound ffree in a
let inddef_metamap fbound ffree  = let (_,a,_,_,_,_,_) = metamaps fbound ffree in a
let arity_metamap fbound ffree   = let (_,_,a,_,_,_,_) = metamaps fbound ffree in a
let constr_metamap fbound ffree  = let (_,_,_,a,_,_,_) = metamaps fbound ffree in a
let cparam_metamap fbound ffree  = let (_,_,_,_,a,_,_) = metamaps fbound ffree in a
let modal_metamap fbound ffree   = let (_,_,_,_,_,a,_) = metamaps fbound ffree in a
let ctxdesc_metamap fbound ffree = let (_,_,_,_,_,_,a) = metamaps fbound ffree in a

module MetabindLterm = Binding(struct
				 type tvar = lmodalterm
				 type t = lterm
				 type tenv = int
				 let  bound  i = i
				 let  varmap f1 f2 = lterm_metamap f1 f2 0
				 let  bvar   i = LBMeta i
				 let  fvar   i = LFMeta i
			       end)

module MetabindModal = Binding(struct
			     type t = lmodalterm
			     type tvar = lmodalterm
			     type tenv = int
			     let  bound i = i
			     let varmap f1 f2 = modal_metamap f1 f2 0
			     let bvar i = LBMeta i
			     let fvar i = LFMeta i
			   end)

module MetabindCtxdesc = Binding(struct
			     type t = lctxdesc
			     type tvar = lmodalterm
			     type tenv = int
			     let  bound i = i
			     let varmap f1 f2 = ctxdesc_metamap f1 f2 0
			     let bvar i = LBMeta i
			     let fvar i = LFMeta i
			   end)

let ctxmaps fbound ffree =
  let rec lterm_varmap start (t : lterm) =
    match t with
      | LLambda (s, k, lt1, lt2)  -> LLambda(s, k, lterm_varmap start lt1, lterm_varmap start lt2)
      | LPi (s, k, lt1, lt2)      -> LPi(s, k, lterm_varmap start lt1, lterm_varmap start lt2)
      | LApp (lt1, lt2)        -> LApp(lterm_varmap start lt1, lterm_varmap start lt2)
      | LInd (idef)            -> LInd(inddef_varmap start idef)
      | LCtor (lt1, i)         -> LCtor(lterm_varmap start lt1, i)
      | LElim(lt1,lt2,ltl)     -> LElim(lterm_varmap start lt1, lterm_varmap start lt2, List.map (lterm_varmap start) ltl)
      | LModal(lt, subst)      -> LModal(modal_varmap start lt, List.map (lterm_varmap start) subst)
      | LTermList(tmlist)      -> LTermList(tmlist_varmap start tmlist)
      | t -> t
  and inddef_varmap start (t : linddef) =
    match t with
	LIndDef(s, arity, constrlist) ->
	  LIndDef(s, arity_varmap start arity, List.map (constr_varmap start) constrlist)
  and arity_varmap start (t : larity) =
    match t with
	LArity(termlist, sort) ->
	  LArity(stringlist (List.map (lterm_varmap start)) termlist, sort)
  and constr_varmap start (t : lconstr) =
    match t with
	LConstr(paramlist, arglist) ->
	  (LConstr(stringlist (List.map (cparam_varmap start)) paramlist,
		     List.map (lterm_varmap start) arglist))
  and cparam_varmap start (t : lcparam) =
    match t with
	LParNonrec(lt) -> LParNonrec(lterm_varmap start lt)
      | LParStrictPos(paramlist, arglist) ->
	  (LParStrictPos(stringlist (List.map (lterm_varmap start)) paramlist,
			   List.map (lterm_varmap start) arglist))
  and modal_varmap start (t : lmodalterm) =
    match t with
	LTermInCtx(ctx, lt) ->
	  (LTermInCtx(stringlist (List.map (lterm_varmap start)) ctx, lterm_varmap start lt))
      | t -> t
  and tmlist_varmap start (t : lctxdesc) =
    match t with
	LFCtx(i) -> ffree start i
      | LBCtx(i) -> fbound start i
      | LCtxAsList(lt) -> LCtxAsList(stringlist (List.map (lterm_varmap start)) lt)
  in
    (lterm_varmap, inddef_varmap, arity_varmap, constr_varmap, cparam_varmap, modal_varmap, tmlist_varmap)

let lterm_ctxmap fbound ffree  = let (a,_,_,_,_,_,_) = ctxmaps fbound ffree in a
let modal_ctxmap fbound ffree  = let (_,_,_,_,_,a,_) = ctxmaps fbound ffree in a
let tmlist_ctxmap fbound ffree = let (_,_,_,_,_,_,a) = ctxmaps fbound ffree in a

module CtxbindLterm = Binding(struct
				type tvar = lctxdesc
				type t = lterm
				type tenv = int
				let  bound  i = i
				let  varmap f1 f2 = lterm_ctxmap f1 f2 0
				let  bvar   i = LBCtx i
				let  fvar   i = LFCtx i
			      end)

module CtxbindModal = Binding(struct
				type t = lmodalterm
				type tvar = lctxdesc
				type tenv = int
				let  bound  i = i
				let varmap f1 f2 = modal_ctxmap f1 f2 0
				let bvar i = LBCtx i
				let fvar i = LFCtx i
			      end)

module CtxbindCtxdesc = Binding(struct  type tvar = lctxdesc
				type t = lctxdesc
				type tenv = int
				let  bound  i = i
				let  varmap f1 f2 = tmlist_ctxmap f1 f2 0
				let  bvar   i = LBCtx i
				let  fvar   i = LFCtx i
			end)
