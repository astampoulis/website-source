open Camlp4.PreCast
module LCst = Logic_cst
module LAst = Logic_ast
module LMain = Logic_main

module LogicGram = MakeGram(Lexer)

let term = LogicGram.Entry.mk "term"
let term_eoi = LogicGram.Entry.mk "logic term quotation"
let termast_eoi = LogicGram.Entry.mk "logic term ast quotation"
let modalterm = LogicGram.Entry.mk "contextual term"
let modalterm_eoi = LogicGram.Entry.mk "contextual term quotation"
let logicdef = LogicGram.Entry.mk "logic definition"
let logicdef_eoi = LogicGram.Entry.mk "logic definition quotation"
let ident = LogicGram.Entry.mk "identifier"
let context = LogicGram.Entry.mk "context"

let exprlist _loc ls = List.fold_right (fun elm cur -> <:expr< $elm$ :: $cur$ >>) ls <:expr< [] >>

EXTEND LogicGram
  GLOBAL: term term_eoi termast_eoi modalterm modalterm_eoi logicdef logicdef_eoi ident context;

  term:
    [ "pilambda" RIGHTA
	[ "fun"; v = vars; "=>"; t' = term ->
	    <:expr< LCst.lammany $v$ $t'$ >>
	| "forall"; v = vars; ","; t' = term ->
	    <:expr< LCst.pimany $v$ $t'$ >> ]
    | "arrow" RIGHTA
	[ t = term; "->"; t' = term ->
	    <:expr< LCst.LArrow($t$, $t'$) >> ]
    | "app" LEFTA
	[ t = term; t' = term ->
	    <:expr< LCst.LApp($t$, $t'$) >> ]
    | "simple"
        [ "Type" -> <:expr< LCst.LSort(LAst.LType) >>
	| "Set"  -> <:expr< LCst.LSort(LAst.LSet) >>
	| "Prop" -> <:expr< LCst.LSort(LAst.LProp) >>
	| x = ident -> <:expr< LCst.LVar($str:x$) >>
	| "Ind"; "("; name = ident; ":"; arity = term; ")"; "{"; constrs = termlist; "}" ->
	    <:expr< LCst.LInd(LCst.LIndDef($str:name$, $arity$, $constrs$)) >>
	| "Ctor"; "("; tm = term; ","; i = INT; ")" ->
	    <:expr< LCst.LCtor($tm$, $int:i$) >>
	| "Elim"; "("; res = term; ","; tm = term; ")"; "{"; branches = termlist; "}" ->
	    <:expr< LCst.LElim($res$, $tm$, $branches$) >>
	| mt = modalterm; "/"; "["; subst = LIST0 term SEP ","; "]" ->
	    let subst' = exprlist _loc (List.map (fun t -> <:expr< $t$ >>) subst) in 
	    <:expr< LCst.LModal($mt$, $subst'$) >>
	| i = INT ->
	    <:expr< LCst.logicint $int:i$ >>
	| "("; t = term; ")" -> t ] ];

  modalterm:
    [ [ ctx = context; "."; t = term ->
	    <:expr< LCst.LTermInCtx($ctx$, $t$) >>
      | "?"; x = ident ->
	  <:expr< LCst.LMeta($str:x$) >> ] ];

  context:
    [ [ "["; xs = LIST0 ctxelem SEP ","; "]" -> exprlist _loc xs ]];

  ctxelem:
    [ [ x = ident; ":"; t = term -> <:expr< ($str:x$, $t$) >> 
      | "#"; y = ident -> <:expr< ("", LCst.LTermList(LCst.LCtxVar($str:y$))) >>
      | c = context -> <:expr< ("", LCst.LTermList(LCst.LCtxAsList($c$))) >>
      | x = ident; ":"; "#"; y = ident -> <:expr< ($str:x$, LCst.LTermList(LCst.LCtxVar($str:y$))) >>
      | x = ident; ":"; c = context -> <:expr< ($str:x$, LCst.LTermList(LCst.LCtxAsList($c$))) >> ]];

  termlist:
    [ [ ts = LIST0 term SEP "|" -> exprlist _loc ts ]];

  varlist:
    [ [ "("; is = LIST1 ident; ":"; t = term; ")" -> List.map (fun i -> (i,t)) is ] ];

  vars:
    [ [ x = ident; ":"; t = term -> <:expr< [($str:x$,$t$)] >> ]
    | [ xs = LIST1 varlist ->
	  let xs' = List.flatten xs in
 	    exprlist _loc (List.map (fun (i,t) -> <:expr< ($str:i$, $t$)>>) xs') ]];

  term_eoi:
    [[ t = term; `EOI -> t ]];

  boundlist:
    [[ "["; bound = LIST1 ident SEP ","; "]" -> bound ]];

  termast_eoi:
    [ [ bound = OPT boundlist; t = term; `EOI ->
	 let xs = match bound with Some bound -> exprlist _loc (List.map (fun x -> <:expr< $str:x$ >>) bound) | None -> <:expr< [] >> in
	 <:expr< LCst.ast_of_cst ~bound:$xs$ $t$ >>
      ]
    ];

  modalterm_eoi:
    [[ t = modalterm; `EOI -> t ]];

  ident:
    [ [ x = LIDENT -> x
      | x = UIDENT -> x ]];

  paramlist:
    [ [ xs = LIST0 varlist ->
	  let xs' = List.flatten xs in
 	    exprlist _loc (List.map (fun (i,t) -> <:expr< ($str:i$, $t$)>>) xs') ] ];

  logicdef:
    [ [ "Definition"; name = ident; params = paramlist; ":"; tp = term; ":="; tm = term; "." ->
	  <:expr< LMain.logic_define_typed $str:name$ $params$ $tm$ $tp$ >>
      | "Definition"; name = ident; params = paramlist; ":="; tm = term; "." ->
	  <:expr< LMain.logic_define $str:name$ $params$ $tm$ >> 
      | "Inductive"; name = ident; params = paramlist; ":"; arity = term; ":="; constrs = constrlist; "." ->
	  <:expr< LMain.logic_inductive $str:name$ $params$ $arity$ $constrs$ >>
      | "Print"; tm = term; "." ->
	  <:expr< LMain.logic_print $tm$ >>
      | "Check"; tm = term; "." ->
	  <:expr< LMain.logic_check $tm$ >>
      | "Eval"; "whnf"; "in"; tm = term; "." ->
	  <:expr< LMain.logic_whnf $tm$ >>
      | "Eval"; "whdelta"; "in"; tm = term; "." ->
	  <:expr< LMain.logic_whdelta $tm$ >>
      | "Metadef"; name = ident; ":="; tm = modalterm; "." ->
	  <:expr< LMain.logic_define_meta $str:name$ $tm$ >>
      | "Metadef"; name = ident; ":"; tp = modalterm; ":="; tm = modalterm; "." ->
	  <:expr< LMain.logic_define_meta_typed $str:name$ $tm$ $tp$ >>
      ] ];

  constrlist:
    [ [ constrs = LIST0 constr SEP "|" ->
	  List.fold_right (fun (id,elm) cur -> <:expr< ($str:id$, $elm$) :: $cur$ >>) constrs <:expr< [] >> ] ];

  constr:
    [ [ name = ident; ":"; tm = term -> (name, tm) ] ];

  logicdef_eoi:
    [[ lds = LIST1 logicdef; `EOI ->
	 let ldexpr = List.fold_right (fun ld cur -> <:expr< $ld$ ; $cur$>>) lds <:expr< () >> in
	 <:str_item< let _ = $ldexpr$ >> ]];

END;;

let expand_logic_quot loc _loc_name_opt quotation_contents = LogicGram.parse_string term_eoi loc quotation_contents;;
let expand_logicdef_quot loc _loc_name_opt quotation_contents = LogicGram.parse_string logicdef_eoi loc quotation_contents;;
let expand_logicast_quot loc _loc_name_opt quotation_contents = LogicGram.parse_string termast_eoi loc quotation_contents;;

Syntax.Quotation.add "logic" Syntax.Quotation.DynAst.expr_tag expand_logic_quot;;
Syntax.Quotation.add "logicdef" Syntax.Quotation.DynAst.str_item_tag expand_logicdef_quot;;
Syntax.Quotation.add "ll" Syntax.Quotation.DynAst.expr_tag expand_logicast_quot;;



