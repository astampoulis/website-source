open Utils
module LAst = Logic_ast
module BindLterm = LAst.BindLterm
module BindConstr = LAst.BindConstr

type 
  lterm =  LSort of LAst.lsort
	  |LVar of string
	  |LLambda of string * lterm * lterm
	  |LPi of string * lterm * lterm
	  |LArrow of lterm * lterm
	  |LApp of lterm * lterm
	  |LInd of linddef
	  |LCtor of lterm * int
	  |LElim of lterm (* result *) * lterm (* ind. term *) * lterm list (* branches *)
	  |LModal of lmodalterm * lsubst
	  |LTermList of lctxdesc
and
  lsubst = lterm list
and
  lctx = (string * lterm) list
and
  lctxdesc = LCtxVar of string
	     | LCtxAsList of (string * lterm) list
and
  lmodalterm = LTermInCtx of lctx * lterm
	       | LMeta of string
and
  linddef = LIndDef of string * lterm (* arity *) * lterm list (* constructors *)

let appmany (lt : lterm) (l : lterm list) =
  List.fold_left (fun res cur -> LApp(res, cur)) lt l

let lammany (l : (string * lterm) list) (lt : lterm) =
  List.fold_right (fun (str,cur) res -> LLambda(str, cur, res)) l lt

let pimany (l : (string * lterm) list) (lt : lterm) =
  List.fold_right (fun (str,cur) res -> LPi(str, cur, res)) l lt

type lpimany_gathered  = LPiMany of (string * lterm) list * lterm
type lappmany_gathered = LAppMany of lterm * lterm list

let rec gather_pi e =
  match e with
      LPi(s,t,e') -> let LPiMany (ts, e'') = gather_pi e' in LPiMany((s,t) :: ts, e'')
    | LArrow(t,e') -> let LPiMany (ts, e'') = gather_pi e' in LPiMany(("",t) :: ts, e'')
    | e -> LPiMany([], e)

let rec gather_app e =
  match e with
      LApp(e,e') -> let LAppMany (e0, es) = gather_app e in LAppMany(e0, List.append es [e'])
    | e -> LAppMany(e, [])

let rec is_fv (var : string) (e : lterm) =
  match e with
      LSort(s) -> false
    | LVar(str) -> str = var
    | LLambda(str, t1, t2) ->
	is_fv var t1 || (str <> var && is_fv var t2)
    | LPi(str, t1, t2) ->
	is_fv var t1 || (str <> var && is_fv var t2)
    | LArrow(t1, t2) ->
	is_fv var t1 || is_fv var t2
    | LApp(t1, t2) ->
	is_fv var t1 || is_fv var t2
    | LInd(LIndDef(name, arity, constrs)) ->
	is_fv var arity || (name <> var && List.exists (is_fv var) constrs)
    | LCtor(t1, i) ->
	is_fv var t1
    | LElim(t1,t2,tl) ->
	is_fv var t1 || is_fv var t2 || List.exists (is_fv var) tl
    | LModal(m,subst) ->
	List.exists (is_fv var) subst
    | LTermList(LCtxAsList(ctx)) ->
	failwith "not implemented yet"
    | LTermList(_) -> false

let conversions benv metaenv ctxenv = 
  let rec ast_of_cst (benv : string list) (e : lterm) =
    match e with
	LSort(s) -> LAst.LSort(s)
      | LVar(str) ->
	  begin
	    try
	      let i = ExtList.findindex ((=) str) benv in LAst.LVar (LAst.LBVar i)
	    with Not_found ->
	      LAst.LVar (LAst.LNVar str)
	  end
      | LLambda(str, t1, t2) ->
	  LAst.LLambda(Some str, mk_inferred (), ast_of_cst benv t1, ast_of_cst (str :: benv) t2)
      | LPi(str, t1, t2) ->
	  LAst.LPi(Some str, mk_inferred (), ast_of_cst benv t1, ast_of_cst (str :: benv) t2)
      | LArrow(t1, t2) ->
	  LAst.LPi(None, mk_inferred (), ast_of_cst benv t1, ast_of_cst ("" :: benv) t2)
      | LApp(t1, t2) ->
	  LAst.LApp(ast_of_cst benv t1, ast_of_cst benv t2)
      | LInd(idef) ->
	  LAst.LInd(ast_inddef_of_cst_inddef benv idef)
      | LCtor(tm, i) ->
	  LAst.LCtor(ast_of_cst benv tm, i)
      | LElim(t1, t2, tl) ->
	  LAst.LElim(ast_of_cst benv t1, ast_of_cst benv t2, List.map (ast_of_cst benv) tl)
      | LModal(m, subst) ->
	  LAst.LModal(ast_of_modal m, List.map (ast_of_cst benv) subst)
      | LTermList(ctxdesc) ->
	  LAst.LTermList(ast_of_ctxdesc benv ctxdesc)

  and ast_of_modal m =
    match m with
	LTermInCtx(ctx, lt) ->
	  (let rec aux ctx benv lt =
	     match ctx with
		 [] -> ([], ast_of_cst benv lt)
	       | (namehd, typehd) :: tl ->
		   let ctx_tl, lt = aux tl (namehd :: benv) lt in
		   let ctx_hd = ast_of_cst benv typehd in
		     ((Some namehd, ctx_hd) :: ctx_tl, lt)
	   in
	   let ctx', lt' = aux ctx [] lt in
	     LAst.LTermInCtx(ctx', lt'))
      | LMeta(str) ->
	  begin
	    try
	      (let i = ExtList.findindex ((=) str) metaenv in
		 LAst.LBMeta(i))
	    with Not_found ->
	      LAst.LNMeta(str)
	  end

  and ast_of_ctxdesc benv c =
    match c with
	LCtxVar(str) -> (let i = ExtList.findindex ((=) str) ctxenv in
			 LAst.LBCtx(i))
      | LCtxAsList(ctx) -> 
	  (let rec aux benv ctx =
	     match ctx with
		 [] -> []
	       | (namehd, typehd) :: tl ->
		   let ctx_tl = aux (namehd :: benv) tl in
		   let ctx_hd = ast_of_cst benv typehd in
		     (Some namehd, ctx_hd) :: ctx_tl
	   in
	   let ctx' = aux benv ctx in
	     LAst.LCtxAsList(ctx'))
	    
  and ast_inddef_of_cst_inddef (benv : string list) (LIndDef(name, arity, constrs) : linddef) =
    
    let rec binderlist conv benv =
      function
	  [] -> []
	| (str,hd) :: tl -> (Some str, conv benv hd) :: (binderlist conv (str::benv) tl)
    in

    let arity_conv =
      match gather_pi arity with
	  LPiMany(namedterms, LSort(sort)) -> LAst.LArity(binderlist ast_of_cst benv namedterms, sort)
	| _ -> failwith ("inductive definition " ^ name ^ " has wrong arity")
    in

    let strict_pos_conv benv e =
      let LPiMany(params, body) = gather_pi e in
      let LAppMany(base, args) = gather_app body in
      let paramnames, paramterms = List.split params in
	if List.exists ((=) name) paramnames then
	  failwith ("parameter shadows inductive type under definition " ^ name)
	else if List.exists (is_fv name) (List.append paramterms args) then
	  failwith ("non-strict positive occurrence of inductive type " ^ name)
	else if base <> LVar name then
	  failwith ("shouldn't happen -- strict positive parameter has a result type different than the inductive type being defined")
	else
	  (let benv' = List.append (List.rev paramnames) benv in
	   LAst.LParStrictPos(binderlist ast_of_cst benv params, List.map (ast_of_cst benv') args))
    in

    let cparam_conv benv e =
      if is_fv name e then
	strict_pos_conv benv e
      else
	LAst.LParNonrec(ast_of_cst benv e)
    in

    let constr_conv benv e =
      let LPiMany(params, body) = gather_pi e in
      let LAppMany(base, args) = gather_app body in
      let cparams = binderlist cparam_conv benv params in
      let paramnames, _ = List.split params in
	if List.exists ((=) name) paramnames then
	  failwith ("parameter shadows inductive type under definition " ^ name)
	else if List.exists (is_fv name) args then
	  failwith ("non-strict positive occurrence of inductive type " ^ name)
	else if base <> LVar name then
	  failwith ("a branch has a result type different than the inductive type " ^ name ^ " being defined")
	else
	  (let benv' = List.append (List.rev (List.map fst params)) benv in
	   LAst.LConstr(cparams, List.map (ast_of_cst benv') args))
    in
      LAst.LIndDef(Some name, arity_conv, List.map (constr_conv benv) constrs)
  in
    (ast_of_cst (List.rev benv), ast_of_modal, ast_of_ctxdesc [])

let ast_of_cst     ?(bound = []) ?(metaenv = []) ?(ctxenv = []) e =
  let (f,_,_) = conversions bound metaenv ctxenv in f e
let ast_of_modal   ?(metaenv = []) ?(ctxenv = []) e =
  let (_,f,_) = conversions [] metaenv ctxenv in f e
let ast_of_ctxdesc ?(metaenv = []) ?(ctxenv = []) e =
  let (_,_,f) = conversions [] metaenv ctxenv in f e

let rec logicint i =
  match i with
      0 -> LVar "zero"
    | i when i > 0-> LApp (LVar "succ", logicint (i-1))
    | _ -> failwith "negative number passed to logicint"
	
(* potential bug: naming an inductive definition under something already in the context *)

let get_new_id default env s =
  (* let get_ident_nums s1 s2 = *)
  (*   let re = Str.regexp ("^" ^ (Str.quote s1) ^ "\\([0-9]+\\)$") in *)
  (*   let matched = Str.string_match re s2 0 in *)
  (*   let i = if matched then int_of_string (Str.matched_group 1 s2) else -1 in *)
  (*     i *)
  (* in *)
  let identbase = match s with Some(s) -> s | None -> default in
  (* let identnums = List.map (get_ident_nums identbase) env in *)
  (* let maxn = List.fold_left max (-1) identnums in *)
  (* let ident = if maxn = -1 then identbase else identbase ^ (string_of_int (maxn + 1)) in *)
  let is_safe base = not (List.exists ((=) base) env) in
  let rec first_safe i base =
    let id = base ^ (string_of_int i) in (if is_safe id then id else first_safe (i+1) base)
  in
  let ident = if is_safe identbase then identbase else first_safe 0 identbase in
    ident

let conversions fenv metaenv ctxenv =

  let add_to_normenv (fenv, metaenv, ctxenv) elm = (elm :: fenv, metaenv, ctxenv) in
  let new_normenv ((fenv, metaenv, ctxenv) as env) elm = let id = get_new_id "x" fenv elm in (id, add_to_normenv env id) in

  let rec cst_of_ast ((fenv, metaenv, ctxenv) as env) (e : LAst.lterm) =
    match e with
	LAst.LSort(s) -> LSort(s)
      | LAst.LVar(LAst.LBVar i) -> LVar("b" ^ (string_of_int i))
      | LAst.LVar(LAst.LFVar i) -> LVar(try List.nth fenv i with _ -> "f!!" ^ (string_of_int i))
      | LAst.LVar(LAst.LNVar s) -> LVar(s)
      | LAst.LLambda(ss,_,t1,t2)  ->
	  (let s, env' = new_normenv env ss in
	   let t2' = BindLterm.open_up t2 in
	     LLambda(s, cst_of_ast env t1, cst_of_ast env' t2'))
      | LAst.LPi(ss,_,t1,t2) when BindLterm.has_bound_var 0 t2 ->
	  (let s, env' = new_normenv env ss in
	   let t2' = BindLterm.open_up t2 in
	     LPi(s, cst_of_ast env t1, cst_of_ast env' t2'))
      | LAst.LPi(ss,_,t1,t2) ->
	  (let env' = add_to_normenv env "" in
	   let t2' = BindLterm.open_up t2 in
	     LArrow(cst_of_ast env t1, cst_of_ast env' t2'))
      | LAst.LApp(t1,t2) ->
	  LApp(cst_of_ast env t1, cst_of_ast env t2)
      | LAst.LCtor(t,i) ->
	  LCtor(cst_of_ast env t, i)
      | LAst.LElim(t1,t2,tl) ->
	  LElim(cst_of_ast env t1, cst_of_ast env t2, List.map (cst_of_ast env) tl)
      | LAst.LInd(idef) ->
	  LInd(cst_of_inddef env idef)
      | LAst.LModal(mt,subst) ->
	  LModal(cst_of_modal env mt,List.map (cst_of_ast env) subst)
      | LAst.LTermList(ctxdesc) ->
	  LTermList(cst_of_ctxdesc env ctxdesc)

  and cst_of_inddef ((fenv, metaenv, ctxenv) as env) (e : LAst.linddef) =
    let LAst.LIndDef(ss, arity, constrlist) = e in
    let arityterm = Logic_core.arity_to_term arity in
    let s, env' = new_normenv env ss in
    let constr_conv constr = Logic_core.constr_to_term (LAst.LVar (LAst.LFVar 0)) (BindConstr.bumpup_fvar 1 constr) in
    let constrterms = List.map constr_conv constrlist in
      LIndDef(s, cst_of_ast env arityterm, List.map (cst_of_ast env') constrterms)

  and cst_of_modal ((fenv, metaenv, ctxenv) as env) (e : LAst.lmodalterm) =
      match e with
	  LAst.LTermInCtx(ctx, t) ->
	    (let ctx'', env' = cst_of_ctx env ctx in
	     let t' = BindLterm.open_up ~howmany:(List.length ctx) t in
	       LTermInCtx(ctx'', cst_of_ast env' t'))
	| LAst.LFMeta(i) -> LMeta("f" ^ (string_of_int i))
	| LAst.LBMeta(i) -> LMeta(try List.nth metaenv i with _ -> ("b!!" ^ (string_of_int i)))
	| LAst.LNMeta(s) -> LMeta(s)
		   
  and cst_of_ctx ((fenv, metaenv, ctxenv) as env) ?(openup=0) (ctx : (string option * LAst.lterm) list) =
    
    match ctx with
	[] -> ([], env)
      | (ss,tm) :: tl ->
	  (let tm' =  BindLterm.open_up ~howmany:openup tm in
	   let s, env' = new_normenv env ss in
	   let ctx', env'' = cst_of_ctx env' ~openup:(openup+1) tl in
	     ((s, cst_of_ast env tm') :: ctx', env''))
  
  and cst_of_ctxdesc ((fenv, metaenv, ctxenv) as env) (ctxdesc : LAst.lctxdesc) =
    
    match ctxdesc with
	LAst.LFCtx(i) -> LCtxVar("f" ^ (string_of_int i))
      | LAst.LBCtx(i) -> LCtxVar(try List.nth ctxenv i with _ -> ("b!!" ^ (string_of_int i)))
      | LAst.LCtxAsList(ctx) -> (let ctx', _ = cst_of_ctx env ctx in LCtxAsList(ctx'))

  in

    (cst_of_ast (fenv,metaenv,ctxenv),
     cst_of_modal (fenv,metaenv,ctxenv),
     cst_of_ctxdesc (fenv,metaenv,ctxenv))

let cst_of_ast ?(fenv=[]) ?(metaenv=[]) ?(ctxenv=[]) e = let (f,_,_) = conversions fenv metaenv ctxenv in f e
let cst_of_modal ?(fenv=[]) ?(metaenv=[]) ?(ctxenv=[]) e = let (_,f,_) = conversions fenv metaenv ctxenv in f e
let cst_of_ctxdesc ?(fenv=[]) ?(metaenv=[]) ?(ctxenv=[]) e = let (_,_,f) = conversions fenv metaenv ctxenv in f e
