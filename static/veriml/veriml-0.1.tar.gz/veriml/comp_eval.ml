open Utils
open Logic_ast
open Comp_ast
open Logic_core
open Logic_typing
open Comp_typing
open Comp_print
open Format

let open_up_2 ~case1:((_,var1) as s1) ~case2:((_,var2) as s2) =
  if var1 = var2 then open_up ~case:s1 ~howmany:2 else compose (open_up ~case:s1) (open_up ~case:s2)

let subst_bound_2 ~case1:((_,var1) as s1) ~case2:((_,var2) as s2) ~term:t ~subst1:e1 ~subst2:e2 =
  if var1 = var2 then
    (match var1 with
	 CType | CKind -> CbindCtermS.subst_bound_list [e1; e2] t
       | _ -> failwith "this shouldn't be possible")
  else
    subst_bound ~case:s2 ~subst:e2 ~term:(subst_bound ~case:s1 ~subst:e1 ~term:t)

let normalize_ctx e = 
  (nowarn let LCtxAsList(ctx) = e in
   let norm_ctx = List.map (fun (a,b) -> (a,lterm_map ~lmodal:(fun _ _ mt1 subst -> modal_apply_subst mt1 subst) b)) ctx in
     LCtxAsList(norm_ctx))

let normalize_modal t =
  (nowarn let LTermInCtx(ctx,tm) = t in
   let norm_tm = lterm_map ~lmodal:(fun _ _ mt1 subst -> modal_apply_subst mt1 subst) tm in
   nowarn let LCtxAsList(norm_ctx) = normalize_ctx (LCtxAsList(ctx)) in 
     LTermInCtx(norm_ctx, norm_tm))

let eval defenv cdefenv e =
  let rec eval e = 
    match e with
	
	CApp(e1,e2) ->
	  (nowarn let CLambda(var, _, body) = eval e1 in
	   let e'' = subst_bound ~case:var ~term:body ~subst:(eval e2) in
	     eval e'')
	    
      | CPack(e1,nam,typ,e2) ->
	  CPack(eval e1, nam, typ, eval e2)
	    
      | CUnpack(e, nam1, nam2, e') ->
	  (nowarn let CPack(e1,_,_,e2) = eval e in
	   let e'' = subst_bound_2 ~case1:nam1 ~case2:nam2 ~term:e' ~subst1:e1 ~subst2:e2 in
	     eval e'')

      | CHolCase(t,nam,ret,branches) ->
	  (let rec find_branch ctx tm branches =
	     match branches with
		 [] -> failwith "non-covering HOL case"
	       | (metas, pat, e) :: tail ->
		   (try
		      nowarn let CHolTerm(LTermInCtx(_,pat)) = pat in
		      let subst = pattern_match_term defenv ~ctx:ctx ~check:false (List.length metas) pat tm in
			MetabindCtermS.subst_bound_list subst e
		    with NoPatternMatch ->
		      find_branch ctx tm tail)
	   in
	     nowarn let CHolTerm(LTermInCtx(ctx,tm)) = eval t in
	     let e' = find_branch ctx tm branches in
	       eval e')

      | CAny(l) ->
	  (match !l with
	       None -> failwith "non-unified wildcard found during evaluation"
	     | Some t -> eval t)

      | CNVar(n) when n = "bot" ->
	  failwith "error!!!"

      | CNVar(n) ->
	  let e' = get_cdef_term n cdefenv in 
	    eval e'

      | CHolTerm(t) ->
	  (CHolTerm(normalize_modal t))

      | CCtxTerm(t) ->
	  (CCtxTerm(normalize_ctx t))

      | CTuple(e1,e2) ->
	  CTuple(eval e1, eval e2)

      | CProj(i,e) ->
	  (nowarn let CTuple(e1,e2) = eval e in
	     if i = 1 then eval e1 else eval e2)

      | CFold(e,t) ->
	  (CFold(eval e, t))

      | CUnfold(e) ->
	  (nowarn let CFold(v,t) = eval e in
	     v)

      | CCtor(i,t,e) ->
	  CCtor(i,t,eval e)

      | CMatch(e,branches) ->
	  (nowarn let CCtor(i,_,param) = eval e in
	   let (_,body) = List.nth branches i in
	   let e' = CbindCtermS.subst_bound param body in
	     eval e')

      | CLet(v,d,e) ->
	  (let d' = eval d in
	   let e' = subst_bound ~case:v ~subst:d' ~term:e in
	     eval e')

      | CLetRec(defs,e) ->
	  (let subst_from_def (_,_,ei) = CLetRec(defs,ei) in
	   let substlist = List.map subst_from_def defs in
	   let e' = CbindCtermS.subst_bound_list substlist e in
	     eval e')
	    
      | CMkRef(e,t) ->
	  let e' = eval e in
	  CLoc(ref e', t)

      | CAssign(e1,e2) ->
	  (nowarn let CLoc(l,_) = eval e1 in
	   let e2' = eval e2 in
	     l := e2'; CUnitExpr)

      | CReadRef(e) ->
	  (nowarn let CLoc(l,_) = eval e in
	     !l)

      | CSeq(e1,e2) ->
	  (let _ = eval e1 in
	     eval e2)

      | CArrayLit(es,t) ->
	  (let es' = List.map eval es in
	     CArrayLoc(Array.of_list es',t))

      | CMkArray(e1,e2,t) ->
	  (nowarn let CIntConst(i) = eval e1 in
	   let v = eval e2 in
	     CArrayLoc(Array.make i v,t))

      | CArrayGet(e1,e2) ->
	  (nowarn let CArrayLoc(ar,_) = eval e1 in
	   nowarn let CIntConst(i) = eval e2 in
	     ar.(i))

      | CArraySet(e1,e2,e3) ->
	  (nowarn let CArrayLoc(ar,_) = eval e1 in
	   nowarn let CIntConst(i) = eval e2 in
	   let v = eval e3 in
	     ar.(i) <- v; CUnitExpr)

      | CArrayLen(e) ->
	  (nowarn let CArrayLoc(ar,_) = eval e in
	     CIntConst(Array.length ar))

      | CIntOp(op,e1,e2) ->
	  (nowarn let CIntConst(i1) = eval e1 in
	   nowarn let CIntConst(i2) = eval e2 in
	     match op with
		 Plus -> CIntConst(i1+i2)
	       | Minus -> CIntConst(i1-i2)
	       | Times -> CIntConst(i1*i2)
	       | Mod -> CIntConst(i1 mod i2))

      | CIntTest(op,e1,e2) ->
	  (nowarn let CIntConst(i1) = eval e1 in
	   nowarn let CIntConst(i2) = eval e2 in
	     match op with
		 LT -> CBoolConst(i1 < i2)
	       | LE -> CBoolConst(i1 <= i2)
	       | GT -> CBoolConst(i1 > i2)
	       | GE -> CBoolConst(i1 >= i2)
	       | EQ -> CBoolConst(i1 = i2))
	    
      | CBoolOp(op,e1,e2) ->
	  (nowarn let CBoolConst(i1) = eval e1 in
	   nowarn let CBoolConst(i2) = eval e2 in
	     match op with
		 BAnd -> CBoolConst(i1 && i2)
	       | BOr -> CBoolConst(i1 || i2))

      | CIfThenElse(e1,e2,e3) ->
	  (nowarn let CBoolConst(b) = eval e1 in
	     if b then eval e2 else eval e3)

      | CHolHash(e) ->
	  (let v = eval e in
	   let v' = cterm_map ~cholterm:(fun t -> CHolTerm(fullnf_modal defenv t))
	                      ~cctxterm:(fun t -> CCtxTerm(fullnf_ctx defenv t)) v in
	     CIntConst(Hashtbl.hash_param 100 200 v'))

      | CPrint(e) ->
	  (let v = eval e in
	     fprintf std_formatter "%a@\n" pr_cterm v;
	     CUnitExpr)
	    
      | t -> t
  in
    eval e

let eval_fast defenv cdefenv e =
  let add_to_subst ~case:k =
    case_kind ~case:k
      (function CHolTerm(what) -> fun (metasubst,ctxsubst,compsubst) -> what::metasubst,ctxsubst,compsubst | _ -> failwith "add_to_subst")
      (function CCtxTerm(what) -> fun (metasubst,ctxsubst,compsubst) -> metasubst,what::ctxsubst,compsubst | _ -> failwith "add_to_subst")
      (function what ->           fun (metasubst,ctxsubst,compsubst) -> metasubst,ctxsubst,what::compsubst)
  in
  let closedown_meta_ctx (metasubst,ctxsubst,_) what =
    flatten_all_cterm
      (MetabindCtermS.subst_bound_list (List.rev metasubst)
	 (CtxbindCtermS.subst_bound_list (List.rev ctxsubst)
	    what))
  in
  let rec eval ((metasubst,ctxsubst,compsubst) as subst) e = 
    (* fprintf std_formatter "%a@\n@\n" pr_cterm e; *)
    match e with
	
	CApp(e1,e2) ->
	  (nowarn let CClosure(subst', CLambda(var, _, body)) = eval subst e1 in
	   let e2' = eval subst e2 in
	     eval (add_to_subst ~case:var e2' subst') body)
	    
      | CPack(e1,nam,typ,e2) ->
	  CPack(eval subst e1, nam, eval subst typ, eval subst e2)
	    
      | CUnpack(e, nam1, nam2, e') ->
	  (nowarn let CPack(e1,_,_,e2) = eval subst e in
	   let subst' = add_to_subst ~case:nam2 e2 (add_to_subst ~case:nam1 e1 subst) in
	     eval subst' e')

      | CHolCase(t,nam,ret,branches) ->
	  (let rec find_branch ctx tm branches =
	     match branches with
		 [] -> failwith "non-covering HOL case"
	       | (metas, pat, e) :: tail ->
		   (try
		      let n = List.length metas in
		      let subst' = List.append (List.map (fun i -> LBMeta i) (increasing n)) metasubst, ctxsubst, compsubst in
		      nowarn let CHolTerm(LTermInCtx(_,pat)) = closedown_meta_ctx subst' pat in
		      let subst_metas = pattern_match_term defenv ~ctx:ctx ~check:true n pat tm in
		      let subst'' = List.append (List.rev subst_metas) metasubst, ctxsubst, compsubst in
			eval subst'' e
		    with NoPatternMatch ->
		      find_branch ctx tm tail)
	   in
	     nowarn let CHolTerm(LTermInCtx(ctx,tm)) = eval subst t in
	       find_branch ctx tm branches)

      | CAny(l) ->
	  (match !l with
	       None -> failwith "non-unified wildcard found during evaluation"
	     | Some t -> eval subst t)

      | CNVar(n) when n = "bot" ->
	  failwith "error!!!"

      | CNVar(n) ->
	  let e' = get_cdef_term n cdefenv in 
	    eval subst e'

      | CBVar(i) ->
	  eval subst (List.nth compsubst i)

      | CHolTerm(t) ->
	  (nowarn let CHolTerm(t) = closedown_meta_ctx subst e in
	     CHolTerm(normalize_modal t))

      | CCtxTerm(t) ->
	  (nowarn let CCtxTerm(t) = closedown_meta_ctx subst e in
	     CCtxTerm(normalize_ctx t))

      | CLambda(var,t1,e) ->
	  CClosure(subst, CLambda(var,t1,e))

      | CTuple(e1,e2) ->
	  CTuple(eval subst e1, eval subst e2)

      | CProj(i,e) ->
	  (nowarn let CTuple(e1,e2) = eval subst e in
	     if i = 1 then eval subst e1 else eval subst e2)

      | CFold(e,t) ->
	  CFold(eval subst e, eval subst t)

      | CUnfold(e) ->
	  (nowarn let CFold(v,_) = eval subst e in
	     v)

      | CCtor(i,t,e) ->
	  CCtor(i,eval subst t,eval subst e)

      | CMatch(e,branches) ->
	  (nowarn let CCtor(i,_,param) = eval subst e in
	   let (v,body) = List.nth branches i in
	     eval (add_to_subst ~case:v param subst) body)

      | CLet(v,d,e) ->
	  (let d' = eval subst d in
	     eval (add_to_subst ~case:v d' subst) e)

      | CLetRec(defs,e) ->
	  (let refs = List.map (fun (_,t,_) -> ref (CSort CType), t) (List.rev defs) in
	   let compadd = List.map (fun (r,t) -> CReadRef(CLoc(r,t))) refs in
	   let subst'  = (metasubst,ctxsubst,List.append compadd compsubst) in
	   let defseval = List.map (function (_,_,e) -> eval subst' e) (List.rev defs) in
	   let _ = List.iter2 (fun (l,_) what -> l := what) refs defseval in
	     eval subst' e)

      | CMkRef(e,t) ->
	  let e' = eval subst e in
	  CLoc(ref (e'), t)

      | CAssign(e1,e2) ->
	  (nowarn let CLoc(l,_) = eval subst e1 in
	   let e2' = eval subst e2 in
	     l := e2'; CUnitExpr)

      | CReadRef(e) ->
	  (nowarn let CLoc(l,_) = eval subst e in
	     !l)

      | CSeq(e1,e2) ->
	  (let _ = eval subst e1 in
	     eval subst e2)

      | CArrayLit(es,t) ->
	  (let es' = List.map (eval subst) es in
	     CArrayLoc(Array.of_list es',t))

      | CMkArray(e1,e2,t) ->
	  (nowarn let CIntConst(i) = eval subst e1 in
	   let v = eval subst e2 in
	   let t' = eval subst t in
	     CArrayLoc(Array.make i v,t'))

      | CArrayGet(e1,e2) ->
	  (nowarn let CArrayLoc(ar,_) = eval subst e1 in
	   nowarn let CIntConst(i) = eval subst e2 in
	     ar.(i))

      | CArraySet(e1,e2,e3) ->
	  (nowarn let CArrayLoc(ar,_) = eval subst e1 in
	   nowarn let CIntConst(i) = eval subst e2 in
	   let v = eval subst e3 in
	     ar.(i) <- v; CUnitExpr)

      | CArrayLen(e) ->
	  (nowarn let CArrayLoc(ar,_) = eval subst e in
	     CIntConst(Array.length ar))


      | CIntOp(op,e1,e2) ->
	  (nowarn let CIntConst(i1) = eval subst e1 in
	   nowarn let CIntConst(i2) = eval subst e2 in
	     match op with
		 Plus -> CIntConst(i1+i2)
	       | Minus -> CIntConst(i1-i2)
	       | Times -> CIntConst(i1*i2)
	       | Mod -> CIntConst(i1 mod i2))

      | CIntTest(op,e1,e2) ->
	  (nowarn let CIntConst(i1) = eval subst e1 in
	   nowarn let CIntConst(i2) = eval subst e2 in
	     match op with
		 LT -> CBoolConst(i1 < i2)
	       | LE -> CBoolConst(i1 <= i2)
	       | GT -> CBoolConst(i1 > i2)
	       | GE -> CBoolConst(i1 >= i2)
	       | EQ -> CBoolConst(i1 = i2))
	    
      | CBoolOp(op,e1,e2) ->
	  (nowarn let CBoolConst(i1) = eval subst e1 in
	   nowarn let CBoolConst(i2) = eval subst e2 in
	     match op with
		 BAnd -> CBoolConst(i1 && i2)
	       | BOr -> CBoolConst(i1 || i2))

      | CIfThenElse(e1,e2,e3) ->
	  (nowarn let CBoolConst(b) = eval subst e1 in
	     if b then eval subst e2 else eval subst e3)

      | CHolHash(e) ->
	  (let v = eval subst e in
	   let v' = cterm_map ~cholterm:(fun t -> CHolTerm(fullnf_modal defenv t))
	                      ~cctxterm:(fun t -> CCtxTerm(fullnf_ctx defenv t)) v in
	     CIntConst(Hashtbl.hash_param 100 200 v'))

      | CPrint(e) ->
	  (let v = eval subst e in
	     fprintf std_formatter "%a@\n" pr_cterm v;
	     CUnitExpr)

      | t -> t
	    
  in
    eval ([],[],[]) e


let comp_print_eval e =
  let t = comp_gettype e in
  let v = eval !Logic_main.logic_global_env !comp_global_env e in
  let t' = comp_gettype v in
    (if ctype_equal !Logic_main.logic_global_env !comp_global_env t t' then
       fprintf std_formatter "%a@ -->@ %a@\n" pr_cterm e pr_cterm v
     else
       fprintf std_formatter "%s@\n%a@ :@ %a@ -->@ %a@ :@ %a" "WARNING TYPE UNSAFETY!!" pr_cterm e pr_cterm t pr_cterm v pr_cterm t')

let comp_print_eval_fast e =
  (* let t = comp_gettype e in *)
  let v = eval_fast !Logic_main.logic_global_env !comp_global_env e in
    fprintf std_formatter "%a@ -->@ %a@\n" pr_cterm e pr_cterm v

let comp_eval_safe defenv cdefenv e =
  let t = comp_gettype e in
  let v = eval !Logic_main.logic_global_env !comp_global_env e in
  let t' = comp_gettype v in
    (if ctype_equal defenv cdefenv t t' then
       v
     else
       failwith "TYPE UNSAFETY IN EVALUATOR!!!")

let comp_eval_fast defenv cdefenv e =
  let t = comp_gettype e in
  let v = eval_fast !Logic_main.logic_global_env !comp_global_env e in
  let t' = comp_gettype v in
    (if ctype_equal defenv cdefenv t t' then
       v
     else
       failwith "TYPE UNSAFETY IN EVALUATOR!!!")
	
let comp_define name tm =
  let tm' = comp_eval_fast !Logic_main.logic_global_env !comp_global_env tm in
  comp_global_env := cterm_def_add name tm' !Logic_main.logic_global_env !comp_global_env

let comp_define_typed name tm tp =
  let tm' = comp_eval_fast !Logic_main.logic_global_env !comp_global_env tm in
  comp_global_env := cterm_def_add name tm' ~expected_tp:(Some tp) !Logic_main.logic_global_env !comp_global_env
