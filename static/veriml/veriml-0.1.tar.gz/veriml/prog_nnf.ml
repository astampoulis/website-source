open Syntax_logic;;
open Syntax_comp;;
open Prog_basis;;

<<

(* Hash for props *)
let STANDARD_HASH_SIZE = 20

(* Hash implementation *)

let prophash = fun #phi : ctx => fun res : ([#phi].Prop) -> CType =>
              array (option (< ?key : [#phi].Prop > res ?key))

let mkhash = fun #phi : ctx => fun res : (([#phi].Prop) -> CType) => fun i : int =>
             mkarray( i, (none (< ?key : [#phi].Prop > res ?key)), option (< ?key : [#phi].Prop > res ?key)) 

let hashget = fun #phi : ctx => fun res : ([#phi].Prop) -> CType => fun h : prophash #[#phi] res =>
              fun ?n : [#phi].Prop =>
              let hn = arraylen h in
              letrec find : {?n : [#phi].Prop} (int -> (option (res ?n))) =
		fun ?n : [#phi].Prop => fun i : int => 
		  match h.(i) with
		      som |-> unpack < ?n', result > = som in
                              (holcase ?n as ?n return option (res ?n) with
				  ().[s:#phi].?n'/[s] |-> some (res ?n') result
				| ( ?n : [#phi].Prop ).[s:#phi].?n/[s] |-> find ?n ((i iplus 1) imod hn))
                    | non |-> none (res ?n)
              in
                find ?n ((hash <| ?n |>) imod hn)

let hashget_uns = fun #phi : ctx => fun res : ([#phi].Prop) -> CType => fun h : prophash #[#phi] res =>
              fun ?n : [#phi].Prop =>
              match hashget #[#phi] res h ?n with
		  som |-> som
		| non |-> bot (res ?n)

let hashset = fun #phi : ctx => fun res : ([#phi].Prop) -> CType => fun h : prophash #[#phi] res =>
              fun ?n : [#phi].Prop => fun r : res ?n =>
              let hn = arraylen h in
              letrec find : (int -> Unit) =
		fun i : int => 
		  match h.(i) with
		      som |-> unpack < ?n', result > = som in
                              (holcase ?n' as ?n' return Unit with
				  ().[s:#phi].?n/[s] |-> h.(i) <- (some (< ?key : [#phi].Prop > res ?key) (pack ?n as ?n return res ?n with r))
				| ( ?n : [#phi].Prop ).[s:#phi].?n/[s] |-> find ((i iplus 1) imod hn))
                    | non |-> h.(i) <- (some (< ?key : [#phi].Prop > res ?key) (pack ?n as ?n return res ?n with r))
              in
                find ((hash <| ?n |>) imod hn)

(* Set implementation *)

let propset = fun #phi : ctx => (prophash #[#phi] (fun ?n : [#phi].Prop => Unit)) * (list hol([#phi].Prop))
let mkset = fun #phi : ctx => fun i : int => tup( mkhash #[#phi] (fun ?n : [#phi].Prop => Unit) i,
						  nil hol([#phi].Prop) )

let setmem = fun #phi : ctx => fun s : propset #[#phi] => fun ?P : [#phi].Prop =>
             (match hashget #[#phi] (fun ?n : [#phi].Prop => Unit) (fst s) ?P with
		  som |-> true
		| none |-> false)
let setadd = fun #phi : ctx => fun s : propset #[#phi] => fun ?n : [#phi].Prop =>
             (match hashget #[#phi] (fun ?n : [#phi].Prop => Unit) (fst s) ?n with
		  som |-> s
		| non |-> ((hashset #[#phi] (fun ?n : [#phi].Prop => Unit) (fst s) ?n unit);
		           tup(fst s, cons hol([#phi].Prop) <| ?n |> (snd s))))
let setfold = fun a : CType => fun #phi : ctx =>  
              fun f : {?n : [#phi].Prop}(a -> a) => fun start : a => fun s : propset #[#phi] =>
              listfold (hol([#phi].Prop)) a
	      (fun st : a => fun n : hol([#phi].Prop) =>
		  unpack < ?n, unused > = n in
		  f ?n st)
	      start
	      (snd s)

let setiter = fun #phi : ctx =>
              fun f : ([#phi].Prop) -> Unit =>
              fun s : propset #[#phi] =>
              setfold Unit #[#phi] (fun ?n : [#phi].Prop => fun unused : Unit => f ?n) unit s

let setunion = fun #phi : ctx => fun s1 : propset #[#phi] => fun s2 : propset #[#phi] =>
               setfold (propset #[#phi]) #[#phi]
	       (fun ?n : [#phi].Prop => fun s : propset #[#phi] => setadd #[#phi] s ?n)
	       s1
	       s2



(* Hypotheses-list types *)

let hyptype = fun #phi : ctx => < ?P0 : [#phi].Prop >hol( [s:#phi].?P0/[s] )
let hyplist = fun #phi : ctx => list (hyptype #[#phi])
let hypnil  = fun #phi : ctx => nil (hyptype #[#phi])
let hypcons = fun #phi : ctx => cons (hyptype #[#phi])
let hypweaken : { #phi : ctx, ?x : [#phi].Set } hyptype #[#phi] -> hyptype #[s : #phi, y : ?x/[s]] =
  fun #phi : ctx, ?x : [#phi].Set, H : hyptype #[#phi] =>
  unpack < ?P0, ?prf, unused > = H in
  pack [s : #phi, y : ?x/[s]].?P0/[s] as ?P0' return hol( [s:#phi, y : ?x/[s]].?P0'/[s,y]) with
      <| [s : #phi, y : ?x/[s]].?prf/[s] |>
typeof hypweaken.

let hypweakenprop : { #phi : ctx, ?x : [#phi].Prop } hyptype #[#phi] -> hyptype #[s : #phi, y : ?x/[s]] =
  fun #phi : ctx, ?x : [#phi].Prop, H : hyptype #[#phi] =>
  unpack < ?P0, ?prf, unused > = H in
  pack [s : #phi, y : ?x/[s]].?P0/[s] as ?P0' return hol( [s:#phi, y : ?x/[s]].?P0'/[s,y]) with
      <| [s : #phi, y : ?x/[s]].?prf/[s] |>

let hyplistweaken : { #phi : ctx, ?x : [#phi].Set } hyplist #[#phi] -> hyplist #[s : #phi, y : ?x/[s]] =
  fun #phi : ctx, ?x : [#phi].Set, l : hyplist #[#phi] =>
  listmap (hyptype #[#phi]) (hyptype #[s : #phi, y : ?x/[s]]) (hypweaken #[#phi] ?x) l
typeof hyplistweaken.

let hyplistweakenprop : { #phi : ctx, ?x : [#phi].Prop } hyplist #[#phi] -> hyplist #[s : #phi, y : ?x/[s]] =
  fun #phi : ctx, ?x : [#phi].Prop, l : hyplist #[#phi] =>
  listmap (hyptype #[#phi]) (hyptype #[s : #phi, y : ?x/[s]]) (hypweakenprop #[#phi] ?x) l
typeof hyplistweakenprop.

let hyplistconsprf =
  fun #phi : ctx, ?x : [#phi].Prop, l : hyplist #[#phi] =>
  hypcons #[s : #phi, y : ?x/[s]] (pack [s : #phi, y : ?x/[s]].?x/[s] as ?x' return hol([s : #phi, y : ?x/[s]].?x'/[s,y]) with <| [s : #phi, y : ?x/[s]].y |>) (hyplistweakenprop #[#phi] (?x) l)
		    
  
(* A simple tauto-like tactic. Keeps a list of hypotheses, and a set of visited goals (in order
   to avoid loops). *)

let autoprove =
  letrec maybeprove_visited :
    { #phi : ctx, ?P : [#phi].Prop } hyplist #[#phi] -> propset #[#phi] -> option (hol([s : #phi].?P/[s])) =
    fun #phi : ctx => fun ?P : [#phi].Prop => fun hyps : hyplist #[#phi] => fun visited : propset #[#phi] =>
    if setmem #[#phi] visited ?P then
      none (hol([s:#phi].?P/[s]))
    else
    holcase ?P as ?P return option (hol([s : #phi].?P/[s])) with
	(?A : [#phi].Set, ?P' : [s : #phi, x : ?A/[s]].Prop).[s:#phi].(forall x : ?A/[s], ?P'/[s,x]) |->
          do return (hol([s : #phi].forall x : ?A/[s], ?P'/[s,x])) {
	    prf <-  maybeprove #[s : #phi, x : ?A/[s]]
	             ?P'
	             (hyplistweaken #[#phi] ([s : #phi].?A/[s]) hyps) ;;
	    return (
	      unpack < ?prf, unused > = prf in
              <| [s : #phi].fun x : ?A/[s] => ?prf/[s,x] |>
	    )
	  }

      | (?P1 : [#phi].Prop, ?P2 : [#phi].Prop).[s:#phi].(?P1/[s] -> ?P2/[s]) |->
          maybeprove_with_hyp #[#phi] ?P1 ?P2 hyps

      | (?P1 : [#phi].Prop, ?P2 : [#phi].Prop).[s:#phi].(and ?P1/[s] ?P2/[s]) |->
          do return (hol([s : #phi].and ?P1/[s] ?P2/[s])) {
	    prf1 <- maybeprove_visited #[#phi] ?P1 hyps visited ;;
	    prf2 <- maybeprove_visited #[#phi] ?P2 hyps visited ;;
	    return (
	      unpack < ?prf1, unused > = prf1 in
              unpack < ?prf2, unused > = prf2 in
              <| [s:#phi].conj ?P1/[s] ?P2/[s] ?prf1/[s] ?prf2/[s] |>
	   )
	  }

      | (?P1 : [#phi].Prop, ?P2 : [#phi].Prop).[s:#phi].(or ?P1/[s] ?P2/[s]) |->

	  (let prf1 = maybeprove_visited #[#phi] ?P1 hyps visited in
	   let prf2 = maybeprove_visited #[#phi] ?P2 hyps visited in
	   match prf1 with
	       som |-> (unpack < ?prf1, unused > = som in
		        some (hol([s : #phi].or ?P1/[s] ?P2/[s])) <| [s:#phi].injl ?P1/[s] ?P2/[s] ?prf1/[s] |>)
	     | non |-> (match prf2 with
			    som |-> (unpack < ?prf2, unused > = som in
		              some (hol([s : #phi].or ?P1/[s] ?P2/[s])) <| [s:#phi].injr ?P1/[s] ?P2/[s] ?prf2/[s] |>)
			  | non |-> none (hol([s:#phi].or ?P1/[s] ?P2/[s]))))

      | ().[s : #phi].True |->
	   some (hol([s : #phi].True)) <| [s : #phi].triv |>

      | (?P : [#phi].Prop). [s:#phi].(?P/[s]) |->
	  (let res = findhyp #[#phi] hyps (setadd #[#phi] visited ?P) ?P in
	   match res with
	       som |-> res
	     | non |-> (match findhyp #[#phi] hyps (setadd #[#phi] visited ?P) [#phi].False with
	  	         som |-> unpack < ?fals, u > = som in
	                         some (hol([s:#phi].?P/[s])) <| [s:#phi].Elim(?P/[s], ?fals/[s]) { } |>
                        | non |-> res))
	  (* findhyp #[#phi] hyps ?P *)

  andrec maybeprove : 
    { #phi : ctx, ?P : [#phi].Prop } hyplist #[#phi] -> option (hol([s : #phi].?P/[s])) =
    fun #phi : ctx => fun ?P : [#phi].Prop => fun hyps : hyplist #[#phi] =>
    maybeprove_visited #[#phi] ?P hyps (mkset #[#phi] STANDARD_HASH_SIZE)

  andrec maybeprove_with_hyp :

    { #phi : ctx, ?H : [#phi].Prop, ?G : [#phi].Prop } hyplist #[#phi] -> option (hol([s:#phi].?H/[s] -> ?G/[s])) =
    fun #phi : ctx, ?H : [#phi].Prop, ?G : [#phi].Prop, l : hyplist #[#phi] =>
    holcase ?H as ?H return option(hol([s:#phi].?H/[s] -> ?G/[s])) with

      (?P1 : [#phi].Prop, ?P2 : [#phi].Prop).[s:#phi].(and ?P1/[s] ?P2/[s]) |->
	(let l' = hyplistconsprf #[#phi] ([s : #phi].?P1/[s]) l in
	 let l'' = hyplistconsprf #[s : #phi, x : ?P1/[s]] ([s : #phi, x : ?P1/[s]].?P2/[s]) l' in
	 do return (hol([s:#phi].and ?P1/[s] ?P2/[s] -> ?G/[s])) {
	   prfG <- maybeprove #[s : #phi, pf1 : ?P1/[s], pf2 : ?P2/[s]] ([s : #phi, pf1 : ?P1/[s], pf2 : ?P2/[s]].?G/[s]) l'' ;;
	   return (
	     unpack < ?prfG, u > = prfG in
             <| [s : #phi].fun pf : and ?P1/[s] ?P2/[s] => ?prfG/[s, andProj1 ?P1/[s] ?P2/[s] pf, andProj2 ?P1/[s] ?P2/[s] pf] |>)
	 })

      | (?P1 : [#phi].Prop, ?P2 : [#phi].Prop).[s:#phi].(or ?P1/[s] ?P2/[s]) |->
	(let l1 = hyplistconsprf #[#phi] ([s : #phi].?P1/[s]) l in
	 let l2 = hyplistconsprf #[#phi] ([s : #phi].?P2/[s]) l in
	 do return (hol([s:#phi].or ?P1/[s] ?P2/[s] -> ?G/[s])) {
	   prf1 <- maybeprove #[s : #phi, pf1 : ?P1/[s]] ([s : #phi, pf1 : ?P1/[s]].?G/[s]) l1 ;;
	   prf2 <- maybeprove #[s : #phi, pf2 : ?P2/[s]] ([s : #phi, pf2 : ?P2/[s]].?G/[s]) l2 ;;
	   return (
	     unpack < ?prf1, u > = prf1 in
	     unpack < ?prf2, u > = prf2 in
             <| [s : #phi].
	       fun pf : or ?P1/[s] ?P2/[s] =>
		 Elim(?G/[s], pf) {
		   fun a : ?P1/[s] => ?prf1/[s,a] 
		   | fun a : ?P2/[s] => ?prf2/[s,a] } |>)
	 })

      | (?H : [#phi].Prop).[s:#phi].?H/[s] |->
	  (let l' = hyplistconsprf #[#phi] ([s:#phi].?H/[s]) l in
	   do return (hol([s:#phi].?H/[s] -> ?G/[s])) {
	     pf <- maybeprove #[s : #phi, pfH : ?H/[s]] ([s:#phi, pfH : ?H/[s]].?G/[s]) l' ;;
	     return (
	       unpack < ?pf, u > = pf in
	       <| [s:#phi].fun pfh : ?H/[s] => ?pf/[s, pfh] |>)
	   })

  andrec autoprove :
    { #phi : ctx, ?P : [#phi].Prop } hyplist #[#phi] -> hol([s : #phi].?P/[s]) =
    fun #phi : ctx, ?P : [#phi].Prop, l : hyplist #[#phi] =>
    match maybeprove #[#phi] ?P l with
	som |-> som
      | non |-> bot (hol([s : #phi].?P/[s]))

  andrec findhyp :
    { #phi : ctx, l : hyplist #[#phi], visited : propset #[#phi], ?P : [#phi].Prop }option (hol([s:#phi].?P/[s])) =
    fun #phi : ctx, l : hyplist #[#phi], visited : propset #[#phi], ?P : [#phi].Prop =>

    listfold
    (hyptype #[#phi])
    (option (hol([s:#phi].?P/[s])))
    (fun s : option (hol([s:#phi].?P/[s])) => fun e : hyptype #[#phi] =>
	match s with
	    som |-> s
	  | non |-> unpack < ?P0, pf0 > = e in
                    (holcase ?P0 as ?P0 return { pf0 : hol([s:#phi].?P0/[s]) } option (hol([s:#phi].?P/[s])) with
			 ().[s:#phi].?P/[s] |-> (fun pf0 : hol([s:#phi].?P/[s]) => some (hol([s:#phi].?P/[s])) pf0)
		       | (?H : [#phi].Prop).[s:#phi].?H/[s] -> ?P/[s] |->
			   (fun pf0 : hol([s:#phi].?H/[s] -> ?P/[s]) =>
   			    match maybeprove_visited #[#phi] ?H l visited with
				som |-> unpack < ?pf, u > = som in
		                        unpack < ?pf0, u > = pf0 in
		                        some (hol([s:#phi].?P/[s])) <| [s:#phi].?pf0/[s] ?pf/[s] |>
                              | non |-> none (hol([s:#phi].?P/[s])))

		       | (?H1 : [#phi].Prop, ?H2 : [#phi].Prop).[s:#phi].?H1/[s] -> ?H2/[s] -> ?P/[s] |->
			   (fun pf0 : hol([s:#phi].?H1/[s] -> ?H2/[s] -> ?P/[s]) =>
   			    match maybeprove_visited #[#phi] ([s:#phi].and ?H1/[s] ?H2/[s]) l visited with
				som |-> unpack < ?pf, u > = som in
		                        unpack < ?pf0, u > = pf0 in
		                        some (hol([s:#phi].?P/[s])) <| [s:#phi].?pf0/[s] (andProj1 ?H1/[s] ?H2/[s] ?pf/[s]) (andProj2 ?H1/[s] ?H2/[s] ?pf/[s]) |>
                              | non |-> none (hol([s:#phi].?P/[s])))

		       | (?P' : [#phi].Prop).[s:#phi].?P'/[s] |->
			   fun pf0 : hol([s:#phi].?P'/[s]) => none (hol([s:#phi].?P/[s])))
		      pf0
    )
    (none (hol([s:#phi].?P/[s])))
    l
  in
  fun #phi : ctx => fun ?P : [#phi].Prop => 
      let res = autoprove #[#phi] ?P (hypnil #[#phi]) in (* (print res); *) res


(* Conversion to NNF form: from a proposition P to a proposition P' such that 
   P' only uses negation in front of (what are deemed to be) propositional atoms.
   Uses the above tactic in order to prove the theorems needed so that we return a proof of 
   P' -> P; thus if we create a proof object for P' we will be able to construct a proof
   object for P. *)

let nnf =
 
  unpack < ?prf_nnp, u > = autoprove #[P : Prop, P' : Prop] ([P : Prop, P' : Prop].(P' -> P) -> (P' -> not (not P))) in
  unpack < ?prf_p1_and_p2, u > = autoprove #[P1 : Prop, P2 : Prop, P1' : Prop, P2' : Prop]
                                           ([P1 : Prop, P2 : Prop, P1' : Prop, P2' : Prop].(P1' -> not P1) -> (P2' -> not P2) -> (or P1' P2' -> not (and P1 P2))) in
  unpack < ?prf_p1_or_p2, u >  = autoprove #[P1 : Prop, P2 : Prop, P1' : Prop, P2' : Prop]
                                           ([P1 : Prop, P2 : Prop, P1' : Prop, P2' : Prop].(P1' -> not P1) -> (P2' -> not P2) -> (and P1' P2' -> not (or P1 P2))) in
  unpack < ?prf_p1_imp_p2, u > = autoprove #[P1 : Prop, P2 : Prop, P1' : Prop, P2' : Prop]
                                           ([P1 : Prop, P2 : Prop, P1' : Prop, P2' : Prop].(P1' -> not P1) -> (P2' -> P2) -> (or P1' P2' -> P1 -> P2)) in
  unpack < ?prf_np1_imp_p2, u > = autoprove #[P1 : Prop, P2 : Prop, P1' : Prop, P2' : Prop]
                                           ([P1 : Prop, P2 : Prop, P1' : Prop, P2' : Prop].(P1' -> P1) -> (P2' -> not P2) -> (and P1' P2' -> not (P1 -> P2))) in


  fun #phi : ctx =>
  letrec nnf : { ?P : [#phi].Prop } < ?P' : [#phi].Prop > hol( [s:#phi].?P'/[s] -> ?P/[s]) =
    fun ?P : [#phi].Prop =>
    holcase ?P as ?P return < ?P' : [#phi].Prop > hol( [s:#phi].?P'/[s] -> ?P/[s]) with
	(?P0 : [#phi].Prop).[s:#phi].((?P0/[s] -> False) -> False) |->
	  unpack < ?P0', ?pf0, unused > = nnf ?P0 in
	  pack ?P0' as ?P0' return hol( [s:#phi].?P0'/[s] -> ((?P0/[s] -> False) -> False) ) with
	      <| [s:#phi].?prf_nnp/[?P0/[s], ?P0'/[s]] ?pf0/[s] |>

      | (?P1 : [#phi].Prop, ?P2 : [#phi].Prop).[s:#phi].((and ?P1/[s] ?P2/[s]) -> False) |->
	  unpack < ?nP1, ?pf1, unused > = nnf ([s:#phi].not ?P1/[s]) in
          unpack < ?nP2, ?pf2, unused > = nnf ([s:#phi].not ?P2/[s]) in
          pack ([s:#phi].or ?nP1/[s] ?nP2/[s]) as ?P' return hol( [s:#phi].?P'/[s] -> ((and ?P1/[s] ?P2/[s]) -> False)) with
	      <| [s:#phi].?prf_p1_and_p2/[?P1/[s],?P2/[s],?nP1/[s],?nP2/[s]] ?pf1/[s] ?pf2/[s] |>

      | (?P1 : [#phi].Prop, ?P2 : [#phi].Prop).[s:#phi].((or ?P1/[s] ?P2/[s]) -> False) |->
	  unpack < ?nP1, ?pf1, unused > = nnf ([s:#phi].not ?P1/[s]) in
          unpack < ?nP2, ?pf2, unused > = nnf ([s:#phi].not ?P2/[s]) in
          pack ([s:#phi].and ?nP1/[s] ?nP2/[s]) as ?P' return hol( [s:#phi].?P'/[s] -> ((or ?P1/[s] ?P2/[s]) -> False)) with
	      <| [s:#phi].?prf_p1_or_p2/[?P1/[s],?P2/[s],?nP1/[s],?nP2/[s]] ?pf1/[s] ?pf2/[s] |>

      | (?P1 : [#phi].Prop, ?P2 : [#phi].Prop).[s:#phi].((?P1/[s] -> ?P2/[s]) -> False) |->
	  unpack < ?P1', ?pf1, unused > = nnf ([s:#phi].?P1/[s]) in
          unpack < ?nP2, ?pf2, unused > = nnf ([s:#phi].not ?P2/[s]) in
          pack ([s:#phi].and ?P1'/[s] ?nP2/[s]) as ?P' return hol( [s:#phi].?P'/[s] -> ((?P1/[s] -> ?P2/[s]) -> False)) with
	      <| [s:#phi].?prf_np1_imp_p2/[?P1/[s],?P2/[s],?P1'/[s],?nP2/[s]] ?pf1/[s] ?pf2/[s] |>

      | (?P : [#phi].Prop).[s:#phi].(?P/[s] -> False) |->
	  pack [s:#phi].not ?P/[s] as ?P' return hol( [s:#phi].?P'/[s] -> (?P/[s] -> False) ) with
	      <| [s:#phi].fun h : (?P/[s] -> False) => h |>

      | (?P1 : [#phi].Prop, ?P2 : [#phi].Prop).[s:#phi].(?P1/[s] -> ?P2/[s]) |->
	  unpack < ?nP1, ?pf1, unused > = nnf ([s:#phi].not ?P1/[s]) in
          unpack < ?P2', ?pf2, unused > = nnf ([s:#phi].?P2/[s]) in
          pack ([s:#phi].or ?nP1/[s] ?P2'/[s]) as ?P' return hol( [s:#phi].?P'/[s] -> (?P1/[s] -> ?P2/[s])) with
	      <| [s:#phi].?prf_p1_imp_p2/[?P1/[s],?P2/[s],?nP1/[s],?P2'/[s]] ?pf1/[s] ?pf2/[s] |>

      | (?P : [#phi].Prop).[s:#phi].?P/[s] |->
	  pack ?P as ?P' return hol( [s:#phi].?P'/[s] -> ?P/[s] ) with
	      <| [s:#phi].fun h : ?P/[s] => h |>

  in
    nnf

evalfast (nnf #[A : Prop, B : Prop] ([A : Prop, B : Prop].(not (or (and A B) (A -> B))))).

>>

