open Utils
open Logic_ast

let lbvar i = LVar (LBVar i)
let lfvar i = LVar (LFVar i)

(* lterm invariant:
   no BVar outside a binder *)

let appmany (lt : lterm) (l : lterm list) =
  List.fold_left (fun res cur -> LApp(res, cur)) lt l

let lammany (l : (string option * lterm) list) (lt : lterm) =
  List.fold_right (fun (s,t) res -> LLambda(s, mk_inferred (), t, res)) l lt

let pimany (l : (string option * lterm) list) (lt : lterm) =
  List.fold_right (fun (s,t) res -> LPi(s, mk_inferred (), t, res)) l lt

let boundlist (n : int) =
  List.map (fun n -> LVar (LBVar n)) (decreasing n)

(* recursive_param_to_term

   Convert a recursive parameter of a constructor into a term
   M_i is the first list of def
   m_i is the second list of def
   X is the res argument
   Pi x_0 : M_0.Pi x_1 : M_1. ... Pi x_n : M_n. X (vec x) (vec m) or
   lam x_0 : M_0. ... *)
let recursive_param_to_term (def : (string option * lterm) list * lterm list) (bindmany : (string option * lterm) list -> lterm -> lterm) (res : lterm list -> lterm list -> lterm) =
  let (bigmi, mi) = def in
  let n = List.length bigmi in
  let xvm = res (boundlist n) mi in
    bindmany bigmi xvm
let recursive_param_to_type def res = recursive_param_to_term def pimany res

(* type_for_elim_branch

   Convert a constructor into the type of the dependent branch for that constructor
   (\Pi x:P.C){X,Q,c} = \Pi p : P.\Pi prec : (\Pi vec.x : vec.P.Q vec.m (p vec.x)).C{X,Q,c p}
   (\Pi x:M.C){X,Q}=\Pi x:M.(C{X,Q,c x})
   (X vec.a){X,Q,c} = Q vec.a c  *)
let type_for_elim_branch (idef : linddef) (idefterm : lterm) (constr : lconstr) (res : lterm list -> lterm -> lterm) (c : lterm) =
  let LConstr (params, args) = constr in
  let n = List.length params in 
  let recursive =
    let rec aux i l =
      match l with
	  [] -> []
	| (_,LParNonrec(lt)) :: tl ->
	    aux (i-1) (stringlist (BindCparam.swap_bound_in_binderlist 0 i) tl)
	| (s,LParStrictPos(a,b)) :: tl ->
	    (s ^? "rec", recursive_param_to_type (a,b) (fun vars args -> res args (appmany (LVar (LBVar i)) vars))) ::
	      aux i tl
    in
      aux (n-1) params
  in
    pimany
      (List.map (function
		   | s, LParNonrec(lt) -> s, lt
		   | s, LParStrictPos(a,b) -> s, recursive_param_to_type (a,b) (fun vars args -> appmany idefterm args))
	 params)
      (pimany recursive
	 (BindLterm.shift_bound (List.length recursive) (res args (appmany c (boundlist n)))))

(* type_for_elim
   Compute the type for the elimination of idef. idef should be in beta-iota-normal form, idefterm and
   res should only have free variables (no bound variables) *)
(* dead code -- not really needed *)
(* let type_for_elim (idef : linddef) (idefterm : lterm) (res : lterm list -> lterm -> lterm) = *)
(*   let LIndDef (LArity(indexes,sort), branches) = idef in *)
(*   let n = List.length indexes in *)
(*   let k = List.length branches in *)
(*     (pimany (List.map (fun i -> type_for_elim_branch idef idefterm (List.nth branches i) res (LCtor(idefterm, i))) (increasing k)) *)
(*        (pimany indexes (LPi(None, appmany idefterm (boundlist n), *)
(* 			    let bvars = List.map (fun n -> LVar (LBVar n)) (decreasing_start n 1) in *)
(* 			      res bvars (LVar (LBVar 0)))))) *)

let cparam_to_term (idefterm : lterm) (def : lcparam) =
  match def with
      LParNonrec(lt) -> lt
    | LParStrictPos(a,b) -> recursive_param_to_type (a,b) (fun vars args -> appmany idefterm args)

let constr_to_term (idefterm : lterm) (constr : lconstr) =
  let LConstr(params, args) = constr in
  pimany (stringlist (List.map (cparam_to_term idefterm)) params)
    (appmany idefterm args)

let arity_to_term (LArity(args, s) : larity) =
  pimany args (LSort(s))

let term_for_elim_branch (idef : linddef) (idefterm : lterm) (constr : lconstr) (f_branch : lterm) (bigF : lterm) =
  let LConstr(params, args) = constr in
  let n = List.length params in
  let f_branch' = BindLterm.shift_bound n f_branch in
  let recursive =
    let rec aux i l =
      match l with
	  [] -> []
	| (s,LParNonrec(lt)) :: tl ->
	    aux (i-1) tl
	| (s,LParStrictPos(a,b)) :: tl ->
	    (recursive_param_to_term (a,b) lammany
	       (fun vars args ->
		  let m = List.length vars in
		  let bigF' = BindLterm.shift_bound m bigF in
		  let args' = List.map (BindLterm.shift_bound m) args in
		    LApp(appmany bigF' args', appmany (LVar (LBVar (i+m))) vars))) ::
	      aux (i-1) tl
    in
      aux (n-1) params
  in
    lammany (stringlist (List.map (cparam_to_term idefterm)) params)
      (appmany (appmany f_branch' (boundlist n))
	 recursive)

let iota_step (idef : linddef) (idefterm : lterm) (res : lterm) (f_branches : lterm list) (branch : int) (args : lterm list) =
  let LIndDef(s, LArity(arity, _), constrs) = idef in
  let n = List.length arity in
  let bigF = lammany arity (LLambda(None, mk_inferred (),
				    appmany idefterm (boundlist n), LElim(BindLterm.shift_bound (n+1) res,
									  LVar (LBVar 0),
									  List.map (BindLterm.shift_bound (n+1)) f_branches))) in
    appmany (term_for_elim_branch idef idefterm (List.nth constrs branch) (List.nth f_branches branch) bigF)
            args

type lterm_gathered_app = LAppMany of lterm * lterm list
type lterm_gathered_lam = LLamMany of lterm list * lterm
type lterm_gathered_pi  = LPiMany  of lterm list * lterm

let rec gather_app = function 
    LApp(e1, e2) -> (let LAppMany(e, el) = gather_app e1 in
		       LAppMany(e, List.append el [e2]))
  | e -> LAppMany(e, [])

let rec gather_lam = function
    LLambda(_, _, e1, e2) -> (let LLamMany(el, e) = gather_lam e2 in
				LLamMany(e1 :: el, e2))
  | e -> LLamMany([], e)

let rec gather_pi = function
    LPi(_, _, e1, e2) -> (let LPiMany(el, e) = gather_pi e2 in
			    LPiMany(e1 :: el, e2))
  | e -> LPiMany([], e)

let get_def_term name (dict1,dict2) = ExtDict.getsnd name dict1 
let get_def_type name (dict1,dict2) = ExtDict.getfst name dict1
let get_metadef_term name (dict1,dict2) = ExtDict.getsnd name dict2
let get_metadef_type name (dict1,dict2) = ExtDict.getfst name dict2
  
let terminctx_close_down ctx tm =
  let n = List.length ctx in
    LTermInCtx(ctx, BindLterm.close_down ~howmany:n tm)

let modal_apply_subst modal subst = 
    match modal with
	LTermInCtx(ctx,lt) -> BindLtermS.subst_bound_list subst lt
      | meta -> LModal(meta, subst)

let replace_f0_in_substs n t =
  lterm_map ~lfvar:(fun i -> LVar (LFVar (if i > 0 then i + (n - 1) else i)))
            ~lsubstelem:(fun tm res ->
			   match tm with
			       LVar(LFVar 0) -> List.map (fun i -> LVar(LFVar i)) (decreasing n)
			     | _ -> [res])
    t

let rec flatten_term_in_context ctx t =
  match ctx with
      [] -> ctx, t
    | (s, LTermList(LCtxAsList(l))) :: tl ->
	let n = List.length l in
	nowarn let LTermInCtx(tl', t') = BindModal.open_up (LTermInCtx(tl, t)) in
	let tl', t' = List.map (fun (s,t) -> (s,replace_f0_in_substs n t)) tl', replace_f0_in_substs n t' in
	nowarn let LTermInCtx(tl', t') = BindModal.close_down ~howmany:n (LTermInCtx(tl', t')) in
	let ctx' = List.append l tl' in
	  flatten_term_in_context ctx' t'
    | hd :: tl ->
	nowarn let LTermInCtx(tl', t') = BindModal.open_up (LTermInCtx(tl, t)) in
	let tl', t' = flatten_term_in_context tl' t' in
	nowarn let LTermInCtx(tl', t') = BindModal.close_down (LTermInCtx(tl',t')) in
	  (hd :: tl', t')

let terminctx_open_up ctx tm =
  let rec aux ctx fenv lt =
    match ctx with
	[] -> (fenv, lt)
      | (s,hd) :: tl ->
	  nowarn let LTermInCtx(ctx', lt') = BindModal.open_up (LTermInCtx(tl,lt)) in
	  let fenv' = List.map (BindLterm.bumpup_fvar 1) (hd :: fenv) in
	    aux ctx' fenv' lt'
  in
    aux ctx [] tm

let flatten_context ctx =
  let ctx', _ = flatten_term_in_context ctx (LSort(LSet)) in ctx'

let ctx_open_up ctx =
  let ctx', _ = terminctx_open_up ctx (LSort(LSet)) in ctx'

let flatten_all_lterm =
  lterm_map ~lterminctx:(fun ctx lt rctx rlt ->
			   let ctx', lt' = flatten_term_in_context rctx rlt in
			     LTermInCtx(ctx', lt'))
            ~lctxaslist:(fun ctx rctx -> LCtxAsList(flatten_context rctx))

let flatten_all_lmodal mt = 
  nowarn let LModal(mt,_) = flatten_all_lterm (LModal(mt,[])) in
    mt

let flatten_all_lctxdesc ctx = 
  nowarn let LTermList(ctx) = flatten_all_lterm (LTermList(ctx)) in
    ctx

(* invariant that needs to be maintained: all terms should have flattened contexts! *)
    

let rec fulldelta_modal defenv e subst =
  match modal_apply_subst e subst with
      LModal(LNMeta(s), subst') -> fulldelta_modal defenv (get_metadef_term s defenv) subst'
    | t -> t

let rec is_inddef defenv tm =
  match tm with
      LInd(_) -> true
    | LVar(LNVar(n)) -> is_inddef defenv (get_def_term n defenv)
    | LModal(e,subst) -> is_inddef defenv (fulldelta_modal defenv e subst)
    | _ -> false

let rec get_inddef defenv tm =
  match tm with
      LInd(idef) -> idef
    | LVar(LNVar(n)) -> get_inddef defenv (get_def_term n defenv)
    | LModal(e,subst) -> get_inddef defenv (fulldelta_modal defenv e subst)
    | _ -> failwith "get_inddef on non-ind.def"


let whnf (defenv : lterm_defenv) =
  let rec whnf e =
    match e with
	LApp(e1, e2) -> (match whnf e1 with
			     LLambda(_, _, _, e) -> whnf (BindLtermS.subst_bound e2 e)
			   | e1' -> LApp(e1', e2))
      | LElim(res, ctorargs, branches) ->
	  (match gather_app (whnf ctorargs) with
	       LAppMany(LCtor(tm, i), args) when is_inddef defenv tm ->
		 whnf
		   (iota_step (get_inddef defenv tm) tm res branches i args)
	     | LAppMany(e, el) ->
		 LElim(res, appmany e el, branches))
      | LModal(LTermInCtx(_,_) as modal, subst)
      | LModal(LNMeta(_) as modal, subst) ->
	  (whnf (fulldelta_modal defenv modal subst))
      | e -> e
  in
    whnf

let fullnf (defenv : lterm_defenv) =
  let rec fullnf e =
    match e with
	LApp(e1, e2) -> (match fullnf e1 with
			     LLambda(_, _, _, e) -> fullnf (BindLtermS.subst_bound (fullnf e2) e)
			   | e1' -> LApp(e1', fullnf e2))
      | LElim(res, ctorargs, branches) ->
	  (match gather_app (fullnf ctorargs) with
	       LAppMany(LCtor(tm, i), args) when is_inddef defenv tm ->
		 fullnf
		   (iota_step (get_inddef defenv tm) tm res branches i args)
	     | LAppMany(e, el) ->
		 LElim(fullnf res, appmany e el, List.map fullnf branches))
      | LModal(LTermInCtx(_,_) as modal, subst)
      | LModal(LNMeta(_) as modal, subst) ->
	  (fullnf (fulldelta_modal defenv modal subst))
      | LVar(LNVar(n)) ->
	  fullnf (get_def_term n defenv)
      | e -> e
  in
    fullnf

let fullnf_term (defenv : lterm_defenv) t =
  lterm_map
    ~llambda:(fun s k t1 t2 rt1 rt2 -> LLambda(None, k, rt1, rt2))
    ~lpi:(fun s k t1 t2 rt1 rt2 -> LPi(None, k, rt1, rt2))
    ~lterminctx:(fun ctx lt rctx rlt ->
		   LTermInCtx(rctx, fullnf defenv rlt))
    ~lctxelem:(fun s t rt -> [(None, fullnf defenv rt)])
    t


let fullnf_modal (defenv : lterm_defenv) mt =
  nowarn let LModal(mt,_) = fullnf_term defenv (LModal(mt,[])) in
    mt
      
let fullnf_ctx (defenv : lterm_defenv) ctx = 
  nowarn let LTermList(ctx) = fullnf_term defenv (LTermList(ctx)) in
    ctx
  
(* let whnf (defenv : lterm_defenv)       = let (f,_) = whnf_all defenv in f *)
	     
let whdelta (defenv : lterm_defenv) (e : lterm) =
  monadic option_monad in begin
    let rec aux e =
      match e with
	  LVar(LNVar n) -> cmd { return (get_def_term n defenv) }
	| LApp(e1, e2) ->  cmd { e1' <- aux e1 then
				 return (LApp(e1', e2)) }
	| LElim(res, tm, branches) ->
	                   cmd { tm' <- aux tm then
				 return (LElim(res, tm', branches)) }
	| e -> None
    in
      cmd { e' <- aux e then
	    return (whnf defenv e') }
  end

let fullwhdelta defenv e =
  let rec aux e = 
    let e' = whnf defenv e in
    match whdelta defenv e' with
	None -> e'
      | Some e'' -> aux e''
  in
    aux e

(* this is a hack: we try to do as many iota-steps as possible, even
   unfolding definitions; but avoid unfolding definitions when leading
   to terms with Ind constructors. Used in pattern-matching *)
let powerwhnf (defenv : lterm_defenv) =
  let rec whnf e =
    match e with
	LApp(e1, e2) -> (match whdelta e1 with
			     LLambda(_, _, _, e) ->
			       (match gather_lam e with
				    LLamMany(_, LInd(_)) -> LApp(e1, e2)
				  | _ -> whnf (BindLtermS.subst_bound e2 e))
			   | e1' -> LApp(e1, e2))
      | LElim(res, ctorargs, branches) ->
	  (match gather_app (whdelta ctorargs) with
	       LAppMany(LCtor(tm, i), args) when is_inddef defenv tm ->
		 whnf
		   (iota_step (get_inddef defenv tm) tm res branches i args)
	     | LAppMany(e, el) ->
		 LElim(res, ctorargs, branches))
      | LModal(LTermInCtx(_,_) as modal, subst)
      | LModal(LNMeta(_) as modal, subst) ->
	  (whnf (fulldelta_modal defenv modal subst))
      | e -> e
  and whdelta e =
    let e' =
      match e with
	  LVar(LNVar n) -> get_def_term n defenv
	| LApp(e1, e2)  -> LApp(whdelta e1, e2)
	| LElim(res, tm, branches) -> LElim(res, whdelta tm, branches)
	| e -> e
    in
      whnf e'
  in
    whnf


let fullwhdelta_modal (defenv : lterm_defenv) mt =
  match mt with
      LTermInCtx(ctx,t) ->
	let t' = BindLterm.open_up ~howmany:(List.length ctx) t in
	let t'' = fullwhdelta defenv t' in
	let t''' = BindLterm.close_down ~howmany:(List.length ctx) t'' in
	LTermInCtx(ctx,t''')
    | mt -> mt

let equal_checks (defenv : lterm_defenv) =
  let rec aux e1 e2 =
    let e1', e2' = whnf defenv e1, whnf defenv e2 in
    match e1', e2' with
	LSort(s1), LSort(s2) -> s1 = s2
      | LVar(v1), LVar(v2) when v1 = v2 -> true
      | LVar(LNVar(n1)), e2 -> (aux (get_def_term n1 defenv) e2)
      | e1, LVar(LNVar(n2)) -> (aux e1 (get_def_term n2 defenv))
      | LLambda(_, _, a1, b1), LLambda(_, _, a2, b2) -> aux a1 a2 && aux (BindLterm.open_up b1) (BindLterm.open_up b2)
      | LPi(_, _, a1, b1), LPi(_, _, a2, b2) -> aux a1 a2 && aux (BindLterm.open_up b1) (BindLterm.open_up b2)
      | LInd(i1), LInd(i2) -> i1 = i2
      | LCtor(a1,i1), LCtor(a2,i2) -> i1 = i2 && aux a1 a2
      | LApp(a1,b1), LApp(a2,b2) when aux a1 a2 && aux b1 b2 -> true
      | LElim(a1,b1,c1), LElim(a2,b2,c2) when aux a1 a2 && aux b1 b2 && List.for_all2 aux c1 c2 -> true
      | LModal(m1,s1), LModal(m2,s2) -> modalaux m1 m2 && List.for_all2 aux s1 s2
      | LTermList(l1), LTermList(l2) -> ctxdescaux l1 l2
      | e1', e2' -> (match whdelta defenv e1', whdelta defenv e2' with
		       | Some e1'', Some e2'' -> aux e1'' e2''
		       | Some e1'', None -> aux e1'' e2'
		       | None, Some e2'' -> aux e1' e2''
		       | None, None -> false)
  and modalaux e1 e2 =
      match e1, e2 with
	  LFMeta(i1), LFMeta(i2) -> i1 = i2
	| LBMeta(i1), LBMeta(i2) -> i1 = i2
	| LNMeta(s1), LNMeta(s2) when s1 = s2 -> true
	| LNMeta(s1), e2 -> modalaux (get_metadef_term s1 defenv) e2
	| e1, LNMeta(s2) -> modalaux e1 (get_metadef_term s2 defenv)
	| LTermInCtx(ct1,t1), LTermInCtx(ct2,t2) ->
	    let n1 = List.length ct1 in
	    let n2 = List.length ct2 in
	    ctxdescaux (LCtxAsList(ct1)) (LCtxAsList(ct2)) &&
	      aux (BindLterm.open_up ~howmany:n1 t1) (BindLterm.open_up ~howmany:n2 t2)
	| LTermInCtx(ct1,LModal(t1,s1)), t2 when modalaux t1 t2 && ExtList.is_prefix s1 (boundlist (List.length ct1)) -> true
	| t2, LTermInCtx(ct1,LModal(t1,s1)) when modalaux t1 t2 && ExtList.is_prefix s1 (boundlist (List.length ct1)) -> true
	| _, _ -> false
  and ctxdescaux c1 c2 =
    match c1, c2 with
	LFCtx(i1), LFCtx(i2) -> i1 = i2
      | LBCtx(i1), LBCtx(i2) -> i1 = i2
      | LCtxAsList(l1), LCtxAsList(l2) ->
	  let l1' = ctx_open_up l1 in
	  let l2' = ctx_open_up l2 in
	  List.for_all2 aux l1' l2'
      | _, _ -> false
  in
    (aux, modalaux, ctxdescaux);;

let lterm_equal d    = let (f,_,_) = equal_checks d in f
let lmodal_equal d   = let (_,f,_) = equal_checks d in f
let lctxdesc_equal d = let (_,_,f) = equal_checks d in f

