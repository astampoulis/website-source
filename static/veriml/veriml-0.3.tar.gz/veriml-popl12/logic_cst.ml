open Utils
module LAst = Logic_ast
module BindLterm = LAst.BindLterm

type 
  lterm =  LSort of LAst.lsort
	  |LVar of string
	  |LLambda of string * lterm * lterm
	  |LPi of string * lterm * lterm
	  |LArrow of lterm * lterm
	  |LApp of lterm * lterm
	  |LInd of linddef
	  |LCtor of lterm * int
	  |LElim of lterm (* result *) * lterm (* ind. term *) * lterm list (* branches *)
	  |LModal of lmodalterm * lsubst
	  |LModalIdsubst of lmodalterm
	  |LTermList of lctxdesc
	  |LAny of int
and
  lsubst = lterm list
and
  lctxdesc =   LCtxVar of string
	     | LCtxAsList of (string * lterm) list
	     | LCurctx
and
  lmodalterm =   LTermInCtx of lctxdesc * lterm
	       | LMeta of string
and
  linddef = LIndDef of string * lterm (* arity *) * lterm list (* constructors *)

let appmany (lt : lterm) (l : lterm list) =
  List.fold_left (fun res cur -> LApp(res, cur)) lt l

let lammany (l : (string * lterm) list) (lt : lterm) =
  List.fold_right (fun (str,cur) res -> LLambda(str, cur, res)) l lt

let pimany (l : (string * lterm) list) (lt : lterm) =
  List.fold_right (fun (str,cur) res -> LPi(str, cur, res)) l lt

type lpimany_gathered  = LPiMany of (string * lterm) list * lterm
type lappmany_gathered = LAppMany of lterm * lterm list

let rec gather_pi e =
  match e with
      LPi(s,t,e') -> let LPiMany (ts, e'') = gather_pi e' in LPiMany((s,t) :: ts, e'')
    | LArrow(t,e') -> let LPiMany (ts, e'') = gather_pi e' in LPiMany(("",t) :: ts, e'')
    | e -> LPiMany([], e)

let rec gather_app e =
  match e with
      LApp(e,e') -> let LAppMany (e0, es) = gather_app e in LAppMany(e0, List.append es [e'])
    | e -> LAppMany(e, [])

let rec is_fv (var : string) (e : lterm) =
  match e with
      LSort(s) -> false
    | LVar(str) -> str = var
    | LLambda(str, t1, t2) ->
	is_fv var t1 || (str <> var && is_fv var t2)
    | LPi(str, t1, t2) ->
	is_fv var t1 || (str <> var && is_fv var t2)
    | LArrow(t1, t2) ->
	is_fv var t1 || is_fv var t2
    | LApp(t1, t2) ->
	is_fv var t1 || is_fv var t2
    | LInd(LIndDef(name, arity, constrs)) ->
	is_fv var arity || (name <> var && List.exists (is_fv var) constrs)
    | LCtor(t1, i) ->
	is_fv var t1
    | LElim(t1,t2,tl) ->
	is_fv var t1 || is_fv var t2 || List.exists (is_fv var) tl
    | LModal(m,subst) ->
	List.exists (is_fv var) subst
    | LModalIdsubst _ ->
	failwith "not implemented yet"
    | LTermList(LCtxAsList(_)) ->
	failwith "not implemented yet"
    | LTermList(_) -> false
    | LAny(_) -> false

let conversions benv metaenv ctxenv cursubst guessubst = 
  let somefst (s,x) = (Some s, x) in
  let cross_binder str t benv cursubst =
    let benv' = (str, t) :: (* (List.map (fun (s',t') -> (s',BindLterm.shift_bound 1 t')) benv) *) benv in
    let cursubst' = (LAst.LVar (LAst.LBVar(0))) :: (List.map (BindLterm.shift_bound 1) cursubst) in
    benv',cursubst'
  in
  let cross_silent_binder t benv cursubst =
    let benv' = ("", t) :: (* (List.map (fun (s',t') -> (s',BindLterm.shift_bound 1 t')) benv) *) benv in
    let cursubst' = List.map (BindLterm.shift_bound 1) cursubst in
    benv',cursubst'
  in
  let rec ast_of_cst (benv : (string * LAst.lterm) list) (cursubst : LAst.lterm list) (e : lterm) =
    let benvstrs = List.map fst benv in
    match e with
	LSort(s) -> LAst.LSort(s)
      | LVar(str) ->
	  begin
	    try
	      let i = ExtList.findindex ((=) str) benvstrs in LAst.LVar (LAst.LBVar i)
	    with Not_found ->
	      (try
	      	 let _ = ExtList.findindex ((=) str) metaenv in
	      	   ast_of_cst benv cursubst (LModalIdsubst(LMeta(str)))
	       with Not_found ->
		 (try
	      	    let _ = ExtList.findindex ((=) str) ctxenv in
	      	      ast_of_cst benv cursubst (LTermList(LCtxVar(str)))
		  with Not_found ->
		    LAst.LVar (LAst.LNVar str)))
	  end
      | LLambda(str, t1, t2) ->
	  let t1a = ast_of_cst benv cursubst t1 in
	  let benv', cursubst' = cross_binder str t1a benv cursubst in
	  LAst.LLambda(Some str, mk_inferred (), t1a, ast_of_cst benv' cursubst' t2)
      | LPi(str, t1, t2) ->
	  let t1a = ast_of_cst benv cursubst t1 in
	  let benv', cursubst' = cross_binder str t1a benv cursubst in
	  LAst.LPi(Some str, mk_inferred (), t1a, ast_of_cst benv' cursubst' t2)
      | LArrow(t1, t2) ->
	  let t1a = ast_of_cst benv cursubst t1 in
	  let benv', cursubst' = cross_silent_binder t1a benv cursubst in
	  LAst.LPi(None, mk_inferred (), t1a, ast_of_cst benv' cursubst' t2)
      | LApp(t1, t2) ->
	  LAst.LApp(ast_of_cst benv cursubst t1, ast_of_cst benv cursubst t2)
      | LInd(idef) ->
	  failwith "ind thrown out"
	  (* LAst.LInd(ast_inddef_of_cst_inddef benv idef) *)
      | LCtor(tm, i) ->
	  LAst.LCtor(ast_of_cst benv cursubst tm, i)
      | LElim(t1, t2, tl) ->
	  LAst.LElim(ast_of_cst benv cursubst t1, ast_of_cst benv cursubst t2, List.map (ast_of_cst benv cursubst) tl)
      | LModal(m, subst) ->
	  LAst.LModal(ast_of_modal benv cursubst m, List.map (ast_of_cst benv cursubst) subst)
      | LModalIdsubst(m) ->
	  LAst.LModal(ast_of_modal benv cursubst m, List.rev cursubst)
      | LTermList(ctxdesc) ->
	  let ctx, _, _ = ast_of_ctxdesc benv cursubst ctxdesc in
	    LAst.LTermList(ctx)
      | LAny(_) ->
	  LAst.mk_infer 0 (List.length benv) 0 (List.length metaenv) 0 (List.length ctxenv) ~guessubst:guessubst

  and ast_of_modal curctx cursubst m =
    match m with
	LTermInCtx(ctx, lt) ->
	  (let ctxA, curctx, cursubst = ast_of_ctxdesc curctx cursubst ctx in
	   let ltA = ast_of_cst curctx cursubst lt in
	     match ctxA with
		 LAst.LCtxAsList(ctxA') -> LAst.LTermInCtx(ctxA', ltA)
	       | _ -> failwith "modal's context is not a list")
      | LMeta(str) ->
	  begin
	    try
	      (let i = ExtList.findindex ((=) str) metaenv in
		 LAst.LBMeta(i))
	    with Not_found ->
	      LAst.LNMeta(str)
	  end

  and ast_of_ctxdesc curctx cursubst c =
    match c with
	LCtxVar(str) -> 
	  let i = ExtList.findindex ((=) str) ctxenv in
	  let curctx' =   [ ("id_"^str, LAst.LTermList(LAst.LBCtx(i))) ] in
	  let cursubst' = [ LAst.LVar(LAst.LBVar(0)) ] in
	  (LAst.LBCtx(i), curctx', cursubst')
      | LCtxAsList(ctx) ->
  	  let prevcurctx = curctx in
	  let prevcursubst = cursubst in
   	  let rec aux curctx cursubst ctx =
	    match ctx with
		[] -> ( [] , curctx, cursubst )

	      | (_, LTermList(LCurctx)) :: tl ->
		let ctx_hd, curctx', cursubst' = List.rev (List.map somefst prevcurctx), prevcurctx, prevcursubst in
		let ctx_tl, curctx'', cursubst'' = aux curctx' cursubst' tl in
		(List.append ctx_hd ctx_tl, curctx'', cursubst'')
	      
	      | (namehd, typehd) :: tl ->

		   let namehd = match typehd with LTermList(LCtxVar(s)) when namehd = "" -> ("id_"^s) | _ -> namehd in
		   let ctx_hd = ast_of_cst curctx cursubst typehd in
		   let curctx', cursubst' = cross_binder namehd ctx_hd curctx cursubst in
		   let ctx_tl, curctx'', cursubst'' = aux curctx' cursubst' tl in
		     ( (Some namehd , ctx_hd) :: ctx_tl , curctx'' , cursubst'' )
	  in
	   let ctx', curctx', cursubst' = aux [] [] ctx in
	     (LAst.LCtxAsList(ctx'), curctx', cursubst')

      | LCurctx ->
	let ctx' = LAst.LCtxAsList(List.rev (List.map somefst curctx)) in
	(ctx', curctx, cursubst)


(*	    
  and ast_inddef_of_cst_inddef (benv : string list) (LIndDef(name, arity, constrs) : linddef) =
    
    let rec binderlist conv benv =
      function
	  [] -> []
	| (str,hd) :: tl -> (Some str, conv benv hd) :: (binderlist conv (str::benv) tl)
    in

    let arity_conv =
      match gather_pi arity with
	  LPiMany(namedterms, LSort(sort)) -> LAst.LArity(binderlist ast_of_cst benv namedterms, sort)
	| _ -> failwith ("inductive definition " ^ name ^ " has wrong arity")
    in

    let strict_pos_conv benv e =
      let LPiMany(params, body) = gather_pi e in
      let LAppMany(base, args) = gather_app body in
      let paramnames, paramterms = List.split params in
	if List.exists ((=) name) paramnames then
	  failwith ("parameter shadows inductive type under definition " ^ name)
	else if List.exists (is_fv name) (List.append paramterms args) then
	  failwith ("non-strict positive occurrence of inductive type " ^ name)
	else if base <> LVar name then
	  failwith ("shouldn't happen -- strict positive parameter has a result type different than the inductive type being defined")
	else
	  (let benv' = List.append (List.rev paramnames) benv in
	   LAst.LParStrictPos(binderlist ast_of_cst benv params, List.map (ast_of_cst benv') args))
    in

    let cparam_conv benv e =
      if is_fv name e then
	strict_pos_conv benv e
      else
	LAst.LParNonrec(ast_of_cst benv e)
    in

    let constr_conv benv e =
      let LPiMany(params, body) = gather_pi e in
      let LAppMany(base, args) = gather_app body in
      let cparams = binderlist cparam_conv benv params in
      let paramnames, _ = List.split params in
	if List.exists ((=) name) paramnames then
	  failwith ("parameter shadows inductive type under definition " ^ name)
	else if List.exists (is_fv name) args then
	  failwith ("non-strict positive occurrence of inductive type " ^ name)
	else if base <> LVar name then
	  failwith ("a branch has a result type different than the inductive type " ^ name ^ " being defined")
	else
	  (let benv' = List.append (List.rev (List.map fst params)) benv in
	   LAst.LConstr(cparams, List.map (ast_of_cst benv') args))
    in
      LAst.LIndDef(Some name, arity_conv, List.map (constr_conv benv) constrs)
*)
  in
    (ast_of_cst benv cursubst, ast_of_modal benv cursubst, ast_of_ctxdesc benv cursubst)

let ast_of_cst     ?(bound = []) ?(metaenv = []) ?(ctxenv = []) ?(cursubst=[]) ?(guessubst=[]) e =
  let (f,_,_) = conversions bound metaenv ctxenv cursubst guessubst in f e
let ast_of_modal   ?(curctx = []) ?(metaenv = []) ?(ctxenv = []) ?(cursubst=[]) ?(guessubst=[]) e =
  let (_,f,_) = conversions curctx metaenv ctxenv cursubst guessubst in f e
let ast_of_ctxdesc ?(curctx = []) ?(metaenv = []) ?(ctxenv = []) ?(cursubst=[]) ?(guessubst=[]) e =
  let (_,_,f) = conversions curctx metaenv ctxenv cursubst guessubst in f e

let rec logicint i =
  match i with
      0 -> LVar "zero"
    | i when i > 0-> LApp (LVar "succ", logicint (i-1))
    | _ -> failwith "negative number passed to logicint"
	
(* potential bug: naming an inductive definition under something already in the context *)

let get_new_id default env s =
  (* let get_ident_nums s1 s2 = *)
  (*   let re = Str.regexp ("^" ^ (Str.quote s1) ^ "\\([0-9]+\\)$") in *)
  (*   let matched = Str.string_match re s2 0 in *)
  (*   let i = if matched then int_of_string (Str.matched_group 1 s2) else -1 in *)
  (*     i *)
  (* in *)
  let identbase = match s with Some(s) -> s | None -> default in
  (* let identnums = List.map (get_ident_nums identbase) env in *)
  (* let maxn = List.fold_left max (-1) identnums in *)
  (* let ident = if maxn = -1 then identbase else identbase ^ (string_of_int (maxn + 1)) in *)
  let is_safe base = not (List.exists ((=) base) env) in
  let rec first_safe i base =
    let id = base ^ (string_of_int i) in (if is_safe id then id else first_safe (i+1) base)
  in
  let ident = if is_safe identbase then identbase else first_safe 0 identbase in
    ident

let conversions fenv metaenv ctxenv =

  let add_to_normenv (fenv, metaenv, ctxenv) elm = (elm :: fenv, metaenv, ctxenv) in
  let new_normenv ((fenv, metaenv, ctxenv) as env) elm = let id = get_new_id "x" fenv elm in (id, add_to_normenv env id) in

  let rec cst_of_ast ((fenv, metaenv, ctxenv) as env) (e : LAst.lterm) =
    let n = List.length fenv in
    match e with
	LAst.LSort(s) -> LSort(s)
      | LAst.LVar(LAst.LBVar i) -> LVar("b" ^ (string_of_int i))
      | LAst.LVar(LAst.LFVar i) -> LVar(try List.nth fenv (n - i - 1) with _ -> "f!!" ^ (string_of_int i))
      | LAst.LVar(LAst.LNVar s) -> LVar(s)
      | LAst.LLambda(ss,_,t1,t2)  ->
	  (let s, env' = new_normenv env ss in
	   let t2' = BindLterm.open_up n t2 in
	     LLambda(s, cst_of_ast env t1, cst_of_ast env' t2'))
      | LAst.LPi(ss,_,t1,t2) when BindLterm.has_bound_var 0 t2 ->
	  (let s, env' = new_normenv env ss in
	   let t2' = BindLterm.open_up n t2 in
	     LPi(s, cst_of_ast env t1, cst_of_ast env' t2'))
      | LAst.LPi(ss,_,t1,t2) ->
	  (let env' = add_to_normenv env "" in
	   let t2' = BindLterm.open_up n t2 in
	     LArrow(cst_of_ast env t1, cst_of_ast env' t2'))
      | LAst.LApp(t1,t2) ->
	  LApp(cst_of_ast env t1, cst_of_ast env t2)
      | LAst.LCtor(t,i) ->
	  LCtor(cst_of_ast env t, i)
      | LAst.LElim(t1,t2,tl) ->
	  LElim(cst_of_ast env t1, cst_of_ast env t2, List.map (cst_of_ast env) tl)
      | LAst.LInd(idef) ->
	  LInd(cst_of_inddef env idef)
      | LAst.LModal(mt,subst) ->
	  LModal(cst_of_modal env mt,List.map (cst_of_ast env) subst)
      | LAst.LTermList(ctxdesc) ->
	  LTermList(cst_of_ctxdesc env ctxdesc)
      | LAst.LInfer(l,f) ->
	  (match !(LAst.match_lunif l) with
	       Inst(t,_)   -> cst_of_ast env (f t)
	     | Uninst(i,_) -> LAny(i))

  and cst_of_inddef ((fenv, metaenv, ctxenv) as env) (e : LAst.linddef) =
    let n = List.length fenv in
    let LAst.LIndDef(ss, arity, constrlist) = e in
    let arityterm = Logic_core.arity_to_term arity in
    let s, env' = new_normenv env ss in
    let constr_conv constr = Logic_core.constr_to_term (LAst.LVar (LAst.LFVar n)) constr in
    let constrterms = List.map constr_conv constrlist in
      LIndDef(s, cst_of_ast env arityterm, List.map (cst_of_ast env') constrterms)

(* something wrong is going on here -- need to investigate more. *)
  and cst_of_modal (fenv, metaenv, ctxenv) (e : LAst.lmodalterm) =
      match e with
	  LAst.LTermInCtx(ctx, t) ->
	    (let ctx'', env' = cst_of_ctx ([],metaenv,ctxenv) ctx in
	     let t' = BindLterm.open_up ~howmany:(List.length ctx) 0 t in
	       LTermInCtx(LCtxAsList(ctx''), cst_of_ast env' t'))
	| LAst.LFMeta(i) -> LMeta("f" ^ (string_of_int i))
	| LAst.LBMeta(i) -> LMeta(try List.nth metaenv i with _ -> ("b!!" ^ (string_of_int i)))
	| LAst.LNMeta(s) -> LMeta(s)
		   
  and cst_of_ctx ((fenv, metaenv, ctxenv) as env) ?(openup=0) (ctx : (string option * LAst.lterm) list) =
    
    match ctx with
	[] -> ([], env)
      | (ss,tm) :: tl ->
	  (let tm' =  BindLterm.open_up ~howmany:openup 0 tm in
	   let s, env' = new_normenv env ss in
	   let ctx', env'' = cst_of_ctx env' ~openup:(openup+1) tl in
	     ((s, cst_of_ast env tm') :: ctx', env''))
  
  and cst_of_ctxdesc ((fenv, metaenv, ctxenv) as env) (ctxdesc : LAst.lctxdesc) =
    
    match ctxdesc with
	LAst.LFCtx(i) -> LCtxVar("f" ^ (string_of_int i))
      | LAst.LBCtx(i) -> LCtxVar(try List.nth ctxenv i with _ -> ("b!!" ^ (string_of_int i)))
      | LAst.LCtxAsList(ctx) -> (let ctx', _ = cst_of_ctx env ctx in LCtxAsList(ctx'))

  in

    (cst_of_ast (fenv,metaenv,ctxenv),
     cst_of_modal (fenv,metaenv,ctxenv),
     cst_of_ctxdesc (fenv,metaenv,ctxenv))

let cst_of_ast ?(fenv=[]) ?(metaenv=[]) ?(ctxenv=[]) e = let (f,_,_) = conversions fenv metaenv ctxenv in f e
let cst_of_modal ?(fenv=[]) ?(metaenv=[]) ?(ctxenv=[]) e = let (_,f,_) = conversions fenv metaenv ctxenv in f e
let cst_of_ctxdesc ?(fenv=[]) ?(metaenv=[]) ?(ctxenv=[]) e = let (_,_,f) = conversions fenv metaenv ctxenv in f e
