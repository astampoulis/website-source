module type TYPE_WITH_BINDING =
  sig
    type tvar
    type t
    type tenv
    val bvar : (int -> tvar)
    val fvar : (int -> tvar)
    val bound : (tenv -> int)
    val varmap :
      (tenv -> int -> tvar) -> (* bound variables *)
      (tenv -> int -> tvar) -> (* free variables *)
      t -> t
  end

module Binding =
  functor (BT : TYPE_WITH_BINDING) ->
(*   functor (BTvar : TYPE_WITH_BINDING with type t = BT.tvar and type tvar = BT.tvar) -> *)
    struct
      type tvar = BT.tvar
      type t = BT.t

      let shift_bound ?(start = 0) (add : int) (e : t) =
	let f_bvar bound i = if i >= BT.bound bound + start then BT.bvar (i + add) else BT.bvar i in
	let f_fvar bound i = BT.fvar i in
	  BT.varmap f_bvar f_fvar e

      let shift_bound_in_binderlist ?(start = 0) (add : int) (list : t list) =
	let rec aux i (start : 'a) (list : 'b list) =
	  match list with
	      [] -> []
	    | hd :: tl -> (shift_bound ~start:(start+i) add hd) :: aux (i+1) start tl
	in
	  aux 0 start list
	    
      exception HasBoundVar
      let has_bound_var (which : int) (e : t) =
	try
	  let f_bvar bound i = if i = which + BT.bound bound then raise HasBoundVar else BT.bvar i in
	  let f_fvar bound i = BT.fvar i in
	    ignore(BT.varmap f_bvar f_fvar e); false
	with HasBoundVar ->
	  true

      exception HasFreeVar
      let has_free_var (which : int) (e : t) =
	try
	  let f_bvar bound i = BT.bvar i in
	  let f_fvar bound i = if i = which then raise HasFreeVar else BT.fvar i in
	    ignore(BT.varmap f_bvar f_fvar e); false
	with HasFreeVar ->
	  true

      let swap_bound (which : int) (what : int) (e : t) =
	let f_bvar bound i = if (i = BT.bound bound + which) then BT.bvar (BT.bound bound+what) else BT.bvar i in
	let f_fvar bound i = BT.fvar i in
	  BT.varmap f_bvar f_fvar e

      let swap_bound_in_binderlist (which : int) (what : int) (list : t list) =
	let rec aux i (list : 'b list) =
	  match list with
	      [] -> []
	    | hd :: tl -> (swap_bound (i+which) what hd) :: aux (i+1) tl
	in
	  aux 0 list

      let open_up ?(howmany=1) ?(start=0) (envlen : int) (e : t) =
	let f_bvar bound i = 
	  let bound = BT.bound bound + start in
	  if (i >= bound + howmany) then failwith "open_up on something with more than one floating bound variable"
	  else if (i >= bound) then BT.fvar (envlen + howmany - (i-bound) - 1) else BT.bvar i
	in
	let f_fvar bound i =
	  if (i >= envlen) then failwith "open_up with wrong envlen!"
	  else BT.fvar i
	in
	  BT.varmap f_bvar f_fvar e

      let close_down ?(howmany=1) (envlen : int) (e : t) =
	let f_bvar bound i =
	  let bound = BT.bound bound in
	  (* this could be if i + howmany > bound, but i'm not sure *)
	  if (i >= bound) then failwith "close_down on something with floating bound variables"
	  else BT.bvar i
	in
	let f_fvar bound i =
	  if (i >= envlen) then failwith "close_down with wrong envlen!"
	  else if (i >= envlen - howmany) then BT.bvar ((envlen - i - 1) + BT.bound bound)
	  else BT.fvar i
	in
	  BT.varmap f_bvar f_fvar e

      (* let bumpup_fvar (add : int) (e : t) = *)
      (* 	let f_bvar _ i = BT.bvar i in *)
      (* 	let f_fvar _ i = BT.fvar (add + i) in *)
      (* 	  BT.varmap f_bvar f_fvar e *)

      let subst_fvar (bywhat : tvar) (which : int) (e : t) =
	let f_bvar _ i = BT.bvar i in
	let f_fvar _ i = if (i == which) then bywhat else BT.fvar i in
	  BT.varmap f_bvar f_fvar e

      let subst_bound_list_bvar bywhat =
	let n = List.length bywhat in
	let f_bvar bound i =
	  if (i >= BT.bound bound && i < BT.bound bound + n) then
	    (let j = (n - 1) - (i - BT.bound bound) in (List.nth bywhat j))
	  else if (i >= BT.bound bound + n) then BT.bvar (i-n)
	  else BT.bvar i
	in
	  f_bvar

      let subst_bound_list_given_shift shift bywhat =
	BT.varmap (fun bound -> subst_bound_list_bvar (List.map (shift bound) bywhat) bound)
	  (fun bound i -> BT.fvar i)

      let subst_bound_given_list f bywhat term = f [bywhat] term

    end
