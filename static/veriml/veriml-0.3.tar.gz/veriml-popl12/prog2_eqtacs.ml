open Syntax_logic;;
open Syntax_comp;;

<<

reset.
import "prog2_basis".

let eq_context =
  fun phi : ctx, A : @Set, B : @Set,
  a1 : @A , a2 : @A,
  C : [ @ , a : A ].B/[id_phi] ,
  pfeq : hol( @a1 = a2 ) =>
  unpack < pfeq , unused > = pfeq in
  <| @leibn (fun x : A => C/[id_phi, a1/[id_phi]] = C/[id_phi, x]) pfeq (refl C/[id_phi, a1]) |>

let eq_leibniz =
  fun phi : ctx, A : @Set, 
  a1 : @A, a2 : @A, 
  C : [ @ , a : A ].Prop ,
  pf  : hol( @C/[id_phi, a1] ) ,
  pfeq : hol( @a1 = a2 ) =>
  unpack < pf   , unused > = pf in
  unpack < pfeq , unused > = pfeq in
  <| @leibn (fun x : A => C/[id_phi, x]) pfeq pf |>

let eq_trans =
  fun phi : ctx, A : @Set,
  a1 : @A, a2 : @A, a3 : @A,
  pf1 : hol( @a1 = a2 ) , pf2 : hol( @a2 = a3 ) =>
  unpack < pf1 , unused > = pf1 in 
  unpack < pf2 , unused > = pf2 in
  <| @trans pf1 pf2 |>

let eq_refl =
  fun phi : ctx, A : @Set, a : @A =>
  <| @refl a |>

let eq_change =
  fun phi : ctx, P1 : @Prop , P2 : @Prop ,
    pf1 : hol( @P1) ,
    pf2 : hol( @P1 = P2) =>
  unpack < pf1 , unused > = pf1 in
  unpack < pf2 , unused > = pf2 in
  <| @leibn (fun x => x) pf2 pf1 |>


save "prog2_eqtacs".

>>;;
