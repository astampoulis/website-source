open Utils
open Binding
open Logic_ast
open Comp_ast
open Comp_typinf
open Format
open Comp_print

let openin (_,_,metaenv,ctxenv,compenv) t =
  MetabindCterm.open_up ~howmany:(List.length metaenv) 0
    (CtxbindCterm.open_up ~howmany:(List.length ctxenv) 0
       (CbindCterm.open_up ~howmany:(List.length compenv) 0 t))

let closedown (_,_,metaenv,ctxenv,compenv) t =
  MetabindCterm.close_down ~howmany:(List.length metaenv) (List.length metaenv)
    (CtxbindCterm.close_down ~howmany:(List.length ctxenv) (List.length ctxenv)
       (CbindCterm.close_down ~howmany:(List.length compenv) (List.length compenv) t))

let withtype v t ((_,cdefenv,_,_,_) as env) f =
  case_kind ~case:v
    (fun () -> f (ctype_fullwhdelta cdefenv (type_of_HOL env (openin env t))))
    (fun () -> f (ctype_fullwhdelta cdefenv (type_of_ctx env (openin env t))))
    (fun () -> f (ctype_fullwhdelta cdefenv (type_of_cterm env (openin env t))))
    ()

let
    cterm_map_env
              ?(csort   = fun s -> CSort(s))
              ?(cpi     = fun v t1 t2 rt1 rt2 -> CPi(v,rt1,rt2))
	      ?(clambda = fun v t1 t2 rt1 rt2 -> CLambda(v,rt1,rt2))
	      ?(capp    = fun env t1 t2 rt1 rt2 -> CApp(rt1,rt2))
	      ?(cholterm = fun _ t -> CHolTerm(t))
	      ?(cctxterm = fun t -> CCtxTerm(t))
	      ?(cbvar    = fun i -> CBVar(i))
	      ?(cfvar    = fun i -> CFVar(i))
	      ?(cnvar    = fun i -> CNVar(i))
	      ?(cunitexpr = fun () -> CUnitExpr)
	      ?(cunittype = fun () -> CUnitType)
	      ?(csigma    = fun v t1 t2 rt1 rt2 -> CSigma(v,rt1,rt2))
	      ?(cpack     = fun t1 v t2 t3 rt1 rt2 rt3 -> CPack(rt1,v,rt2,rt3))
	      ?(cunpack   = fun t1 v1 v2 t2 rt1 rt2 -> CUnpack(rt1,v1,v2,rt2))
              ?(cholcase  = fun t1 v1 t2 branches rt1 rt2 rtbranches -> CHolCase(rt1,v1,rt2,rtbranches))
              ?(cctxcase  = fun t1 v1 t2 branches rt1 rt2 rtbranches -> CCtxCase(rt1,v1,rt2,rtbranches))
              ?(cprodtype = fun t1 t2 rt1 rt2 -> CProdType(rt1,rt2))
              ?(ctuple    = fun t1 t2 rt1 rt2 -> CTuple(rt1,rt2))
              ?(cproj     = fun i t1 rt1 -> CProj(i,rt1))
              ?(crectype  = fun v t1 t2 rt1 rt2 -> CRecType(v,rt1,rt2))
              ?(csumtype  = fun ts rts -> CSumType(rts))
              ?(cfold     = fun t1 t2 rt1 rt2 -> CFold(rt1,rt2))
              ?(cunfold   = fun t1 rt1 -> CUnfold(rt1))
              ?(cctor     = fun i t p rt rp -> CCtor(i,rt,rp))
              ?(cmatch    = fun t branches rt rtbranches -> CMatch(rt,rtbranches))
              ?(cletrec   = fun defs t rdefs rt -> CLetRec(rdefs, rt))
              ?(clet      = fun v t1 t2 rt1 rt2 -> CLet(v,rt1,rt2))
              ?(cpreeval  = fun env t1 t2 t3 rt1 rt2 rt3 -> CPreEval(rt1,rt2,rt3))
      env
      e =
  
  let rec aux1 ((defenv, cdefenv, metaenv, ctxenv, compenv) as env) =
    let aux e = aux1 env e in
    let add v t env = add_to_env ~case:v (openin env t) env in
    function
      CSort(s) -> csort s
    | CPi(v,t1,t2) -> cpi v t1 t2 (aux t1) (aux1 (add v t1 env) t2)
    | CLambda(v,t1,t2) -> clambda v t1 t2 (aux t1) (aux1 (add v t1 env) t2)
    | CApp(t1,t2) -> capp env t1 t2 (aux t1) (aux t2)
    | CHolTerm(t) -> cholterm env t
    | CCtxTerm(t) -> cctxterm t
    | CBVar(i)    -> cbvar i
    | CFVar(i)    -> cfvar i
    | CNVar(s)    -> cnvar s
    | CUnitExpr   -> cunitexpr ()
    | CUnitType   -> cunittype ()
    | CSigma(v,t1,t2) -> csigma v t1 t2 (aux t1) (aux1 (add v t1 env) t2)
    | CPack(t1,v,t2,t3) -> cpack t1 v t2 t3 (aux t1) (aux1 (withtype v t1 env (fun t1_t -> add_to_env ~case:v t1_t env)) t2) (aux t3)
    | CUnpack(t1,v1,v2,t2) ->
	let env' = withtype (None, CType) t1 env
	  (function CSigma(_,ta,tb) ->
	     let env' = add_to_env ~case:v1 ta env in
	     let tb' = open_up ~case:v1 env tb in
	       add_to_env ~case:v2 tb' env'
	     | _ -> failwith "typechecker is erroneous probably for sigma...")
	in
	cunpack t1 v1 v2 t2 (aux t1) (aux1 env' t2)
    | CHolCase(t1,v,t2,branches) ->
	(let origenv = env in

	 let patconv (env, output, patout) (scrutinee,(metas,t)) =
	   let env', outputhd = 
	     List.fold_left (fun (env,out) (v,mt) ->
			       add v mt env, ((v,aux1 env mt) :: out)) (env,[]) metas
	   in
	   let env'' = subst_fmeta_in_env env' (openin origenv scrutinee) (openin env' t) in
	     (env'', ((List.rev outputhd, aux1 env'' t) :: output), openin env' t :: patout)
	 in
	 let branchconv ts (pats,e) =
	   let env', pats', openpatts = List.fold_left patconv (env,[],[]) (List.combine ts pats) in
	   let pats' = List.rev pats' in
	   let openpatts = List.rev openpatts in
	   let e' = List.fold_left (fun e (scrutinee, t) -> subst_fmeta (openin origenv scrutinee) t e) (openin env' e) (List.combine ts openpatts) in
	   let e'' = closedown env' e' in
	   (pats',aux1 env' e'')
	 in

	 let t2env = List.fold_left (fun env' (v,t1) -> withtype v t1 env (fun t_t -> add_to_env ~case:v t_t env')) env (List.combine v t1) in
	 let t2env' = List.fold_left 
	   (fun env (scrutinee, i) -> subst_fmeta_in_env env (openin origenv scrutinee) (CHolTerm(LFMeta(List.length metaenv + i))))
	   t2env (List.combine t1 (increasing (List.length t1)))
	 in

	   cholcase t1 v t2 branches (List.map aux t1) (aux1 t2env' t2) (List.map (branchconv t1) branches))
    | CCtxCase(t1,v,t2,branches) ->

	(let origenv = env in
	 let branchconv scrutinee (ctxvs, metavs, ctxpat, body) =
	   let env' = List.fold_left (fun env v -> add v (CSort(CCtx)) env) env ctxvs in

	   let ctxvs' = ctxvs in
	   let env'', metavs'rev = List.fold_left
	     (fun (env, out) (v,meta) ->
		add v meta env, ((v, aux1 env meta) :: out))
	     (env', []) metavs
	   in
	   let metavs' = List.rev metavs'rev in

  	   let ctxpat' = aux1 env'' ctxpat in
	   let env''' = subst_fctx_in_env env'' (openin origenv scrutinee) (openin env'' ctxpat) in
	   let body' = subst_fctx (openin origenv scrutinee) (openin env''' ctxpat') (openin env''' body) in
	   let body'' = closedown env''' body' in
	     (ctxvs', metavs', ctxpat', aux1 env''' body'')

	 in
	 let t2env = withtype v t1 env (fun t_t -> add_to_env ~case:v t_t env) in
	 let t2env' = subst_fctx_in_env t2env (openin origenv t1) (CCtxTerm(LFCtx(List.length ctxenv))) in

	   cctxcase t1 v t2 branches (aux t1) (aux1 t2env' t2) (List.map (branchconv t1) branches))

    | CProdType(t1,t2) -> cprodtype t1 t2 (aux t1) (aux t2)
    | CTuple(t1,t2) -> ctuple t1 t2 (aux t1) (aux t2)
    | CProj(i,t1) -> cproj i t1 (aux t1)
    | CRecType(v,t1,t2) -> crectype v t1 t2 (aux t1) (aux1 (add v t1 env) t2)
    | CSumType(ts) -> csumtype ts (List.map aux ts)
    | CFold(t1,t2) -> cfold t1 t2 (aux t1) (aux t2)
    | CUnfold(t1) -> cunfold t1 (aux t1)
    | CCtor(i,t,p) -> cctor i t p (aux t) (aux p)
    | CMatch(t,branches) ->
	(let arglist = withtype (None, CType) t env
	   (function CSumType(l) -> l
	      | _ -> failwith "expected sum type") in
	 let branches' = List.map (fun (argt,(v,t)) -> v, aux1 (add_to_env ~case:v argt env) t)
	                 (List.combine arglist branches) in
	   cmatch t branches (aux t) branches')
    | CLetRec(defs,t) ->
	(let env' = List.fold_left (fun env' (v,t,tm) -> add_to_env ~case:v (openin env t) env') env defs in
	cletrec defs t (List.map (fun (v,t1,t2)->(v,aux t1,aux1 env' t2)) defs) (aux1 env' t))
    | CLet(v,t1,t2) -> clet v t1 t2 (aux t1) (aux1 (withtype v t1 env (fun t1_t -> add_to_env ~case:v t1_t env)) t2)
	(* BUG warning:: let of type doesn't work *)
    | CRefType(t) -> CRefType(aux t)
    | CMkRef(t,t') -> CMkRef(aux t, aux t')
    | CReadRef(t) -> CReadRef(aux t)
    | CAssign(t1,t2) -> CAssign(aux t1, aux t2)
    | CLoc(l,t) -> CLoc(l,t)
    | CSeq(t1,t2) -> CSeq(aux t1, aux t2)
    | CIntType -> CIntType
    | CIntConst(i) -> CIntConst(i)
    | CIntOp(o,t1,t2) -> CIntOp(o,aux t1,aux t2)
    | CIntTest(o,t1,t2) -> CIntTest(o,aux t1,aux t2)
    | CBoolType -> CBoolType
    | CBoolConst(b) -> CBoolConst(b)
    | CBoolOp(o,t1,t2) -> CBoolOp(o,aux t1,aux t2)
    | CStringType -> CStringType
    | CStringConst(s) -> CStringConst(s)
    | CIfThenElse(t1,t2,t3) -> CIfThenElse(aux t1,aux t2,aux t3)
    | CArrayType(t) -> CArrayType(aux t)
    | CMkArray(t1,t2,t3) -> CMkArray(aux t1, aux t2, aux t3)
    | CArrayGet(t1,t2) -> CArrayGet(aux t1, aux t2)
    | CArraySet(t1,t2,t3) -> CArraySet(aux t1, aux t2, aux t3)
    | CArrayLoc(l,t) -> CArrayLoc(l,t)
    | CArrayLen(t) -> CArrayLen(aux t)
    | CArrayLit(ts,t) -> CArrayLit(List.map aux ts, aux t)
    | CHolHash(t) -> CHolHash(aux t)
    | CPrint(t) -> CPrint(aux t)
    | CClosure(subst, t) -> failwith "closure not handled"
    | CTypeAscribe(e,t) -> CTypeAscribe(aux e, aux t)
    | CPreEval(t, ctx, params) -> cpreeval env t ctx params (aux t) (aux ctx) (List.map aux params)
    | CInfer(_,_) -> failwith "unifvar found post-typechecking!!" 
  in
    aux1 env e

let is_proof_object env t = 
  let t_t = type_of_HOL env (openin env t) in
    match t_t with
	CHolTerm(LTermInCtx(_, LSort(_))) -> false
	| _ -> (match type_of_HOL env t_t with
		    CHolTerm(LTermInCtx(_, LSort(LProp))) -> true
		  | _ -> false)

let is_prop env t =
  let t_t = type_of_HOL env (openin env t) in
    match t_t with
	CHolTerm(LTermInCtx(_, LSort(LProp))) -> true
	| _ -> false

let comp_discard_proofobjects e =
  cterm_map_env ~cholterm:(fun ((_,cdefenv,_,_,_) as env) t ->
  			     let t = CHolTerm(t) in
  			     if is_proof_object env t then
  			       CHolTerm(LTermInCtx([],LVar(LNVar("~trusted"))))
  			     else
  			       t)
                ~capp:(fun env t1 t2 rt1 rt2 ->
			 match rt1, rt2 with
			     CNVar("magic"), CHolTerm(t) when is_prop env rt2 ->
			       CPack(
				 CHolTerm(LTermInCtx([],LVar(LNVar("~magic")))),
				 (None, CHol),
				 CUnitType,
				 CUnitExpr)
			   | _, _ -> CApp(rt1,rt2))
    (!Logic_main.logic_global_env, !comp_global_env, [], [], [])
    e

let comp_lift_preevals e = 

  let preevals = ref [] in
  let curbvar (_,_,metaenv,_,_) = LBMeta((List.length metaenv) + (List.length !preevals)) in

  let nullify_ctxs_lmodal ctxenv lt =
    let lt' = CtxbindModalS.subst_bound_list (List.map (fun _ -> LCtxAsList([])) (increasing (List.length ctxenv))) lt in
    let lt'' = Logic_core.flatten_all_lmodal lt' in
      lt''
  in
  let nullify_ctxs_lctxdesc ctxenv ct =
    let ct' = CtxbindCtxdescS.subst_bound_list (List.map (fun _ -> LCtxAsList([])) (increasing (List.length ctxenv))) ct in
    let ct'' = Logic_core.flatten_all_lctxdesc ct' in
      ct''
  in
  let cappmany body lst = List.fold_left (fun cur elm -> CApp(cur,elm)) body lst in
  let metavars_to_bvars ctx metaN tm =
    let tm' = lterm_map ~lmodal:(fun _ _ rmt rs ->
				   match rmt with
				       LBMeta(i) -> LVar(LFVar(metaN - i - 1))
				     | LTermInCtx(_,lt) -> lt
				     | LNMeta(s) -> LModal(LNMeta(s), rs)
				     | _ -> failwith "metavars_to_bvars")
              tm
    in
    let tm'' = BindLterm.shift_bound metaN tm' in
    let tm''' = BindLterm.close_down metaN ~howmany:metaN tm'' in
      tm'''
  in
  let metavars_to_bvars_modal ctx metaN modal =
    match modal with
	LBMeta(i) -> LTermInCtx(ctx, LVar(LBVar(i)))
      | LTermInCtx(_,tm) -> LTermInCtx(ctx, metavars_to_bvars ctx metaN tm)
      | _ -> failwith "metavars_to_bvars_modal"
  in

  let replace ((_,_,metaenv,ctxenv,_) as env) tac ctx params =
    
    nowarn let CCtxTerm(ctxaslist) = ctx in
    nowarn let LCtxAsList(ctx) = ctxaslist in
    let ctxN = List.length ctx in
    let metaN = List.length metaenv in

    let newctx_before = ExtList.foldindex
      (fun i mt ctx ->
	 nowarn let LTermInCtx(_,lt) = mt in
	 let lt' = MetabindLterm.close_down ~howmany:i i lt in
	 let lt'' = metavars_to_bvars ctx i lt' in
	   List.append ctx [(None, lt'')])
      ctx
      (List.rev metaenv)
    in
    nowarn let LCtxAsList(newctx) = nullify_ctxs_lctxdesc ctxenv (LCtxAsList(newctx_before)) in
    
    let params'  = List.map (function CHolTerm(t) -> metavars_to_bvars_modal newctx_before metaN t | _ -> failwith "replace params in preeval") params in
    let params'' = List.map (nullify_ctxs_lmodal ctxenv) params' in
    let preeval = cappmany tac ((CCtxTerm(LCtxAsList(newctx))) ::
				(List.map (fun x -> CHolTerm(x)) params'')) in

    let idsubst n = List.map (fun i -> LVar(LBVar(i + (ctxN - n)))) (decreasing n) in
    nowarn let LTermInCtx(_,LModal(_,ctxsubst)) = nullify_ctxs_lmodal ctxenv (LTermInCtx(ctx,LModal(LBMeta(0),idsubst (List.length ctx)))) in

    let metasubsts =
      ExtList.mapi (fun i mt -> nowarn let LTermInCtx(ctx',_) = mt in
		             LModal( LBMeta(metaN - i - 1), idsubst (List.length ctx') ))
	(List.rev metaenv)
    in
    let res = 
      CPack( CHolTerm(LTermInCtx( ctx, LModal( curbvar env , List.append ctxsubst metasubsts ))) ,
	     (None,CHol), CUnitType ,
	     CUnitExpr )
    in
      preevals := preeval :: !preevals;
      res
  in
  let body = 
    cterm_map_env ~cpreeval:(fun env tac ctx params _ _ _ ->
			       replace env tac ctx params)
      (!Logic_main.logic_global_env, !comp_global_env, [], [], [])
      e
  in
  let unpackmany lst body =
    List.fold_left
      (fun cur what -> CUnpack(what,(None,CHol),(None,CType),cur))
      body lst
  in
    unpackmany (List.rev !preevals) body


let comp_gettype ?(expected=None) e =
  let _, e' = comp_gettype ~expected:expected e in
  let e'' = comp_lift_preevals e' in
  let tp, e''' = Comp_typing.comp_gettype ~expected:expected e'' in
    normalize_cterm tp, e'''

let comp_eval_normal e =
  let _, e = comp_gettype e in
  let v = Comp_eval.eval ~trusted:false !Logic_main.logic_global_env !comp_global_env e in
    v

let comp_eval_opt e =
  let _, e = comp_gettype e in
  let v = Comp_eval.eval ~trusted:true !Logic_main.logic_global_env !comp_global_env (comp_discard_proofobjects e) in
    v

let comp_print_eval e =
  fprintf std_formatter "%a@ -->@ %a@\n" pr_cterm e pr_cterm (comp_eval_normal e)

let comp_print_eval_opt e =
  fprintf std_formatter "%a@ -->@ %a@\n" pr_cterm e pr_cterm (comp_eval_opt e)

let comp_define name tm =
  let tp, tm = comp_gettype tm in
  let tm' = comp_eval_normal tm in
  let tm_opt = comp_eval_opt tm in
  comp_global_env := cterm_def_add_trusted name tm' tm_opt tp false !Logic_main.logic_global_env !comp_global_env

let comp_define_typed name tm tp =
  let tp', tm = comp_gettype tm ~expected:(Some tp) in
  (if true || ctype_equal (!Logic_main.logic_global_env, !comp_global_env, [], [], []) tp tp' then
     let tm' = comp_eval_normal tm in
     let tm_opt = comp_eval_opt tm in
       comp_global_env := cterm_def_add_trusted name tm' tm_opt tp' false !Logic_main.logic_global_env !comp_global_env

   else
     failwith "wrong type in definition")

let comp_define_logic name tm tp =
  let tp', tm = comp_gettype tm ~expected:(Some tp) in
  nowarn let CSigma(_, CHolTerm(rtp), _) = tp in
    (match tp' with
	 CSigma(_,CHolTerm(mod_tp),CUnitType) ->
	   (let tm' = comp_eval_normal tm in
	      match tm' with
		  CPack(CHolTerm(mod_tm),_,_,_) ->
		    (Format.fprintf Format.std_formatter "defined %s : %a.@\n" name Logic_print.pr_modal rtp;
		     flush stdout;
		     Logic_main.logic_global_env := Logic_typinf.ltermdefenv_add_meta_infer name mod_tm mod_tp !Logic_main.logic_global_env)
		| _ -> failwith "error in evaluator!")
       | _ -> failwith "trying to assign name to non-lifted-logical-term")

let comp_define_opt name tm =
  let tp, tm = comp_gettype tm in
  let tm' = comp_eval_opt tm in
  comp_global_env := cterm_def_add_trusted name tm' tm' tp true !Logic_main.logic_global_env !comp_global_env

let comp_define_typed_opt name tm tp =
  let tp', tm = comp_gettype tm ~expected:(Some tp) in
  (if true || ctype_equal (!Logic_main.logic_global_env, !comp_global_env, [], [], []) tp tp' then
     let tm' = comp_eval_opt tm in
       comp_global_env := cterm_def_add_trusted name tm' tm' tp' true !Logic_main.logic_global_env !comp_global_env
   else
     failwith "wrong type in definition")


let comp_print_full tm = 
  let fulldelta_lterm tm =
    (lterm_map
       ~lnmeta:(fun s rf ->
	        if not (Logic_core.get_metadef_isaxiom s !Logic_main.logic_global_env) then
		  rf (Logic_core.get_metadef_term s !Logic_main.logic_global_env)
		else LNMeta(s))
       tm)
  in
  let fulldelta_lmodal mt = 
    nowarn let LModal(mt,_) = fulldelta_lterm (LModal(mt,[])) in mt
  in
  let fulldelta_lctxdesc ctx = 
    nowarn let LTermList(ctx) = fulldelta_lterm (LTermList(ctx)) in ctx
  in
  let fulldelta_cterm t =
    normalize_cterm
      (cterm_map ~cholterm:(fun t -> CHolTerm(fulldelta_lmodal t))
         ~cctxterm:(fun t -> CCtxTerm(fulldelta_lctxdesc t))
         t)
  in
  match tm with
      CNVar(s) -> Comp_print.print_cterm (fulldelta_cterm (get_cdef_term s !comp_global_env))
    | _ -> Comp_print.print_cterm (fulldelta_cterm tm)

