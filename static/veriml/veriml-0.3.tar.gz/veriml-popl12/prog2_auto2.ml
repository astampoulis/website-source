open Syntax_logic;;
open Syntax_comp;;

<<

reset.
import "prog2_rewrite_nat".

(* Hash implementation *)

let prophash = fun phi : ctx => fun res : ( @Prop ) -> CType =>
              array (option (< key : @Prop > res @key))

let mkphash = fun phi : ctx => fun res : ( @Prop ) -> CType => fun i : int =>
              mkarray( i, none _, _ ) :: ( prophash #@ res )

let phashget = fun phi : ctx => fun res : ( @Prop) -> CType => fun h : prophash #@ res =>
              fun n : @Prop =>
              let hn = arraylen h in
              letrec find : {n : @Prop} int -> (option (res @n)) =
		fun n : @Prop => fun i : int => 
		  match h.(i) with
		      som |-> unpack < n', result > = som in
                              (holcase @n as n return option (res @n) with
				  (). @n' |-> some _ result
				| ( n : @Prop ). @n |-> find ( @n ) ((i iplus 1) imod hn))
                    | non |-> none _
              in
                find ( @n ) ((hash <| @n |>) imod hn)

let phashget_uns = fun phi : ctx => fun res : ( @Prop) -> CType => fun h : prophash #@ res =>
              fun n : @Prop =>
              match phashget #@ res h @n with
		  som |-> som
		| non |-> bot _

let phashset = fun phi : ctx => fun res : ( @Prop) -> CType => fun h : prophash #@ res =>
              fun n : @Prop => fun r : res @n =>
              let hn = arraylen h in
              letrec find : (int -> Unit) =
		fun i : int => 
		  match h.(i) with
		      som |-> unpack < n', result > = som in
                              (holcase @n' as n' return Unit with
				  (). @n |-> h.(i) <- ( some _ ( < @n , r > :: < n : @?? > res @n ) )
				| ( ?n : @Prop ). @n |-> find ((i iplus 1) imod hn))
                    | non |-> h.(i) <- ( some _ ( < @n , r > :: < n : @?? > res @n ) )
              in
                find ((hash <| @n |>) imod hn)

(* Set implementation *)

let propset = fun phi : ctx => (prophash #@ (fun n : @Prop => Unit)) * (list hol( @Prop))
let mkpset = fun phi : ctx => fun i : int =>
             tup( mkphash #@ _ i, nil _ ) :: ( propset #@ )

let psetmem = fun phi : ctx => fun s : propset #@ => fun P : @Prop =>
             (match phashget #@ _ (fst s) @P with
		  som |-> true
		| none |-> false)

let psetadd = fun phi : ctx => fun s : propset #@ => fun n : @Prop =>
             (match phashget #@ _ (fst s) @n with
		  som |-> s
		| non |-> ((phashset #@ _ (fst s) @n unit);
		           tup(fst s, cons _ <| @n |> (snd s))))
let psetfold = fun a : CType => fun phi : ctx =>  
              fun f : {?n : @Prop}(a -> a) => fun start : a => fun s : propset #@ =>
              listfold _ _
	      (fun st : a => fun n : hol( @Prop) =>
		  unpack < n, unused > = n in
		  f ( @n ) st)
	      start
	      (snd s)

let psetiter = fun phi : ctx =>
              fun f : ( @Prop) -> Unit =>
              fun s : propset #@ =>
              psetfold _ #@ (fun n : @Prop => fun unused : Unit => f @n) unit s

let psetunion = fun phi : ctx => fun s1 : propset #@ => fun s2 : propset #@ =>
               psetfold _ #@
	       (fun n : @Prop => fun s : propset #@ => psetadd #@ s @n)
	       s1
	       s2

let hyptype = fun phi : ctx => < H : @Prop >hol( @H )
let hyplist_t = fun phi : ctx => list (hyptype #@ )

let gatherhyps = 
  fun rewriter : rewriter_t =>
  letrec gatherhyps : {phi : ctx} hyplist_t #@ =
  fun phi : ctx =>
    ctxcase #@ as phi' return hyplist_t #[phi'] with
	().().[] |-> nil ( hyptype #@ )
      | (phi0 ).(P : [ phi0 ].Prop).
	  [ phi0 , pf : P ] |->
	  (let @ = #[phi0] in
	   let res = gatherhyps #@ in
	   unpack < Peq, pfPPeq, unused > = rewriter #@  @Prop @P in
	   nu pf : P in
           cons _
	     ( < @Peq/[id_phi0] , eq_change #@ @?? @?? <| @pf |> <| @pfPPeq/[id_phi0] |> >
	       :: ( hyptype #@ ) )
	     res )
      | (phi0 ).(T : [phi0].Set).[ phi0, t : T ] |->
	  gatherhyps #[phi0]
      | (phi0 ).().[ phi0, t : Set] |->
	  gatherhyps #[phi0]
  in
  gatherhyps

(* A simple tauto-like tactic. Keeps a list of hypotheses, and a set of visited goals (in order
   to avoid loops). *)

let autoprove =
  fun rewriter : rewriter_t, equaltester : equaltester_t =>
  letrec maybeprove_visited :
    { phi : ctx, P : @Prop } propset #@ -> option (hol( @P)) =
    fun phi : ctx => fun P : @Prop => fun visited : propset #@ =>
    if psetmem #@ visited @P then
      none _
    else
    holcase @P as P return option (hol( @P)) with

	( A : @Set, P' : [ @ , x : A ].Prop). @forall x : A, P' |->
          do return ( hol(  @P ) ) {
	    prf <- nu x : A in maybeprove #@ @P' ;;
	    return (
	      unpack < prf, unused > = prf in
              <| @fun x : A => prf |>
	    )
	  }

      | (P1 : @Prop, P2 : @Prop). @ P1 -> P2 |->
          maybeprove_with_hyp #@ @P1 @P2

      | (P1 : @Prop, P2 : @Prop). @and P1 P2 |->
          do return (hol( @and P1 P2 )) {
	    prf1 <- maybeprove_visited #@ ( @P1 ) visited ;;
	    prf2 <- maybeprove_visited #@ ( @P2 ) visited ;;
	    return (
	      unpack < prf1, unused > = prf1 in
              unpack < prf2, unused > = prf2 in
              <| @andIntro ?? ?? prf1 prf2 |>
	   )
	  }

      | (P1 : @Prop, P2 : @Prop). @or P1 P2 |->
	  (let prf1 = maybeprove_visited #@ ( @P1) visited in
	   let prf2 = maybeprove_visited #@ ( @P2) visited in
	   match prf1 with
	       som |-> (unpack < prf1, unused > = som in
		        some _ <| @orIntro1 ?? ?? prf1 |>)
	     | non |->
	       (match prf2 with
		   som |-> (unpack < prf2, unused > = som in
		            some _ <| @orIntro2 ?? ?? prf2 |>)
			  | non |-> none _))

      | (). @True |->
	   some _ <| @trueIntro |>
	       
      | (T : @Set, t1 : @T, t2 : @T). @t1 = t2 |->
	   equaltester #@ @T @t1 @t2

      | (P : @Prop). @P |->
	  (let res = findhyp #@ (psetadd #@ visited @P) @P in
	   match res with
	       som |-> res
	     | non |-> (match findhyp #@ (psetadd #@ visited @P) @False with
	  	         som |-> unpack < fals, u > = som in
	                         some _ <| @falseElim ?? fals |>
                        | non |-> res))


  andrec maybeprove : 
    { phi : ctx, P : @Prop } option (hol( @P )) =

    fun phi : ctx => fun P : @Prop =>
    maybeprove_visited #[phi] ( @P ) (mkpset #@ STANDARD_HASH_SIZE)

  andrec maybeprove_with_hyp :

    { phi : ctx, H : @Prop, G : @Prop } option (hol( @H -> G )) =
    fun phi : ctx, H : @Prop, G : @Prop =>
    holcase @H as H return option(hol( @H -> G )) with

      (P1 : @Prop, P2 : @Prop). @and P1 P2 |->
	(do return _ {


	   prfG <- maybeprove_with_hyp #@ ( @P1 ) ( @P2 -> G ) ;;
	   return (
	     unpack < prfG, u > = prfG in
	     <| @fun pf : and P1 P2 =>
	           prfG/[id_phi] (andElim1 ?? ?? pf) (andElim2 ?? ?? pf) |>)

	 })

      | (P1 : @Prop, P2 : @Prop). @or P1 P2 |->
	(do return _ {
	   prf1 <- maybeprove_with_hyp #@ ( @P1 ) ( @G ) ;;
	   prf2 <- maybeprove_with_hyp #@ ( @P2 ) ( @G ) ;;
	   return (
	     unpack < prf1 , u > = prf1 in
	     unpack < prf2 , u > = prf2 in
	     <| @fun pf : or P1 P2 =>
		 orElim ?? ?? ?? pf (fun x => prf1/[id_phi] x)
		                    (fun x => prf2/[id_phi] x)
		 |>)
	 })

      | (H : @Prop). @H |->

	  (do return _ {
	     pf <- nu pfH : H in ( maybeprove #@ ( @G/[id_phi] ) ) ;;
	     return (
	       unpack < pf, u > = pf in
	       <| @ fun pfh : H => pf |> )
	   })

  andrec autoprove :
    { phi : ctx, P : @Prop } hol( @P ) =
    fun phi : ctx, P : @Prop =>
    match maybeprove #@ @P with
	som |-> som
      | non |-> (print "failure to prove with auto:\n");
	        (print <| @P |>);
		bot (hol( @P ))

  andrec findhyp :
    { phi : ctx, visited : propset #@, P : @Prop }option (hol( @P )) =
    fun phi : ctx, visited : propset #@, P : @Prop =>

    let l = gatherhyps rewriter #@ in
    let mayOR = fun s : option (hol( @P )) =>
               fun f : Unit -> option (hol( @P )) =>
               match s with som |-> s | non |-> f unit in
    let mayEQ = fun P : @Prop, P' : @Prop, pf : @P' =>
               match equaltester #@ @Prop @P @P' with
		   som |-> (unpack < pfPP', unused > = som in
		            some _ <| @leibn (fun P : Prop => P) (symm pfPP') pf |>)
		 | non |-> none _
    in
    let mayDO = fun P0 : @Prop , s : option (hol( @P0 )) ,
                    f : {pf : @P0 } option (hol( @P )) =>
                match s with
		    som |-> (unpack < pf , unused > = som in f @pf)
		  | non |-> none _
    in

    listfold
    (hyptype #@ )
    (option (hol( @P )))
    (fun s : option (hol( @P )) => fun e : hyptype #@ =>
	unpack < P0 , pf0 , unused > = e in
	mayOR s
	(fun u : Unit =>
	 mayOR (mayEQ @P @P0 @pf0)
	       (fun u : Unit => 
		mayOR
	       (holcase @P0 as P0 return option (hol( @P )) with
	 	    (H : @Prop, G : @Prop).
		      @H -> G |->
		      mayDO @?? (mayEQ ( @H -> P) ( @H -> G) @pf0)
			(fun pf0 : @?? =>
			    match maybeprove_visited #@ ( @H ) visited with
				som |-> (unpack < pf , unused > = som in
				         some _ <| @pf0 pf |> )
			      | non |-> none _ )
		  | (P' : @Prop). @P' |-> none _)
	       (fun u : Unit =>
		holcase @P0 as P0 return option (hol( @P )) with
	 	    (H1 : @Prop, H2 : @Prop, G : @Prop).
		      @H1 -> H2 -> G |->
		      mayDO @?? (mayEQ ( @H1 -> H2 -> P) ( @H1 -> H2 -> G) @pf0)
			(fun pf0 : @?? =>
   			    match maybeprove_visited #@ ( @and H1 H2) visited with
				som |-> unpack < pf, u > = som in
		                        some _ <| @pf0 (andElim1 H1 H2 pf) (andElim2 H1 H2 pf) |>
                              | non |-> none _ )

		  | (P' : @Prop). @P' |-> none _ ))))
      ( none _ )
      l
  in
  fun phi : ctx , P : @Prop =>
      (DEBUGPRINT "proving using auto:\n");
      (DEBUG (fun u : Unit => print <| @P |>));
      let res = autoprove #@ @P in (* (print res); *) res

let def_auto = autoprove def_rewr def_iseq

ExtDefinition test_auto1 : [].forall (x y z : Nat) (P : Nat -> Prop), (and (x = y) (and (y = z) (P x)) -> P z) := Auto.


save "prog2_auto".

>>;;
