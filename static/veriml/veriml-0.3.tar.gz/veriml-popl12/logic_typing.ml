open Utils
open Logic_ast
open Logic_core
open Logic_print

let impredicative_set = ref false

let add_to_env (fenv, defenv, metaenv, ctxenv) tp =
  let fenv' = tp :: fenv in
  (* let fenv'' = List.map (BindLterm.bumpup_fvar 1) fenv' in *)
    (fenv', defenv, metaenv, ctxenv)  (* assuming meta-variables cannot refer to free variables. *)

(* let rec get_idef_args defenv tm = *)
(*   monadic option_monad in begin *)
(*     match gather_app (whnf defenv tm) with *)
(* 	LAppMany(hd, args) when is_inddef defenv hd -> cmd { return (hd, args) } *)
(*       | _ -> cmd { x <- whdelta defenv tm then res <- get_idef_args defenv x then return res } *)
(*   end *)
	  
let rec type_of_lterm ((fenv, defenv, metaenv, ctxenv) as env : lterm_env) (e : lterm) =
  let n = List.length fenv in
  match e with
      LSort(LSet)  -> LSort(LType)
    | LSort(LProp) -> LSort(LSet)
    | LSort(LType) -> failwith "LType has no type"
    | LVar(LBVar i) -> failwith "accessing type of bound var -- shouldn't happen!"
    | LVar(LFVar i) -> List.nth fenv (List.length fenv - i - 1)
	
(* special handling of equality *)
    | LApp(LVar(LNVar(eq)), t) when eq = "eq" ->
	let tp = type_of_lterm env t in
	let thistp = LPi(None,mk_inferred (),tp,LSort(LProp)) in
	let _ = type_of_lterm env thistp in
	  thistp

    | LApp(LVar(LNVar(refl)), t) when refl = "refl" ->
	let tp = LApp(LApp(LVar(LNVar("eq")), t), t) in
	let _ = type_of_lterm env tp in
	  tp

    | LApp(LVar(LNVar(symm)), t) when symm = "symm" ->
	begin
	let tp = type_of_lterm env t in
	  match whnf defenv tp with
	      LApp(LApp(LVar(LNVar(eq)), t1), t2) when eq = "eq" ->
		LApp(LApp(LVar(LNVar(eq)), t2), t1)
	    | _ -> failwith "symmetricity used on wrong term"
	end

    | LApp(LApp(LVar(LNVar(trans)), t1), t2) when trans = "trans" ->
	begin
	let tp1 = type_of_lterm env t1 in
	let tp2 = type_of_lterm env t2 in
	  match whnf defenv tp1, whnf defenv tp2 with
	      (LApp(LApp(LVar(LNVar(eq)), t1), t2), LApp(LApp(LVar(LNVar(eq')), t2'), t3)) when eq = "eq" && eq' = "eq" && lterm_equal defenv n t2 t2' ->
		LApp(LApp(LVar(LNVar(eq)), t1), t3)
	    | _ -> failwith "transitivity used on wrong terms"
	end

    | LApp(LApp(LApp(LVar(LNVar(leibn)), (LLambda(_, _, tp, tm) as e)), pf'), pf) when leibn = "leibn" ->
	begin
	let ewf = type_of_lterm env e in
	let _ = if lterm_equal defenv n ewf (LPi(None,mk_inferred (), tp, LSort(LProp))) then () else failwith "in leibniz, the P argument should be a one-place predicate" in
	let pftp = type_of_lterm env pf in
	let pftp' = type_of_lterm env pf' in
	  match whnf defenv pftp' with
	      LApp(LApp(LVar(LNVar(eq)), t1), t2) when eq = "eq" ->
		(if lterm_equal defenv n pftp (BindLtermS.subst_bound t1 tm) then
		   BindLtermS.subst_bound t2 tm
		 else
		   failwith "in leibniz, terms or proof object of incorrect type")
	    | _ -> failwith "in leibniz, equality term of wrong type"
	end

    | LApp(LVar(LNVar(lameq)), pf) when lameq = "lameq" ->
	begin
	  let pftp = type_of_lterm env pf in
	  let pfk = type_of_lterm env pftp in
	    match whnf defenv pfk with
		LSort(LProp) ->
		  (match whnf defenv pftp with
		       LPi(var,_,tp,LApp(LApp(LVar(LNVar(eq)),t1),t2)) when eq = "eq" ->
			 LApp(LApp(LVar(LNVar(eq)),LLambda(var,mk_inferred (),tp,t1)),(LLambda(var,mk_inferred (),tp,t2)))
		     | _ -> failwith "wrong type for proof in lameq application")
	      | _ -> failwith "wrong term applied to lameq -- need forall proposition"
	end

    | LApp(LVar(LNVar(foralleq)), pf) when foralleq = "foralleq" ->
	begin
	  let pftp = type_of_lterm env pf in
	  let pfk = type_of_lterm env pftp in
	    match whnf defenv pfk with
		LSort(LProp) ->
		  (match whnf defenv pftp with
		       LPi(var,_,tp,LApp(LApp(LVar(LNVar(eq)),t1),t2)) when eq = "eq" ->
			 LApp(LApp(LVar(LNVar(eq)),LPi(var,mk_inferred (),tp,t1)),(LPi(var,mk_inferred (),tp,t2)))
		     | _ -> failwith "wrong type for proof in foralleq application")
	      | _ -> failwith "wrong term applied to foralleq -- need forall proposition"
	end		

    | LApp(LApp(LVar(LNVar(beta)), (LLambda(_, _, tp, tm) as e)), e2) when beta = "beta" ->
	begin
	  let _ = type_of_lterm env e in
	  let thistp = LApp(LApp(LVar(LNVar("eq")), LApp(e,e2)),BindLtermS.subst_bound e2 tm) in
	  let _ = type_of_lterm env thistp in
	    thistp
	end

    | LApp(LVar(LNVar(metaunfold)), (LModal(LNMeta(s), subst) as e))
	when (metaunfold = "metaunfold" && not (get_metadef_isaxiom s defenv)) ->
	begin
	  let _  = type_of_lterm env (LApp(LApp(LVar(LNVar("eq")),e),e)) in
	  let unfolded = modal_apply_subst (get_metadef_term s defenv) subst in
	    LApp(LApp(LVar(LNVar("eq")), e), unfolded)
	end

(* ok, equality done *)

    | LVar(LNVar i) -> get_def_type i defenv
    | LPi(var, k, t1, t2) ->
	let t1_t = type_of_lterm env t1 in
	let env' = add_to_env env t1 in
	let t2' = BindLterm.open_up n t2 in
	let t2_t = type_of_lterm env' t2' in
	  begin
	    match whnf defenv t1_t, whnf defenv t2_t with
	    	LSort(LProp), LSort(LProp) -> inferred_is k LProp; LSort(LProp)
	      | LSort(LSet), LSort(LSet) -> inferred_is k LSet; LSort(LSet)
	      | LSort(LSet), LSort(LProp) -> inferred_is k LSet; LSort(LProp)
	    	  (* impredicative Set? *)
	      | LSort(LType), LSort(LType) when !impredicative_set -> inferred_is k LType; LSort(LType)
	      | LSort(LType), LSort(LSet)  when !impredicative_set -> inferred_is k LType; LSort(LSet)
	      | LSort(LType), LSort(LProp) when !impredicative_set -> inferred_is k LType; LSort(LProp)
		  
	      | _ -> failwith ("invalid type " ^ (string_of_lterm e))
	  end
    | LLambda(var, k, t1, e2) ->
	let env' = add_to_env env t1 in
	let t2 = type_of_lterm env' (BindLterm.open_up n e2) in 
	let tp = LPi(var, k, t1, BindLterm.close_down (n+1) t2) in
	let _ = type_of_lterm env tp in
	  tp
    | LApp(e1, e2) ->
	let t1 = type_of_lterm env e1 in
	let t2 = type_of_lterm env e2 in
	  begin
	    match whnf defenv t1 with
		LPi(_, _, t, t') ->
		  if lterm_equal defenv n t2 t then
		    BindLtermS.subst_bound e2 t'
		  else
		    failwith ("types don't match: " ^ (string_of_lterm t) ^ " and " ^ (string_of_lterm t2))
	      | _ ->
		  failwith ("expected Pi type, got " ^ (string_of_lterm t1))
	  end
    | LInd(idef) -> failwith "ind thrown out"  (* term_of_idef env idef *)
    | LCtor(id, i) ->
	failwith "ind thrown out"
	(* let id' = fullwhdelta defenv id in *)
	(* if is_inddef defenv id' then *)
	(*   begin *)
	(*     let _ = type_of_lterm env id in *)
	(*     let LIndDef(_,arity, constrs) = get_inddef defenv id' in *)
	(*       constr_to_term id (List.nth constrs i) *)
	(*   end *)
	(* else *)
	(*   failwith ("constructor used on a non-inductive term" ^ (string_of_lterm id)) *)
    | LModal(mt, subst) ->
	(let mt_t = type_of_modal env mt in
	 let rec getctx mt_t =
	   match mt_t with
	       LTermInCtx(ctx, _) -> ctx
	     | _ -> getctx (type_of_modal env mt_t)
	 in
	 let ctx = getctx mt_t in
	 let _ = type_of_subst_is env subst ctx in
	 (* let _ = *)
	 (*   match mt_t with *)
	 (*       LTermInCtx(ctx, _) -> type_of_subst_is env subst ctx *)
	 (*     | _ -> failwith ("can't handle metavariable-typed metavariables yet") in *)
	   modal_apply_subst mt_t subst)
    | LTermList(ctx) ->
	failwith "asking type of context inside type_of_lterm!"
    | LElim(res, idtm, branches) ->
	failwith "ind thrown out"
	(* begin *)
	(*   match get_idef_args defenv (type_of_lterm env idtm) with *)
	(*       Some(idefterm, args) -> *)
	(* 	let LIndDef(_,LArity(params, sort), constrs) as idef = get_inddef defenv idefterm in *)
	(* 	let paramsnum = List.length params in *)
	(* 	let resf = *)
	(* 	  match sort with *)
	(* 	      LProp -> (\* noDep(Prop, Prop) -- this could also be Dep(Prop, Prop) though that's not used often *\) *)
	(* 		let rest = type_of_lterm env res in *)
	(* 		if lterm_equal defenv n rest (pimany params (LSort(LProp))) then *)
	(* 		  (fun args tm -> appmany res args) *)
	(* 		else *)
	(* 		  failwith ("type for result of elimination is not correct " ^ (string_of_lterm rest)) *)
	(* 	    | LSet -> *)
	(* 		let rest = type_of_lterm env res in *)
	(* 		(\* noDep(Set,Set) *\) *)
	(* 		if lterm_equal defenv n rest (pimany params (LSort(LSet))) then *)
	(* 		  (fun args tm -> appmany res args) *)
	(* 		(\* Dep(Set,Prop) *\) *)
	(* 		else if lterm_equal defenv n rest (pimany (List.append params [(None,appmany idefterm (boundlist paramsnum))]) *)
	(* 						   (LSort(LProp))) then *)
	(* 		  (fun args tm -> LApp(appmany res args, tm)) *)
	(* 		else *)
	(* 		  failwith ("type for result of elimination is not correct " ^ (string_of_lterm rest)) *)
	(* 	    | _ -> failwith ("shouldn't happen") *)
	(* 	in *)
	(* 	let check_branch i =  *)
	(* 	  let branch_type = type_of_lterm env (List.nth branches i) in *)
	(* 	  let branch_expected = type_for_elim_branch idef idefterm (List.nth constrs i) resf (LCtor(idefterm, i)) in *)
	(* 	    lterm_equal defenv n branch_type branch_expected *)
	(* 	in *)
	(* 	let n = List.length branches in *)
	(* 	  if List.length constrs = n then *)
	(* 	    (if List.for_all check_branch (increasing n) then *)
	(* 	       whnf defenv (resf args idtm) *)
	(* 	     else *)
	(* 	       failwith ("some branch with wrong type")) *)
	(* 	  else *)
	(* 	    failwith ("number of elimination cases and constructors do not match") *)
	(*     | None -> failwith ("elimination applied to non-inductive term "^ (string_of_lterm idtm)) *)
	(* end *)
    | LInfer(el, f) ->
	failwith "infer-placeholder shouldn't be visible at this point!"
	
and term_of_idef ((fenv, defenv, metaenv, ctxenv) as env : lterm_env) (idef : linddef) =
  let n = List.length fenv in
  let LIndDef(s, (LArity(params, sort) as arity), constrs) = idef in
  let ideftp = arity_to_term arity in
  let _ = type_of_lterm env ideftp in
  let check_constr constr =
    let tp = constr_to_term (LVar (LFVar (List.length fenv))) constr in
    let sort' = type_of_lterm (add_to_env env ideftp) tp in
      lterm_equal defenv (n+1) (LSort(sort)) sort'
  in
    if (List.for_all check_constr constrs) then
      ideftp
    else
      failwith ("some constructor is ill-typed for " ^ (string_of_lterm (LInd(idef))))
and type_of_modal ((fenv, defenv, metaenv, ctxenv) : lterm_env) (mt : lmodalterm) =
  match mt with
      LTermInCtx(ctx,lt) ->
	(let _ = ctx_wf ([], defenv, metaenv, ctxenv) (LCtxAsList(ctx)) in
	 let newfenv, openlt = terminctx_open_up ctx lt in
	 let tp = type_of_lterm (newfenv, defenv, metaenv, ctxenv) openlt in
	   terminctx_close_down ctx tp)
    | LFMeta(i) -> List.nth metaenv (List.length metaenv - i - 1)
    | LBMeta(i) -> failwith ("accessing bound meta variable while type checking -- shouldn't happen")
    | LNMeta(s) -> get_metadef_type s defenv
and type_of_subst_is ((fenv, defenv, metaenv, ctxenv) as env: lterm_env) (subst : lsubst) (ctx : lctx) =
  match subst, ctx with
      [], [] -> true
    | (shd::stl), ((_,chd)::ctl) ->
	let shd_t = type_of_lterm env shd in
	let ctx' = BindCtxS.subst_bound shd ctl in
	let _ = if not (lterm_equal defenv (List.length fenv) shd_t chd) then
	  failwith ("subst and context do not match in type!") in
	  type_of_subst_is env stl ctx'
    | _, _ -> failwith ("subst and context do not match in size")
and ctx_wf ((fenv, defenv, metaenv, ctxenv) as env : lterm_env) (ctx : lctxdesc) =
  match ctx with
      LFCtx(i) -> List.nth ctxenv (List.length ctxenv - i - 1)
    | LBCtx(i) -> failwith "getting type of bound context variable"
    | LCtxAsList(l) ->
	ignore
	  (List.fold_left (fun ((fenv, _, _, _) as curenv,n) (_,elm) ->
			     let elm = BindLterm.open_up ~howmany:n 0 elm in
			     valid_ctxelem curenv elm;
			     (add_to_env curenv elm, n+1))
	     (env,0) l)
and valid_ctxelem ((fenv, defenv, metaenv, ctxenv) as env) (ctxelem : lterm) =
  match ctxelem with
      LTermList(LCtxAsList(_)) -> failwith "nested context lists are not allowed!"
    | LTermList(ctx) -> ctx_wf env ctx
    | t -> ignore(type_of_lterm env t)

let ltermdefenv_empty = (Dict.empty, Dict.empty)

let ltermdefenv_add_term name tm expected_tp (defenv : lterm_defenv) =
  let tp = type_of_lterm ([],defenv,[],[]) tm in
  let add name what (defenv,d2) =
    (if Dict.mem name defenv then
       failwith ("definition " ^ name ^ " already exists")
     else
       (Dict.add name what defenv,d2))
  in    
    if lterm_equal defenv 0 tp expected_tp then
      add name expected_tp defenv
    else
      failwith ("the term's type doesn't match the definition type" ^ (string_of_lterm tm))

let ltermdefenv_add name tp (defenv : lterm_defenv) =
  let _ = type_of_lterm ([],defenv,[],[]) tp in
  let add name what (defenv,d2) =
    (if Dict.mem name defenv then
       failwith ("definition " ^ name ^ " already exists")
     else
       (Dict.add name what defenv,d2))
  in
    add name tp defenv

let ltermdefenv_add_meta name tm ?(expected_tp=None) (defenv : lterm_defenv) =
  let tp = type_of_modal ([],defenv,[],[]) tm in
  let add name what (d1,defenv) =
    (if Dict.mem name defenv then
       failwith ("definition " ^ name ^ " already exists")
     else
       (d1,Dict.add name what defenv))
  in    
    match expected_tp with
	Some((LTermInCtx(_,_)) as expected_tp) ->
	  (if lmodal_equal defenv 0 tp expected_tp then
	     add name (expected_tp, Some tm) defenv
	   else
	     failwith ("the term's type doesn't match the definition type"))
      | Some(_) -> failwith ("metavariables should have non-metavariable type")
      | None ->
	  add name (tp, Some tm) defenv

let ltermdefenv_add_meta_axiom name tp (defenv : lterm_defenv) =
  let tp' = type_of_modal ([],defenv,[],[]) tp in
  let add name what (d1,defenv) =
    (if Dict.mem name defenv then
       failwith ("definition " ^ name ^ " already exists")
     else
       (d1,Dict.add name what defenv))
  in    
    match tp' with
	LTermInCtx(_,LSort(_)) ->
	  add name (tp, None) defenv
      | _ ->
	failwith ("the meta-axiom does not have a valid type")

let ltermenv_empty def = ([], def, [], [])

let check_pattern defenv ctx patvars pat =

  let is_whnf ctx e = true (* let _, e' = terminctx_open_up ctx e in (whnf defenv e' = e') *) in
  let rec is_decreasing_bound curmax subst =
    match subst with
	[] -> true
      | LVar (LBVar hd) :: tl -> hd = curmax - 1 && is_decreasing_bound hd tl
      | _ -> false
  in
  let rec aux (ctx : lctx) (cur : int) (pat : lterm) =

    (require (is_whnf ctx pat) "pattern should be in normal form");
    (match pat with
	 LModal(LBMeta(i), subst) ->
	   (* (require (i = cur - 1) "pattern variables should be used in increasing order"); *)
	   (require (is_decreasing_bound (List.length ctx) subst) "substitutions used in pattern variables should only mention free variables in increasing order");
	   cur - 1

       | LModal(LNMeta(s), subst) ->
	   List.fold_left (fun cur elm -> aux ctx cur elm) cur subst

       | LLambda(s, k, a, b) ->
	   (let cur'  = aux ctx cur a in
	    let cur'' = aux (List.append ctx [(s,a)]) cur' b in
	      cur'')

       | LPi(s, k, a, b) ->
	   (let cur'  = aux ctx cur a in
	    let cur'' = aux (List.append ctx [(s,a)]) cur' b in
	      cur'')

       | LApp(a, b) ->
	   (let cur' = aux ctx cur a in
	    let cur'' = aux ctx cur' b in
	      cur'')

       | e ->
	   ignore (lterm_map ~lbmeta:(fun i -> failwith "invalid pattern -- pattern variable shows up where it shouldn't") e);
	   cur
    )
  in
  let _ = aux ctx patvars pat in
    (* require (^^ the above, if calculated properly ^^ patvars_unused = 0) "not all pattern variables are used" *)
    ()

(* metavars should be with ctxvars still bound *)
(* pat is a (string * lterm) list *)
let check_context_pattern defenv ctxfenv ctxvars metavars pat =
  match pat with
      [ (_, LTermList(LBCtx(0))); (_, typat) ] ->
	(let typat = CtxbindLterm.open_up ctxfenv typat in
	   (require (List.length ctxvars = 1) "not right number of context pattern variables defined");
	   check_pattern defenv [ (None, LTermList(LFCtx(ctxfenv))) ] (List.length metavars) typat)

    | [ (_, LTermList(LBCtx(0))) ] ->
	(require (List.length ctxvars = 1) "not right number of context pattern variables defined");
        (require (List.length metavars = 0) "more context pattern variables defined than used")

    | [ (_, (LTermList(ctx) as t') ) ] ->
        (require (not (CtxbindLterm.has_bound_var 0 t')) "pattern not allowed");
        (require (List.length ctxvars = 0) "more context pattern variables defined than used");
        (require (List.length metavars = 0) "more context pattern variables defined than used")

    | ctx' ->
        (require (not (CtxbindLterm.has_bound_var 0 (LTermList(LCtxAsList(ctx'))))) "pattern not allowed");
        (require (List.length ctxvars = 0) "more context pattern variables defined than used");
        (require (List.length metavars = 0) "more context pattern variables defined than used")

exception NoPatternMatch
let pattern_match_term defenv ?(ctx = []) ?(check = false) patvars pat e =

  let remove_from_ctx n ctx =
    ExtList.updatenth n (None, LTermList(LCtxAsList([]))) ctx
  in

  let rec pattern_match_term (ctx : lctx) (assignment : lmodalterm map) (pat : lterm) (e : lterm) =

    let e' = whnf defenv e in

    let subst_assignment subst n assignment tm =
      List.fold_left
	(fun tm i ->
	   if (IMap.mem i assignment) then 
	     subst (IMap.find i assignment) (n - i - 1) tm
	   else
	     tm) tm (increasing n)
    in

    let typeof metaenv assignment ctx e =

      let metactx_to_metafenv ctx =
	let rec aux n ctx =
	  match ctx with
	      [] -> []
	    | hd :: tl ->
		(MetabindModal.open_up ~howmany:n 0 hd) :: (aux (n+1) tl)
	in
	  List.rev (aux 0 ctx)
      in

      let fenv, e' = terminctx_open_up ctx e in
      let metafenv = metactx_to_metafenv metaenv in
      let metafenv = List.map (subst_assignment MetabindModal.subst_fvar (List.length metafenv) assignment) metafenv in
      let e'' = MetabindLterm.open_up ~howmany:(List.length metafenv) 0 e' in
      let typ = type_of_lterm (fenv,defenv,metafenv,[]) e'' in
	BindLterm.close_down ~howmany:(List.length fenv) (List.length fenv) typ
    in

    (* TODO:: fix this properly *)
    (* in order to fill in sorts we do a type checking. of course this is not needed,
       and should be removed once the logic_core is updated properly so that it generates
       proper inferred sorts for all lambda's and pi's. *)
    let _ = 
      if check then
	match e' with
	    LPi(_,_,_,_) | LLambda(_,_,_,_) -> ignore(typeof [] assignment ctx e')
	  | _ -> ()
    in

    let pat' =
      let patopen = MetabindLterm.open_up ~howmany:(List.length patvars) 0 pat in
      let patopen' = subst_assignment MetabindLterm.subst_fvar (List.length patvars) assignment patopen in
	MetabindLterm.close_down ~howmany:(List.length patvars) (List.length patvars) patopen'
    in

      match pat', e' with

	  LModal(LBMeta(i), subst), e ->

	    let ty_pat, ty_e = typeof patvars assignment ctx pat', typeof [] assignment ctx e in
	    let assignment = pattern_match_term ctx assignment (MetabindLterm.close_down ~howmany:(List.length patvars) (List.length patvars) ty_pat) ty_e in
	      
	    let n = List.length ctx in
	    let ctx' =
	      List.fold_left
		(fun ctx0 j ->
		   let unif_allows_it = List.exists ((=) (LVar (LBVar j))) subst in
		   let term_has_it = BindLterm.has_bound_var j e in
		     if not unif_allows_it then
		       (if not term_has_it then
			  remove_from_ctx (n - j - 1) ctx0
			else
			  raise NoPatternMatch)
		     else
		       ctx0)
		ctx (increasing n)
	    in
	    let ctx', e' = flatten_term_in_context ctx' e in
	      IMap.add i (LTermInCtx(ctx',e')) assignment
		  
	| LLambda(s1, k1, a1, b1), LLambda(s2, k2, a2, b2) when true || (get_inferred k1) = (get_inferred k2) ->
	    let assignment' = pattern_match_term ctx assignment a1 a2 in
	    let assignment'' = pattern_match_term (List.append ctx [(s2,a2)]) assignment' b1 b2 in
	      assignment''
	| LPi(s1, k1, a1, b1), LPi(s2, k2, a2, b2) when true || (get_inferred k1) = (get_inferred k2) ->
	    let assignment' = pattern_match_term ctx assignment a1 a2 in
	    let assignment'' = pattern_match_term (List.append ctx [(s2,a2)]) assignment' b1 b2 in
	      assignment''
	| LApp(LModal(LBMeta(_),_),_), LApp(LVar(LNVar("eq")),_) ->
	    raise NoPatternMatch
	| LApp(a1,b1), LApp(a2,b2) ->
	    let assignment' = pattern_match_term ctx assignment a1 a2 in
	    let assignment'' = pattern_match_term ctx assignment' b1 b2 in
	      assignment''

 	| LModal(LNMeta(s), subst1), LModal(LNMeta(s'), subst2) when s = s' ->
 	    let assignment' = List.fold_left2 (fun asgn elm1 elm2 -> pattern_match_term ctx asgn elm1 elm2) assignment subst1 subst2 in
 	      assignment'

	| e1, e2 -> (let nctx = List.length ctx in
		       if lterm_equal defenv nctx
			 (BindLterm.open_up ~howmany:nctx 0 e1)
			 (BindLterm.open_up ~howmany:nctx 0 e2) then assignment else
			   raise NoPatternMatch)
  in
  let assignment = pattern_match_term ctx IMap.empty pat e in
  let subst =
    List.map
      (fun i -> try IMap.find i assignment with Not_found -> raise NoPatternMatch)
      (decreasing (List.length patvars))
  in
    subst


let context_match_term defenv metavars pat ctx =
  match pat with
      [ (_, LTermList(LBCtx(0))); (_, typat) ] ->
	(let ctx', (_, last) = try ExtList.last ctx with _ -> raise NoPatternMatch in
	 nowarn let LTermList(LCtxAsList(patctx)) = flatten_all_lterm (CtxbindLtermS.subst_bound (LCtxAsList(ctx')) (LTermList(LCtxAsList(pat)))) in
	 let _, (_, typat') = ExtList.last patctx in
	 let metavars' = List.map
	   (fun m -> flatten_all_lmodal (CtxbindModalS.subst_bound (LCtxAsList(ctx')) m)) metavars in

	 let assignment = pattern_match_term ~ctx:ctx' ~check:true defenv metavars' typat' last in
	   ([LCtxAsList(ctx')], assignment))

    | [ (_, LTermList(LBCtx(0))) ] ->
        ( [LCtxAsList(ctx)], [] )

    | ctx' ->
        (if lctxdesc_equal defenv (LCtxAsList(ctx)) (LCtxAsList(ctx')) then
	    ( [], [] )
	 else
	    raise NoPatternMatch)
