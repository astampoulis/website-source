open Camlp4.PreCast
module CAst = Comp_ast
module CCst = Comp_cst
module LCst = Logic_cst
module LMain = Logic_main
module CTyp = Comp_typing

module CompGram = Syntax_logic.LogicGram

let ident = Syntax_logic.ident
let modalterm = Syntax_logic.modalterm
let context = Syntax_logic.context
let exprlist = Syntax_logic.exprlist
let logicdef = Syntax_logic.logicdef
let lterm    = Syntax_logic.term

let ctxterm = Syntax_comp.ctxterm
let cterm = Syntax_comp.cterm
let cterm_eoi = Syntax_comp.cterm_eoi
let cterm_ast_eoi = Syntax_comp.cterm_ast
let cterm_ast_eoi = Syntax_comp.cterm_ast_eoi
let compdef = Syntax_comp.compdef
let compdef_eoi = Syntax_comp.compdef_eoi


EXTEND CompGram
  cterm: FIRST
  [  "tactics" LEFTA
      [
	"ReqEqual" ->
	<:expr< <:cc< req_iseq #@ @?? @?? @?? >> >>
      | "Exact"; e = cterm ->
        <:expr< <:cc< eq_change #@ ( @ ?? ) ( @ ?? ) ( $e$ ) ( req_iseq #@ @?? @?? @?? ) >> >>
      | "Exact"; e = cterm; "by"; e' = cterm ->
        <:expr< <:cc< eq_change #@ ( @ ?? ) ( @ ?? ) ( $e$ ) ( $e'$ ) >> >>
      | "Reflexivity" ->
        <:expr< <:cc< eq_refl #@ ( @ ?? ) ( @ ?? ) >> >>
      | "Intro"; x = ident; "in"; e = cterm ->  
	<:expr< <:cc< intro #@ ( [].?? ) ( nu $id:x$ : ?? in @?? ) (nu $id:x$ : ?? in $e$ ) >> >>
      | "Intro"; x = ident; ":"; l = lterm; "in"; e = cterm ->
	<:expr< <:cc< intro #@ ( [].?? ) ( nu $id:x$ : $l$ in @?? ) (nu $id:x$ : $l$ in $e$ ) >> >>
      | "Assume"; x = ident; ":"; l = lterm; "in"; e' = cterm ->
        <:expr< <:cc< assume #@ ( @ ( $l$ ) ) (nu $id:x$ : $l$ in @ ?? ) (nu $id:x$ : $l$ in $e'$ ) >> >>
      | "Assume"; x = ident; "in"; e' = cterm ->
        <:expr< <:cc< assume #@ ( @ ?? ) ( nu $id:x$ : ?? in @ ?? ) (nu $id:x$ : ?? in $e'$ ) >> >>
      | "Auto" ->
	<:expr< <:cc< def_auto #@ @?? >> >>
      | "ChangeGoal"; l = lterm; e = cterm ->
	<:expr< <:cc< eq_change #@ ( @ $l$ ) ( @ ?? ) ( $e$ ) ( req_iseq #@ @?? @?? @?? ) >> >>
      | "ChangeInGoal"; x = ident; "."; l = lterm;
	"from"; a = modalterm; "to"; b = modalterm;
	"by"; pf = cterm ->
        <:expr< <:cc<
	  change_leibn_goal #@ ( @ ?? ) ( @ ?? )
	  ( nu x : ?? in @ $l$ ) ( $mt:b$ ) ( $mt:a$ )
	  ( $pf$ ) ( req_iseq #@ @?? @?? @?? ) ( req_iseq #@ @?? @?? @?? )
        >> >>
      |	"NatInduction"; "for"; x = ident; "."; l = lterm;
	"base"; "case"; "by"; b = cterm;
	"inductive"; "case"; "by"; c = cterm ->
        <:expr< <:cc< nat_induction #@ ( nu $id:x$ : Nat in @ $l$ ) ( $b$ ) ( $c$ )
	               ( req_iseq #@ ( @ ?? ) ( @ ?? )  ( @ ?? ) )
	               ( req_iseq #@ ( @ ?? ) ( @ ?? )  ( @ ?? ) )
	               ( req_iseq #@ ( @ ?? ) ( @ ?? )  ( @ ?? ) ) >> >>
      |	"NatInduction";
	"base"; "case"; "by"; b = cterm;
	"inductive"; "case"; "by"; c = cterm ->
        <:expr< <:cc< nat_induction #@ ( [ @ , x : Nat]. ?? ) 
	               ( $b$ ) ( $c$ )
	               ( req_iseq #@ ( @ ?? ) ( @ ?? )  ( @ ?? ) )
	               ( req_iseq #@ ( @ ?? ) ( @ ?? )  ( @ ?? ) )
	               ( req_iseq #@ ( @ ?? ) ( @ ?? )  ( @ ?? ) ) >> >>
      | "Trivial" -> <:expr< <:cc< eq_change #@ ( @ ?? ) ( @ ?? ) <| @trueIntro |> (req_iseq #@ @?? @?? @?? ) >> >> 
      | "Instantiate"; pf = cterm; "with"; m = modalterm ->
       <:expr< <:cc< instantiate #@ ( @ ?? ) ( [ @ , x : ?? ].?? ) ( $mt:m$ ) ( $pf$ ) >> >>
      | "Cut"; x = ident; ":"; l = lterm; "by"; e = cterm; "for"; e' = cterm ->
      <:expr< <:cc< cutpf #@ ( @ ?? ) ( @ $l$ ) ( nu $id:x$ : $l$ in $e'$ ) ( $e$ ) >> >>
      | "Apply"; e = cterm; "by"; e' = cterm ->
      <:expr< <:cc< apply #@ ( @ ?? ) ( @ ?? ) ( $e$ ) ( $e'$ ) >> >>
      | "Temporary"; "Rewriter"; r = cterm; "in"; e = cterm ->
      <:expr< <:cc< ( global_rewriter_add_top ( $r$ ) ) ;
 	            ( let res = $e$ in ( global_rewriter_remove_top unit ) ; res ) >> >>
      ]
  ];
END;;

