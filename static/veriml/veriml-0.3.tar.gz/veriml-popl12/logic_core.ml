open Utils
open Resumable
open Logic_ast

let lbvar i = LVar (LBVar i)
let lfvar i = LVar (LFVar i)

(* lterm invariant:
   no BVar outside a binder *)

let appmany (lt : lterm) (l : lterm list) =
  List.fold_left (fun res cur -> LApp(res, cur)) lt l

let lammany (l : (string option * lterm) list) (lt : lterm) =
  List.fold_right (fun (s,t) res -> LLambda(s, mk_inferred (), t, res)) l lt

let pimany (l : (string option * lterm) list) (lt : lterm) =
  List.fold_right (fun (s,t) res -> LPi(s, mk_inferred (), t, res)) l lt

let boundlist (n : int) =
  List.map (fun n -> LVar (LBVar n)) (decreasing n)

(* recursive_param_to_term

   Convert a recursive parameter of a constructor into a term
   M_i is the first list of def
   m_i is the second list of def
   X is the res argument
   Pi x_0 : M_0.Pi x_1 : M_1. ... Pi x_n : M_n. X (vec x) (vec m) or
   lam x_0 : M_0. ... *)
let recursive_param_to_term (def : (string option * lterm) list * lterm list) (bindmany : (string option * lterm) list -> lterm -> lterm) (res : lterm list -> lterm list -> lterm) =
  let (bigmi, mi) = def in
  let n = List.length bigmi in
  let xvm = res (boundlist n) mi in
    bindmany bigmi xvm
let recursive_param_to_type def res = recursive_param_to_term def pimany res

(* type_for_elim_branch

   Convert a constructor into the type of the dependent branch for that constructor
   (\Pi x:P.C){X,Q,c} = \Pi p : P.\Pi prec : (\Pi vec.x : vec.P.Q vec.m (p vec.x)).C{X,Q,c p}
   (\Pi x:M.C){X,Q}=\Pi x:M.(C{X,Q,c x})
   (X vec.a){X,Q,c} = Q vec.a c  *)
let type_for_elim_branch (idef : linddef) (idefterm : lterm) (constr : lconstr) (res : lterm list -> lterm -> lterm) (c : lterm) =
  let LConstr (params, args) = constr in
  let n = List.length params in 
  let recursive =
    let rec aux i l =
      match l with
	  [] -> []
	| (_,LParNonrec(lt)) :: tl ->
	    aux (i-1) (stringlist (BindCparam.swap_bound_in_binderlist 0 i) tl)
	| (s,LParStrictPos(a,b)) :: tl ->
	    (s ^? "rec", recursive_param_to_type (a,b) (fun vars args -> res args (appmany (LVar (LBVar i)) vars))) ::
	      aux i tl
    in
      aux (n-1) params
  in
    pimany
      (List.map (function
		   | s, LParNonrec(lt) -> s, lt
		   | s, LParStrictPos(a,b) -> s, recursive_param_to_type (a,b) (fun vars args -> appmany idefterm args))
	 params)
      (pimany recursive
	 (BindLterm.shift_bound (List.length recursive) (res args (appmany c (boundlist n)))))

(* type_for_elim
   Compute the type for the elimination of idef. idef should be in beta-iota-normal form, idefterm and
   res should only have free variables (no bound variables) *)
(* dead code -- not really needed *)
(* let type_for_elim (idef : linddef) (idefterm : lterm) (res : lterm list -> lterm -> lterm) = *)
(*   let LIndDef (LArity(indexes,sort), branches) = idef in *)
(*   let n = List.length indexes in *)
(*   let k = List.length branches in *)
(*     (pimany (List.map (fun i -> type_for_elim_branch idef idefterm (List.nth branches i) res (LCtor(idefterm, i))) (increasing k)) *)
(*        (pimany indexes (LPi(None, appmany idefterm (boundlist n), *)
(* 			    let bvars = List.map (fun n -> LVar (LBVar n)) (decreasing_start n 1) in *)
(* 			      res bvars (LVar (LBVar 0)))))) *)

let cparam_to_term (idefterm : lterm) (def : lcparam) =
  match def with
      LParNonrec(lt) -> lt
    | LParStrictPos(a,b) -> recursive_param_to_type (a,b) (fun vars args -> appmany idefterm args)

let constr_to_term (idefterm : lterm) (constr : lconstr) =
  let LConstr(params, args) = constr in
  pimany (stringlist (List.map (cparam_to_term idefterm)) params)
    (appmany idefterm args)

let arity_to_term (LArity(args, s) : larity) =
  pimany args (LSort(s))

let term_for_elim_branch (idef : linddef) (idefterm : lterm) (constr : lconstr) (f_branch : lterm) (bigF : lterm) =
  let LConstr(params, args) = constr in
  let n = List.length params in
  let f_branch' = BindLterm.shift_bound n f_branch in
  let recursive =
    let rec aux i l =
      match l with
	  [] -> []
	| (s,LParNonrec(lt)) :: tl ->
	    aux (i-1) tl
	| (s,LParStrictPos(a,b)) :: tl ->
	    (recursive_param_to_term (a,b) lammany
	       (fun vars args ->
		  let m = List.length vars in
		  let bigF' = BindLterm.shift_bound m bigF in
		  let args' = List.map (BindLterm.shift_bound m) args in
		    LApp(appmany bigF' args', appmany (LVar (LBVar (i+m))) vars))) ::
	      aux (i-1) tl
    in
      aux (n-1) params
  in
    lammany (stringlist (List.map (cparam_to_term idefterm)) params)
      (appmany (appmany f_branch' (boundlist n))
	 recursive)

let iota_step (idef : linddef) (idefterm : lterm) (res : lterm) (f_branches : lterm list) (branch : int) (args : lterm list) =
  let LIndDef(s, LArity(arity, _), constrs) = idef in
  let n = List.length arity in
  let bigF = lammany arity (LLambda(None, mk_inferred (),
				    appmany idefterm (boundlist n), LElim(BindLterm.shift_bound (n+1) res,
									  LVar (LBVar 0),
									  List.map (BindLterm.shift_bound (n+1)) f_branches))) in
    appmany (term_for_elim_branch idef idefterm (List.nth constrs branch) (List.nth f_branches branch) bigF)
            args

type lterm_gathered_app = LAppMany of lterm * lterm list
type lterm_gathered_lam = LLamMany of lterm list * lterm
type lterm_gathered_pi  = LPiMany  of lterm list * lterm

let rec gather_app = function 
    LApp(e1, e2) -> (let LAppMany(e, el) = gather_app e1 in
		       LAppMany(e, List.append el [e2]))
  | e -> LAppMany(e, [])

let rec gather_lam = function
    LLambda(_, _, e1, e2) -> (let LLamMany(el, e) = gather_lam e2 in
				LLamMany(e1 :: el, e2))
  | e -> LLamMany([], e)

let rec gather_pi = function
    LPi(_, _, e1, e2) -> (let LPiMany(el, e) = gather_pi e2 in
			    LPiMany(e1 :: el, e2))
  | e -> LPiMany([], e)

let get_def_type name (dict1,dict2) = ExtDict.find name dict1
exception MetaAxiom
let get_metadef_term name (dict1,dict2) = match ExtDict.getsnd name dict2 with None -> raise MetaAxiom | Some mt -> mt
let get_metadef_type name (dict1,dict2) = ExtDict.getfst name dict2
let get_metadef_isaxiom name (dict1,dict2) = match ExtDict.getsnd name dict2 with None -> true | Some mt -> false
  
let terminctx_close_down ctx tm =
  let n = List.length ctx in
    LTermInCtx(ctx, BindLterm.close_down ~howmany:n n tm)


(* so what happens here is that we have a term that mentions fN
   as a substitution; this should be substituted by (fN, f(N+1), ... f(N+M-1)).
   also free variables after fN should be f(N+M) etc. *)
let replace_fN_in_substs n m t =
  lterm_map ~lfvar:(fun i -> LVar (LFVar (if i > n then i + (m - 1) else i)))
            ~lsubstelem:(fun tm res ->
			   match tm with
			       LVar(LFVar n) -> List.map (fun i -> LVar(LFVar (i+n))) (increasing m)
			     | _ -> [res])
    t

let rec flatten_term_in_context ctx t =
  try
    nowarn let (before, (_, LTermList(LCtxAsList(l))), after), index = ExtList.find_partition_index (function (_, LTermList(LCtxAsList(_))) -> true | _ -> false) ctx in
    let m = List.length l in
    nowarn let LTermInCtx(after', t') = BindModal.open_up ~howmany:(index+1) 0 (LTermInCtx(after, t)) in
    let after', t' = List.map (fun (s,t) -> (s,replace_fN_in_substs index m t)) after', replace_fN_in_substs index m t' in
    nowarn let LTermInCtx(after', t') = BindModal.close_down ~howmany:(index+m) (index+m) (LTermInCtx(after',t')) in
      flatten_term_in_context (List.append before (List.append l after')) t'
  with ExtList.NotFoundPartition -> (ctx, t)

let terminctx_open_up ctx tm =
  let rec aux ctx fenv lt =
    match ctx with
	[] -> (fenv, lt)
      | (s,hd) :: tl ->
	  nowarn let LTermInCtx(ctx', lt') = BindModal.open_up (List.length fenv) (LTermInCtx(tl,lt)) in
	  let fenv' = hd :: fenv in
	    aux ctx' fenv' lt'
  in
    aux ctx [] tm

let flatten_context ctx =
  let ctx', _ = flatten_term_in_context ctx (LSort(LSet)) in ctx'

let ctx_open_up ctx =
  let ctx', _ = terminctx_open_up ctx (LSort(LSet)) in List.rev ctx'

let flatten_all_lterm lt =
  lterm_map ~lterminctx:(fun ctx lt rctx rlt ->
  			   let ctx', lt' = flatten_term_in_context rctx rlt in
  			     LTermInCtx(ctx', lt'))
            ~lctxaslist:(fun ctx rctx -> LCtxAsList(flatten_context rctx))
    lt

let flatten_all_lmodal mt =
  nowarn let LModal(mt,_) = flatten_all_lterm (LModal(mt,[])) in
    mt

let flatten_all_lctxdesc ctx =
  nowarn let LTermList(ctx) = flatten_all_lterm (LTermList(ctx)) in
    ctx

(* invariant that needs to be maintained: all terms should have flattened contexts! *)
    
(*
let rec fulldelta_modal defenv e subst =
  match modal_apply_subst e subst with
      LModal(LNMeta(s), subst') when not (get_metadef_isaxiom s defenv) -> fulldelta_modal defenv (get_metadef_term s defenv) subst'
    | t -> t
*)

(*
let rec is_inddef defenv tm =
  match tm with
      LInd(_) -> true
    | LVar(LNVar(n)) -> false
    | LModal(e,subst) -> is_inddef defenv (fulldelta_modal defenv e subst)
    | _ -> false

let rec get_inddef defenv tm =
  match tm with
      LInd(idef) -> idef
    | LVar(LNVar(n)) -> failwith "no inddefs really supported"
    | LModal(e,subst) -> get_inddef defenv (fulldelta_modal defenv e subst)
    | _ -> failwith "get_inddef on non-ind.def"
*)

let whnf (defenv : lterm_defenv) =
  let rec whnf e =
    match e with
	LApp(e1, e2) -> (match whnf e1 with
			     (* LLambda(_, _, _, e) -> whnf (BindLtermS.subst_bound e2 e) *)
			   | e1' -> LApp(e1', e2))
      (* | LElim(res, ctorargs, branches) -> *)
      (* 	  (match gather_app (whnf ctorargs) with *)
      (* 	       LAppMany(LCtor(tm, i), args) when is_inddef defenv tm -> *)
      (* 		 whnf *)
      (* 		   (iota_step (get_inddef defenv tm) tm res branches i args) *)
      (* 	     | LAppMany(e, el) -> *)
      (* 		 LElim(res, appmany e el, branches)) *)
      | LModal(LTermInCtx(_,_) as modal, subst) ->
	  (whnf (modal_apply_subst modal subst))

      (* | LModal(LNMeta(s) as modal, subst) when not (get_metadef_isaxiom s defenv) ->
	  (whnf (fulldelta_modal defenv modal subst)) *)

      | LInfer(l,f) ->
	  (match !(match_lunif l) with Inst(t,_) -> whnf (f t) | _ -> e)
      | e -> e
  in
    whnf
	     

let fullwhdelta_modal (defenv : lterm_defenv) mt =
  match mt with
      LTermInCtx(ctx,t) ->
	let n = List.length ctx in
	let t' = BindLterm.open_up ~howmany:n 0 t in
	let t'' = BindLterm.close_down ~howmany:n n t' in
	LTermInCtx(ctx,t'')
    | mt -> mt

let fullnf_term (defenv : lterm_defenv) t =
  lterm_map
    ~llambda:(fun s k t1 t2 rt1 rt2 -> LLambda(None, k, rt1, rt2))
    ~lpi:(fun s k t1 t2 rt1 rt2 -> LPi(None, k, rt1, rt2))
    ~lterminctx:(fun ctx lt rctx rlt ->
		   LTermInCtx(rctx, whnf defenv rlt))
    ~lctxelem:(fun s t rt -> [(None, whnf defenv rt)])
    t

let fullnf_modal (defenv : lterm_defenv) mt =
  nowarn let LModal(mt,_) = fullnf_term defenv (LModal(mt,[])) in
    mt
      
let fullnf_ctx (defenv : lterm_defenv) ctx = 
  nowarn let LTermList(ctx) = fullnf_term defenv (LTermList(ctx)) in
    ctx


let equal_checks (defenv : lterm_defenv) =
  let rec aux n e1 e2 =
    let e1', e2' = whnf defenv e1, whnf defenv e2 in
    match e1', e2' with
	LSort(s1), LSort(s2) -> s1 = s2
      | LVar(v1), LVar(v2) when v1 = v2 -> true
      | LVar(LNVar(n1)), LVar(LNVar(n2)) when n1 = n2 -> true
      | LLambda(_, _, a1, b1), LLambda(_, _, a2, b2) -> aux n a1 a2 && aux (n+1) (BindLterm.open_up n b1) (BindLterm.open_up n b2)
      | LPi(_, _, a1, b1), LPi(_, _, a2, b2) -> aux n a1 a2 && aux (n+1) (BindLterm.open_up n b1) (BindLterm.open_up n b2)
      | LInd(i1), LInd(i2) -> i1 = i2
      | LCtor(a1,i1), LCtor(a2,i2) -> i1 = i2 && aux n a1 a2
      | LApp(a1,b1), LApp(a2,b2) when aux n a1 a2 && aux n b1 b2 -> true
      | LElim(a1,b1,c1), LElim(a2,b2,c2) when aux n a1 a2 && aux n b1 b2 && List.for_all2 (aux n) c1 c2 -> true
      | LModal(m1,s1), LModal(m2,s2) -> modalaux n m1 m2 && (* changed 8/31/2010 *) ExtList.min_for_all2 (aux n) s1 s2
      | LTermList(l1), LTermList(l2) -> ctxdescaux l1 l2
      | LInfer(l1,f1), LInfer(l2,f2) when match_lunif l1 == match_lunif l2 ->
	  true
      | LInfer(l1,f1), LInfer(l2,f2) ->
	  (let l1 = match_lunif l1 in
	   let l2 = match_lunif l2 in
	     lunifvar_type_unify (aux n) l1 f1 l2 f2;
	     match !l1, !l2 with
	       Inst(t1,otyp1), _ -> aux n (f1 t1) e2'
	     | _, Inst(t2,otyp2) -> aux n e1' (f2 t2)
	     | (Uninst(_,otyp1)) , (Uninst(_,otyp2)) ->
		 l1 := Inst(LInfer(l2,fun x -> x),otyp2); true)
      | LInfer(l,f), e
      | e, LInfer(l,f) ->
	  (let l = match_lunif l in
	     match !l with
	       Inst(t,_) -> aux n (f t) e
	     | Uninst(i,otyp) ->
		 (l := Inst(e,otyp);
		  aux n e1' e2'
		  (* (try aux n e1' e2' *)
		  (*  with _ -> failwith "can't unify") *)
		 ))
      | e1', e2' -> false
  and modalaux n e1 e2 =
      match e1, e2 with
	  LFMeta(i1), LFMeta(i2) -> i1 = i2
	| LBMeta(i1), LBMeta(i2) -> i1 = i2
	| LNMeta(s1), LNMeta(s2) when s1 = s2 -> true
	| LNMeta(s1), e2 when not (get_metadef_isaxiom s1 defenv) -> modalaux n (get_metadef_term s1 defenv) e2
	| e1, LNMeta(s2) when not (get_metadef_isaxiom s2 defenv) -> modalaux n e1 (get_metadef_term s2 defenv)
(* changed 8/31/2010 *)
(* 	| LTermInCtx(ct1,t1), LTermInCtx(ct2,t2) -> *)
(* 	    let n1 = List.length ct1 in *)
(* 	    let n2 = List.length ct2 in *)
(* 	    ctxdescaux (LCtxAsList(ct1)) (LCtxAsList(ct2)) && *)
(* 	      aux (max n1 n2) (BindLterm.open_up ~howmany:n1 0 t1) (BindLterm.open_up ~howmany:n2 0 t2) *)

	| LTermInCtx(ct1,t1), LTermInCtx(ct2,t2) when List.length ct1 = List.length ct2 ->
	    let n = List.length ct1 in
	    ctxdescaux (LCtxAsList(ct1)) (LCtxAsList(ct2)) &&
	      aux n (BindLterm.open_up ~howmany:n 0 t1) (BindLterm.open_up ~howmany:n 0 t2)
	| LTermInCtx(ct1,LModal(t1,s1)), t2 when modalaux (max n (List.length ct1)) t1 t2 && ExtList.is_prefix s1 (boundlist (List.length ct1)) -> true
	| t2, LTermInCtx(ct1,LModal(t1,s1)) when modalaux (max n (List.length ct1)) t1 t2 && ExtList.is_prefix s1 (boundlist (List.length ct1)) -> true
	| _, _ -> false
  and ctxdescaux c1 c2 =
    match c1, c2 with
	LFCtx(i1), LFCtx(i2) -> i1 = i2
      | LBCtx(i1), LBCtx(i2) -> i1 = i2
      | LCtxAsList(l1), LCtxAsList(l2) when (List.length l1) = (List.length l2) ->
	  let l1' = ctx_open_up l1 in
	  let l2' = ctx_open_up l2 in
	    ExtList.foldindex (fun i (a,b) res -> res && (aux i a b)) true (List.combine l1' l2')
      | _, _ -> false
    
  in
    (aux, modalaux, ctxdescaux);;

let lterm_equal d n e1 e2  = let (f,_,_) = equal_checks d in f n e1 e2
let lmodal_equal d n e1 e2 = let (_,f,_) = equal_checks d in f n e1 e2
let lctxdesc_equal d e1 e2 = let (_,_,f) = equal_checks d in f e1 e2

