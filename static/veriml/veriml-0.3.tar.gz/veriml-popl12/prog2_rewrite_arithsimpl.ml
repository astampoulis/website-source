open Syntax_logic;;
open Syntax_comp;;
open Syntax_tac;;

<<

reset.
import "prog2_rewrite_list".

let natrepr = fun phi : ctx, n : @Nat => < l : @List/[Nat] > hol( @n = sumlist/[] l )

let natrepr_rewrite = fun phi : ctx, n : @Nat, n' : @Nat , pf : hol( @n = n') ,
                          nr : natrepr #@ @n =>
  unpack < pf , u > = pf in
  unpack < l , pf', u > = nr in
  ( < @l , preeval( req_iseq #@ @?? @?? @?? ) > :: ( natrepr #@ @n' ) ) 

let is_const = fun phi : ctx, n : @Nat =>
  holcase @n as n return bool with
      ( boxN : [].Nat ). @ boxN/[] |-> 
	true
    | ( n : @Nat ). @n |->
        false

let nat_to_sumlist =
  letrec aux : { phi : ctx , n : @Nat } (natrepr #@ @n ) =
    fun phi : ctx , n : @Nat =>
    holcase @n as n return natrepr #@ @n with
      ( e1 : @Nat, e2 : @Nat ). @plus/[] e1 e2 |->
  	unpack < l1, pf1 , u > = aux #@ @e1 in
        unpack < l2, pf2 , u > = aux #@ @e2 in
        unpack < pf3 , u > = <| @append_sum/[] l1 l2 |> in
        < @append/[Nat] l1 l2 , preeval( def_auto #@ @?? ) >

    | (a : @Nat, b : @Nat). @mult/[] a b |->
        (if (if is_const #@ @a then false else (is_const #@ @b)) then
	    unpack < pf , unused > = <| @mult_comm/[] a b |> in
	    < @cons/[Nat] (mult/[] b a) nil/[Nat] , preeval( def_auto #@ @?? ) >
         else 
            < @cons/[Nat] (mult/[] a b) nil/[Nat] , preeval( def_auto #@ @?? ) > )

    | (e : @Nat ). @e |->
      (if is_const #@ @e then
         < @cons/[Nat] (mult/[] 1 e) nil/[Nat] , preeval( def_auto #@ @?? ) >
       else
	 < @cons/[Nat] (mult/[] e 1) nil/[Nat] , preeval( def_auto #@ @?? ) > )
  in
  aux

let sumlist_sorter =
  fun phi : ctx, e1 : @Nat, e2 : @Nat =>
  holcase @e1, @e2 as e1, e2 return bool with
      ( a1 : @Nat, b1 : @Nat). @mult/[] a1 b1,
      ( a2 : @Nat, b2 : @Nat). @mult/[] a2 b2 |->
	( hash( <| @b1 |> ) ) LT ( hash( <| @b2 |> ) )
    | ( e1 : @Nat ). @e1 ,
      ( e2 : @Nat ). @e2 |->
        ( hash( <| @e1 |> ) ) LT ( hash( <| @e2 |> ) ) 

let rewriter_sumlist_full : rewriter_module_t =

  unpack < spf, u > =
      (let @ = #[ l : List/[Nat] , l' : List/[Nat] , pfl' : l = l' , e' : Nat, pfe' : sumlist/[] l' = e' ] in
	 ( ReqEqual :: hol( @sumlist/[] l = e' ) ) )
  in
  unpack < spf1 , u > =
      (let @ = #[ ] in
       (Temporary Rewriter unfolder_sumlist in ReqEqual ) :: hol( @sumlist/[] nil/[??] = zero ) )
  in
  unpack < spf2 , u > =
      (let @ = #[ hd : Nat, tl : List/[Nat], tln' : Nat, pf : sumlist/[] tl = tln' ] in
       ((* Temporary Rewriter unfolder_sumlist in *) ReqEqual ) :: hol( @sumlist/[] (cons/[??] hd tl) = plus/[] hd tln' ) )
in

  fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>
  holcase ?T , ?e as T, e return < e' : @T >hol( @e = e' ) with
      ( ). @Nat, ( l : @List/[Nat] ). @sumlist/[] l |->
	(unpack < l' , pfl' , unused > = recursive #@ @List/[Nat] @l in
	 unpack < e' , pfe' , unused > =
	    (holcase @l' as x'
	       return < e' : @Nat >hol( @sumlist/[] x' = e' )
	     with
		 (). @nil/[??] |->
		   < @0 , <| @spf1/[] |> >
	       | (hd : @Nat , tl : @List/[Nat]).@cons/[??] hd tl |->
		   (unpack < tln' , pftln' , u > = recursive #@ @?? ( @sumlist/[] tl ) in
		   < @plus/[] hd tln' , <| @spf2/[ hd, tl, tln', pftln' ] |> > )
	       | (l' : @List/[Nat]).@l' |->
		   < @sumlist/[] l' , Reflexivity >  )
         in
           < @e' , <| @spf/[l,l',pfl',e',pfe'] |> > )

    | ( T : @Set ). @T, ( e : @T ). @e |-> 
       < @e , Reflexivity >


let sumlist_to_nat =
  fun phi : ctx, n : @Nat, nr : natrepr #@ @n =>
  unpack < l , pf , u > = nr in
  (* unpack < n' , pf', u > = rewriter_sumlist_full def_rewr #@ @?? ( @sumlist/[] l ) in *)
  ( < @sumlist/[] l , preeval( req_iseq #@ @?? @?? @?? ) >  :: < n' : @Nat >hol( @n = n') )
      
ExtDefinition mult_plus_distr2 : [].forall (a b x y : Nat), 
    plus/[] (mult/[] a x) (plus/[] (mult/[] b x) y) =
    plus/[] (mult/[] (plus/[] a b) x) y :=
   Intro a : Nat in
   Intro b : Nat in
   Intro x : Nat in
   Intro y : Nat in
   Cut H1 : mult/[] x (plus/[] a b) = plus/[] (mult/[] x a) (mult/[] x b) by
       <| @mult_plus_distr/[] x a b |> for
   Cut H11 : (mult/[] x (plus/[] a b) = mult/[] (plus/[] a b) x) by <| @mult_comm/[] ?? ?? |> for
   Cut H12 : (mult/[] x a = mult/[] a x) by <| @mult_comm/[] ?? ?? |> for
   Cut H13 : (mult/[] x b = mult/[] b x) by <| @mult_comm/[] ?? ?? |> for
   Cut H14 : plus/[] (mult/[] x a) (mult/[] x b) = plus/[] (mult/[] a x) (mult/[] b x) by ReqEqual for
   Cut H15 : (mult/[] (plus/[] a b) x = plus/[] (mult/[] a x) (mult/[] b x)) by Auto for
   Cut H2 : plus/[] (mult/[] a x) (plus/[] (mult/[] b x) y) = plus/[] (plus/[] (mult/[] a x) (mult/[] b x)) y by <| @plus_assoc/[] ?? ?? ?? |> for
   ( ReqEqual :: hol( @plus/[] (mult/[] a x) (plus/[] (mult/[] b x) y) =
    plus/[] (mult/[] (plus/[] a b) x) y ) )
.


let factorize_sumlist : { phi : ctx, l : @List/[Nat] } < l' : @List/[Nat] > hol( @sumlist/[] l = sumlist/[] l' ) =
  unpack < spf , u > =
     let @ = #[ hda : Nat, hdb : Nat, tl : List/[Nat], hdc : Nat, tl'' : List/[Nat],
		pftl : sumlist/[] tl = sumlist/[] (cons/[Nat] (mult/[] hdc hdb) tl'')] in
     Cut H1 : sumlist/[] (cons/[Nat] (mult/[] hda hdb) tl) = plus/[] (mult/[] hda hdb) (sumlist/[] tl) by ReqEqual for
     Cut H2 : plus/[] (mult/[] hda hdb) (sumlist/[] tl) = plus/[] (mult/[] hda hdb) (sumlist/[] (cons/[Nat] (mult/[] hdc hdb) tl'') ) by
         <| @leibn (fun x : Nat => plus/[] (mult/[] hda hdb) (sumlist/[] tl) = plus/[] (mult/[] hda hdb) x) pftl (refl ??) |>
     for
     Cut H3 : plus/[] (mult/[] hda hdb) (sumlist/[] (cons/[Nat] (mult/[] hdc hdb) tl'')) = plus/[] (mult/[] hda hdb) (plus/[] (mult/[] hdc hdb) (sumlist/[] tl'')) by ReqEqual for
     Cut H4 : plus/[] (mult/[] hda hdb) (plus/[] (mult/[] hdc hdb) (sumlist/[] tl'')) = plus/[] (mult/[] (plus/[] hda hdc) hdb) (sumlist/[] tl'') by
	 Exact <| @mult_plus_distr2/[] hda hdc hdb (sumlist/[] tl'') |> for
     Cut H5 : plus/[] (mult/[] (plus/[] hda hdc) hdb) (sumlist/[] tl'') =
	      sumlist/[] (cons/[Nat] (mult/[] (plus/[] hda hdc) hdb) tl'') by
		Temporary Rewriter unfolder_sumlist in ReqEqual for
     ReqEqual :: hol( @sumlist/[] (cons/[Nat] (mult/[] hda hdb) tl) =
             sumlist/[] (cons/[Nat] (mult/[] (plus/[] hda hdc) hdb) tl'') )
  in
  unpack < spf1, u > =
      let @ = #[ hda : Nat, hdb : Nat, tl : List/[Nat] , tl' : List/[Nat], pf : sumlist/[] tl = sumlist/[] tl' ] in
      ReqEqual :: hol( @sumlist/[] (cons/[Nat] (mult/[] hda hdb) tl) = sumlist/[] (cons/[Nat] (mult/[] hda hdb) tl' ) )
  in
  fun phi : ctx =>
  letrec aux : { l : @List/[Nat] } < l' : @List/[Nat] > hol( @sumlist/[] l = sumlist/[] l' ) =
    fun l : @List/[Nat] =>
    holcase @l as l return < l' : @List/[Nat] > hol( @sumlist/[] l = sumlist/[] l') with
	( hda : @Nat, hdb : @Nat, tl : @List/[Nat] ).
	  @cons/[Nat] (mult/[] hda hdb ) tl |->
	   ( unpack < tl' , pftl' , u > = aux @tl in
	     holcase @tl' as tl' return < l' : @List/[Nat] >hol( @sumlist/[] (cons/[Nat] (mult/[] hda hdb) tl ) = sumlist/[] l' ) with
		 ( hdc : @Nat , tl'' : @List/[Nat] ).
		   @cons/[Nat] (mult/[] hdc hdb) tl'' |->
		     < @cons/[Nat] (mult/[] (plus/[] hda hdc) hdb) tl'' ,
		       <| @spf/[ hda, hdb, tl, hdc, tl'', pftl' ] |> >
	       | ( tl' : @List/[Nat] ). @tl' |->
		     < @cons/[Nat] (mult/[] hda hdb) tl' ,
		       <| @spf1/[ hda, hdb, tl , tl' , pftl' ] |> > )

      |  ( l : @List/[Nat] ). @l |-> < @l , Reflexivity >
  in
  aux 

let rewriter_arithsimpl : rewriter_module_t =
  fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>
  holcase @T, @e as T, e return < e' : @T >hol( @e = e' ) with
      (). @Nat, ( e1 : @Nat, e2 : @Nat ). @plus/[] e1 e2 |->
	( unpack < l , pf1 , u > = nat_to_sumlist #@ ( @plus/[] e1 e2 ) in
	  unpack < l', pf2 , u > = sort_list #@ @?? ( sumlist_sorter #@ ) @l in
          unpack < pf3 , u > = <| @permutation_sum/[] l l' pf2 |> in
          unpack < l'', pf4 , u > = factorize_sumlist #@ @l' in
          unpack < n', pf5 , u > = sumlist_to_nat #@ @?? ( < @l'', eq_refl #@ @?? ( @sumlist/[] l'' ) > ) in
          < @n' , preeval( req_iseq #@ @?? @?? @?? ) > )

    | ( T : @Set ). @T , ( e : @T ). @e |-> < @e , Reflexivity >

save "prog2_rewrite_arithsimpl".

>>;;

  
