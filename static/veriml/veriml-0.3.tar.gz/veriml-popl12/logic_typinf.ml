open Utils
open Logic_ast
open Logic_core
open Logic_print

let impredicative_set = Logic_typing.impredicative_set
let add_to_env = Logic_typing.add_to_env

let ctx_is_prefix defenv l1 l2 =
    if (List.length l1 > List.length l2) then false
    else ExtList.foldindex (fun i ((_,a),(_,b)) res -> res && (lterm_equal defenv i a b)) true
      (List.combine l1 (ExtList.take (List.length l1) l2))

exception LTermsNotEqual
let require_lterm_equal ((fenv, defenv, metaenv, ctxenv) : lterm_env) t t' =
  if lterm_equal defenv (List.length fenv) t t' then
    ()
  else
    raise LTermsNotEqual

let require_lmodal_equal ((fenv, defenv, metaenv, ctxenv) : lterm_env) t t' =
  if lmodal_equal defenv (List.length metaenv) t t' then
    ()
  else
    raise LTermsNotEqual

let rec type_of_lterm ((fenv, defenv, metaenv, ctxenv) as env : lterm_env) ?(trusted = false) ?(expected = None) (e : lterm) =
  let type_of_lterm env ?expected e = type_of_lterm env ~trusted:trusted ?expected:expected e in
  let return t =
    match expected with
	Some t' -> require_lterm_equal env t t'; t
      | _ -> t
  in
  let n = List.length fenv in
  let metan = List.length metaenv in
  let ctxn = List.length ctxenv in
  match e with
      LSort(LSet)  -> return (LSort(LType))
    | LSort(LProp) -> return (LSort(LSet))
    | LSort(LType) -> failwith "LType has no type"
    | LVar(LBVar i) -> failwith "accessing type of bound var -- shouldn't happen!"
    | LVar(LFVar i) -> return (List.nth fenv (List.length fenv - i - 1))
	
(* special handling of equality *)
    | LApp(LVar(LNVar(eq)), t) when eq = "eq" ->
	let tp = type_of_lterm env t in
	let thistp = LPi(None,mk_inferred (),tp,LSort(LProp)) in
	let _ = type_of_lterm env thistp in
	  return thistp

    | LApp(LVar(LNVar(refl)), t) when refl = "refl" ->
	let tp = LApp(LApp(LVar(LNVar("eq")), t), t) in
	let _ = type_of_lterm env tp in
	  return tp

    | LApp(LVar(LNVar(symm)), t) when symm = "symm" ->
	begin
	let uv1 = mk_infer n 0 metan 0 ctxn 0 in
	let uv2 = mk_infer n 0 metan 0 ctxn 0 in
	let exp = LApp(LApp(LVar(LNVar("eq")), uv1), uv2) in
	let _ = try type_of_lterm env ~expected:(Some exp) t with LTermsNotEqual -> failwith "in symm, first argument of incorrect type" in
	return (LApp(LApp(LVar(LNVar("eq")), uv2), uv1))
	end

    | LApp(LApp(LVar(LNVar(trans)), t1), t2) when trans = "trans" ->
	begin
	let uv1 = mk_infer n 0 metan 0 ctxn 0 in
	let uv2 = mk_infer n 0 metan 0 ctxn 0 in
	let uv3 = mk_infer n 0 metan 0 ctxn 0 in
	let exp1 = LApp(LApp(LVar(LNVar("eq")), uv1), uv2) in
	let exp2 = LApp(LApp(LVar(LNVar("eq")), uv2), uv3) in
	let _ = try type_of_lterm env ~expected:(Some exp1) t1 with LTermsNotEqual -> failwith "in trans, first argument of incorrect type" in
	let _ = try type_of_lterm env ~expected:(Some exp2) t2 with LTermsNotEqual -> failwith "in trans, second argument of incorrect type" in
	return (LApp(LApp(LVar(LNVar("eq")), uv1), uv3))
	end

    | LApp(LApp(LApp(LVar(LNVar(leibn)), (LLambda(_, _, tp, tm) as e)), pf'), pf) when leibn = "leibn" ->
	begin
	let ewf = type_of_lterm env e in
	let _ = if lterm_equal defenv n ewf (LPi(None,mk_inferred (), tp, LSort(LProp))) then () else failwith "in leibniz, the P argument should be a one-place predicate" in
	let uv1 = mk_infer n 0 metan 0 ctxn 0 in
	let uv2 = mk_infer n 0 metan 0 ctxn 0 in
	let exp' = LApp(LApp(LVar(LNVar("eq")), uv1), uv2) in
	let exp  = BindLtermS.subst_bound uv1 tm in
	let _ = try type_of_lterm env ~expected:(Some exp') pf' with LTermsNotEqual -> failwith "in leibniz, equality term of wrong type" in
	let _ = try type_of_lterm env ~expected:(Some exp) pf with LTermsNotEqual -> failwith "in leibniz, terms or proof object of incorrect type" in
	return (BindLtermS.subst_bound uv2 tm)

	end

    | LApp(LVar(LNVar(lameq)), pf) when lameq = "lameq" ->
        begin
  	  let _ = match pf with LLambda(_,_,_,_) -> () | _ -> failwith "proof must be lambda in lameq" in

	  let utp = mk_infer n 0 metan 0 ctxn 0 in
	  let uv1 = mk_infer n 1 metan 0 ctxn 0 in
	  let uv2 = mk_infer n 1 metan 0 ctxn 0 in
	  let exp = LPi(None,mk_inferred (),utp,LApp(LApp(LVar(LNVar("eq")),uv1),uv2)) in

	  let pftp = try type_of_lterm env ~expected:(Some exp) pf with LTermsNotEqual -> failwith "in lameq, wrong type for proof" in
	  let _ = try type_of_lterm env ~expected:(Some (LSort(LProp))) pftp with LTermsNotEqual -> failwith "wrong term applied to lameq -- need forall proposition" in
	  let var, k = (match pftp with LPi(var,k,_,_) -> var,k | _ -> failwith "oops!") in
	  
	  return (LApp(LApp(LVar(LNVar("eq")),LLambda(var,k,utp,uv1)),(LLambda(var,k,utp,uv2))))
	end

    | LApp(LVar(LNVar(foralleq)), pf) when foralleq = "foralleq" ->
	begin
  	  let _ = match pf with LLambda(_,_,_,_) -> () | _ -> failwith "proof must be lambda in foralleq" in

	  let utp = mk_infer n 0 metan 0 ctxn 0 in
	  let uv1 = mk_infer n 1 metan 0 ctxn 0 in
	  let uv2 = mk_infer n 1 metan 0 ctxn 0 in
	  let exp = LPi(None,mk_inferred (),utp,LApp(LApp(LVar(LNVar("eq")),uv1),uv2)) in

	  let pftp = try type_of_lterm env ~expected:(Some exp) pf with LTermsNotEqual -> failwith "wrong type for proof in foralleq application" in
	  let _ = try type_of_lterm env ~expected:(Some (LSort(LProp))) pftp with LTermsNotEqual -> failwith "wrong term applied to foralleq -- need forall proposition" in
	  let var, k = (match pftp with LPi(var,k,_,_) -> var,k | _ -> failwith "oops!") in

	  return (LApp(LApp(LVar(LNVar("eq")),LPi(var,k,utp,uv1)),(LPi(var,k,utp,uv2))))
	end		

    | LApp(LApp(LVar(LNVar(beta)), (LLambda(_, _, tp, tm) as e)), e2) when beta = "beta" ->
	begin
	  let _ = type_of_lterm env e in
	  let thistp = LApp(LApp(LVar(LNVar("eq")), LApp(e,e2)),BindLtermS.subst_bound e2 tm) in
	  let _ = type_of_lterm env thistp in
	    return thistp
	end

    | LApp(LVar(LNVar(metaunfold)), (LModal(LNMeta(s), subst) as e))
	when (metaunfold = "metaunfold" && not (get_metadef_isaxiom s defenv)) ->
	begin
	  let _  = type_of_lterm env (LApp(LApp(LVar(LNVar("eq")),e),e)) in
	  let unfolded = modal_apply_subst (get_metadef_term s defenv) subst in
	    return (LApp(LApp(LVar(LNVar("eq")), e), unfolded))
	end

(* unsafe feature *)
    | LVar(LNVar(s)) when s = "~trusted" && trusted ->
      let uv = mk_infer n 0 metan 0 ctxn 0 in
      return uv

(* ok, equality done *)

    | LVar(LNVar i) -> return (get_def_type i defenv)
    | LPi(var, k, t1, t2) ->
	let t1_t = type_of_lterm env t1 in
	let env' = add_to_env env t1 in
	let t2' = BindLterm.open_up n t2 in
	let t2_t = type_of_lterm env' t2' in
	  begin
	    match whnf defenv t1_t, whnf defenv t2_t with
	    	LSort(LProp), LSort(LProp) -> inferred_is k LProp; return (LSort(LProp))
	      | LSort(LSet), LSort(LSet) -> inferred_is k LSet; return (LSort(LSet))
	      | LSort(LSet), LSort(LProp) -> inferred_is k LSet; return (LSort(LProp))
	    	  (* impredicative Set? *)
	      | LSort(LType), LSort(LType) when !impredicative_set -> inferred_is k LType; return(LSort(LType))
	      | LSort(LType), LSort(LSet)  when !impredicative_set -> inferred_is k LType; return(LSort(LSet))
	      | LSort(LType), LSort(LProp) when !impredicative_set -> inferred_is k LType; return(LSort(LProp))
	      | LInfer(l,_), LSort(LProp) -> return(LSort(LProp))
	      | LInfer(_,_), LSort(LSet) -> (let _ = lterm_equal defenv n t1_t (LSort(LSet)) in inferred_is k LSet; return (LSort(LSet)))
	      | LSort(LProp), LInfer(_,_) -> (let _ = lterm_equal defenv n t2_t (LSort(LProp)) in inferred_is k LProp; return (LSort(LProp)))
	      | LSort(LSet), LInfer(_,_) -> return t2_t
	      | LInfer(_,_), LInfer(_,_) -> return t2_t
		  
	      | _ -> failwith ("invalid type " ^ (string_of_lterm e))
	  end
    | LLambda(var, k, t1, e2) ->
	let uv2 = mk_infer n 1 metan 0 ctxn 0 in
	let realexp = LPi(var, k, t1, uv2) in
	let _ = return realexp in
	let exp2 = BindLterm.open_up n uv2 in
	let env' = add_to_env env t1 in
	let _ = try type_of_lterm env' ~expected:(Some exp2) (BindLterm.open_up n e2) with LTermsNotEqual -> failwith "body of lambda not of the right type" in 
	let _ = type_of_lterm env realexp in
	  return realexp
    | LApp(e1, e2) ->
        let uva = mk_infer n 0 metan 0 ctxn 0 in
        let uvb = mk_infer n 1 metan 0 ctxn 0 in
        let exp1 = (LPi(None, ref None, uva, uvb)) in
	let exp2 = uva in
	let _  = try type_of_lterm env ~expected:(Some exp2) e2 with LTermsNotEqual -> failwith "in application, argument not of the right type" in
	let t1 = try type_of_lterm env ~expected:(Some exp1) e1 with LTermsNotEqual -> failwith "in application, function not of the right type" in
	let _ = require_lterm_equal env t1 exp1 (* TODO: is this needed? *) in
	begin
	  return (BindLtermS.subst_bound e2 uvb)
	end
    | LInd(idef) -> failwith "ind thrown out"  (* term_of_idef env idef *)
    | LCtor(id, i) -> failwith "ind thrown out"
    | LModal(mt, subst) ->
	(let mt_t = type_of_modal env ~trusted:trusted mt in
	 let rec getctx mt_t =
	   match mt_t with
	       LTermInCtx(ctx, _) -> ctx
	     | _ -> getctx (type_of_modal env ~trusted:trusted mt_t)
	 in
	 let ctx = getctx mt_t in
	 let _ = type_of_subst_is env subst ctx in
	   return (modal_apply_subst mt_t subst))
    | LTermList(ctx) ->
	failwith "asking type of context inside type_of_lterm!"
    | LElim(res, idtm, branches) ->
	failwith "ind thrown out"
    | LInfer(el, f) ->
	(match !(match_lunif el) with
	     Inst(ei,ti) ->
	       (let t' = type_of_lterm env ~expected:expected (try f ei with _ -> failwith "can't unify! -- problem while applying f^-1!") in
		  if (match !ti with Some ot -> lterm_equal defenv n t' (LInfer(ot,f)) | _ -> true) then
		    return t'
		  else
		    failwith "instantiation of inferred term with wrong type!")
	   | Uninst(i,otyp) ->
	       (match !otyp with
		    None -> (let uv = mk_lunifvar () in otyp := (Some uv); return(LInfer(uv, f)))
		  | Some ti -> return (LInfer(ti, f))))
	
and type_of_modal ((fenv, defenv, metaenv, ctxenv) as env : lterm_env) ?(trusted = false) ?(expected = None) (mt : lmodalterm) =
  let return t =
    match expected with
	Some t' -> require_lmodal_equal env t t'; t
      | _ -> t
  in
  match mt with
      LTermInCtx(ctx,lt) ->
	(* TODO: take expected more into account (e.g. even for context) *)
	(let _ = ctx_wf ([], defenv, metaenv, ctxenv) (LCtxAsList(ctx)) in
	 let newfenv, openlt = terminctx_open_up ctx lt in
	 let expected =
	   match expected with
	    (*   Some(LTermInCtx(ctx',lt')) ->
		 (if ctx_is_prefix defenv ctx ctx' then
		     (let _, openlt' = terminctx_open_up ctx' lt' in Some (openlt'))
		  else
		     failwith "context does not match expected one!")
	     |*) _ -> None
	 in
	 let tp = type_of_lterm (newfenv, defenv, metaenv, ctxenv) ~trusted:trusted ~expected:expected openlt in
	   return (terminctx_close_down ctx tp))
    | LFMeta(i) -> return (List.nth metaenv (List.length metaenv - i - 1))
    | LBMeta(i) -> failwith ("accessing bound meta variable while type checking -- shouldn't happen")
    | LNMeta(s) -> return (get_metadef_type s defenv)

and type_of_subst_is ((fenv, defenv, metaenv, ctxenv) as env: lterm_env) (subst : lsubst) (ctx : lctx) =
  match subst, ctx with
      [], [] -> true
    | (shd::stl), ((v,chd)::ctl) ->
	let _ = try type_of_lterm env ~expected:(Some chd) shd
	        with LTermsNotEqual -> failwith ("subst and ctx do not match in type for " ^(match v with None -> "?" | Some s -> s)) in
	let ctx' = BindCtxS.subst_bound shd ctl in
	  type_of_subst_is env stl ctx'
    | _, _ -> failwith ("subst and context do not match in size")
and ctx_wf ((fenv, defenv, metaenv, ctxenv) as env : lterm_env) (ctx : lctxdesc) =
  match ctx with
      LFCtx(i) -> List.nth ctxenv (List.length ctxenv - i - 1)
    | LBCtx(i) -> failwith "getting type of bound context variable"
    | LCtxAsList(l) ->
	ignore
	  (List.fold_left (fun ((fenv, _, _, _) as curenv,n) (_,elm) ->
			     let elm = BindLterm.open_up ~howmany:n 0 elm in
			     valid_ctxelem curenv elm;
			     (add_to_env curenv elm, n+1))
	     (env,0) l)
and valid_ctxelem ((fenv, defenv, metaenv, ctxenv) as env) (ctxelem : lterm) =
  match ctxelem with
      LTermList(LCtxAsList(_)) -> failwith "nested context lists are not allowed!"
    | LTermList(ctx) -> ctx_wf env ctx
    | t -> ignore(type_of_lterm env t)

let type_of_lterm a ?(expected = None) ?(trusted = false) tm =
                         repeatmany 1 (fun () -> type_of_lterm a ~expected:expected ~trusted:trusted tm)
let type_of_modal a ?(expected = None) ?(trusted = false) tm = repeatmany 1 (fun () -> type_of_modal a ~expected:expected ~trusted:trusted tm)
let ctx_wf a tm        = repeatmany 1 (fun () -> ctx_wf a tm)


let ltermdefenv_add_term_infer name tm expected_tp (defenv : lterm_defenv) =
  let _ =
    try type_of_lterm ([],defenv,[],[]) ~expected:(Some expected_tp) tm
    with LTermsNotEqual -> failwith ("the term's type doesn't match the definition type" ^ (string_of_lterm tm))
  in
  (let tm' = remove_infer tm in
   let exptp' = remove_infer expected_tp in
   (Format.fprintf Format.std_formatter "%s@ :@ %a@ :=@ %a.@\n" name pr_lterm exptp' pr_lterm tm');
   Logic_typing.ltermdefenv_add_term name tm' exptp' defenv)

let ltermdefenv_add_meta_infer name tm expected_tp (defenv : lterm_defenv) =
  let _ =
    try type_of_modal ([],defenv,[],[]) ~expected:(Some expected_tp) ~trusted:true tm
    with LTermsNotEqual -> failwith ("the term's type doesn't match the definition type")
  in
  let add name what (d1,defenv) =
    (if Dict.mem name defenv then
       failwith ("definition " ^ name ^ " already exists")
     else
       (d1,Dict.add name what defenv))
  in
  let tm' = remove_infer_lmodal tm in
  let exptp' = remove_infer_lmodal expected_tp in
  add name (exptp', Some tm') defenv
