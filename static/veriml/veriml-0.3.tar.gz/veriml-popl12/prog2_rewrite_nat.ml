open Syntax_logic;;
open Syntax_comp;;

<<

reset.
import "prog2_rewrite_beta".

Axiom Nat : Set.
Axiom zero : Nat.
Axiom succ : Nat -> Nat.

Axiom natInd : forall (P : Nat -> Prop), P zero -> (forall x : Nat, P x -> P (succ x)) -> forall n : Nat, P n.

MetaAxiom natFold : [T : Set].(T -> (Nat -> T -> T) -> Nat -> T).
MetaAxiom natFold_base : [T : Set].forall (fz : T) (fs : Nat -> T -> T),
                          natFold/[T] fz fs 0 = fz.
MetaAxiom natFold_step : [T : Set].forall (fz : T) (fs : Nat -> T -> T) (n' : Nat),
                          natFold/[T] fz fs (succ n') = fs n' (natFold/[T] fz fs n').

let rewriter_natfold : rewriter_module_t =

  fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>

  holcase @e as x return < e' : @T >hol( @x = e' ) with

      ( fz : @T, fs : @Nat -> T -> T , n : @Nat ). @natFold/[T] fz fs n |->

	 unpack < n' , pfn' , unused > = recursive #@ @Nat @n in
	 unpack < e' , pfe' , unused > =
	    (holcase ?n' as n'
	                 return < e' : @T >hol( @natFold/[T] fz fs n' = e' )
	     with
		 (). @zero |->
		   < @fz , <| @ natFold_base/[T] fz fs |> >

	       | (x : @Nat). @succ x |->
		   < @fs x (natFold/[T] fz fs x) , <| @ natFold_step/[T] fz fs x |> >

	       | (x : @Nat). @x |->
		   < @natFold/[T] fz fs x , eq_refl #@ @?? @?? > )

         in
         < @e' , preeval( req_iseq #@ @?? @?? @?? ) >

    | ( e : @T ). @e |->
       < @e , preeval( eq_refl #@ @?? @?? ) >

let _ = global_rewriter_add_top rewriter_natfold


save "prog2_rewrite_nat".

>>
