open Syntax_logic;;
open Syntax_comp;;

<<

reset.
import "prog2_eqtacs".

let rewriter_t = { phi : ctx , T : @Set, e : @T } < e' : @T > hol( @e = e' )
let rewriter_module_t =
  (* recursive *) rewriter_t ->
  { phi : ctx , T : @Set, e : @T } < e' : @T > hol( @e = e' )

let trusted build_rewriter : list rewriter_module_t -> rewriter_t =
  fun rewriters_list : list rewriter_module_t =>
  (letrec rewriter : rewriter_t =
      fun phi : ctx, T : @Set, e : @T =>
      (let test_progress =
	 fun res : < e' : @T > hol( @e = e' ) =>
	 unpack < e' , unused > = res in
         holcase @e' as x return bool with
	     ( ). @e |-> false
	   | ( e' : @T ). @e' |-> true
       in
       let idelem =
	 (* hack to avoid subtyping bug *)
	  holcase @e as e return < e' : @T >hol( @e = e' ) with
	     ( e : @T ). @e |-> < @e , <| @refl e |> >
       in
       let first_successful =
	 listfold rewriter_module_t ( < e' : @T > hol( @e = e') )
	   (fun res : < e' : @T > hol( @e = e') => fun currewrite : rewriter_module_t =>
	       (if test_progress res then
		   ((unpack < e , unused > = res in DEBUG (fun u : Unit => print <| @e |>)));
		   res
		else
		   (currewrite rewriter #@ @T @e)))
	   idelem
	   rewriters_list
       in
       if test_progress first_successful then
	 (unpack < e' , pfe' , unused > = first_successful in
	  unpack < e'' , pfe'', unused > = rewriter #@ @T @e' in
          < @e'' , <| @trans pfe' pfe'' |> > )
       else
	 first_successful)
   in
   rewriter)

let global_rewriter_modules : ref (list rewriter_module_t) = mkref (nil _, _ )
let global_rewriter_add = fun r : rewriter_module_t => (global_rewriter_modules := listsnoc _ (!global_rewriter_modules) r)
let global_rewriter_add_top = fun r : rewriter_module_t => (global_rewriter_modules := cons _ r (!global_rewriter_modules))
let global_rewriter_remove_top = fun u : Unit =>
  match unfold !global_rewriter_modules with
      nl |-> unit
    | cns |-> (global_rewriter_modules := snd cns)


let def_rewr : rewriter_t =
  fun phi : ctx, T : @Set, e : @T =>
  build_rewriter (!global_rewriter_modules) #@ @T @e

let equaltester_t = { phi : ctx, T : @Set , e1 : @T , e2 : @T } option (hol( @e1 = e2))

let equaltester_syntactic : equaltester_t =
  fun phi : ctx, T : @Set , e1s : @T , e2s : @T =>
  holcase @e2s as e2 return option( hol( @e1s = e2)) with
      (). @e1s |-> some _ <| @refl e1s |>
    | (e2s : @T). @e2s |-> none _

let equaltester_ctx : rewriter_t -> equaltester_t -> equaltester_t =
  fun rewriter : rewriter_t, basetester : equaltester_t =>
  letrec test_equal : { phi : ctx, T : @Set , e1 : @T , e2 : @T }option (hol( @e1 = e2)) =
    fun phi : ctx, T : @Set , e1s : @T , e2s : @T =>
    unpack < e1, pfe1, unused > = rewriter #@ @T @e1s in
    unpack < e2, pfe2, unused > = rewriter #@ @T @e2s in
    let pf =
      let baseres = basetester #@ @T @e1 @e2 in
      match baseres with som |-> baseres | non |->
      ( holcase @T, @e1, @e2 as T, e1, e2 return option (hol( @e1 = e2)) with

	  (* equality *)
	( ).@Prop ,
	   ( T : @Set, a1 : @T, b1 : @T ). @a1 = b1 ,
	   ( a2 : @T , b2 : @T ). @a2 = b2 |->
	     (match test_equal #@ @T @a1 @a2 with
		  som1 |-> (match test_equal #@ @T @b1 @b2 with
				som2 |-> unpack < pfa , unused > = som1 in
		                         unpack < pfb , unused > = som2 in
	                                 some _
	                                 <| @leibn (fun b1' : T => (a1/[id_phi] = b1/[id_phi]) = (a2/[id_phi] = b1')) pfb
					     (leibn (fun a1' : T => (a1/[id_phi] = b1/[id_phi]) = (a1' = b1/[id_phi])) pfa (refl (a1 = b1))) |>
	                      | non2 |-> none _ )
		| non1 |-> none _ )
					                                                                    
	  (* application *)
       | ( T : @Set ). @T ,
	   ( T' : @Set, a1 : @T' -> T , b1 : @T' ). @a1 b1 ,
	   ( a2 : @T' -> T , b2 : @T'). @a2 b2 |->
	(match test_equal #@ ( @T' -> T) @a1 @a2 with
	     som1 |-> (match test_equal #@ @T' @b1 @b2 with
			   som2 |-> unpack < pfa , unused > = som1 in
	                            unpack < pfb , unused > = som2 in
	                            some _ <| @app_eq/[T' , T] a1 a2 b1 b2 pfa pfb |>
	                |  non2 |-> none _ )
	   | non1 |-> none _ )

	  (* implication *)
       | (). @Prop ,
	  ( a1 : @Prop , b1 : @Prop ).@a1 -> b1 ,
	  ( a2 : @Prop , b2 : @Prop ).@a2 -> b2 |->

	(* can we add proof of a1 to the context??? *)

	(match test_equal #@ @Prop @a1 @a2 with
	     som1 |-> (match test_equal #@ @Prop @b1 @b2 with
			   som2 |-> unpack < pfa , unused > = som1 in
	                            unpack < pfb , unused > = som2 in
	                            some _
	                                 <| @leibn (fun b1' : T => (a1/[id_phi] -> b1/[id_phi]) = (a2/[id_phi] -> b1')) pfb
					     (leibn (fun a1' : T => (a1/[id_phi] -> b1/[id_phi]) = (a1' -> b1/[id_phi])) pfa (refl (a1 -> b1))) |>
	                |  non2 |-> none _ )
	   | non1 |-> none _ )

	  (* quantification *)
       | (). @Prop ,
	  ( T : @Set, P1 : [ @, x : T].Prop ).@forall x : T, P1 ,
	  ( P2 : [ @ , x : T ].Prop ).@forall x : T, P2 |->
	(match nu x : T in test_equal #@ @Prop @P1 @P2 with
	     som1 |-> unpack < pfP , unused > = som1 in
	              some _  <| @foralleq (fun x : T => pfP) |>
	   | non1 |-> none _)

	  (* lambda *)
       | ( T : @Set , T' : @Set ). @T -> T' ,
	  ( a1 : [ @, x : T].T'/[id_phi] ). @fun x : T => a1 ,
	  ( a2 : [ @, x : T].T'/[id_phi] ). @fun x : T => a2 |->
	(match nu x : T in test_equal #@ ( @T'/[id_phi] ) @a1 @a2 with
	     som1 |-> unpack < pfa , unused > = som1 in
	              some _  <| @lameq (fun x : T => pfa) |>
	   | non1 |-> none _ )

	  (* general fallback case *)
       | ( T : @Set ). @T ,
	    ( a1 : @T ). @a1 ,
	    ( a2 : @T ). @a2 |->
	    break;
	    none _ 
     )

    in
    match pf with
	som |-> (unpack < pf , unused > = som in
	         some _ <| @gen_eq_repl2/[T] e1 e2 e1s e2s pf (symm pfe1) (symm pfe2)  |>)
      | non |-> none _
  in
    test_equal


let equaltester_compose_many =
  fun equaltesters : list equaltester_t =>
  fun phi : ctx, T : @Set , e1 : @T , e2 : @T =>
  listfold _ _
  (fun prf : option (hol( @e1 = e2 ) ) => fun tester : equaltester_t =>
      match prf with
	  som |-> prf
	| non |-> tester #@ @T @e1 @e2)
  (equaltester_syntactic #@ @T @e1 @e2)  (* (none (hol(@e1 = e2))) *)
  equaltesters


let trusted build_equaltester =
  fun rewriter : rewriter_t =>
  fun equaltesters_list : list equaltester_t =>
  equaltester_ctx rewriter (equaltester_compose_many equaltesters_list)


let global_equaltesters : ref (list equaltester_t) = mkref( nil _ , _ )
let global_equaltester_add = fun eq : equaltester_t => (global_equaltesters := listsnoc _ (!global_equaltesters) eq)
let global_equaltester_add_top = fun eq : equaltester_t => (global_equaltesters := cons _ eq (!global_equaltesters))
let def_iseq : equaltester_t = fun phi : ctx, T : @Set, e1 : @T , e2 : @T => (build_equaltester def_rewr (!global_equaltesters)) #@ @T @e1 @e2
let req_iseq =
  fun phi : ctx, T : @Set, e : @T , e' : @T =>
    match def_iseq #@ @T @e @e' with
 	som |-> som
      | non |-> (print "failure to prove equal:\n"); (print <| @e |>); (print <| @e' |>); bot _

save "prog2_rewrite_base".

>>;;

