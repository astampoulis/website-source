open Syntax_logic;;
open Syntax_comp;;
open Syntax_tac;;

<<

reset.
import "prog2_rewrite_base".

let hyps_t = fun phi : ctx => list ( < T : @Set, t1 : @T, t2 : @T >
				  hol( @t1 = t2 ))

let rewrite_direction =
  letrec get_my_hash : { phi : ctx, T : @Set, t : @T } int =
  fun phi : ctx, T : @Set, t1 : @T =>
  holcase @t1 as t1 return int with
      ( T' : @Set , f : @T' -> T , a : @T' ). @f a |->
	( get_my_hash #@ @?? @f ) iplus ( get_my_hash #@ @?? @a )
    | ( a : @T ). @a |-> 1
  in
  fun phi : ctx, T : @Set, t1 : @T, t2 : @T =>
  (get_my_hash #@ @T @t1) LT (get_my_hash #@ @T @t2)

let rewriter_naive_eq : rewriter_module_t =
  letrec gatherhyps : { phi : ctx} hyps_t #@ =
  fun phi : ctx =>
    ctxcase #@ as phi return hyps_t #[phi] with
	().().[] |-> nil _

      | ( phi0 ).(T : [ phi0 ].Set, t1 : [ phi0 ].T, t2 : [ phi0 ].T).
	  [ phi0, pf : t1 = t2 ] |->
	(let res = gatherhyps #[ phi0 ] in
	 let @ = #[ phi0, pf : t1 = t2 ] in
	 let res' = cons _
	            (pack @T/[id_phi0] as T return < t1' : @T , t2' : @T >hol( @t1' = t2' ) with
		     pack @t1/[id_phi0] as t1' return < t2' : @T/[id_phi0] >hol( @t1' = t2' ) with
		     pack @t2/[id_phi0] as t2' return hol( @t1/[id_phi0] = t2' ) with
		     <| @pf |> )
		    res
	 in
	 let res'' = cons _
	            (pack @T/[id_phi0] as T return < t1' : @T , t2' : @T >hol( @t1' = t2' ) with
		     pack @t2/[id_phi0] as t1' return < t2' : @T/[id_phi0] >hol( @t1' = t2' ) with
		     pack @t1/[id_phi0] as t2' return hol( @t2/[id_phi0] = t2' ) with
		     <| @symm pf |> )
		    res
	 in
	 let @ = #[ phi0 ] in
	 if rewrite_direction #@ @T @t1 @t2 then res' else res'' )
      | ( phi0 ).(P : [ phi0 ].Prop).[ phi0, pf : P ] |->
	  gatherhyps #[ phi0 ]
      | ( phi0 ).(T : [ phi0 ].Set ).[ phi0, t : T ] |->
	  gatherhyps #[ phi0 ]
      | ( phi0 ).().[ phi0, t : Set] |->
	  gatherhyps #[ phi0 ]
  in
  letrec subst : { phi : ctx , hyps : hyps_t #@ , T : @Set , t : @T } < t' : @T >hol( @t = t' ) =
    fun phi : ctx, hyps : hyps_t #@ , T : @Set, t : @T =>
    let res = 
    listfold _ _
    (fun cur : _ , elm : ( < T : @Set, t1 : @T, t2 : @T > hol( @t1 = t2 )) =>
	match cur with
	    som |-> cur
	  | non |-> (unpack < T' , t1' , t2' , pf , unused > = elm in
		     holcase @T , @t as T' , t' return option ( < t'' : @T' >hol( @t' = t'' ) ) with
			 (). @T' , (). @t1' |-> ( some ( < t'' : @T' >hol( @t1' = t'' ) ) ( < @t2' , <| @pf |> > ) )
		       | ( T : @Set ).@T , ( t : @T ). @t |-> none _ ))
     ( none ( < t' : @T >hol( @t = t') ) )
     hyps
    in match res with som |-> som | non |-> < @t , <| @refl t |> >
  in
  fun recursive : rewriter_t , phi : ctx =>
      let hyplist = gatherhyps #@ in
      fun T : @Set, e : @T => subst #@ hyplist @T @e

let test_naive = 
  (fun phi : ctx, T : @Set, t1 : @T, t2 : @T =>
      Temporary Rewriter rewriter_naive_eq in
      def_iseq #@ @T @t1 @t2 )

save "prog2_rewrite_naive".

>>;;

