open Syntax_logic;;
open Syntax_comp;;
open Syntax_tac;;

<<

reset.
import "prog2_rewrite_mult".

MetaAxiom List : [T : Set].Set.
MetaAxiom nil  : [T : Set].List/[T].
MetaAxiom cons : [T : Set].T -> List/[T] -> List/[T]. 

MetaAxiom listInd : [T : Set].forall (P : List/[T] -> Prop), P nil/[T] -> (forall t : T, forall l : List/[T], P l -> P (cons/[T] t l) ) .

>>;;

<<

MetaAxiom listFold : [T : Set, T' : Set].(T -> (T' -> List/[T'] -> T -> T) -> List/[T'] -> T).
MetaAxiom listFold_base : [T : Set, T' : Set].forall (fn : T) (fc : T' -> List/[T'] -> T -> T),
                          listFold/[T,T'] fn fc nil/[T'] = fn.
MetaAxiom listFold_step : [T : Set, T' : Set].forall (fn : T) (fc : T' -> List/[T'] -> T -> T) (hd : T') (tl : List/[T']),
                          listFold/[T,T'] fn fc (cons/[T'] hd tl) = fc hd tl (listFold/[T,T'] fn fc tl).

>>;;

<<

let rewriter_listfold : rewriter_module_t =

  unpack < spf, unused > =
    let @ = #[ T : Set, T' : Set, fn : T, fc : T' -> List/[T'] -> T -> T,
               l : List/[T'], l' : List/[T'], pf1 : l = l',
               e' : T, pf2 : listFold/[T,T'] fn fc l' = e' ] in
    req_iseq #@ ( @T ) ( @listFold/[T,T'] fn fc l ) ( @e') 
  in
  fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>

  holcase @e as x return < e' : @T >hol( @x = e' ) with

      ( T' : @Set, fn : @T, fc : @T' -> List/[T'] -> T -> T , l : @List/[T'] ).
       @listFold/[T,T'] fn fc l |->

	(unpack < l' , pfn' , unused > = recursive #@ ( @List/[T'] ) @l in
	 unpack < e' , pfe' , unused > =
	    (holcase ?l' as l'
	                 return < e' : @T >hol( @listFold/[T,T'] fn fc l' = e' )
	     with
		 (). @nil/[T'] |->
		  < @fn , <| @listFold_base/[T,T'] fn fc |> >

	       | (hd : @T', tl : @List/[T']). @cons/[T'] hd tl |->

		 < @?? , <| @listFold_step/[T,T'] fn fc hd tl |> >


	       | (l' : @List/[T']). @l' |->

		 < @?? , Reflexivity > )

         in
	 < @e' , <| @spf/[T,T',fn,fc,l,l',pfn',e',pfe'] |> > )


    | ( e : @T ). @e |->
       < @e , Reflexivity >

let _ = global_rewriter_add_top rewriter_listfold
>>;;

<<
MetaAxiom removed : [T : Set].List/[T] -> T -> List/[T] -> Prop.
MetaAxiom removedHead : [T:Set].forall hd : T, forall tl : List/[T], removed/[T] (cons/[T] hd tl) hd tl.
MetaAxiom removedTail : [T:Set].forall (elm hd : T) (tl rm : List/[T]), removed/[T] tl elm rm -> removed/[T] (cons/[T] hd tl) elm (cons/[T] hd rm).
>>;;

<<
let remove_list : { phi : ctx, T : @Set, elm : @T, l : @List/[T] } < rest : @List/[T] > hol( @removed/[T] l elm rest ) =
 fun phi : ctx, T : @Set , elm : @T =>
 (letrec aux : { l : @List/[T] } < rest : @List/[T] > hol( @removed/[T] l elm rest ) = fun l : @List/[T] =>
  holcase @l as l' return < rest : @List/[T] > hol( @removed/[T] l' elm rest ) with
     ().@nil/[T] |-> bot ( < rest : @List/[T] > hol( @removed/[T] nil/[T] elm rest ) )
   | ( hd : @T , tl : @List/[T] ).@cons/[T] hd tl |->
     (match def_iseq #@ @?? @hd @elm with
       som |-> unpack < pf , unused > = som in
                < @tl, Exact <| @removedHead/[T] hd tl |> by preeval( req_iseq #@ @?? @?? @?? ) > 
      |non |-> unpack < rem, pf, unused > = aux @tl in
                < @cons/[T] hd rem, <| @removedTail/[T] elm hd tl rem pf |> > )
  in
    aux)

>>;;

<<
MetaAxiom permutation : [T : Set].List/[T] -> List/[T] -> Prop.
MetaAxiom permutationNil  : [T : Set].permutation/[T] nil/[T] nil/[T] .
MetaAxiom permutationCons : [T : Set].forall (hd : T) (tl1 tl2 l2 : List/[T]), removed/[T] l2 hd tl2 -> permutation/[T] tl1 tl2 -> permutation/[T] (cons/[T] hd tl1) l2.

MetaAxiom permutationInd : [T : Set].forall (P : List/[T] -> List/[T] -> Prop),
                                         (P nil/[T] nil/[T]) ->
					 (forall (hd : T) (tl1 tl2 l2 : List/[T]), removed/[T] l2 hd tl2 -> P tl1 tl2 -> P (cons/[T] hd tl1) l2) ->
					 (forall (l1 l2 : List/[T]), permutation/[T] l1 l2 -> P l1 l2).
>>;;

(* << *)
(* ExtDefinition permutationSymm : [T : Set].forall (l1 l2 : List/[T]), permutation/[T] l1 l2 -> permutation/[T] l2 l1 := *)
(*   nu T : Set in *)
(*   Exact (Apply (Apply <| @permutationInd/[T] (fun (l1 l2 : List/[T] ) => permutation/[T] l2 l1 ) |> *)

(*     (\* base case *\) *)
(*     by (Exact <| @permutationNil/[T] |> ) ) *)

(*     (\* inductive case *\) *)
(*     by (Intro hd : T in *)
(* 	Intro tl1 in Intro tl2 in Intro l2 in *)
(* 	Assume H1 : removed/[T] l2 hd tl2 in *)
(*         Assume IH : permutation/[T] tl2 tl1 in *)
(*         (\* need to prove that permutation/[T] l2 (cons/[T] hd tl1) *\) *)
(*        ) ) *)
(* . *)

(* >>;; *)


<<
let min_list : { phi : ctx, T : @Set, f : ( @T ) -> ( @T ) -> bool , l : @List/[T] }
               < min : @T > < rest : @List/[T] > hol( @removed/[T] l min rest ) =
 fun phi : ctx, T : @Set , f : ( @T ) -> ( @T ) -> bool =>
 (letrec aux : ( { l : @List/[T] } < min : @T > < rest : @List/[T] > hol( @removed/[T] l min rest ) ) -> { l : @List/[T] } < min : @T > < rest : @List/[T] > hol( @removed/[T] l min rest ) = fun realaux : { l : @List/[T] } < min : @T > < rest : @List/[T] > hol( @removed/[T] l min rest ) => fun l : @List/[T] =>
   holcase @l as l' return < min : @T > < rest : @List/[T] > hol( @removed/[T] l' min rest ) with
     ().@nil/[T] |-> bot _
   | ( hd : @T ). @cons/[T] hd nil/[T] |->
       < @hd , < @nil/[T] , <| @removedHead/[T] ?? ?? |> > >
   | ( hd : @T , tl : @List/[T] ).@cons/[T] hd tl |->
     unpack < min', rem, pf, unused > = realaux @tl in
     if (f @hd @min' ) then
        < @hd , < @tl, Exact <| @removedHead/[T] hd tl |> by preeval( req_iseq #@ @?? @?? @?? ) > >
     else
        < @min', < @cons/[T] hd rem, <| @removedTail/[T] ?? ?? ?? ?? pf |> > >
  in
  letrec aux2 : { l : @List/[T] } < min : @T > < rest : @List/[T] > hol( @removed/[T] l min rest ) =
      fun l : @List/[T] =>
      unpack < lr , pf , u > = def_rewr #@ @?? @l in
      unpack < min, l', pf', u > = aux aux2 @lr in
      < @min , < @l' , preeval( def_auto #@ @?? ) > >
  in
    aux2)
>>;;

<<
MetaAxiom permutationSymm : [T : Set].forall (l1 l2 : List/[T]), permutation/[T] l1 l2 -> permutation/[T] l2 l1 .
>>;;

<<
let sort_list : { phi : ctx, T : @Set, f : ( @T ) -> ( @T ) -> bool, l : @List/[T] }
                < l' : @List/[T] > hol ( @permutation/[T] l l' ) =
  fun phi : ctx, T : @Set, f :  ( @T ) -> ( @T ) -> bool =>
  (letrec aux : { l : @List/[T] } < l' : @List/[T] > hol( @permutation/[T] l l' ) =
   fun l : @List/[T] =>
   unpack < lr , pflr , u > = def_rewr #@ @?? @l in
   unpack < l' , pfl' , u > =
    holcase @lr as l0 return < l' : @List/[T] > hol( @permutation/[T] l0 l' ) with
      ().@nil/[T] |-> < @nil/[T] , <| @permutationNil/[T] |> >
    | (hd : @T, tl : @List/[T]). @cons/[T] hd tl |->
     ( unpack < newhd, newtl , prf1 , unused > = min_list #@ @?? f ( @cons/[T] hd tl ) in
       unpack < newtl' , prf2 , unused > = aux @newtl in
       unpack < prf2' , unused > = <| @permutationSymm/[T] newtl newtl' prf2 |> in
       < @cons/[T] newhd newtl' , <| @permutationSymm/[T] ?? ?? (permutationCons/[T] ?? ?? ?? ?? prf1 prf2') |> > )
   in
   < @l', preeval( def_auto #@ @?? ) > 
  in aux)

>>;;

<<
let test1 = 
  let @ = #[a : Nat, b : Nat, c : Nat, d : Nat] in
  let f = ( fun x : @Nat, y : @Nat => ( hash( <| @x |> ) LT hash( <| @y |> ) ) ) in
  ( sort_list #@ ( @Nat ) f ( @cons/[??] a (cons/[??] b (cons/[??] a (cons/[??] b nil/[??])))))
>>;;

<<
Metadef sumlist : [].List/[Nat] -> Nat :=
 [].listFold/[Nat,Nat] 0 (fun (hd : Nat) (tl : List/[Nat]) (res : Nat) => plus/[] hd res).

let unfolder_sumlist =
   fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>
      holcase @T, @e as t, x return < e' : @t >hol( @x = e' ) with
	  ().@??, ().@sumlist/[] |->
	    < @?? , <| @metaunfold sumlist/[] |> >
	| (T : @Set).@T, (t : @T).@t |->
	    < @t , Reflexivity >
>>;;

<<
Metadef append : [T : Set].List/[T] -> List/[T] -> List/[T] :=
 [T : Set].fun (x y : List/[T] ) => listFold/[List/[T],T] y (fun (hd : T) (tl : List/[T]) (res : List/[T]) => cons/[T] hd res) x.

let unfolder_append =
   fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>
      holcase @T, @e as t, x return < e' : @t >hol( @x = e' ) with
	  ( T' : @Set ). @??, (). @append/[T'] |->
	    < @?? , <| @metaunfold append/[T'] |> >
	| ( T : @Set). @T, (t : @T). @t |->
	    < @t , Reflexivity >
>>;;

<<

let rewriter_sumlist_and_append : rewriter_module_t =

  unpack < spf, u > =
      (let @ = #[ l : List/[Nat] , l' : List/[Nat] , pfl' : l = l' , e' : Nat, pfe' : sumlist/[] l' = e' ] in
	 Auto :: hol( @sumlist/[] l = e' ) )
  in
  unpack < spf1 , u > =
      (let @ = #[ ] in
       (Temporary Rewriter unfolder_sumlist in ReqEqual ) :: hol( @sumlist/[] nil/[??] = zero ) )
  in
  unpack < spf2 , u > =
      (let @ = #[ hd : Nat, tl : List/[Nat] ] in
       (Temporary Rewriter unfolder_sumlist in ReqEqual ) :: hol( @sumlist/[] (cons/[??] hd tl) = plus/[] hd (sumlist/[] tl) ) )
in

  unpack < spf', u > =
      (let @ = #[ T' : Set, x : List/[T'], y : List/[T'], x' : List/[T'], e' : List/[T'], pf1 : x = x', pf2 : append/[T'] x' y = e' ] in
	 Auto :: hol( @append/[T'] x y = e' ) )
  in
  unpack < spf1' , u > =
      (let @ = #[ T' : Set, y : List/[T'] ] in
       (Temporary Rewriter unfolder_append in ReqEqual ) :: hol( @append/[T'] nil/[T'] y = y ) )
  in
  unpack < spf2' , u > =
      (let @ = #[ T' : Set, y : List/[T'], hd : T', x'' : List/[T'] ] in
       (Temporary Rewriter unfolder_append in ReqEqual ) :: hol( @append/[T'] (cons/[T'] hd x'') y = cons/[T'] hd (append/[T'] x'' y) ) )
  in


  fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>
  holcase ?T , ?e as T, e return < e' : @T >hol( @e = e' ) with
      ( ). @Nat, ( l : @List/[Nat] ). @sumlist/[] l |->
	(unpack < l' , pfl' , unused > = recursive #@ @List/[Nat] @l in
	 unpack < e' , pfe' , unused > =
	    (holcase @l' as x'
	       return < e' : @Nat >hol( @sumlist/[] x' = e' )
	     with
		 (). @nil/[??] |->
		   < @0 , <| @spf1/[] |> >
	       | (hd : @Nat , tl : @List/[Nat]).@cons/[??] hd tl |->
		   < @plus/[] hd (sumlist/[] tl) , <| @spf2/[ hd, tl ] |> >
	       | (l' : @List/[Nat]).@l' |->
		   < @sumlist/[] l' , Reflexivity >  )
         in
           < @e' , <| @spf/[l,l',pfl',e',pfe'] |> > )
    | ( T' : @Set ). @List/[T'] , (x : @List/[T'], y : @List/[T'] ). @append/[T'] x y |->
	(unpack < x' , pfx' , unused > = recursive #@ @?? @x in
	 unpack < e' , pfe' , unused > =
	    (holcase @x' as x'
	       return < e' : @List/[T'] >hol( @append/[T'] x' y = e' )
	     with
		 (). @nil/[T'] |->
		   < @y , <| @spf1'/[T',y] |> >
	       | (hd : @T', x'' : @List/[T']).@cons/[T'] hd x'' |->
		   < @cons/[T'] hd (append/[T'] x'' y) , <| @spf2'/[T',y,hd,x''] |> >
	       | (x' : @List/[T']).@x' |->
		   < @append/[T'] x' y , Reflexivity > )
         in
           < @e' , <| @spf'/[T',x,y,x',e',pfx',pfe'] |> > )

    | ( T : @Set ). @T, ( e : @T ). @e |-> 
       < @e , Reflexivity >

let _ = global_rewriter_add rewriter_sumlist_and_append

>>;;

<<
MetaAxiom removed_sum : [].forall (l : List/[Nat]) (elm : Nat) (rest : List/[Nat]), removed/[Nat] l elm rest -> sumlist/[] l = plus/[] elm (sumlist/[] rest) .
>>;;

<<
ExtDefinition permutation_sum : [].forall (l1 l2 : List/[Nat]), permutation/[Nat] l1 l2 -> sumlist/[] l1 = sumlist/[] l2 :=
    Exact (Apply (Apply ( <| @permutationInd/[Nat] (fun (l1 l2 : List/[Nat]) => sumlist/[] l1 = sumlist/[] l2 ) |> )
	 by Exact (Reflexivity :: hol ( @ 0 = 0 ) ) )
	 by Exact
	    (Intro hd : Nat in Intro tl1 : List/[Nat] in Intro tl2 : List/[Nat] in Intro l2 : List/[Nat] in 
             Assume H : removed/[Nat] l2 hd tl2 in 
             Assume IH : sumlist/[] tl1 = sumlist/[] tl2 in
	     Cut H' : sumlist/[] l2 = plus/[] hd (sumlist/[] tl2) by <| @removed_sum/[] l2 hd tl2 H |> for
	     Cut H'' : plus/[] hd (sumlist/[] tl1) = plus/[] hd (sumlist/[] tl2) by Auto for
	     Cut H''' : sumlist/[] (cons/[Nat] hd tl1) = plus/[] hd (sumlist/[] tl1) by Auto for
	     ( Auto :: hol( @sumlist/[] (cons/[Nat] hd tl1) = sumlist/[] l2 ) )
)

) .
>>;;

(* << *)
(* ExtDefinition append_sum : [].forall (l1 l2 : List/[Nat]), sumlist/[] (append/[Nat] l1 l2) = plus/[] (sumlist/[] l1) (sumlist/[] l2) := *)
(*     Intro l1 : List/[Nat] in *)
(*     Intro l2 : List/[Nat] in *)
(*     Exact  (Instantiate (Apply (Apply ( <| @listInd/[Nat] (fun l1' : List/[Nat] => sumlist/[] (append/[Nat] l1' l2) = plus/[] (sumlist/[] l1') (sumlist/[] l2)) |> ) *)
(*         by (Exact (Auto :: hol( @sumlist/[] (append/[Nat] nil/[Nat] l2) = plus/[] (sumlist/[] nil/[Nat]) (sumlist/[] l2) ) ) ) ) *)
(* 	by (Exact (Auto :: hol( @forall (hd : Nat) (tl : List/[Nat]), sumlist/[] (append/[Nat] tl l2) = plus/[] (sumlist/[] tl) (sumlist/[] l2) -> sumlist/[] (append/[Nat] (cons/[Nat] hd tl) l2) = plus/[] (sumlist/[] (cons/[Nat] hd tl)) (sumlist/[] l2) ) ) ) ) with @l1 ). *)
(* >>;; *)

<<
MetaAxiom append_sum : [].forall (l1 l2 : List/[Nat]), sumlist/[] (append/[Nat] l1 l2) = plus/[] (sumlist/[] l1) (sumlist/[] l2) .
>>;;

<<
save "prog2_rewrite_list".
>>;;
