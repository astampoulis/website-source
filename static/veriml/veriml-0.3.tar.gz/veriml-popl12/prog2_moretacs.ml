open Syntax_logic;;
open Syntax_comp;;

<<

reset.
import "prog2_auto".

let intro = (fun phi : ctx, T : [].Set,
                 P : [ @, x : T/[]].Prop ,
                 pf : hol([ @ , x : T/[]].P) =>
    unpack < pf, unused > = pf in
    <| @fun x : T/[] => pf |>)

let assume =
  (fun phi : ctx, P : @Prop, P' : [ @, x : P ].Prop , pf : hol([ @, x : P].P') =>
    unpack < pf, unused > = pf in
    <| @fun x : P => pf |>)

let change_leibn_goal =
  fun phi : ctx, G : @Prop, T : @Set, P : [phi, x : T].Prop ,
      a : @T, b : @T,
      pf1 : hol( @P/[id_phi, a] ) ,
      pf2 : hol( @a = b) ,
      pf3 : hol( @P/[id_phi, b] = G ) =>
  (eq_change #@ @?? @??
     (eq_leibniz #@ @?? @?? @??
	( [ @ , x :  T].P ) pf1 pf2)
   pf3) :: hol( @G )

let nat_induction =
  (fun phi : ctx, P : [phi, x : Nat].Prop,
       pf1 : hol( @P/[id_phi,0]),
       pf2 : hol( @forall x : Nat, P/[id_phi,x] -> P/[id_phi, succ x]),
       spf1 : hol( @ ?? ),
       spf2 : hol( @ ?? ),
       spf3 : hol( @ ?? )
     =>
    unpack < pf1', unused > = Exact pf1 by spf1 in
    unpack < pf2', unused > = Exact pf2 by spf2 in
    ( Exact <| @natInd (fun x : Nat => P) pf1' pf2' |> by spf3 ) :: hol( @forall x : Nat, P )
    )

let gen_implication = (fun phi : ctx, T : [].Set, P : [ phi, x : T/[] ].Prop, P' : [ phi, x : T/[] ].Prop ,
		   pf : hol( @forall x : T/[], P -> P'/[id_phi,x]) =>
    unpack < pf , unused > = pf in
    <| @fun genpf : forall x : T/[], P => fun x : T/[] => (pf/[id_phi] x (genpf x)) |>)

let instantiate = 
  (fun phi : ctx, T : @Set, P : [ @, x : T ].Prop , a : @T,
   pf : hol( @forall x : T, P) =>
   unpack < pf , unused > = pf in 
   <| @pf a |> :: hol( @P/[id_phi, a] ))

let cutpf =
  (fun phi : ctx, P : @Prop, P' : @Prop ,
    pf1 : hol( [ @ , H : P'/[id_phi] ].P/[id_phi] ),
    pf2 : hol( @P' ) =>
    unpack < pf1 , unused > = pf1 in
    unpack < pf2 , unused > = pf2 in
    <| @pf1/[id_phi, pf2 ] |> :: hol( @P ) )

let apply =
   (fun phi : ctx, P : @Prop, P' : @Prop,
    pf1 : hol( @P -> P'),
    pf2 : hol( @P ) =>
    unpack < pf1 , unused > = pf1 in
    unpack < pf2 , unused > = pf2 in
    <| @pf1 pf2 |> :: hol( @P' ) )

save "prog2_moretacs".

>>;;

