open Utils
open Binding
open Logic_ast

type
  csort =   CType
	  | CKind
	  | CCtx
	  | CHol
and
  cterm =   CSort of csort
	  | CPi of cvarname * cterm * cterm
	  | CLambda of cvarname * cterm * cterm
	  | CApp of cterm * cterm
	  | CHolTerm of lmodalterm
	  | CCtxTerm of lctxdesc
	  | CBVar of int
	  | CFVar of int
	  | CNVar of string
	  | CUnitExpr
	  | CUnitType
	  | CSigma of cvarname * cterm * cterm
	  | CPack of cterm (* witness *) * cvarname (* name of witness *) * cterm (* return type *) * cterm (* exist. body *)
	  | CUnpack of cterm * cvarname * cvarname * cterm
	  | CHolCase of cterm list (* case subj *) * cvarname list (* name *) * cterm (* return type *) *
	      (((cvarname * cterm) list (* pattern metavariables *) * cterm (* pattern *)) list * cterm (* branch body *)) list
	  | CCtxCase of cterm (* case subj *) * cvarname (* name *) * cterm (* return type *) *
	      (cvarname list (* ctx unif. vars *) * (cvarname * cterm) list (* pattern unif. vars *)
	       * cterm (* pattern *) * cterm (* branch body *)) list
	  | CProdType of cterm * cterm
	  | CTuple of cterm * cterm
	  | CProj of int * cterm
	  | CRecType of cvarname * cterm * cterm
	  | CFold of cterm * cterm
	  | CUnfold of cterm
	  | CSumType of cterm list
	  | CCtor of int * cterm * cterm
	  | CMatch of cterm (* term *) * (cvarname * cterm) list (* branches *)
	  | CLetRec of (cvarname * cterm * cterm) list * cterm
	  | CLet of cvarname * cterm * cterm

	  | CRefType of cterm
	  | CMkRef of cterm * cterm
	  | CAssign of cterm * cterm
	  | CReadRef of cterm
	  | CLoc of cterm ref * cterm (* type *)
	  | CSeq of cterm * cterm

	  | CArrayType of cterm
	  | CArrayLit of cterm list * cterm
	  | CMkArray of cterm * cterm * cterm
	  | CArrayGet of cterm * cterm
	  | CArraySet of cterm * cterm * cterm
	  | CArrayLoc of cterm array * cterm
	  | CArrayLen of cterm

	  | CIntType
	  | CIntConst of int
	  | CIntOp of cintop * cterm * cterm
	  | CIntTest of cinttest * cterm * cterm

	  | CBoolType
	  | CBoolConst of bool
	  | CBoolOp of cboolop * cterm * cterm
	  | CIfThenElse of cterm * cterm * cterm

	  | CHolHash of cterm
	  | CPrint of cterm
	  | CStringConst of string
	  | CStringType

	  | CPreEval of cterm * cterm * cterm list

	  | CTypeAscribe of cterm * cterm

	  | CInfer of (cterm unifvar) ref * (cterm -> cterm)
	  | CClosure of csubstenv * cterm
and
  cvarname = string option * csort
and
  csubstenv = lmodalterm list * lctxdesc list * cterm list

and
  cintop = Plus | Minus | Times | Mod
and
  cboolop = BAnd | BOr
and
  cinttest = LT | LE | GT | GE | EQ

type cterm_defenv = (cterm * cterm * cterm * bool) Dict.t

let _cunifcount    = ref 0
let _cifinfer      = (function CInfer(l,_) -> (fun y n -> y l) | _ -> (fun y n -> n))
let _cinject  l f  = CInfer(l,f)
let mk_cunifvar () = 
  let l = mk_unifvar _cunifcount in
  l
  (* (match !l with *)
  (*     Uninst(_, otyp) -> otyp := Some (ref (Inst(CSort(CType), ref None))) *)
  (*   | _ -> ()); l *)
let match_cunif    = match_unif _cifinfer
let cunifvar_type_unify unification = unifvar_type_unify unification _cifinfer _cinject _cunifcount


let case_sort f1 f2 f3 (_,s) = 
  match s with
      CHol -> f1
    | CCtx -> f2
    | _ -> f3

let
    cterm_map ?(csort   = fun s -> CSort(s))
              ?(cpi     = fun v t1 t2 rt1 rt2 -> CPi(v,rt1,rt2))
	      ?(clambda = fun v t1 t2 rt1 rt2 -> CLambda(v,rt1,rt2))
	      ?(capp    = fun t1 t2 rt1 rt2 -> CApp(rt1,rt2))
	      ?(cholterm = fun t -> CHolTerm(t))
	      ?(cctxterm = fun t -> CCtxTerm(t))
	      ?(cbvar    = fun i -> CBVar(i))
	      ?(cfvar    = fun i -> CFVar(i))
	      ?(cnvar    = fun i -> CNVar(i))
	      ?(cunitexpr = fun () -> CUnitExpr)
	      ?(cunittype = fun () -> CUnitType)
	      ?(csigma    = fun v t1 t2 rt1 rt2 -> CSigma(v,rt1,rt2))
	      ?(cpack     = fun t1 v t2 t3 rt1 rt2 rt3 -> CPack(rt1,v,rt2,rt3))
	      ?(cunpack   = fun t1 v1 v2 t2 rt1 rt2 -> CUnpack(rt1,v1,v2,rt2))
              ?(cholcase  = fun t1 v1 t2 branches rt1 rt2 rtbranches -> CHolCase(rt1,v1,rt2,rtbranches))
              ?(cctxcase  = fun t1 v1 t2 branches rt1 rt2 rtbranches -> CCtxCase(rt1,v1,rt2,rtbranches))
              ?(cprodtype = fun t1 t2 rt1 rt2 -> CProdType(rt1,rt2))
              ?(ctuple    = fun t1 t2 rt1 rt2 -> CTuple(rt1,rt2))
              ?(cproj     = fun i t1 rt1 -> CProj(i,rt1))
              ?(crectype  = fun v t1 t2 rt1 rt2 -> CRecType(v,rt1,rt2))
              ?(csumtype  = fun ts rts -> CSumType(rts))
              ?(cfold     = fun t1 t2 rt1 rt2 -> CFold(rt1,rt2))
              ?(cunfold   = fun t1 rt1 -> CUnfold(rt1))
              ?(cctor     = fun i t p rt rp -> CCtor(i,rt,rp))
              ?(cmatch    = fun t branches rt rtbranches -> CMatch(rt,rtbranches))
              ?(cletrec   = fun defs t rdefs rt -> CLetRec(rdefs, rt))
              ?(clet      = fun v t1 t2 rt1 rt2 -> CLet(v,rt1,rt2))
	      ?(cinfer    = fun l f rf-> CInfer(l,rf)) e = 
  
  let rec aux = function
      CSort(s) -> csort s
    | CPi(v,t1,t2) -> cpi v t1 t2 (aux t1) (aux t2)
    | CLambda(v,t1,t2) -> clambda v t1 t2 (aux t1) (aux t2)
    | CApp(t1,t2) -> capp t1 t2 (aux t1) (aux t2)
    | CHolTerm(t) -> cholterm t
    | CCtxTerm(t) -> cctxterm t
    | CBVar(i)    -> cbvar i
    | CFVar(i)    -> cfvar i
    | CNVar(s)    -> cnvar s
    | CUnitExpr   -> cunitexpr ()
    | CUnitType   -> cunittype ()
    | CSigma(v,t1,t2) -> csigma v t1 t2 (aux t1) (aux t2)
    | CPack(t1,v,t2,t3) -> cpack t1 v t2 t3 (aux t1) (aux t2) (aux t3)
    | CUnpack(t1,v1,v2,t2) -> cunpack t1 v1 v2 t2 (aux t1) (aux t2)
    | CHolCase(t1,v,t2,branches) ->
	(let patconv (metas,t) = (ExtList.sndmap aux metas, aux t) in
	 let branchconv (pats,e) = (List.map patconv pats, aux e) in
	   cholcase t1 v t2 branches (List.map aux t1) (aux t2) (List.map branchconv branches))
    | CCtxCase(t1,v,t2,branches) ->
	(let branchconv (ctxvs,metas,t,e) = (ctxvs, ExtList.sndmap aux metas, aux t, aux e) in
	   cctxcase t1 v t2 branches (aux t1) (aux t2) (List.map branchconv branches))	
    | CProdType(t1,t2) -> cprodtype t1 t2 (aux t1) (aux t2)
    | CTuple(t1,t2) -> ctuple t1 t2 (aux t1) (aux t2)
    | CProj(i,t1) -> cproj i t1 (aux t1)
    | CRecType(v,t1,t2) -> crectype v t1 t2 (aux t1) (aux t2)
    | CSumType(ts) -> csumtype ts (List.map aux ts)
    | CFold(t1,t2) -> cfold t1 t2 (aux t1) (aux t2)
    | CUnfold(t1) -> cunfold t1 (aux t1)
    | CCtor(i,t,p) -> cctor i t p (aux t) (aux p)
    | CMatch(t,branches) -> cmatch t branches (aux t) (ExtList.sndmap aux branches)
    | CLetRec(defs,t) -> cletrec defs t (List.map (fun (v,t1,t2)->(v,aux t1,aux t2)) defs) (aux t)
    | CLet(v,t1,t2) -> clet v t1 t2 (aux t1) (aux t2)
    | CRefType(t) -> CRefType(aux t)
    | CMkRef(t,t') -> CMkRef(aux t, aux t')
    | CReadRef(t) -> CReadRef(aux t)
    | CAssign(t1,t2) -> CAssign(aux t1, aux t2)
    | CLoc(l,t) -> CLoc(l,t)
    | CSeq(t1,t2) -> CSeq(aux t1, aux t2)
    | CIntType -> CIntType
    | CIntConst(i) -> CIntConst(i)
    | CIntOp(o,t1,t2) -> CIntOp(o,aux t1,aux t2)
    | CIntTest(o,t1,t2) -> CIntTest(o,aux t1,aux t2)
    | CBoolType -> CBoolType
    | CBoolConst(b) -> CBoolConst(b)
    | CBoolOp(o,t1,t2) -> CBoolOp(o,aux t1,aux t2)
    | CIfThenElse(t1,t2,t3) -> CIfThenElse(aux t1,aux t2,aux t3)
    | CArrayType(t) -> CArrayType(aux t)
    | CMkArray(t1,t2,t3) -> CMkArray(aux t1, aux t2, aux t3)
    | CArrayGet(t1,t2) -> CArrayGet(aux t1, aux t2)
    | CArraySet(t1,t2,t3) -> CArraySet(aux t1, aux t2, aux t3)
    | CArrayLoc(l,t) -> CArrayLoc(l,t)
    | CArrayLen(t) -> CArrayLen(aux t)
    | CArrayLit(ts,t) -> CArrayLit(List.map aux ts, aux t)
    | CHolHash(t) -> CHolHash(aux t)
    | CPrint(t) -> CPrint(aux t)
    | CStringConst(s) -> CStringConst(s)
    | CStringType -> CStringType
    | CTypeAscribe(e, t) -> CTypeAscribe(aux e, aux t)
    | CClosure(subst, t) -> CClosure(subst, t)
    | CPreEval(t1,t2,t3) -> CPreEval(aux t1,aux t2,List.map aux t3)
    | CInfer(l,f) -> cinfer l f (compose aux f)
  in
    aux e

let varmaps start getbound modal_map ctxdesc_map fbound ffree =
  let metaextend (m,x,c) i = (m+i,x,c) in
  let ctxextend  (m,x,c) i = (m,x+i,c) in
  let compextend (m,x,c) i = (m,x,c+i) in
  let extend = case_sort metaextend ctxextend compextend in
  let rec cterm_map start (t : cterm) =
    match t with
      | CPi(s, t1, t2) ->
	     CPi(s, cterm_map start t1, cterm_map (extend s start 1) t2)
      | CLambda(s, t1, t2) ->
	     CLambda(s, cterm_map start t1, cterm_map (extend s start 1) t2)
      | CApp(t1, t2) -> CApp(cterm_map start t1, cterm_map start t2)
      | CBVar i -> fbound start i
      | CFVar i -> ffree start i
      | CSigma(s,t1,t2)   -> CSigma(s, cterm_map start t1, cterm_map (extend s start 1) t2)
      | CPack(t1,s,t2,e)  -> CPack(cterm_map start t1, s, cterm_map (extend s start 1) t2, cterm_map start e)
      | CUnpack(t1,s1,s2,e) -> CUnpack(cterm_map start t1, s1, s2, cterm_map (compextend (extend s1 start 1) 1) e)
      | CHolCase(t1,v,t2,branches) ->
	  (let n = List.length v in
	   let branch_map s (pats,e) =
	     (let pats', sfinal = list_varmap'
		(fun s (metas, t) ->
		   let metas' = list_varmap (fun s (a,b) -> (a, cterm_map s b)) metaextend s metas in
		   let s' = metaextend s (List.length metas) in
		   let t' = cterm_map s' t in
		     (metas', t'), s') metaextend s pats in
		(pats', cterm_map sfinal e))
	   in CHolCase(List.map (cterm_map start) t1, v, cterm_map (metaextend start n) t2, List.map (branch_map start) branches))
      | CCtxCase(t1,v,t2,branches) ->
	  (let branch_map s (ctxvs,metas,t,e) =
	     let s' = ctxextend s (List.length ctxvs) in
	     (ctxvs,
	      list_varmap (fun s (a,b) -> (a, cterm_map s b)) metaextend s' metas,
	      cterm_map (metaextend s' (List.length metas)) t,
	      cterm_map (metaextend s' (List.length metas)) e)
	   in
	     CCtxCase(cterm_map start t1, v, cterm_map (ctxextend start 1) t2,
		      List.map (branch_map start) branches))
	      
      | CProdType(t1,t2) -> CProdType(cterm_map start t1, cterm_map start t2)
      | CTuple(t1,t2) -> CTuple(cterm_map start t1, cterm_map start t2)
      | CProj(i,t) -> CProj(i, cterm_map start t)
      | CRecType(v,t1,t2) -> CRecType(v, cterm_map start t1, cterm_map (compextend start 1) t2)
      | CFold(t1,t2) -> CFold(cterm_map start t1, cterm_map start t2)
      | CUnfold(t1) -> CUnfold(cterm_map start t1)
      | CSumType(branches) -> CSumType(List.map (cterm_map start) branches)
      | CCtor(i,t,p) -> CCtor(i, cterm_map start t, cterm_map start p)
      | CMatch(t,branches) -> CMatch(cterm_map start t, ExtList.sndmap (cterm_map (compextend start 1)) branches)
      | CLetRec(defs,t) ->
	  let start' = compextend start (List.length defs) in
	    CLetRec(List.map (fun (a,b,c)->(a,cterm_map start b,cterm_map start' c)) defs, cterm_map start' t)
      | CLet(v,t1,t2) -> CLet(v, cterm_map start t1, cterm_map (extend v start 1) t2)
      | CHolTerm(t) -> CHolTerm(modal_map start t)
      | CCtxTerm(t) -> CCtxTerm(ctxdesc_map start t)
      | CRefType(t) -> CRefType(cterm_map start t)
      | CMkRef(t, t') -> CMkRef(cterm_map start t, cterm_map start t')
      | CReadRef(t) -> CReadRef(cterm_map start t)
      | CAssign(t1,t2) -> CAssign(cterm_map start t1, cterm_map start t2)
      | CLoc(l,t) -> CLoc(l, t) (* is this correct? *)
      | CSeq(t1,t2) -> CSeq(cterm_map start t1, cterm_map start t2)
      | CIntOp(o,t1,t2) -> CIntOp(o,cterm_map start t1,cterm_map start t2)
      | CIntTest(o,t1,t2) -> CIntTest(o,cterm_map start t1,cterm_map start t2)
      | CBoolOp(o,t1,t2) -> CBoolOp(o,cterm_map start t1,cterm_map start t2)
      | CIfThenElse(t1,t2,t3) -> CIfThenElse(cterm_map start t1,cterm_map start t2,cterm_map start t3)
      | CArrayType(t) -> CArrayType(cterm_map start t)
      | CMkArray(t1,t2,t3) -> CMkArray(cterm_map start t1, cterm_map start t2, cterm_map start t3)
      | CArrayGet(t1,t2) -> CArrayGet(cterm_map start t1, cterm_map start t2)
      | CArraySet(t1,t2,t3) -> CArraySet(cterm_map start t1, cterm_map start t2, cterm_map start t3)
      | CArrayLoc(l,t) -> CArrayLoc(l,t)
      | CArrayLen(t) -> CArrayLen(cterm_map start t)
      | CArrayLit(ts,t) -> CArrayLit(List.map (cterm_map start) ts, cterm_map start t)
      | CHolHash(t) -> CHolHash(cterm_map start t)
      | CPrint(t) -> CPrint(cterm_map start t)
      | CPreEval(t1,t2,t3) -> CPreEval(cterm_map start t1, cterm_map start t2, List.map (cterm_map start) t3)
      | CTypeAscribe(e,t) -> CTypeAscribe(cterm_map start e, cterm_map start t)
      | CInfer(l,f) -> (match !(match_cunif l) with
	                 Inst(t,_) -> cterm_map start (f t)
 	                |_ -> CInfer(l, compose (cterm_map start) f)) 
      | t -> t
  in
    cterm_map start

module MetabindCterm = Binding(struct
				 type t = cterm
				 type tvar = lmodalterm
				 type tenv = int * int * int
				 let bound (c,_,_) = c
				 let varmap fb ff = varmaps (0,0,0) bound
				   (fun (sm,sx,sc) -> modal_metamap (fun sm' -> fb (sm',sx,sc)) (fun sm' -> ff (sm',sx,sc)) sm)
				   (fun (sm,sx,sc) -> ctxdesc_metamap (fun sm' -> fb (sm',sx,sc)) (fun sm' -> ff (sm',sx,sc)) sm)
				   (fun _ i -> CBVar i) (fun _ i -> CFVar i)
				 let bvar i = LBMeta i
				 let fvar i = LFMeta i
			       end)

module CtxbindCterm = Binding(struct
				type t = cterm
				type tvar = lctxdesc
				type tenv = int * int * int
				let bound (_,c,_) = c
				let varmap fb ff = varmaps (0,0,0) bound
				   (fun (sm,sx,sc) -> modal_ctxmap (fun sx' -> fb (sm,sx',sc)) (fun sx' -> ff (sm,sx',sc)) sx)
				   (fun (sm,sx,sc) -> tmlist_ctxmap (fun sx' -> fb (sm,sx',sc)) (fun sx' -> ff (sm,sx',sc)) sx)
				   (fun _ i -> CBVar i) (fun _ i -> CFVar i)
				let bvar i = LBCtx i
				let fvar i = LFCtx i
			      end)

module CbindCterm = Binding(struct
				type t = cterm
				type tvar = cterm
				type tenv = int * int * int
				let bound (_,_,c) = c
				let varmap fb ff = varmaps (0,0,0) bound 
				  (fun _ t -> t) (fun _ t -> t) fb ff
				let bvar i = CBVar i
				let fvar i = CFVar i
			    end)

let modal_shift_all (sm,sx,sc) t = 
  MetabindModal.shift_bound sm (CtxbindModal.shift_bound sx t)

let ctxdesc_shift_all (sm,sx,sc) t =
  MetabindCtxdesc.shift_bound sm (CtxbindCtxdesc.shift_bound sx t)

let cterm_shift_all (sm,sx,sc) t =
  CbindCterm.shift_bound sc (MetabindCterm.shift_bound sm (CtxbindCterm.shift_bound sx t))

module MetabindCtermS = (struct
			   let subst_bound_list = MetabindCterm.subst_bound_list_given_shift modal_shift_all
			   let subst_bound      = MetabindCterm.subst_bound_given_list subst_bound_list
			 end)

module CtxbindCtermS =  (struct
			   let subst_bound_list = CtxbindCterm.subst_bound_list_given_shift ctxdesc_shift_all
			   let subst_bound      = CtxbindCterm.subst_bound_given_list subst_bound_list
			 end)

module CbindCtermS =  (struct
			 let subst_bound_list = CbindCterm.subst_bound_list_given_shift cterm_shift_all
			 let subst_bound      = CbindCterm.subst_bound_given_list subst_bound_list
		       end)


let mk_cinfer compfree compbound metafree metabound ctxfree ctxbound =
  let closef free bound cl =
    let envlen = free + bound in
    cl ?howmany:(Some bound) envlen
  in
  let top = closef compfree compbound CbindCterm.close_down in
  let mtop = closef metafree metabound MetabindCterm.close_down in
  let ctop = closef ctxfree  ctxbound  CtxbindCterm.close_down in
  CInfer(mk_cunifvar (), compose mtop (compose ctop top))
