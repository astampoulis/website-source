open Syntax_logic;;
open Syntax_comp;;

<<

reset.
import "prog2_rewrite_euf". 

let rewriter_beta : rewriter_module_t =
  fun recursive : rewriter_t =>
  fun phi : ctx, T : @Set, e : @T =>
  holcase ?e as x return < e' : @T >hol( @x = e' ) with

      ( T' : @Set, t1 : @ T' -> T , t2 : @T' ).
	@ t1 t2 |->
	(unpack < t1', pft1, unused > = recursive #@ @?? @t1 in
	 unpack < e', pfe', unused > =
	    holcase @t1' as x return < e' : @T >hol( @x t2 = e' ) with
		  ( t1body : [ @, x : T' ].T/[id_phi] ).@fun x : T' => t1body |->
		    < @t1body/[id_phi, t2 ] , <| @beta (fun x : T' => t1body) t2 |> > 

	       | ( t1' : @T' -> T ). @t1' |->
		 < @t1' t2 , eq_refl #@ @?? @?? >
	 in
           < @e', preeval( req_iseq #@ @?? @?? @?? ) > )

    | ( t : @T ). @t |->
      < @t , preeval( eq_refl #@ @?? @?? ) >


let _ =  global_rewriter_add rewriter_beta

save "prog2_rewrite_beta".

>>;;

