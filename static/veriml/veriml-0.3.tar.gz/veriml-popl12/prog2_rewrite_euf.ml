open Syntax_logic;;
open Syntax_comp;;
open Syntax_tac;;

<<

reset.
import "prog2_rewrite_naive".

let STANDARD_HASH_SIZE = 50

(* Hash implementation *)

let hash_t = fun phi : ctx => fun res : { T : @Set } ( @T ) -> CType =>
              array (option ( < T : @Set , key : @T > res @T @key))

let mkhash = fun phi : ctx => fun res : { T : @Set} ( @T ) -> CType =>
             fun i : int =>
             ( mkarray ( i , none _ , _ ) :: ( hash_t #@ res ) )


let hashget = fun phi : ctx => fun res : {T : @Set} ( @T ) -> CType =>
              fun h : hash_t #@ res =>
              fun T : @Set, t : @T =>
              let hn = arraylen h in
              letrec find : (int -> (option (res @T @t))) =
		  fun i : int => 
		  match h.(i) with
		      som |-> (unpack < T', t', result > = som in
                               holcase @T' , @t' as T', t' return (option (res @T @t)) with
				   ().@T , ().@t |->
				     some _ result
				| (T' : @Set). @T', (t' : @T'). @t' |-> find ((i iplus 1) imod hn))
                    | non |-> none _
              in
                find ((hash <| @t |>) imod hn)


let hashget_uns = fun phi : ctx , res : {T : @Set} ( @T) -> CType =>
  fun h : hash_t #@ res =>
  fun T : @Set, t : @T =>
  match hashget #@ res h @T @t with
      som |-> som
    | non |-> bot _

let hashset = fun phi : ctx => fun res : {T : @Set} ( @T ) -> CType =>
              fun h : hash_t #@ res =>
              fun T : @Set , t : @T , r : res @T @t =>
              let hn = arraylen h in
              letrec find : (int -> Unit) =
		fun i : int => 
		  match h.(i) with
		      som |-> (unpack < T', t', result > = som in
                               holcase @T', @t' as T', t' return Unit with
			 	  (). @T , (). @t |->
				    h.(i) <- (some _ (pack @T as T return < key : @T >res @T @key with < @t , r > ))
				| (T' : @Set). @T' , ( t' : @T' ). @t' |->
				    find ((i iplus 1) imod hn))
                    | non |-> h.(i) <- (some _ (pack @T as T return < key : @T >res @T @key with < @t , r > ))
              in
                find ((hash <| @t |>) imod hn)


(* Set implementation *)

let set_t = fun phi : ctx => (hash_t #@ (fun T : @Set, t : @T => Unit)) * (list ( < T : @Set >hol( @T )) )
let mkset = fun #phi : ctx , i : int => 
             ( tup( mkhash #@ _ i , nil _ ) :: ( set_t #@ ) )
let setadd = fun phi : ctx , s : set_t #@ , T : @Set , t : @T =>
             (match hashget #@ _ (fst s) @T @t with
		  som |-> s
		| non |-> ((hashset #@ _ (fst s) @T @t unit);
		           tup(fst s, cons _
				           (pack @T as T return hol( @T) with <| @t |> )
					   (snd s))))
let setfold = fun a : CType , phi : ctx ,
                  f : { T : @Set , t : @T} a -> a , start : a , s : set_t #@ =>
              listfold _ _ 
	      (fun st : a , t : < T : @Set >hol( @T ) =>
		  unpack < T, t, unused > = t in
		  f ( @T ) ( @t ) st)
	      start
	      (snd s)

let setiter = fun phi : ctx ,
                  f : { T : @Set } ( @T ) -> Unit ,
                  s : set_t #@ =>
              setfold _ #@ (fun T : @Set , t : @T => fun unused : Unit => f @T @t) unit s


let setunion = fun phi : ctx , s1 : set_t #@ , s2 : set_t #@ =>
               setfold _ #@
	       (fun T : @Set, t : @T , s : set_t #@ => setadd #@ s @T @t)
	       s1 s2

(* Union-find with congruence *)

let ufres = fun phi : ctx , T : @Set, t : @T =>
  (ref ( < t' : @T >hol( @t = t') ) ) *
  (ref (set_t #@ ))

let ufhash_t = fun phi : ctx => hash_t #@ ( ufres #@ )

let ufempty = fun phi : ctx => ( mkhash #@ _ STANDARD_HASH_SIZE ) :: ( ufhash_t #@ ) 

let ufprint =
  fun phi : ctx, h : ufhash_t #@ =>
  let hn = arraylen h in
  letrec myprint : (int -> Unit) = fun i : int =>
      if (i EQ hn) then
	unit
      else
	((match h.(i) with
	    som |->
	      (unpack < T, t, res > = som in
	       unpack < trep, unused > = !(fst res) in
	       (print <| @t |> ); (print "points to"); (print <| @trep |> ))
	  | non |-> unit);
	 myprint (i iplus 1))
  in
   myprint 0


let syntactic_iseq = 
  fun phi : ctx, T : @Set , e1s : @T , e2s : @T =>
  holcase @e2s as e2 return bool with
      (). @e1s |-> true
    | (e2s : @T). @e2s |-> false

let _ = global_rewriter_add_top rewriter_naive_eq

let find =
  fun phi : ctx , h : ufhash_t #@ =>
  letrec find : { T : @Set , n : @T } < n' : @T >hol( @n = n') =
  let add_to_ccpar =
    fun T : @Set, n : @T, T' : @Set, n' : @T' =>
      (let nres = find @T @n in
       unpack < nrep, unused > = nres in
       let nentry = hashget_uns #@ _ h @T @nrep in
       let nccpar = snd nentry in
       nccpar := setadd #@ !nccpar @T' @n')
  in
  let findrepforapp =
    fun T : @Set, T' : @Set, f : @T -> T', a : @T =>
    (unpack < frep, fprf, unused > = find @?? @f in
     unpack < arep, aprf, unused > = find @?? @a in
     (if (syntactic_iseq #@ @?? @f @frep) && (syntactic_iseq #@ @?? @a @arep) then
	 < @f a, preeval( req_iseq #@ @?? @?? @?? ) >
      else
	 (unpack < farep, faprf2 , unused > = find @?? ( @frep arep) in
	   < @farep, preeval( req_iseq #@ @?? @?? @?? ) > )

     )) :: ( < fa' : @T' >hol( @f a = fa' ) )
  in
  let res = 
  fun T : @Set, n : @T =>
  (DEBUGPRINT "find for"); 
  (DEBUG (fun u : Unit => (print <| @n |> )) );
  match hashget #[#phi] _ h @T @n with
      som |-> (unpack < n', prf, unused > = !(fst som) in
              if syntactic_iseq #[#phi] @T @n @n' then
		!(fst som)
	      else
		(let res = find @T @n' in
		   unpack < n'', prf', unused > = res in
		   < @n'' , preeval( req_iseq #@ @?? @?? @?? ) > ))
    | non |->
	let ccpar = mkref (mkset #@ STANDARD_HASH_SIZE, set_t #@ ) in
	(holcase @n as n return < n' : @T >hol( @n = n') with

	    (T' : @Set , f : @T' -> T, n1 : @T'). @f n1 |->
	      (let rep = findrepforapp @T' @T @f @n1 in
	        (hashset #@ _ h ( @T ) ( @n ) tup(mkref (rep, _ ), ccpar ) );
	        (add_to_ccpar @?? @n1 @?? @n);
	        (add_to_ccpar @?? @f  @?? @n);
	        rep)

	       | (n : @T). @n |->
		 (let same = < @n , preeval( req_iseq #@ @?? @?? @?? ) > :: < n' : @T >hol( @n = n') in
  		    (hashset #@ _ h ( @T ) ( @n ) tup(mkref (same, _ ), ccpar ));
		    same))
  in
  (* full rewriting *)
  (*fun T : @Set, n : @T =>
    unpack < n' , pfn' , unused > = def_rewr #@ @T @n in
    unpack < n'' , pfn'' , unused > = res @T @n' in
    pack @n'' as n'' return hol ( @n = n'' ) with <| @trans pfn' pfn'' |>  *)
  (* no rewriting *)
    (fun T : @Set, n : @T => res @T @n)
  in
  find

let union = fun phi : ctx , h : ufhash_t #@ =>
  fun T : @Set , n1 : @T , n2 : @T , prf : @n1 = n2 =>
  (let n1res = find #@ h @T @n1 in
   let n2res = find #@ h @T @n2 in
   unpack < n1', prf1 (* n1 = n1' *), unused > = n1res in
   unpack < n2', prf2 (* n2 = n2' *), unused > = n2res in
   if (syntactic_iseq #@ @T @n1' @n2') then
     unit
   else
     (let new2 = < @n2' , preeval (req_iseq #@ @?? @?? @?? ) > :: < n2' : @T >hol( @n1' = n2') in
      let n1entry = hashget_uns #@ _ h @T @n1' in
      let n2entry = hashget_uns #@ _ h @T @n2' in
      let n1ccpar = snd n1entry in
      let n2ccpar = snd n2entry in
      let n1rep = fst n1entry in
	(n1rep := new2 );
	(n2ccpar := (setunion #@ !n1ccpar !n2ccpar));
	(n1ccpar := (mkset #@ STANDARD_HASH_SIZE))))

let already_eq = fun phi : ctx , h : hash_t #@ (ufres #@ ) ,
                     T : @Set , n1 : @T , n2 : @T =>
   let res1 = find #@ h @T @n1 in
   let res2 = find #@ h @T @n2 in
   unpack < n1', pf1, unused > = res1 in
   unpack < n2', pf2, unused > = res2 in
   (* by now we have: n1 = n1' and n2 = n2'. We need n1 = n2 *)

  (* this depends on environment-substitutive pattern matching *)
   holcase @n1' as n1' return option hol( @n1 = n2) with
       (). @n2' |-> (* n1 = n2' /\ n2 = n2' *)
  	                    some _ (* TODO: static *) <| @trans pf1 (symm pf2) |>
     | (n11 : @T). @n11 |-> none _ 


let congruent = fun phi : ctx , h : hash_t #@ _ =>
                fun T : @Set , n1 : @T , n2 : @T =>
  let test1 = already_eq #@ h @T @n1 @n2 in
    (match test1 with
	 som |-> test1
       | non |->
	   (holcase @n1 as n1 return option(hol( @n1 = n2)) with
		(T' : @Set, f : @T' -> T, n0 : @T'). @f n0 |->
		  (holcase @n2 as n2 return option(hol( @f n0 = n2 )) with
		       (f' : @T' -> T, n0' : @T'). @f' n0' |->
			 (let funceq = already_eq #[#phi] h @?? @f @f' in
			  match funceq with
			      som |-> (unpack < pfF , unused > = som in
				      let argseq = already_eq #@ h @T' @n0 @n0' in
				      match argseq with
					  som |-> (unpack < pfA, unused > = som in
						  some _
						    (preeval( req_iseq #@ @?? @?? @?? ))
						  )
					| non |-> none _ )
			    | non |-> none _ )
		     | (n2 : @T).@n2 |->
			 none _ )
	      | (n1 : @T).@n1 |->
		  none _ ) )

let merge = fun phi : ctx , h : hash_t #@ ( ufres #@ ) =>
  letrec merge : { T : @Set, n1 : @T, n2 : @T, prf : @n1 = n2 } Unit =
  fun T : @Set, n1 : @T , n2 : @T , prf : @n1 = n2 =>
  (DEBUGPRINT "merging:");
  (DEBUG (fun u : Unit => (print <| @n1 |> ); (print <| @n2 |> ) ) );
  unpack < n1', unused > = find #@ h @T @n1 in
  unpack < n2', unused > = find #@ h @T @n2 in
  if syntactic_iseq #@ @T @n1' @n2' then
    unit
  else
    (let n1ccpar = !(snd (hashget_uns #@ _ h @T @n1')) in
     let n2ccpar = !(snd (hashget_uns #@ _ h @T @n2')) in
     let mergeifneeded = fun T1 : @Set, t1 : @T1 , T2 : @Set, t2 : @T2 =>
       holcase @T1 as T1 return Unit with
	   (). @T2 |->
	     (unpack < t1', unused > = find #@ h @T1 @t1 in
	      unpack < t2', unused > = find #@ h @T1 @t2 in
              if syntactic_iseq #@ @T1 @t1' @t2' then
		unit
	      else
		(match congruent #@ h @T1 @t1 @t2 with
		     som |-> (unpack < pft, unused > = som in merge @T1 @t1 @t2 @pft)
                   | non |-> unit))
	 | (T1 : @Set). @T1 |-> unit
     in
      (union #@ h @T @n1 @n2 @prf);
      (setiter #@ (fun T1 : @Set, t1 : @T1 =>
	   setiter #@ (fun T2 : @Set, t2 : @T2 => mergeifneeded @T1 @t1 @T2 @t2) n2ccpar)
	 n1ccpar)
    )
  in
  merge


let already_eq_no_mutate = fun phi : ctx , h : hash_t #@ ( ufres #@ ) =>
                 fun T : @Set , n1 : @T , n2 : @T =>
  match hashget #@ ( ufres #@ ) h @T @n1 with
      som |-> (match hashget #@ _ h @T @n2 with
		   som |-> already_eq #@ h @T @n1 @n2
		 | non |-> none _ )
    | non |-> none _

let _ = global_rewriter_remove_top unit


let ufbuilder : { phi : ctx} ufhash_t #@ =
  letrec ufbuilder : { phi : ctx} hyps_t #@ =
  fun phi : ctx =>
    ctxcase #@ as phi return hyps_t #[phi] with
	().().[] |-> nil _

      | ( phi0 ).(T : [ phi0 ].Set, t1 : [ phi0 ].T, t2 : [ phi0 ].T).
	  [ phi0, pf : t1 = t2 ] |->
	(let res = ufbuilder #[ phi0 ] in
	 let @ = #[ phi0, pf : t1 = t2 ] in
	 let res' = cons _
	            (pack @T/[id_phi0] as T return < t1' : @T , t2' : @T >hol( @t1' = t2' ) with
		     pack @t1/[id_phi0] as t1' return < t2' : @T/[id_phi0] >hol( @t1' = t2' ) with
		     pack @t2/[id_phi0] as t2' return hol( @t1/[id_phi0] = t2' ) with
		     <| @pf |> )
		    res
	 in
	 res' )
      | ( phi0 ).(P : [ phi0 ].Prop).[ phi0, pf : P ] |->
	  ufbuilder #[ phi0 ]
      | ( phi0 ).(T : [ phi0 ].Set ).[ phi0, t : T ] |->
	  ufbuilder #[ phi0 ]
      | ( phi0 ).().[ phi0, t : Set] |->
	  ufbuilder #[ phi0 ]
  in
  fun phi : ctx =>
      let hyplist = ufbuilder #@ in
      let ufhash =  ufempty #@ in
       (listiter _
	  (fun hyp : < T : @Set, t1 : @T, t2 : @T>
				  hol( @t1 = t2 ) =>
	      unpack < T, t1, t2, pf, unused > = hyp in
	      merge #[#phi] ufhash @T @t1 @t2 @pf)
          hyplist);
       ufhash

						      
let ufprint_for_ctx = fun phi : ctx =>
  ufprint #@ (ufbuilder #@ )

let equaltester_euf_creator : ( {phi : ctx} ufhash_t #@ ) ->
                              equaltester_t =
  fun ufbuilder : ( {phi : ctx} ufhash_t #@ ) ,
    phi : ctx , T : @Set, e1 : @T, e2 : @T =>
    (DEBUGPRINT "testing equality as part of EUF eqcheck");
    (DEBUG (fun u : Unit => ( print <| @e1 |> ); ( print <| @e2 |> ) ));
    already_eq #@ (ufbuilder #@ ) @T @e1 @e2

let equaltester_euf : equaltester_t = 
  equaltester_euf_creator ufbuilder

let _ = global_equaltester_add equaltester_euf

save "prog2_rewrite_euf".

>>;;
