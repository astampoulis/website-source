open Syntax_logic;;
open Syntax_comp;;
open Syntax_tac;;

<<

reset.
import "prog2_moretacs".

ExtDefinition plus : ([].Nat -> Nat -> Nat) :=
  <| [].fun x : Nat => fun y : Nat => ?natFold/[??] y (fun p : Nat => fun r : Nat => succ r) x |> .

let unfolder_plus = 
      fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>
      holcase @T, @e as t, x return < e' : @t >hol( @x = e' ) with
	  ().@??, ().@plus/[] |->
	    < @?? , <| @metaunfold plus/[] |> >
	| (T : @Set).@T, (t : @T).@t |->
	    < @t , <| @refl t |> >

let rewriter_plus_ZS_x : rewriter_module_t =

  unpack < spf, u > =
      (let @ = #[ x : Nat, y : Nat, x' : Nat, e' : Nat, pf1 : x = x', pf2 : plus/[] x' y = e' ] in
	 Auto :: hol( @plus/[] x y = e' ) )
  in
  unpack < spf1 , u > =
      (let @ = #[ y : Nat ] in
       (Temporary Rewriter unfolder_plus in ReqEqual ) :: hol( @plus/[] zero y = y ) )
  in
  unpack < spf2 , u > =
      (let @ = #[ y : Nat, x'' : Nat ] in
       (Temporary Rewriter unfolder_plus in ReqEqual ) :: hol( @plus/[] (succ x'') y = succ (plus/[] x'' y) ) )
  in

  fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>
  holcase @T , @e as T, e return < e' : @T >hol( @e = e' ) with
      (). @Nat, ( x : @Nat , y : @Nat ). @plus/[] x y |->
	(unpack < x' , pfx' , unused > = recursive #@ @Nat @x in
	 unpack < e' , pfe' , unused > =
	    (holcase @x' as x'
	       return < e' : @Nat >hol( @plus/[] x' y = e' )
	     with
		 (). @zero |->
		   < @y , <| @spf1/[y] |> >
	       | (x'' : @Nat).@succ x'' |->
		   < @succ (plus/[] x'' y) , <| @spf2/[y,x''] |> >
	       | (x' : @Nat).@x' |->
		   < @plus/[] x' y , Reflexivity > )
         in
           < @e' , <| @spf/[x,y,x',e',pfx',pfe'] |> > )
    | ( T : @Set ). @T, ( e : @T ). @e |-> 
       < @e , Reflexivity >

let _ = global_rewriter_add rewriter_plus_ZS_x


ExtDefinition plus_x_z : [].forall x : Nat, plus/[] x 0 = x :=
 NatInduction for x. plus/[] x 0 = x
     base case by Auto
     inductive case by Auto.

ExtDefinition plus_x_Sy : [].forall (x y : Nat), plus/[] x (succ y) = succ (plus/[] x y) :=
 Intro x : Nat in 
 Intro y : Nat in	      
 Instantiate
     (NatInduction for z. plus/[] z (succ y) = succ (plus/[] z y)
		 base case by Auto
		 inductive case by Auto)
 with @x .


let rewriter_plus_x_ZS : rewriter_module_t =

  unpack < spf, u > =
      (let @ = #[ x : Nat, y : Nat, y' : Nat, e' : Nat, pf1 : y = y', pf2 : plus/[] x y' = e' ] in
	 Auto :: hol( @plus/[] x y = e' ) )
  in

  fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>
  holcase @T , @e as T, e return < e' : @T >hol( @e = e' ) with
      (). @Nat, ( x : @Nat , y : @Nat ). @plus/[] x y |->
	(unpack < y' , pfy' , unused > = recursive #@ @Nat @y in
	 unpack < e' , pfe' , unused > =
	    (holcase @y' as y'
	       return < e' : @Nat >hol( @plus/[] x y' = e' )
	     with
		 (). @zero |->
		   <  @x , <| @plus_x_z/[] x |> >
	       | (y'' : @Nat).@succ y'' |->
		   < @succ (plus/[] x y'') , <| @plus_x_Sy/[] x y'' |> >
	       | (y' : @Nat).@y' |->
		   < @plus/[] x y' , Reflexivity > )
         in
           < @e' , <| @spf/[x,y,y',e',pfy',pfe'] |> > )
    | ( T : @Set ). @T, ( e : @T ). @e |-> 
       < @e , Reflexivity > 

let _ = global_rewriter_add rewriter_plus_x_ZS

ExtDefinition plus_comm : [].forall (x y : Nat), plus/[] x y = plus/[] y x :=
  Intro x : Nat in
    NatInduction for y. plus/[] x y = plus/[] y x
     base case by Auto
     inductive case by Auto .

ExtDefinition plus_assoc : [].forall (x y z : Nat), plus/[] x (plus/[] y z) =
		                                    plus/[] (plus/[] x y) z :=
  Intro x : Nat in
  Intro y : Nat in
  NatInduction for z.plus/[] x (plus/[] y z) = plus/[] (plus/[] x y) z
  base case by Auto
  inductive case by Auto.


let rewriter_plus_comm_assoc : rewriter_module_t =

  fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>
  holcase ?T , ?e as T, e return < e' : @T >hol( @e = e' ) with
      (). @Nat, ( x : @Nat , a : @Nat, b : @Nat ). @plus/[] x (plus/[] a b) |->
	 < @plus/[] (plus/[] x a) b , <| @plus_assoc/[] ?? ?? ?? |> >

    | (). @Nat, ( x : @Nat , y : @Nat ). @plus/[] x y |->
        (if ( hash <| ?x |>  ) GT ( hash <| ?y |>) then
	    < @plus/[] x y , Reflexivity >
	 else
	    < @plus/[] y x , <| @plus_comm/[] ?? ?? |> > )
	  
    | ( T : @Set ). @T, ( e : @T ). @e |-> 
       < @e , Reflexivity >

save "prog2_rewrite_plus".

>>;;
