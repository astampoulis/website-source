open Camlp4

module Id = struct
  let name = "syntax_monad"
  let version = "1.0"
end

module Make (Syntax : Sig.Camlp4Syntax) = struct
  open Sig
  include Syntax

  EXTEND Gram
    GLOBAL: expr;

    expr: LEVEL "top"
      [ [ "nowarn"; "let"; i = ipatt; "="; e = expr; "in";
          x = expr LEVEL ";" ->
            <:expr< (match $e$ with $i$ -> $x$ | _ -> assert false) >> ] ];

  END

end

module M = Register.OCamlSyntaxExtension(Id)(Make)

