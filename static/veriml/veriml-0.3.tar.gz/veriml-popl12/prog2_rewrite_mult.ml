open Syntax_logic;;
open Syntax_comp;;
open Syntax_tac;;

<<

reset.
import "prog2_theorems".

ExtDefinition mult : ([].Nat -> Nat -> Nat) :=
  <| [].fun x : Nat => fun y : Nat => ?natFold/[??] 0 (fun p : Nat => fun r : Nat => plus/[] y r) x |> .

>>;;

<<
let _ = global_rewriter_add_top (fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>
      holcase @T, @e as t, x return < e' : @t >hol( @x = e' ) with
	  ().@??, ().@mult/[] |->
	    (pack @?? as e' return hol( @mult/[] = e' ) with
		<| @metaunfold mult/[] |>)
	| (T : @Set).@T, (t : @T).@t |->
	    (pack @t as t' return hol( @t = t') with
		 <| @refl t |>))
>>;;

<<
ExtDefinition mult_z_y  : [].forall y : Nat, mult/[] 0 y = 0 := Auto. 
ExtDefinition mult_Sx_y : [].forall (x y : Nat), mult/[] (succ x) y = plus/[] y (mult/[] x y) := Auto.
>>;;

<<
let _ = global_rewriter_remove_top unit

let rewriter_mult_ZS_x : rewriter_module_t =

  unpack < spf, u > =
      (let @ = #[ x : Nat, y : Nat, x' : Nat, e' : Nat, pf1 : x = x', pf2 : mult/[] x' y = e' ] in
	 Auto :: hol( @mult/[] x y = e' ) )
  in

  fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>
  holcase ?T , ?e as T, e return < e' : @T >hol( @e = e' ) with
      (). @Nat, ( x : @Nat , y : @Nat ). @mult/[] x y |->
	(unpack < x' , pfx' , unused > = recursive #@ @Nat @x in
	 unpack < e' , pfe' , unused > =
	    (holcase @x' as x'
	       return < e' : @Nat >hol( @mult/[] x' y = e' )
	     with
		 (). @zero |->
		   < @zero, <| @mult_z_y/[] y |> > 

	       | (x'' : @Nat).@succ x'' |->
		   < @plus/[] y (mult/[] x'' y) , <| @mult_Sx_y/[] x'' y |> >

	       | (x' : @Nat).@x' |->
		   < @mult/[] x' y, Reflexivity > )

         in
	   < @e' ,  <| @spf/[x,y,x',e',pfx',pfe'] |> > )
    | ( T : @Set ). @T, ( e : @T ). @e |-> 
       < @e , Reflexivity >

let _ = global_rewriter_add rewriter_mult_ZS_x
>>;;

<<

ExtDefinition mult_x_z : [].forall x : Nat, mult/[] x 0 = 0 :=
 NatInduction for x. mult/[] x 0 = 0
     base case by Auto
     inductive case by Auto.

ExtDefinition plus_assoc2 : [].forall (x y z : Nat), plus/[] x (plus/[] y z) = plus/[] y (plus/[] x z) :=
  Temporary Rewriter rewriter_plus_comm_assoc in Auto.

ExtDefinition mult_x_Sy : [].forall (x y : Nat), mult/[] x (succ y) = plus/[] x (mult/[] x y) :=
 Intro x : Nat in 
 Intro y : Nat in
 Instantiate 
 (NatInduction for z. mult/[] z (succ y) = plus/[] z (mult/[] z y)
     base case by Auto
     inductive case by ( Intro z : Nat in
			 Assume IH in
	                 Cut H : plus/[] y (plus/[] z (mult/[] z y)) = plus/[] z (plus/[] y (mult/[] z y) )
			     by <| @plus_assoc2/[] ?? ?? ?? |>
			     for Auto ) )
 with @x.

>>;;

<<
let rewriter_mult_x_ZS : rewriter_module_t =

  unpack < spf, u > =
      (let @ = #[ x : Nat, y : Nat, y' : Nat, e' : Nat, pf1 : y = y', pf2 : mult/[] x y' = e' ] in
	 Auto :: hol( @mult/[] x y = e' ) )
  in

  fun recursive : rewriter_t, phi : ctx, T : @Set, e : @T =>
  holcase ?T , ?e as T, e return < e' : @T >hol( @e = e' ) with
      (). @Nat, ( x : @Nat , y : @Nat ). @mult/[] x y |->
	(unpack < y' , pfy' , unused > = recursive #@ @Nat @y in
	 unpack < e' , pfe' , unused > =
	    (holcase @y' as y'
	       return < e' : @Nat >hol( @mult/[] x y' = e' )
	     with
		 (). @zero |->
		   < @zero, <| @mult_x_z/[] x |> > 

	       | (y'' : @Nat). @succ y'' |->
		   < @plus/[] x (mult/[] x y'') , <| @mult_x_Sy/[] ?? ?? |> >

	       | (y' : @Nat).@y' |->
		   < @mult/[] x y', Reflexivity > )

         in
	   < @e' ,  <| @spf/[x,y,y',e',pfy',pfe'] |> > )
    | ( T : @Set ). @T, ( e : @T ). @e |-> 
       < @e , Reflexivity >

let _ = global_rewriter_add rewriter_mult_x_ZS

>>;;

<<
ExtDefinition mult_comm : [].forall (x y : Nat), mult/[] x y = mult/[] y x :=
  Intro x : Nat in
  NatInduction for y. mult/[] x y = mult/[] y x
  base case by Auto 
  inductive case by Auto .
>>;;

<<
ExtDefinition distr_aux1 : [].forall (q q1 q2 y z : Nat), q = plus/[] q1 q2 ->
                                 plus/[] (plus/[] y z) q =
			         plus/[] (plus/[] y q1) (plus/[] z q2) :=
  Intro q in Intro q1 in Intro q2 in Intro y in Intro z in Assume H in
  Cut H1 : plus/[] (plus/[] y z) q = plus/[] (plus/[] y z) (plus/[] q1 q2) by Auto for
  Cut H2 : plus/[] (plus/[] y z) (plus/[] q1 q2) = plus/[] y (plus/[] z (plus/[] q1 q2)) by <| @symm (plus_assoc/[] ?? ?? ??) |> for
  Cut H3 : plus/[] z (plus/[] q1 q2) = plus/[] q1 (plus/[] z q2) by <| @plus_assoc2/[] ?? ?? ?? |> for
  Cut H4 : plus/[] y (plus/[] z (plus/[] q1 q2)) = plus/[] y (plus/[] q1 (plus/[] z q2)) by Auto for
  Cut H5 : plus/[] y (plus/[] q1 (plus/[] z q2)) = plus/[] (plus/[] y q1) (plus/[] z q2) by <| @plus_assoc/[] ?? ?? ?? |> for
  Auto .


>>;;

<<
ExtDefinition mult_plus_distr : [].forall (x y z : Nat), mult/[] x (plus/[] y z) = plus/[] (mult/[] x y) (mult/[] x z) :=
  Intro x : Nat in
  Intro y : Nat in
  Intro z : Nat in
  Instantiate
    (NatInduction for a. mult/[] a (plus/[] y z) = plus/[] (mult/[] a y) (mult/[] a z)
     base case by Auto
     inductive case by ( Intro a : Nat in
		         Assume IH : ?? in
		         Cut H : ??
			      by <| @distr_aux1/[] (mult/[] a (plus/[] y z)) (mult/[] a y) (mult/[] a z) y z IH |> 
			      for Auto ) )
  with @x .

>>;;

<<

ExtDefinition mult_assoc : [].forall (x y z : Nat), mult/[] x (mult/[] y z) = mult/[] (mult/[] x y) z :=
  Intro x : Nat in
  Intro y : Nat in
  NatInduction for z. mult/[] x (mult/[] y z) = mult/[] (mult/[] x y) z
  base case by Auto
  inductive case by
     (Intro z : Nat in
      Assume IH in
      Cut H1 : mult/[] x (plus/[] y (mult/[] y z)) = plus/[] (mult/[] x y) (mult/[] x (mult/[] y z)) by <| @mult_plus_distr/[] ?? ?? ?? |> for
      Auto
     ) .

>>;;

<<
save "prog2_rewrite_mult".
>>;;
