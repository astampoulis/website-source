open Utils
open Logic_ast
open Comp_ast
open Logic_core
open Logic_typing
open Comp_typing
open Comp_print
open Format

let subst_bound_2 ~case1:((_,var1) as s1) ~case2:((_,var2) as s2) ~term:t ~subst1:e1 ~subst2:e2 =
  if var1 = var2 then
    (match var1 with
	 CType | CKind -> CbindCtermS.subst_bound_list [e1; e2] t
       | _ -> failwith "this shouldn't be possible")
  else
    subst_bound ~case:s2 ~subst:e2 ~term:(subst_bound ~case:s1 ~subst:e1 ~term:t)

let debug_break_point u = ()

let eval defenv cdefenv ?(trusted=false) e =
  let add_to_subst ~case:k =
    case_kind ~case:k
      (function CHolTerm(what) -> fun (metasubst,ctxsubst,compsubst) -> what::metasubst,ctxsubst,compsubst | _ -> failwith "add_to_subst")
      (function CCtxTerm(what) -> fun (metasubst,ctxsubst,compsubst) -> metasubst,what::ctxsubst,compsubst | _ -> failwith "add_to_subst")
      (function what ->           fun (metasubst,ctxsubst,compsubst) -> metasubst,ctxsubst,what::compsubst)
  in
  let new_fvar ~case:k (metabound,ctxbound,compbound) (metasubst,ctxsubst,compsubst) =
    case_kind ~case:k
      ( (metabound+1,ctxbound,compbound) , (LFMeta(metabound) :: metasubst, ctxsubst, compsubst) )
      ( (metabound,ctxbound+1,compbound) , (metasubst, LFCtx(ctxbound) :: ctxsubst, compsubst) )
      ( (metabound,ctxbound,compbound+1) , (metasubst, ctxsubst, CFVar(compbound) :: compsubst) )
  in
  let close_down ~case:k (metabound,ctxbound,compbound) t =
    case_kind (MetabindCterm.close_down ~howmany:1 metabound)
              (CtxbindCterm.close_down ~howmany:1 ctxbound)
              (CbindCterm.close_down ~howmany:1 compbound)
              ~case:k
              t
  in
  let closedown_meta_ctx (metasubst,ctxsubst,_) what =
    flatten_all_cterm
      (MetabindCtermS.subst_bound_list (List.rev metasubst)
	 (CtxbindCtermS.subst_bound_list (List.rev ctxsubst)
	    what))
  in
  let rec isrectype t =
    match t with
	CRecType(_,_,_) -> true
      | CApp(t1,_) -> isrectype t1
      | _ -> false
  in
  let rec evalall ((metasubst,ctxsubst,compsubst) as subst) bound trusted e = 
    let eval subst e = evalall subst bound trusted e in
    let evalunderbinder subst v e = 
      let bound', subst' = new_fvar v bound subst in
	close_down v bound' (evalall subst' bound' trusted e)
    in
      
    (* fprintf std_formatter "%a@\n@\n" pr_cterm e; *)
    match e with
	
	CApp(e1,e2) ->
	  (let v1 = eval subst e1 in
	   let v2 = eval subst e2 in
	     match v1 with
		 CClosure(subst', CLambda(var, _, body)) ->
		   eval (add_to_subst ~case:var v2 subst') body
	       | t when isrectype t ->
		   CApp(v1,v2)
	       | _ -> failwith "app of non-function -- type checker or evaluator is wrong")
	    
      | CPack(e1,nam,typ,e2) ->
	  CPack(eval subst e1, nam, evalunderbinder subst nam typ, eval subst e2)
	    
      | CUnpack(e, nam1, nam2, e') ->
	  (nowarn let CPack(e1,_,_,e2) = eval subst e in
	   let subst' = add_to_subst ~case:nam2 e2 (add_to_subst ~case:nam1 e1 subst) in
	     eval subst' e')

      | CHolCase(ts,nams,ret,branches) ->
	  (let match_one ((metasubst, ctxsubst, compsubst) as subst) t (metas, pat) =

	     nowarn let CHolTerm(LTermInCtx(ctx,tm)) = t in
	     let n = List.length metas in
	       
	     let _,metasevaled = List.fold_left (fun (n,res) (_,meta) ->
						   let subst = List.append (List.map (fun i -> LBMeta i) (increasing n)) metasubst, ctxsubst, compsubst in
						     (n+1, (eval subst meta) :: res))
	       (0,[]) metas in
	     let metas = List.map (function CHolTerm(t) -> t | _ -> failwith "metas") (List.rev metasevaled) in
	       
	     let subst' = List.append (List.map (fun i -> LBMeta i) (increasing n)) metasubst, ctxsubst, compsubst in
	     nowarn let CHolTerm(LTermInCtx(ctx',pat)) = closedown_meta_ctx subst' pat in
	     let ctxM, pat, tm =
	       (if List.length ctx < List.length ctx' then
		  ctx', pat, BindLterm.shift_bound (List.length ctx' - List.length ctx) tm
		else 
		  ctx, BindLterm.shift_bound (List.length ctx - List.length ctx') pat, tm)
	     in
	     let subst_metas = pattern_match_term defenv ~ctx:ctxM ~check:true metas pat tm in
	     let subst'' = List.append (List.rev subst_metas) metasubst, ctxsubst, compsubst in
	       subst''
	   in
	   let rec find_branch tms branches =
	     match branches with
		 [] -> failwith "non-covering HOL case"
	       | (pats, e) :: tail ->
		   (try
		      let subst'' =
			List.fold_left (fun s (x,y) -> match_one s x y) subst
			  (List.combine tms pats)
		      in
			eval subst'' e
		    with NoPatternMatch ->
		      find_branch tms tail)
	   in
	   let ts = List.map (eval subst) ts in
	     find_branch ts branches)

      | CCtxCase(t,nam,ret,branches) ->
      	  (let rec find_branch l branches =
      	     match branches with
      		 [] -> failwith "non-covering context case"
      	       | (ctxvs, metas, pat, e) :: tail ->
      		   (try
      		      let cn = List.length ctxvs in
      		      let n = List.length metas in
      		      let subst' = List.append (List.map (fun i -> LBMeta i) (increasing n)) metasubst, List.append (List.map (fun i -> LBCtx i) (increasing cn)) ctxsubst, compsubst in
      		      nowarn let CCtxTerm(LCtxAsList(l')) = closedown_meta_ctx subst' pat in

		      let ctxsubst' = List.append (List.map (fun i -> LBCtx i) (increasing cn)) ctxsubst in
		      let _,metasevaled = List.fold_left (fun (n,res) (_,meta) ->
							    let subst = List.append (List.map (fun i -> LBMeta i) (increasing n)) metasubst, ctxsubst', compsubst in
							      (n+1, (eval subst meta) :: res))
			(0,[]) metas in
		      let metas = List.map (function CHolTerm(t) -> t | _ -> failwith "metas") (List.rev metasevaled) in
      		      let subst_ctx, subst_metas = context_match_term defenv metas l' l in
      		      let subst'' = List.append (List.rev subst_metas) metasubst, List.append (List.rev subst_ctx) ctxsubst, compsubst in
      			eval subst'' e
      		    with NoPatternMatch ->
      		      find_branch l tail)
      	   in
      	     nowarn let CCtxTerm(LCtxAsList(l)) = eval subst t in
      	       find_branch l branches)

      | CInfer(_,_) ->
	failwith "!!! non-unified unifvar found during evaluation"

      | CNVar(n) when n = "break" ->
	  (debug_break_point (); CUnitExpr)

      | CNVar(n) when n = "bot" ->
	  failwith "error!!!"

      | CNVar(n) ->
	  (let (_, tm, tm_opt, thistrusted) = ExtDict.find n cdefenv in
	   let trusted' = thistrusted || trusted in
	   let e' = if trusted' then tm_opt else tm in
	     evalall subst bound trusted' e')

      | CBVar(i) ->
	  eval subst (List.nth compsubst i)

      | CHolTerm(t) ->
	  (nowarn let CHolTerm(t) = closedown_meta_ctx subst e in
	     CHolTerm(normalize_modal t))

      | CCtxTerm(t) ->
	  (nowarn let CCtxTerm(t) = closedown_meta_ctx subst e in
	     CCtxTerm(normalize_ctx t))

      | CLambda(var,t1,e) ->
	  CClosure(subst, CLambda(var,t1,e))

      | CTuple(e1,e2) ->
	  CTuple(eval subst e1, eval subst e2)

      | CProj(i,e) ->
	  (nowarn let CTuple(e1,e2) = eval subst e in
	     if i = 1 then eval subst e1 else eval subst e2)

      | CFold(e,t) ->
	  CFold(eval subst e, eval subst t)

      | CUnfold(e) ->
	  (nowarn let CFold(v,_) = eval subst e in
	     v)

      | CCtor(i,t,e) ->
	  CCtor(i,eval subst t,eval subst e)

      | CMatch(e,branches) ->
	  (nowarn let CCtor(i,_,param) = eval subst e in
	   let (v,body) = List.nth branches i in
	     eval (add_to_subst ~case:v param subst) body)

      | CLet(v,d,e) ->
	  (let d' = eval subst d in
	     eval (add_to_subst ~case:v d' subst) e)

      | CLetRec(defs,e) ->
	  (let refs = List.map (fun (_,t,_) -> ref (CSort CType), t) (List.rev defs) in
	   let compadd = List.map (fun (r,t) -> CReadRef(CLoc(r,t))) refs in
	   let subst'  = (metasubst,ctxsubst,List.append compadd compsubst) in
	   let defseval = List.map (function (_,_,e) -> eval subst' e) (List.rev defs) in
	   let _ = List.iter2 (fun (l,_) what -> l := what) refs defseval in
	     eval subst' e)

      | CMkRef(e,t) ->
	  let e' = eval subst e in
	  CLoc(ref (e'), t)

      | CAssign(e1,e2) ->
	  (nowarn let CLoc(l,_) = eval subst e1 in
	   let e2' = eval subst e2 in
	     l := e2'; CUnitExpr)

      | CReadRef(e) ->
	  (nowarn let CLoc(l,_) = eval subst e in
	     !l)

      | CSeq(e1,e2) ->
	  (let _ = eval subst e1 in
	     eval subst e2)

      | CArrayLit(es,t) ->
	  (let es' = List.map (eval subst) es in
	     CArrayLoc(Array.of_list es',t))

      | CMkArray(e1,e2,t) ->
	  (nowarn let CIntConst(i) = eval subst e1 in
	   let v = eval subst e2 in
	   let t' = eval subst t in
	     CArrayLoc(Array.make i v,t'))

      | CArrayGet(e1,e2) ->
	  (nowarn let CArrayLoc(ar,_) = eval subst e1 in
	   nowarn let CIntConst(i) = eval subst e2 in
	     ar.(i))

      | CArraySet(e1,e2,e3) ->
	  (nowarn let CArrayLoc(ar,_) = eval subst e1 in
	   nowarn let CIntConst(i) = eval subst e2 in
	   let v = eval subst e3 in
	     ar.(i) <- v; CUnitExpr)

      | CArrayLen(e) ->
	  (nowarn let CArrayLoc(ar,_) = eval subst e in
	     CIntConst(Array.length ar))


      | CIntOp(op,e1,e2) ->
	  (nowarn let CIntConst(i1) = eval subst e1 in
	   nowarn let CIntConst(i2) = eval subst e2 in
	     match op with
		 Plus -> CIntConst(i1+i2)
	       | Minus -> CIntConst(i1-i2)
	       | Times -> CIntConst(i1*i2)
	       | Mod -> CIntConst(i1 mod i2))

      | CIntTest(op,e1,e2) ->
	  (nowarn let CIntConst(i1) = eval subst e1 in
	   nowarn let CIntConst(i2) = eval subst e2 in
	     match op with
		 LT -> CBoolConst(i1 < i2)
	       | LE -> CBoolConst(i1 <= i2)
	       | GT -> CBoolConst(i1 > i2)
	       | GE -> CBoolConst(i1 >= i2)
	       | EQ -> CBoolConst(i1 = i2))
	    
      | CBoolOp(op,e1,e2) ->
	  (nowarn let CBoolConst(i1) = eval subst e1 in
	   nowarn let CBoolConst(i2) = eval subst e2 in
	     match op with
		 BAnd -> CBoolConst(i1 && i2)
	       | BOr -> CBoolConst(i1 || i2))

      | CIfThenElse(e1,e2,e3) ->
	  (nowarn let CBoolConst(b) = eval subst e1 in
	     if b then eval subst e2 else eval subst e3)

      | CHolHash(e) ->
	  (let v = eval subst e in
	   let v' = cterm_map ~cholterm:(fun t -> CHolTerm(fullnf_modal defenv t))
	                      ~cctxterm:(fun t -> CCtxTerm(fullnf_ctx defenv t)) v in
	     CIntConst(Hashtbl.hash_param 100 200 v'))

      | CPrint(e) ->
  	  (let v = eval subst e in
	       (match v with
		 CStringConst(s) -> fprintf std_formatter "%s%!" s
		 | _ ->  fprintf std_formatter "%a@\n%!" pr_cterm v);
	   CUnitExpr)

      | CSigma(v,t1,t) -> CSigma(v,eval subst t1,evalunderbinder subst v t)
      | CPi(v,t1,t) -> CPi(v,eval subst t1,evalunderbinder subst v t)
      | CArrayType(t) -> CArrayType(eval subst t)
      | CRefType(t) -> CRefType(eval subst t)
      | CSumType(ts) -> CSumType(List.map (eval subst) ts)
      | CProdType(t1,t2) -> CProdType(eval subst t1, eval subst t2)
      | CRecType(v,t1,t) -> CRecType(v,t1,evalunderbinder subst v t)
      | CLoc(l,t) -> CLoc(l, t)
      | CArrayLoc(l,t) -> CArrayLoc(l, t)
      | CTypeAscribe(e,t) -> eval subst e
      | t -> t
	    
  in
    evalall ([],[],[]) (0,0,0) trusted e


(* let comp_print_eval e = *)
(*   let t = comp_gettype e in *)
(*   let v = eval !Logic_main.logic_global_env !comp_global_env e in *)
(*   let t' = comp_gettype v in *)
(*   let env = (!Logic_main.logic_global_env, !comp_global_env, [], [], []) in *)
(*     (if ctype_equal env t t' then *)
(*        fprintf std_formatter "%a@ -->@ %a@\n" pr_cterm e pr_cterm v *)
(*      else *)
(*        fprintf std_formatter "%s@\n%a@ :@ %a@ -->@ %a@ :@ %a" "WARNING TYPE UNSAFETY!!" pr_cterm e pr_cterm t pr_cterm v pr_cterm t') *)

(* let comp_eval defenv cdefenv e = *)
(*   let t = comp_gettype e in *)
(*   let v = eval !Logic_main.logic_global_env !comp_global_env e in *)
(*   let t' = comp_gettype v in *)
(*   let env = (!Logic_main.logic_global_env, !comp_global_env, [], [], []) in *)
(*     (if ctype_equal env t t' then *)
(*        v *)
(*      else *)
(*        failwith "TYPE UNSAFETY IN EVALUATOR!!!") *)
	
(* let comp_define name tm = *)
(*   let tm' = comp_eval !Logic_main.logic_global_env !comp_global_env tm in *)
(*   comp_global_env := cterm_def_add name tm' !Logic_main.logic_global_env !comp_global_env *)

(* let comp_define_typed name tm tp = *)
(*   let tm' = comp_eval !Logic_main.logic_global_env !comp_global_env tm in *)
(*   comp_global_env := cterm_def_add name tm' ~expected_tp:(Some tp) !Logic_main.logic_global_env !comp_global_env *)
