open Syntax_logic;;
open Syntax_comp;;

<<

reset.
import "prog2_rewrite_plus".

ExtDefinition nat_zero_not_succ : [].forall P : Prop, forall x : Nat, zero = succ x -> P  :=
   Intro P : Prop in
   Intro x : Nat in
   Assume H : zero = succ x in
   ChangeInGoal x.natFold/[Prop] True (fun n' : Nat => fun r : Prop => P) x
   from @succ x to @zero
   by Trivial .


save "prog2_theorems".


>>;;
