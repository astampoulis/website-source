open Camlp4.PreCast
module CAst = Comp_ast
module CCst = Comp_cst
module LCst = Logic_cst
module LMain = Logic_main
module CTyp = Comp_typinf

module CompGram = Syntax_logic.LogicGram

let ident = Syntax_logic.ident
let modalterm = Syntax_logic.modalterm
let modalterm_paren = Syntax_logic.modalterm_paren
let context = Syntax_logic.context
let exprlist = Syntax_logic.exprlist
let logicdef = Syntax_logic.logicdef
let lterm    = Syntax_logic.term

let ctxterm = CompGram.Entry.mk "context term for comp"
let cterm = CompGram.Entry.mk "computational term"
let cterm_eoi = CompGram.Entry.mk "computational term quotation"
let cterm_ast = CompGram.Entry.mk "computational term (ast)"
let cterm_ast_eoi = CompGram.Entry.mk "computational term quotation (ast)"
let compdef = CompGram.Entry.mk "computational definition"
let compdef_eoi = CompGram.Entry.mk "computational definition quotation"
let mk_anti ?(c = "") n s = "\\$"^n^c^":"^s

let expand_comp_quot loc _loc_name_opt quotation_contents = CompGram.parse_string cterm_eoi loc quotation_contents;;

EXTEND CompGram
  GLOBAL: ctxterm cterm cterm_eoi cterm_ast cterm_ast_eoi compdef compdef_eoi;

  cterm:
    [
      "let" RIGHTA
	[ "letrec"; d = LIST1 def SEP "andrec"; "in"; e = cterm ->
	    let defs = exprlist _loc d in
	    <:expr< CCst.CLetRec($defs$, $e$) >>
	| "let"; x = cident; "="; t = cterm; "in"; e = cterm ->
	    <:expr< CCst.CLet($x$, $t$, $e$) >>
	| "let"; "@"; "="; t = ctxterm; "in"; e = cterm ->
	    <:expr< CCst.CSetContext($t$, $e$) >>
	| "nu"; s = ident; ":"; t = lterm; "in"; e = cterm ->
	    <:expr< CCst.CNuContext($str:s$, $t$, $e$) >>
	| "guess"; l = modalsubst; "in"; e = cterm ->
  	    let l = exprlist _loc l in
	    <:expr< CCst.CGuessSubst($l$, $e$) >>
	]
    | "lambda" RIGHTA
	[ "fun"; v = cvars; "=>"; t = cterm ->
	    <:expr< CCst.clammany $v$ $t$ >> ]
    | "sigma" RIGHTA
	[ "<"; v = cvars; ">"; t = cterm ->
	    <:expr< CCst.csigmamany $v$ $t$ >>
	| "<"; t = cterm; ","; e = cterm; ">" ->
	    <:expr< CCst.CPack($t$, ("x", CAst.CType), CCst.CAny(0), $e$) >> ]
    | "pi" RIGHTA
	[ "{"; v = cvars; "}"; t = cterm ->
	    <:expr< CCst.cpimany $v$ $t$ >> ]
    | "arrow" RIGHTA
	[ t = cterm; "->"; t' = cterm ->
	    <:expr< CCst.CArrow($t$, $t'$) >> ]
    | "packunpack" RIGHTA
	[ "pack"; t = cterm; "as"; x = cident; "return"; ret = cterm; "with"; e = cterm ->
	    <:expr< CCst.CPack($t$, $x$, $ret$, $e$) >>
	| "unpack"; "<"; strs = LIST1 cident SEP ","; ">"; "="; t = cterm; "in"; e = cterm ->
	    let s = exprlist _loc strs in
	    <:expr< CCst.cunpackmany $t$ $s$ $e$ >> ]
    | "cases" RIGHTA
	[ "holcase"; t = LIST1 cterm SEP ","; "as"; v = LIST1 cident SEP ","; "return"; ret = cterm; "with"; b = LIST1 holbranch SEP "|" ->
	    let b = exprlist _loc b in
	    let t = exprlist _loc t in
	    let v = exprlist _loc v in
	      <:expr< CCst.CHolCase($t$, $v$, $ret$, $b$) >>
	|  "ctxcase"; t = ctxterm; "as"; v = cident; "return"; ret = cterm; "with"; b = LIST1 ctxbranch SEP "|" ->
	    let b = exprlist _loc b in
	      <:expr< CCst.CCtxCase(CCst.CCtxTerm($t$), $v$, $ret$, $b$) >>
	| "match"; t = cterm; "with"; b = LIST1 matchbranch SEP "|" ->
	    let b = exprlist _loc b in
	      <:expr< CCst.CMatch($t$, $b$) >>
	]
    | "seq" LEFTA
	[ t = cterm; ";"; t' = cterm -> <:expr< CCst.CSeq($t$, $t'$) >> ]
    | "assign" NONA
	[ t = cterm; ":="; t' = cterm -> <:expr< CCst.CAssign($t$, $t'$) >> ]
    | "intrel" NONA
	[ t = cterm; "LT"; t' = cterm -> <:expr< CCst.CIntTest(CAst.LT, $t$, $t'$) >>
	| t = cterm; "LE"; t' = cterm -> <:expr< CCst.CIntTest(CAst.LE, $t$, $t'$) >>
	| t = cterm; "GT"; t' = cterm -> <:expr< CCst.CIntTest(CAst.GT, $t$, $t'$) >>
	| t = cterm; "GE"; t' = cterm -> <:expr< CCst.CIntTest(CAst.GE, $t$, $t'$) >>
	| t = cterm; "EQ"; t' = cterm -> <:expr< CCst.CIntTest(CAst.EQ, $t$, $t'$) >>  ]
    | "plusand" LEFTA
	[ t = cterm; "iplus"; t' = cterm -> <:expr< CCst.CIntOp(CAst.Plus, $t$, $t'$) >>
	| t = cterm; "iminus"; t' = cterm -> <:expr< CCst.CIntOp(CAst.Minus, $t$, $t'$) >>
	| t = cterm; "&&"; t' = cterm -> <:expr< CCst.CBoolOp(CAst.BAnd, $t$, $t'$) >> ]
    | "multor" LEFTA
	[ t = cterm; "itimes"; t' = cterm -> <:expr< CCst.CIntOp(CAst.Times, $t$, $t'$) >>
	| t = cterm; "imod"; t' = cterm -> <:expr< CCst.CIntOp(CAst.Mod, $t$, $t'$) >>
	| t = cterm; "||"; t' = cterm -> <:expr< CCst.CBoolOp(CAst.BOr, $t$, $t'$) >> ]
    
    | "app" LEFTA
	[ "fst"; t = cterm -> <:expr< CCst.CProj(1, $t$) >>
	| "snd"; t = cterm -> <:expr< CCst.CProj(2, $t$) >>
	| t = cterm; t' = cterm -> <:expr< CCst.CApp($t$, $t'$) >> ]

    | "ascribe" NONA
	[ e = cterm; "::"; t = cterm -> <:expr< CCst.CTypeAscribe($e$, $t$) >> ]

    | "prodtype" LEFTA
	[ t1 = cterm; "*"; t2 = cterm ->
	    <:expr< CCst.CProdType($t1$, $t2$) >> ]
    | "ifthenelse" LEFTA
	[ "if"; t1 = cterm; "then"; t2 = cterm; "else"; t3 = cterm ->
	    <:expr< CCst.CIfThenElse($t1$, $t2$, $t3$) >> ]
    | "simple" NONA
	[ "CType" -> <:expr< CCst.CSort(CAst.CType) >>
	| "hol"; "(";  t = modalterm; ")" ->
	    <:expr< CCst.CSigmaUnit(CCst.CHolTerm($t$)) >>
	| "tup"; "("; t1 = cterm; ","; t2 = cterm; ")" -> <:expr< CCst.CTuple($t1$,$t2$) >> 
	| "<|"; t = modalterm; "|>" ->
	    <:expr< CCst.CPackUnit(CCst.CHolTerm($t$)) >>
	| "preeval"; "("; t1 = ident; ctx = ctxterm; params = LIST1 modalterm_paren; ")" ->
	    let params' = List.fold_right (fun elm cur -> <:expr< CCst.CHolTerm($elm$) :: $cur$ >>) params <:expr< [] >> in
	    <:expr< CCst.CPreEval(CCst.CVar($str:t1$), CCst.CCtxTerm($ctx$), $params'$) >>
	| "Kind" -> <:expr< CCst.CSort(CAst.CKind) >>
	| "ctx" -> <:expr< CCst.CSort(CAst.CCtx) >>
	| "Unit" -> <:expr< CCst.CUnitType >>
	| "unit" -> <:expr< CCst.CUnitExpr >>
	| "int" -> <:expr< CCst.CIntType >>
	| i = INT -> <:expr< CCst.CIntConst($int:i$) >>
	| s = STRING -> <:expr< CCst.CStringConst($str:s$) >>
	| "string" -> <:expr< CCst.CStringType >>
	| "bool" -> <:expr< CCst.CBoolType >>
	| "true" -> <:expr< CCst.CBoolConst(true) >>
	| "false" -> <:expr< CCst.CBoolConst(false) >>
	| x = ident -> <:expr< CCst.CVar($str:x$) >>
	| t = ctxterm -> <:expr< CCst.CCtxTerm($t$) >>
	| "_" -> <:expr< CCst.CAny(0) >>
	| "rec"; x = cident; ":"; t1 = cterm; "=>"; t2 = cterm ->
	    <:expr< CCst.CRecType($x$, $t1$, $t2$) >>
	| "fold"; "("; t1 = cterm; ","; t2 = cterm; ")" ->
	    <:expr< CCst.CFold($t1$, $t2$) >>
	| "unfold"; t1 = cterm ->
	    <:expr< CCst.CUnfold($t1$) >>
	| "sum"; "("; ts = LIST1 cterm SEP "+"; ")" ->
	    let ts' = exprlist _loc ts in
	    <:expr< CCst.CSumType($ts'$) >>
	| "ctor"; "("; i = INT; ","; t = cterm; ","; p = cterm; ")" ->
	    <:expr< CCst.CCtor($int:i$, $t$, $p$) >>
	| "ref"; t = cterm -> <:expr< CCst.CRefType($t$) >>
	| "mkref"; "("; t1 = cterm; ","; t2 = cterm; ")" -> <:expr< CCst.CMkRef($t1$,$t2$) >>
	| "!"; t = cterm -> <:expr< CCst.CReadRef($t$) >>

	| "array"; t = cterm -> <:expr< CCst.CArrayType($t$) >>
	| "mkarray"; "("; t1 = cterm; ","; t2 = cterm; ","; t3 = cterm; ")" ->
	    <:expr< CCst.CMkArray($t1$,$t2$,$t3$) >>
	| "[|"; ts = LIST1 cterm SEP ","; "|]"; "of"; t = cterm ->
	    let ts' = exprlist _loc ts in
	    <:expr< CCst.CArrayLit($ts'$,$t$) >>
	| "arraylen"; t = cterm -> <:expr< CCst.CArrayLen($t$) >>
	| t1 = cterm; "."; "("; t2 = cterm; ")"; "<-"; t3 = cterm ->
	    <:expr< CCst.CArraySet($t1$,$t2$,$t3$) >>
	| t1 = cterm; "."; "("; t2 = cterm; ")" ->
	    <:expr< CCst.CArrayGet($t1$,$t2$) >>
	| "hash"; t = cterm ->
	    <:expr< CCst.CHolHash($t$) >>
	| "print"; t = cterm ->
	    <:expr< CCst.CPrint($t$) >>
	| "^"; x = LIDENT ->
	    <:expr< $lid:x$ >>
	| "do"; "return"; t = cterm; "{"; d = LIST1 docommand SEP ";;"; "}" ->
	    (let d', (_, last) = Utils.ExtList.last d in
	    List.fold_right
	      (fun (x,tm) cmd ->
		 <:expr< CCst.CMatch($tm$, [ ($x$, $cmd$);
							( ("non", CAst.CType),
							  CCst.CApp(CCst.CVar("none"), $t$)) ]) >>)
	      d'
	      <:expr< CCst.CApp(CCst.CApp(CCst.CVar("some"), $t$), $last$) >>)
	| t = modalterm -> <:expr< CCst.CHolTerm($t$) >>
	| "("; t = cterm; ")" -> t  ] ];

  ctxterm:
    [ [ "#"; c = context -> c
      | "#"; "@" -> <:expr< LCst.LCurctx >> ] ];

  docommand:
    [ [ x = ident; "<-"; t = cterm -> (<:expr< ($str:x$, CAst.CType) >>, <:expr< $t$ >>)
      | "return"; t = cterm -> ( <:expr< ( "", CAst.CType) >>, <:expr< $t$ >> ) ] ];

  modalident:
    [ [ "?"; x = ident -> <:expr< ($str:x$, CAst.CHol) >>  ] ];

  ctxident:
    [ [ "#"; x = ident -> <:expr< ($str:x$, CAst.CCtx) >> ] ];

  modalbinder:
    [ [ x = cident; ":"; t = modalterm_paren -> <:expr< ($x$, CCst.CHolTerm($t$)) >> ] ];

  holbranchpat:
    [ [ "("; metas = LIST0 modalbinder SEP ","; ")"; "."; t = modalterm_paren ->
	  let metas = exprlist _loc metas in
	    <:expr< ($metas$, CCst.CHolTerm($t$)) >> ] ];

  holbranch:
    [ [ pats = LIST1 holbranchpat SEP ","; "|->"; e = cterm ->
	  let pats = exprlist _loc pats in
	  <:expr< ($pats$, $e$) >> ] ];

  ctxbranch:
    [ [ "("; ctxvs = LIST0 cident SEP ","; ")"; ".";
	"("; metas = LIST0 modalbinder SEP ","; ")"; ".";
	t = context; "|->"; e = cterm ->
	  let ctxvs = exprlist _loc ctxvs in
	  let metas = exprlist _loc metas in
	  <:expr< ($ctxvs$, $metas$, CCst.CCtxTerm($t$), $e$) >> ] ];

  matchbranch:
    [ [ x = cident; "|->"; e = cterm -> <:expr< ($x$, $e$) >> ] ];

  modalsubst:
    [ [ l = LIST1 modalsubst1 SEP "," -> l ] ];
  modalsubst1:
    [ [ t = modalterm_paren; "~>"; t' = modalterm_paren -> <:expr< ( $t$, $t'$ ) >> ] ];

  def:
    [ [ x = cident; ":"; t = cterm; "="; e = cterm -> <:expr< ($x$, $t$, $e$) >> ] ];

  cident:
    [ [ x = modalident -> x
      | "#"; x = ident -> <:expr< ($str:x$, CAst.CCtx) >>
      | x = ident -> <:expr< ($str:x$, CAst.CType) >>
      | "^"; x = LIDENT ->
	    <:expr< ($str:x$, CAst.CType) >> ] ];

  cvar:
    [ [ x = cident; ":"; t = cterm -> <:expr< ($x$,$t$) >> ] ];

  cvars:
    [ [ xs = LIST1 cvar SEP "," -> exprlist _loc xs ]];

  cterm_eoi:
    [ [ t = cterm; `EOI -> t ]];

  cterm_ast_eoi:
    [ [ t = cterm; `EOI -> <:expr< CCst.comp_ast_of_cst $t$ >> ]];

  cterm_ast:
    [ [ t = cterm -> <:expr< CCst.comp_ast_of_cst $t$ >> ]];

  modalterm_ast:
    [ [ t = modalterm_paren -> <:expr< LCst.ast_of_modal $t$ >> ]];

  compdef:
    [ [ t = logicdef -> t
      | "let"; x = ident; "="; t = cterm_ast -> <:expr< Comp_opteval.comp_define $str:x$ $t$ >>
      | "let"; x = ident; ":"; tp = cterm_ast; "="; t = cterm_ast -> <:expr< Comp_opteval.comp_define_typed $str:x$ $t$ $tp$ >>
      | "let"; "_"; "="; t = cterm_ast -> <:expr< Comp_opteval.comp_define "_" $t$ >>
      | "let"; "_"; ":"; tp = cterm_ast; "="; t = cterm_ast -> <:expr< Comp_opteval.comp_define_typed "_" $t$ $tp$ >>
      | "let"; "trusted"; x = ident; "="; t = cterm_ast -> <:expr< Comp_opteval.comp_define_opt $str:x$ $t$ >>
      | "let"; "trusted"; x = ident; ":"; tp = cterm_ast; "="; t = cterm_ast -> <:expr< Comp_opteval.comp_define_typed_opt $str:x$ $t$ $tp$ >>
      | "print"; t = cterm_ast; "." -> <:expr< CTyp.comp_print $t$ >> 
      | "printfull"; t = cterm_ast; "." -> <:expr< Comp_opteval.comp_print_full $t$ >> 
      | "typeof"; t = cterm_ast; "." -> <:expr< CTyp.comp_print_type $t$ >>
      | "eval"; t = cterm_ast; "." -> <:expr< Comp_opteval.comp_print_eval $t$ >>
      | "evalopt"; t = cterm_ast; "." -> <:expr< Comp_opteval.comp_print_eval_opt $t$ >>

      | "ExtDefinition"; name = ident; ":"; tp = modalterm_ast; ":="; tm = cterm_ast; "." ->
      	  <:expr< Comp_opteval.comp_define_logic $str:name$ $tm$ (CAst.CSigma((None, CAst.CType), CAst.CHolTerm($tp$), CAst.CUnitType)) >>

      | "reset"; "." -> <:expr< CTyp.comp_global_reset_all () >>
      | "import"; t = STRING; "." -> <:expr< CTyp.comp_global_import $str:t$ >> 
      | "save"; t = STRING; "." -> <:expr< CTyp.comp_global_save $str:t$ >> ] ];

  compdef_eoi:
    [[ cds = LIST1 compdef; `EOI ->
	 let cdexpr = List.fold_right (fun cd cur -> <:expr< $cd$ ; $cur$>>) cds <:expr< () >> in
	 <:str_item< let _ = Logic_ast.default_varmap_handler (fun () -> $cdexpr$) >> ]];

  END;;

let expand_comp_quot loc _loc_name_opt quotation_contents = CompGram.parse_string cterm_eoi loc quotation_contents;;
let expand_compast_quot loc _loc_name_opt quotation_contents = CompGram.parse_string cterm_ast_eoi loc quotation_contents;;
let expand_compdef_quot loc _loc_name_opt quotation_contents = CompGram.parse_string compdef_eoi loc quotation_contents;;

Syntax.Quotation.add "cc" Syntax.Quotation.DynAst.expr_tag expand_comp_quot;;
Syntax.Quotation.add "ca" Syntax.Quotation.DynAst.expr_tag expand_compast_quot;;
Syntax.Quotation.add "cd" Syntax.Quotation.DynAst.str_item_tag expand_compdef_quot;;
Syntax.Quotation.default := "cd";;

