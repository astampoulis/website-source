flush stdout;
print_string
"\tVeriML version 0.3\n\
 \t(ICFP - inductive types - conversion\n\
 \t      + HOL style rewriting\n\
 \t      + subtyping + logic inference + comp inference\n\
 \t      + new matching code + ctxmatch + environment-substitutive pmatch\n\
 \t      + proof erasure + preeval + delphin sugar + tactic sugar)\n\n";;

