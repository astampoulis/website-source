open Syntax_logic;;
open Syntax_comp;;

<<

reset.
import "prog2_rewrite_base".

let STANDARD_HASH_SIZE = 50

(* Hash implementation *)

let hash_t = fun #phi : ctx => fun res : {?T : [#phi].Set}([s : #phi].?T/[s]) -> CType =>
              array (option (< ?T : [#phi].Set > < ?key : [s : #phi].?T/[s] > res ?T ?key))

let mkhash = fun #phi : ctx => fun res : {?T : [#phi].Set}(([s : #phi].?T/[s]) -> CType) => fun i : int =>
             mkarray( i, (none (< ?T : [#phi].Set > < ?key : [s : #phi].?T/[s] > res ?T ?key)) , option (< ?T : [#phi].Set > < ?key : [s : #phi].?T/[s] > res ?T ?key)) 

let hashget = fun #phi : ctx => fun res : {?T : [#phi].Set}([s : #phi].?T/[s]) -> CType => fun h : hash_t #[#phi] res =>
              fun ?T : [#phi].Set, ?t : [s : #phi].?T/[s] =>
              let hn = arraylen h in
              letrec find : (int -> (option (res ?T ?t))) =
		  fun i : int => 
		  match h.(i) with
		      som |-> (unpack < ?T', ?t', result > = som in
                               holcase ?T' , ?t' as ?T', ?t' return (option (res ?T ?t)) with
				   ().[s : #phi].?T/[s] , ().[s:#phi].?t/[s] |->
				     some (res ?T ?t) result
				| (?T' : [s:#phi].Set).[s:#phi].?T'/[s], (?t' : [s:#phi].?T'/[s]).[s:#phi].?t'/[s] |-> find ((i iplus 1) imod hn))
                    | non |-> none (res ?T ?t)
              in
                find ((hash <| ?t |>) imod hn)

let hashget_uns = fun #phi : ctx => fun res : {?T : [#phi].Set}([s:#phi].?T/[s]) -> CType => fun h : hash_t #[#phi] res =>
              fun ?T : [#phi].Set, ?t : [s:#phi].?T/[s] =>
              match hashget #[#phi] res h ?T ?t with
		  som |-> som
		| non |-> bot (res ?T ?t)

let hashset = fun #phi : ctx => fun res : {?T : [#phi].Set}([s : #phi].?T/[s]) -> CType => fun h : hash_t #[#phi] res =>
              fun ?T : [#phi].Set => fun ?t : [s:#phi].?T/[s] => fun r : res ?T ?t =>
              let hn = arraylen h in
              letrec find : (int -> Unit) =
		fun i : int => 
		  match h.(i) with
		      som |-> unpack < ?T', ?t', result > = som in
                              (holcase ?T', ?t' as ?T', ?t' return Unit with
				  ().[s:#phi].?T/[s] , ().[s:#phi].?t/[s] |->
				    h.(i) <- (some (< ?T : [#phi].Set > < ?key : [s : #phi].?T/[s] > res ?T ?key)
						(pack ?T as ?T return < ?key : [s:#phi].?T/[s] >res ?T ?key with pack ?t as ?t return res ?T ?t with r))
				| (?T' : [s:#phi].Set).[s:#phi].?T'/[s] , ( ?t' : [s:#phi].?T'/[s] ).[s:#phi].?t'/[s] |-> find ((i iplus 1) imod hn))
                    | non |-> h.(i) <- (some (< ?T : [#phi].Set > < ?key : [s : #phi].?T/[s] > res ?T ?key)
						(pack ?T as ?T return < ?key : [s:#phi].?T/[s] >res ?T ?key with pack ?t as ?t return res ?T ?t with r))
              in
                find ((hash <| ?t |>) imod hn)



(* Set implementation *)

let set_t = fun #phi : ctx => (hash_t #[#phi] (fun ?T : [s : #phi].Set, ?t : [s:#phi].?T/[s] => Unit)) * (list (< ?T : [#phi].Set >hol([s:#phi].?T/[s])) )
let mkset = fun #phi : ctx => fun i : int => tup( mkhash #[#phi] (fun ?T : [s:#phi].Set, ?t : [s : #phi].?T/[s] => Unit) i,
						  nil (< ?T : [#phi].Set > hol([s : #phi].?T/[s]) ) )
let setadd = fun #phi : ctx => fun s : set_t #[#phi] => fun ?T : [#phi].Set => fun ?t : [s : #phi].?T/[s] =>
             (match hashget #[#phi] (fun ?T : [s:#phi].Set , ?t : [s : #phi].?T/[s] => Unit) (fst s) ?T ?t with
		  som |-> s
		| non |-> ((hashset #[#phi] (fun ?T : [s : #phi].Set, ?t : [s:#phi].?T/[s] => Unit) (fst s) ?T ?t unit);
		           tup(fst s, cons (< ?T : [#phi].Set >hol([s:#phi].?T/[s]))
				           (pack ?T as ?T return hol([s:#phi].?T/[s]) with <| ?t |>)
					   (snd s))))
let setfold = fun a : CType => fun #phi : ctx => 
              fun f : {?T : [#phi].Set , ?t : [s:#phi].?T/[s]}(a -> a) => fun start : a => fun s : set_t #[#phi] =>
              listfold (< ?T : [#phi].Set >hol([s:#phi].?T/[s])) a
	      (fun st : a => fun t : < ?T : [#phi].Set >hol([s : #phi].?T/[s]) =>
		  unpack < ?T, ?t, unused > = t in
		  f ?T ?t st)
	      start
	      (snd s)

let setiter = fun #phi : ctx => 
              fun f : { ?T : [#phi].Set }([s:#phi].?T/[s]) -> Unit =>
              fun s : set_t #[#phi] =>
              setfold Unit #[#phi] (fun ?T : [#phi].Set , ?t : [s : #phi].?T/[s] => fun unused : Unit => f ?T ?t) unit s

let setunion = fun #phi : ctx => fun s1 : set_t #[#phi] => fun s2 : set_t #[#phi] =>
               setfold (set_t #[#phi]) #[#phi]
	       (fun ?T : [#phi].Set, ?t : [s : #phi].?T/[s] => fun s : set_t #[#phi] => setadd #[#phi] s ?T ?t)
	       s1
	       s2


(* Union-find with congruence *)

let ufres = fun #phi : ctx , ?T : [#phi].Set, ?t : [s : #phi].?T/[s] =>
  (ref (< ?t' : [s : #phi].?T/[s] >hol([s:#phi].eq ?t/[s] ?t'/[s]))) *
  (ref (set_t #[#phi]))

let ufempty = fun #phi : ctx => mkhash #[#phi] (ufres #[#phi]) STANDARD_HASH_SIZE

let ufhash_t = fun #phi : ctx => hash_t #[#phi] (ufres #[#phi])

let ufprint =
  fun #phi : ctx, h : ufhash_t #[#phi] =>
  let hn = arraylen h in
  letrec myprint : (int -> Unit) = fun i : int =>
      if (i EQ hn) then
	unit
      else
	((match h.(i) with
	    som |->
	      (unpack < ?T, ?t, res > = som in
	       unpack < ?trep, unused > = !(fst res) in
	       (print <| ?t |> ); (print "points to"); (print <| ?trep |> ))
	  | non |-> unit);
	 myprint (i iplus 1))
  in
   myprint 0


let syntactic_iseq = 
  fun #phi : ctx, ?T : [#phi].Set , ?e1s : [s:#phi].?T/[s] , ?e2s : [s:#phi].?T/[s] =>
  holcase ?e2s as ?e2 return bool with
      ().[s:#phi].?e1s/[s] |-> true
    | (?e2s : [s:#phi].?T/[s]).[s:#phi].?e2s/[s] |-> false

let find = fun #phi : ctx => fun h : ufhash_t #[#phi] =>
  letrec find : { ?T : [s : #phi].Set , ?n : [s : #phi].?T/[s] }(< ?n' : [s : #phi].?T/[s] >hol([s:#phi].eq ?n/[s] ?n'/[s])) =
  let add_to_ccpar =
    fun ?T : [#phi].Set, ?n : [s:#phi].?T/[s], ?T' : [#phi].Set, ?n' : [s:#phi].?T'/[s] =>
      (let nres = find ?T ?n in
       unpack < ?nrep, unused > = nres in
       let nentry = hashget_uns #[#phi] (ufres #[#phi]) h ?T ?nrep in
       let nccpar = snd nentry in
       nccpar := setadd #[#phi] !nccpar ?T' ?n')
  in
  let findrepforapp =
    fun ?T : [#phi].Set, ?T' : [#phi].Set, ?f : [s:#phi].?T/[s] -> ?T'/[s], ?a : [s:#phi].?T/[s] =>
    (unpack < ?frep, ?fprf, unused > = find ([#phi].??) ?f in
     unpack < ?arep, ?aprf, unused > = find ([#phi].??) ?a in
     unpack < ?faprf , unused > = <| [s:#phi].?app_eq/[??, ??] ?f/[s] ?frep/[s] ?a/[s] ?arep/[s] ?fprf/[s] ?aprf/[s] |> in
     (if (syntactic_iseq #[#phi] ([#phi].??) ?f ?frep) && (syntactic_iseq #[#phi] ([#phi].??) ?a ?arep) then
	 (pack ([s:#phi].?f/[s] ?a/[s]) as ?x return hol([s:#phi].?f/[s] ?a/[s] = ?x/[s]) with <| [s:#phi].refl (?f/[s] ?a/[s]) |>)
      else
	 (unpack < ?farep, ?faprf2 , unused > = find ([#phi].??) ([s:#phi].?frep/[s] ?arep/[s]) in
	  pack ?farep as ?x return hol([s:#phi].?f/[s] ?a/[s] = ?x/[s]) with
	      <| [s:#phi].trans ?faprf/[s] ?faprf2/[s] |>)))
  in
  let res = 
  fun ?T : [#phi].Set, ?n : [s : #phi].?T/[s] =>
  (DEBUGPRINT "find for"); 
  (DEBUG (fun u : Unit => (print <| ?n |> )) );
  match hashget #[#phi] (ufres #[#phi]) h ?T ?n with
      som |-> (unpack < ?n', ?prf, unused > = !(fst som) in
              if syntactic_iseq #[#phi] ?T ?n ?n' then
		!(fst som)
	      else
		(let res = find ?T ?n' in
		   unpack < ?n'', ?prf', unused > = res in
                   pack ?n'' as ?n'' return hol([s:#phi].eq ?n/[s] ?n''/[s]) with <| [s:#phi].trans ?prf/[s] ?prf'/[s] |>))
    | non |->
	let ccpar = mkref (mkset #[#phi] STANDARD_HASH_SIZE, set_t #[#phi]) in
	(holcase ?n as ?n return < ?n' : [s:#phi].?T/[s] >hol([s:#phi].?n/[s] = ?n'/[s]) with
	    (* here we should add other cases for more parameters *)
	    (?T' : [#phi].Set , ?f : [s : #phi].?T'/[s] -> ?T/[s], ?n1 : [s : #phi].?T'/[s]).[s : #phi].?f/[s] ?n1/[s] |->
	      (let rep = findrepforapp ?T' ?T ?f ?n1 in
	        (hashset #[#phi] (ufres #[#phi]) h ?T ?n tup(mkref (rep, < ?n' : [s : #phi].?T/[s] >hol([s:#phi].eq ?n/[s] ?n'/[s])), ccpar));
	        (add_to_ccpar ?T' ?n1 ?T ?n);
	        (add_to_ccpar ([#phi].??) ?f ([#phi].??) ?n);
	        rep)

	       (* |  (?T1 : [#phi].Set , ?T2 : [#phi].Set, ?f : [s : #phi].?T1/[s] -> ?T2/[s] -> ?T/[s], ?n1 : [s : #phi].?T1/[s], ?n2 : [s:#phi].?T2/[s]). *)
	       (* 	   [s : #phi].?f/[s] ?n1/[s] ?n2/[s] |-> *)
	       (* 	     (add_to_ccpar ([#phi].??) ?n1 ?T ?n); *)
	       (* 	     (add_to_ccpar ([#phi].??) ?n2 ?T ?n); *)
	       (* 	     (add_to_ccpar ([#phi].??) ?f ([#phi].??) ?n) *)

	       | (?n : [s : #phi].?T/[s]).[s:#phi].?n/[s] |->
		 (let same = pack ?n as ?n' return hol([s:#phi].eq ?n/[s] ?n'/[s]) with <| [s:#phi].refl ?n/[s] |> in
  		    (hashset #[#phi] (ufres #[#phi]) h ?T ?n tup(mkref (same, < ?n' : [s : #phi].?T/[s] >hol([s:#phi].eq ?n/[s] ?n'/[s])), ccpar));
		    same))
  in
  (fun T : @Set, n : @T =>
    unpack < n' , pfn' , unused > = def_rewr #@ @T @n in
    unpack < n'' , pfn'' , unused > = res @T @n' in
    pack @n'' as n'' return hol ( @n = n'' ) with <| @trans pfn' pfn'' |> )
  in
  find


let union = fun #phi : ctx => fun h : ufhash_t #[#phi] =>
  fun ?T : [#phi].Set , ?n1 : [s : #phi].?T/[s] , ?n2 : [s : #phi].?T/[s] , ?prf : [s : #phi].eq ?n1/[s] ?n2/[s] =>
  (let n1res = find #[#phi] h ?T ?n1 in
   let n2res = find #[#phi] h ?T ?n2 in
   unpack < ?n1', ?prf1 (* n1 = n1' *), unused > = n1res in
   unpack < ?n2', ?prf2 (* n2 = n2' *), unused > = n2res in
   if (syntactic_iseq #[#phi] ?T ?n1' ?n2') then
     unit
   else
     (let new2 = pack ?n2' as ?n2' return hol([s:#phi].eq ?n1'/[s] ?n2'/[s]) with
			          <| [s:#phi].?gen_eq_repl2/[?T/[s]] ?n1/[s] ?n2/[s] ?n1'/[s] ?n2'/[s] ?prf/[s] ?prf1/[s] ?prf2/[s] |> in
      let n1entry = hashget_uns #[#phi] (ufres #[#phi]) h ?T ?n1' in
      let n2entry = hashget_uns #[#phi] (ufres #[#phi]) h ?T ?n2' in
      let n1ccpar = snd n1entry in
      let n2ccpar = snd n2entry in
      let n1rep = fst n1entry in
	(n1rep := new2);
	(n2ccpar := (setunion #[#phi] !n1ccpar !n2ccpar));
	(n1ccpar := (mkset #[#phi] STANDARD_HASH_SIZE))))

let already_eq = fun #phi : ctx => fun h : hash_t #[#phi] (ufres #[#phi]) =>
                 fun ?T : [#phi].Set => fun ?n1 : [s : #phi].?T/[s] => fun ?n2 : [s : #phi].?T/[s] =>
  (let res1 = find #[#phi] h ?T ?n1 in
   let res2 = find #[#phi] h ?T ?n2 in
   unpack < ?n1', ?pf1, unused > = res1 in
   unpack < ?n2', ?pf2, unused > = res2 in
   (* by now we have: n1 = n1' and n2 = n2'. We need n1 = n2 *)

  (* this depends on environment-substitutive pattern matching *)
  (holcase ?n1' as ?n1' return option hol([s:#phi].eq ?n1/[s] ?n2/[s]) with
       ().[s:#phi].?n2'/[s] |-> (* n1 = n2' /\ n2 = n2' *)
  	                    (some hol([s:#phi].eq ?n1/[s] ?n2/[s]) <|[s:#phi].trans ?pf1/[s] (symm ?pf2/[s]) |>)
     | (?n11 : [s : #phi].?T/[s]).[s:#phi].?n11/[s] |-> (none hol([s:#phi].eq ?n1/[s] ?n2/[s]))))


let congruent = fun #phi : ctx => fun h : hash_t #[#phi] (ufres #[#phi]) =>
                fun ?T : [#phi].Set => fun ?n1 : [s : #phi].?T/[s] => fun ?n2 : [s : #phi].?T/[s] =>
  let test1 = already_eq #[#phi] h ?T ?n1 ?n2 in
    (match test1 with
	 som |-> test1
       | non |->
	   (holcase ?n1 as ?n1 return option(hol([s:#phi].eq ?n1/[s] ?n2/[s])) with
		(?T' : [#phi].Set, ?f : [s : #phi].?T'/[s] -> ?T/[s], ?n0 : [s : #phi].?T'/[s]).[s:#phi].?f/[s] ?n0/[s] |->
		  (holcase ?n2 as ?n2 return option(hol([s:#phi].eq (?f/[s] ?n0/[s]) ?n2/[s])) with
		       (?f' : [s:#phi].?T'/[s] -> ?T/[s], ?n0' : [s : #phi].?T'/[s]).[s:#phi].?f'/[s] ?n0'/[s] |->
			 (let funceq = already_eq #[#phi] h ([#phi].??) ?f ?f' in
			  match funceq with
			      som |-> (unpack < ?pfF , unused > = som in
				      let argseq = already_eq #[#phi] h ?T' ?n0 ?n0' in
				      match argseq with
					  som |-> (unpack < ?pfA, unused > = som in
						  some (hol([s:#phi].??))
						  <| [s:#phi].?app_eq/[?T'/[s],?T/[s]] ?f/[s] ?f'/[s] ?n0/[s] ?n0'/[s] ?pfF/[s] ?pfA/[s] |>)
					| non |-> none (hol([s:#phi].??)))
			    | non |-> none (hol([s:#phi].??)))
		     | (?n2 : [s : #phi].?T/[s]).[s:#phi].?n2/[s] |->
			 none (hol([s:#phi].eq (?f/[s] ?n0/[s]) ?n2/[s])))
	      | (?n1 : [s : #phi].?T/[s]).[s:#phi].?n1/[s] |->
		  none (hol([s:#phi].eq ?n1/[s] ?n2/[s]))))


let merge = fun #phi : ctx => fun h : hash_t #[#phi] (ufres #[#phi]) =>
  letrec merge : { ?T : [#phi].Set, ?n1 : [s : #phi].?T/[s], ?n2 : [s : #phi].?T/[s], ?prf : [s:#phi].eq ?n1/[s] ?n2/[s] } Unit =
  fun ?T : [#phi].Set, ?n1 : [s : #phi].?T/[s] , ?n2 : [s : #phi].?T/[s] , ?prf : [s:#phi].eq ?n1/[s] ?n2/[s] =>
  (DEBUGPRINT "merging:");
  (DEBUG (fun u : Unit => (print <| ?n1 |> ); (print <| ?n2 |> ) ) );
  unpack < ?n1', unused > = find #[#phi] h ?T ?n1 in
  unpack < ?n2', unused > = find #[#phi] h ?T ?n2 in
  if syntactic_iseq #[#phi] ?T ?n1' ?n2' then
    unit
  else
    (let n1ccpar = !(snd (hashget_uns #[#phi] (ufres #[#phi]) h ?T ?n1')) in
     let n2ccpar = !(snd (hashget_uns #[#phi] (ufres #[#phi]) h ?T ?n2')) in
     let mergeifneeded = fun ?T1 : [s : #phi].Set, ?t1 : [s : #phi].?T1/[s] , ?T2 : [s : #phi].Set, ?t2 : [s : #phi].?T2/[s] =>
       holcase ?T1 as ?T1 return Unit with
	   ().[s:#phi].?T2/[s] |->
	     (unpack < ?t1', unused > = find #[#phi] h ?T1 ?t1 in
	      unpack < ?t2', unused > = find #[#phi] h ?T1 ?t2 in
              if syntactic_iseq #[#phi] ?T1 ?t1' ?t2' then
		unit
	      else
		(match congruent #[#phi] h ?T1 ?t1 ?t2 with
		     som |-> (unpack < ?pft, unused > = som in merge ?T1 ?t1 ?t2 ?pft)
                   | non |-> unit))
	 | (?T1 : [s:#phi].Set).[s:#phi].?T1/[s] |-> unit
     in
      (union #[#phi] h ?T ?n1 ?n2 ?prf);
      (setiter #[#phi] (fun ?T1 : [#phi].Set, ?t1 : [s : #phi].?T1/[s] =>
	   setiter #[#phi] (fun ?T2 : [#phi].Set, ?t2 : [s : #phi].?T2/[s] => mergeifneeded ?T1 ?t1 ?T2 ?t2) n2ccpar)
	 n1ccpar)
    )
  in
  merge

let already_eq_no_mutate = fun #phi : ctx => fun h : hash_t #[#phi] (ufres #[#phi]) =>
                 fun ?T : [#phi].Set => fun ?n1 : [s : #phi].?T/[s] => fun ?n2 : [s : #phi].?T/[s] =>
  match hashget #[#phi] (ufres #[#phi]) h ?T ?n1 with
      som |-> (match hashget #[#phi] (ufres #[#phi]) h ?T ?n2 with
		   som |-> already_eq #[#phi] h ?T ?n1 ?n2
		 | non |-> none (hol([s:#phi].?n1/[s] = ?n2/[s])))
    | non |-> none (hol([s:#phi].?n1/[s] = ?n2/[s]))


let hyps_t = fun #phi : ctx => list ( < ?T : [#phi].Set, ?t1 : [s:#phi].?T/[s], ?t2 : [s:#phi].?T/[s] >
				  hol( [s:#phi].?t1/[s] = ?t2/[s] ))


let ufbuilder : {#phi : ctx} ufhash_t #[#phi] =
  letrec ufbuilder : {#phi : ctx} hyps_t #[#phi] =
  fun #phi : ctx =>
    ctxcase #[ #phi ] as #phi return hyps_t #[#phi] with
	().().[] |-> nil (< ?T : [#phi].Set, ?t1 : [s:#phi].?T/[s], ?t2 : [s:#phi].?T/[s]>
				  hol( [s:#phi].?t1/[s] = ?t2/[s] ))
      | (#phi0 ).(?T : [#phi0].Set, ?t1 : [s : #phi0].?T/[s], ?t2 : [s : #phi0].?T/[s]).
	  [ s : #phi0, pf : ?t1/[s] = ?t2/[s] ] |->
	  (let res = ufbuilder #[#phi0] in
	   let res' = cons (< ?T : [#phi].Set, ?t1 : [s:#phi].?T/[s], ?t2 : [s:#phi].?T/[s]>
	   			  hol( [s:#phi].?t1/[s] = ?t2/[s] ))
    	                   (pack [s : #phi0, pf : ?t1/[s] = ?t2/[s]].?T/[s] as ?T return (< ?t1 : [s:#phi].?T/[s], ?t2 : [s:#phi].?T/[s]> hol( [s:#phi].?t1/[s] = ?t2/[s])) with
	   		    pack [s : #phi0, pf : ?t1/[s] = ?t2/[s]].?t1/[s] as ?t1' return (< ?t2' : [s:#phi0, pf : ?t1/[s] = ?t2/[s]].?T/[s]> hol( [s:#phi].?t1'/[s] = ?t2'/[s])) with
	   		    pack [s : #phi0, pf : ?t1/[s] = ?t2/[s]].?t2/[s] as ?t2' return (hol( [s:#phi0, pf : ?t1/[s] = ?t2/[s]].?t1/[s] = ?t2'/[s,pf])) with
	   			<| [s:#phi0 , pf : ?t1/[s] = ?t2/[s] ].pf |>)
	                   res in
	     res')
      | (#phi0 ).(?P : [#phi0].Prop).[s : #phi0, pf : ?P/[s] ] |->
	  ufbuilder #[#phi0]
      | (#phi0 ).(?T : [#phi0].Set).[s : #phi0, t : ?T/[s] ] |->
	  ufbuilder #[#phi0]
      | (#phi0 ).().[s : #phi0, t : Set] |->
	  ufbuilder #[#phi0]
  in
  fun #phi : ctx =>
      let hyplist = ufbuilder #[#phi] in
      let ufhash =  ufempty #[#phi] in
       (listiter (< ?T : [#phi].Set, ?t1 : [s:#phi].?T/[s], ?t2 : [s:#phi].?T/[s]>
		    hol( [s:#phi].?t1/[s] = ?t2/[s] ))
	  (fun hyp : < ?T : [#phi].Set, ?t1 : [s:#phi].?T/[s], ?t2 : [s:#phi].?T/[s]>
				  hol( [s:#phi].?t1/[s] = ?t2/[s] ) =>
	      unpack < ?T, ?t1, ?t2, ?pf, unused > = hyp in
	      merge #[#phi] ufhash ([s:#phi].?T/[s]) ([s:#phi].?t1/[s]) ([s:#phi].?t2/[s]) ([s:#phi].?pf/[s]))
          hyplist);
       ufhash


(* cache for ufbuilder *)

let ctxhash_t = fun res : ctx -> CType =>
              array (option ( < phikey : ctx > res #[ phikey ] ) )

let mkctxhash = fun res : ctx -> CType => fun i : int =>
             mkarray( i, (none ( < phikey : ctx > res #[ phikey ] )) , option ( < phikey : ctx > res #[phikey] )) 

let ctxhashget = fun res : ctx -> CType => fun h : ctxhash_t res =>
              fun phi : ctx =>
              let hn = arraylen h in
              letrec find : (int -> (option (res #@ ))) =
		  fun i : int => 
		  match h.(i) with
		      som |-> (unpack < #phi', result > = som in
                               ctxcase #[ phi' ] as phi'' return (option (res #[ phi ])) with
				   ().(). [ phi ] |-> some (res #[ phi ]) result
				 | ( #phi').(). [ phi' ] |->
				   (find ((i iplus 1) imod hn)))
		    | non |-> (none (res #[ phi ]))
              in
	        find ((hash (pack #[ phi ] as #phi' return Unit with unit)) imod hn)

let ctxhashget_uns = fun res : ctx -> CType => fun h : ctxhash_t res =>
                     fun phi : ctx =>
                     match ctxhashget res h #@ with
			 som |-> som
		       | non |-> bot (res #@ )

let ctxhashset = fun res : ctx -> CType , h : ctxhash_t res , phi : ctx , r : res #@ =>
  let hn = arraylen h in
  letrec find : (int -> Unit) =
      fun i : int => 
      match h.(i) with
	  som |-> unpack < #phi', result > = som in
                  (ctxcase #[ phi' ] as phi' return Unit with
		      ().(). [ phi ] |->
			h.(i) <- (some ( < phi : ctx > res #[ phi ] )
				       (pack #[ phi ] as #phi return res #[ phi ] with r) )
		    | ( #phi' ).().[ phi' ] |->
		        find ((i iplus 1) imod hn))
        | non |-> h.(i) <- (some ( < phi : ctx > res #[ phi ] )
			      (pack #[ phi ] as #phi return res #[ phi ] with r) )
  in
    find ((hash (pack #[ phi ] as #phi' return Unit with unit)) imod hn)

let ufbuilder_cache = mkctxhash ufhash_t STANDARD_HASH_SIZE

let ufbuilder2 = fun phi : ctx =>
  (match ctxhashget ufhash_t ufbuilder_cache #[ phi ] with
      som |-> (print "LALALA: already found!!!\n"); som
    | non |-> (print "LALALA: did not find\n"); (let ufhash = ufbuilder #[ phi ] in
	       (ctxhashset ufhash_t ufbuilder_cache #[ phi ] ufhash);
	       ufhash))

let ufprint_for_ctx = fun #phi : ctx =>
  ufprint #[#phi] (ufbuilder #[#phi])

let equaltester_euf_creator : ({#phi : ctx} ufhash_t #[#phi]) ->
                              equaltester_t =
  fun ufbuilder : ({#phi : ctx} ufhash_t #[#phi]) ,
    #phi : ctx , ?T : [#phi].Set, ?e1 : [s:#phi].?T/[s], ?e2 : [s:#phi].?T/[s] =>
    (DEBUGPRINT "testing equality as part of EUF eqcheck");
    (DEBUG (fun u : Unit => ( print <| ?e1 |> ); ( print <| ?e2 |> ) ));
    already_eq #[#phi] (ufbuilder #[#phi]) ?T ?e1 ?e2

let equaltester_euf : equaltester_t = 
  equaltester_euf_creator ufbuilder2

let _ = global_equaltester_add equaltester_euf

eval ( let @ = #[ T : Set, a : T, b : T , pf : a = b ] in
	  def_iseq #@ @T @b @a ) .

eval ( let @ = #[ T : Set, a : T, b : T , pf : a = b ] in
	  def_iseq #@ @T @b @a ) .

save "prog2_rewrite_euf".

>>;;
