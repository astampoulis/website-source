open Camlp4

module Id = struct
  let name = "syntax_monad"
  let version = "1.0"
end

module Make (Syntax : Sig.Camlp4Syntax) = struct
  open Sig
  include Syntax

  let _ = Gram.Entry.mk "monad_seq"
  let _ = Gram.Entry.mk "monad_block"

  EXTEND Gram
    GLOBAL: expr;

    expr: LEVEL "simple"
      [ [ "monadic"; e1 = expr; "in"; e2 = expr ->
            <:expr< let ret, bind = $e1$ in $e2$ >>
	| "cmd"; "{"; e1 = monad_seq; "}" -> e1 ] ];

    monad_seq:
      [ "simple"
	  [ "return"; e1 = expr -> <:expr< ret $e1$ >> ]
      | "seq" LEFTA
 	  [ p = patt; "<-"; e2 = expr; "then"; e3 = SELF -> <:expr< bind $e2$ (function $p$ -> $e3$) >> ] ];
  END

end

module M = Register.OCamlSyntaxExtension(Id)(Make)

