open Syntax_logic;;
open Syntax_comp;;

<<
reset.

(* --------------------------*)
(* Propositional logic       *)

Axiom and : Prop -> Prop -> Prop.
Axiom andIntro : forall (A B : Prop), A -> B -> and A B.
Axiom andElim  : forall (A B P : Prop), (A -> B -> P) -> and A B -> P.
Definition andElim1 : forall (A B : Prop), and A B -> A :=
  fun (A B : Prop) (pf : and A B) => andElim A B A (fun a : A => fun b : B => a) pf.
Definition andElim2 : forall (A B : Prop), and A B -> B :=
  fun (A B : Prop) (pf : and A B) => andElim A B B (fun a : A => fun b : B => b) pf.


Axiom or : Prop -> Prop -> Prop.
Axiom orIntro1 : forall (A B : Prop), A -> or A B.
Axiom orIntro2 : forall (A B : Prop), B -> or A B.
Axiom orElim   : forall (A B P : Prop), or A B -> (A -> P) -> (B -> P) -> P.

Axiom True : Prop.
Axiom trueIntro : True.

Axiom False : Prop.
Axiom falseElim : forall P : Prop, False -> P.

Metadef not : [].Prop -> Prop := [].fun P : Prop => (P -> False).
    

Metadef app_eq : [ T1 : Set, T2 : Set ].forall (f1 f2 : T1 -> T2) (a1 a2 : T1), f1 = f2 -> a1 = a2 -> f1 a1 = f2 a2 :=
    [ T1 : Set, T2 : Set].fun (f1 f2 : T1 -> T2) (a1 a2 : T1) (pff : f1 = f2) (pfa : a1 = a2) =>
    leibn (fun f : T1 -> T2 => f1 a1 = f a2) pff (leibn (fun a : T1 => f1 a1 = f1 a) pfa (refl (f1 a1))).

Metadef gen_eq_repl2 : [T:Set].forall (x y x' y' : T), x = y -> x = x' -> y = y' -> x' = y' :=
  [T:Set].fun (x y x' y' : T) =>
    fun (pf1 : x = y) (pf2 : x = x') (pf3 : y = y') =>
    leibn (fun y : T => x' = y) pf3
    (leibn (fun x : T => x = y) pf2 pf1).

Metadef gen_f_equal : [T1:Set,T2:Set].forall (f : T1 -> T2) (x y : T1), eq x y -> eq (f x) (f y) :=
   [T1:Set,T2:Set].
      fun (f : T1 -> T2) (x y : T1) (pf : eq x y) =>
      leibn (fun y : T1 => f x = f y) pf (refl (f x)).


(* -------------------- *)
(* Computational stuff  *)


let list = fun a : CType => rec t : CType => sum(Unit + a * t)
let nil = fun a : CType => fold( ctor(0, sum(Unit + a * (list a) ), unit), list a )
let cons = fun a : CType => fun hd : a => fun tl : list a => fold( ctor(1, sum(Unit + a * (list a)), tup(hd, tl)), list a)

let listmap = fun a : CType => fun b : CType => fun f : a -> b => (
  letrec map : list a -> list b =
    fun l : list a =>
    match unfold l with
	u |-> nil _
      | hdtl |-> cons _ (f (fst hdtl)) (map (snd hdtl))
  in
    map)
let listfold = fun a : CType => fun b : CType => fun f : b -> a -> b => fun start : b => (
  letrec lfold : list a -> b =
    fun l : list a =>
    match unfold l with
	u |-> start
      | hdtl |-> f (lfold (snd hdtl)) (fst hdtl)
  in
    lfold)
let listiter = fun a : CType => fun f : a -> Unit => fun l : list a =>
  listfold _ _ (fun unused : Unit => f) unit l
let listappend = fun a : CType , l1 : list a , l2 : list a =>
  listfold _ _ (fun cur : list a, elm : a => cons a elm cur) l2 l1
let listsnoc = fun a : CType , l1 : list a , elm : a => listappend _ l1 (cons _ elm (nil _))
let listlength = fun a : CType , l : list a => listfold _ _ (fun r : int , elm : a => r iplus 1) 0 l


let option = fun a : CType => sum(a + Unit)
let some   = fun a : CType => fun b : a => ctor(0, option a, b)
let none   = fun a : CType => ctor(1, option a, unit)
let optiondo = fun a : CType => fun b : CType => fun param : option a => fun f : a -> option b =>
               match param with som |-> f som | non |-> none _

(* Magic value! *)

let bot =
  letrec bot : {a : CType}a = fun a : CType => bot a in
  bot

let break = unit

let __debug = mkref(false, _)
let DEBUG = fun f : Unit -> Unit => if !(__debug) then f unit else unit
let DEBUGPRINT = fun s : string => DEBUG (fun u : Unit => (print s); print "\n")

save "prog2_basis".

>>;;
