open Camlp4.PreCast
module CAst = Comp_ast
module CCst = Comp_cst
module LCst = Logic_cst
module LMain = Logic_main
module CTyp = Comp_typing

module CamlSyntax = Camlp4GrammarParser.Make(Camlp4OCamlParser.Make(Camlp4OCamlRevisedParser.Make(Syntax)));;
let expr_of_string = CamlSyntax.Gram.parse_string CamlSyntax.expr_eoi;;

module CompGram = Syntax_logic.LogicGram

let ident = Syntax_logic.ident
let modalterm = Syntax_logic.modalterm
let context = Syntax_logic.context
let exprlist = Syntax_logic.exprlist
let logicdef = Syntax_logic.logicdef
let lterm    = Syntax_logic.term

let ctxterm = Syntax_comp.ctxterm
let cterm = Syntax_comp.cterm
let cterm_eoi = Syntax_comp.cterm_eoi
let cterm_ast_eoi = Syntax_comp.cterm_ast
let cterm_ast_eoi = Syntax_comp.cterm_ast_eoi
let compdef = Syntax_comp.compdef
let compdef_eoi = Syntax_comp.compdef_eoi

let mk_anti ?(c = "") n s = "\\$"^n^c^":"^s


EXTEND CompGram

  ident: LAST
  [ "antiquot" NONA
      [ `ANTIQUOT("id",s) -> mk_anti "" s
      ]
  ];

  cterm: FIRST
  [  "antiquot" NONA
      [
	`ANTIQUOT("", s) -> let a = mk_anti "" s in <:expr< $anti:a$ >>
      ]
  ];

  lterm: FIRST
  [ "antiquot" NONA
      [
	`ANTIQUOT("", s) -> let a = mk_anti "" s in <:expr< $anti:a$ >>
      ]
  ];

  modalterm: FIRST
  [ "antiquot" NONA
      [
	`ANTIQUOT("mt", s) -> let a = mk_anti "" s in <:expr< $anti:a$ >>
      ]
  ];

  ctxterm: FIRST
  [ "antiquot" NONA
      [
	`ANTIQUOT("ct", s) -> let a = mk_anti "" s in <:expr< $anti:a$ >>
      ]
  ];
   
END;;

	
