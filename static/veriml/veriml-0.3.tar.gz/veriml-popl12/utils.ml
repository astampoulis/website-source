module Dict = Map.Make(String)
module IMap = Map.Make(struct
			 type t = int
		         let compare = Pervasives.compare
		       end)

module ExtDict =
  struct

    exception Not_found_key of string
    let find (a : string) b =
      try
	Dict.find a b
      with Not_found ->
	raise (Not_found_key(a))

    let getfst s dict =
      let (fst,snd) = find s dict in
	fst
	  
    let getsnd s dict = 
      let (fst,snd) = find s dict in
	snd

  end

type 'a dict = 'a Dict.t
type 'a map  = 'a IMap.t

let decreasing n = 
  let rec aux n = if n = 0 then [] else (n-1) :: aux (n-1) in
    aux n
let decreasing_start n start = 
  let rec aux n = if n = 0 then [] else (n-1+start) :: aux (n-1) in
    aux n
let increasing n = List.rev (decreasing n)

let uncurry f (a,b) = f a b

let option_ret  a = Some a
let option_bind e f = (match e with
			   Some e' -> f e'
			 | None -> None)
let option_monad = ( option_ret, option_bind )

let (^?) s1 s2 = match s1 with Some(s) -> Some(s ^ s2) | None -> None

let compose f g x = f (g x)

let require e why = (if not e then failwith why else ())

module ExtList =
  struct

    let findindex (f : 'a -> bool) (l : 'a list) =
      let rec aux i = function
	  [] -> raise Not_found
	| hd :: tl -> if f hd then i else aux (i+1) tl
      in
	aux 0 l

    let iteri (f : int -> 'a -> unit) (l : 'a list) =
      let rec aux i = function
	  [] -> ()
	| hd :: tl -> (f i hd; aux (i+1) tl)
      in
	aux 0 l

    let mapi (f : int -> 'a -> 'b) (l : 'a list) =
      let rec aux i = function
	  [] -> []
	| hd :: tl -> (f i hd) :: (aux (i+1) tl)
      in
	aux 0 l

    let updatenth (n : int) (what : 'a) (l : 'a list) =
      mapi (fun i elm -> if i = n then what else elm) l

    let filtermapi (f : int -> 'a -> 'b option) (l : 'a list) =
      let rec aux i = function
	  [] -> []
	| hd :: tl -> 
	    let rest = aux (i+1) tl in
	      (match f i hd with
		   Some b -> b :: rest
		 | None -> rest)
      in
	aux 0 l

    let rec sublist (n : int) (l : 'a list) =
      if n = 0 then l else
	(match l with
	     [] -> failwith "ExtList.sublist"
	   | hd :: tl -> sublist (n-1) tl)

    (* let foldindex (f : int -> 'a -> 'b -> 'b) (start : 'b) (l : 'a list) = *)
    (*   let rec aux i = function *)
    (* 	  [] -> start *)
    (* 	| hd :: tl -> *)
    (* 	    f i hd (aux (i+1) tl) *)
    (*   in *)
    (* 	aux 0 l *)

    let foldindex (f : int -> 'a -> 'b -> 'b) (start : 'b) (l : 'a list) =
      let rec aux i res = function
    	  [] -> res
    	| hd :: tl ->
	    let res' = f i hd res in
	      aux (i+1) res' tl
      in
    	aux 0 start l

    let last (l : 'a list) =
      let rec aux res l = 
	match l with
	    t1 :: [] -> res, t1
	  | hd :: tl -> aux (hd :: res) tl
	  | _ -> failwith "ExtList.last"
      in
      let rest, last1 = aux [] l in
	List.rev rest, last1
	  
    let last_two (l : 'a list) =
      let rec aux res l = 
	match l with
	    t1 :: t2 :: [] -> res, t1, t2
	  | hd :: tl -> aux (hd :: res) tl
	  | _ -> failwith "ExtList.last_two"
      in
      let rest, last1, last2 = aux [] l in
	List.rev rest, last1, last2

    let fstmap (f : 'a -> 'b) (l : ('a * 'c) list) =
      List.map (fun (a,c) -> (f a,c)) l

    let sndmap (f : 'a -> 'b) (l : ('c * 'a) list) =
      List.map (fun (c,a) -> (c,f a)) l

    let rec make (n : int) (elm : 'a) =
      if n = 0 then [] else elm :: make (n-1) elm

    let rec take (n : int) (l : 'a list) =
      if n = 0 then [] else match l with hd :: tl -> hd :: take (n-1) tl | [] -> failwith "take"

    let rec drop (n : int) (l : 'a list) =
      if n = 0 then l else match l with _ :: tl -> drop (n-1) tl | [] -> failwith "drop"

    let is_prefix l1 l2 =
      if List.length l1 > List.length l2 then false
      else List.for_all2 (=) l1 (take (List.length l1) l2)

    exception NotFoundPartition
    let find_partition_index f l =
      let rec aux index prev l =
	match l with
	    hd :: tl -> 
	      (if (f hd) then (List.rev prev, hd, tl), index
	       else aux (index+1) (hd :: prev) tl)
	  | [] ->
	      raise NotFoundPartition
      in
	aux 0 [] l

    let midfold f l res =
      let rec aux sofar l res =
	match l with
	    [] -> res
	  | hd :: tl -> let res' = f sofar hd res in
	                aux (List.append sofar [hd]) tl res'
      in
	aux [] l res

    let min_for_all2 f l1 l2 =
      let n1 = List.length l1 in
      let n2 = List.length l2 in
	if n1 > n2 then List.for_all2 f (take n2 l1) l2
	else List.for_all2 f l1 (take n1 l2)

  end

let stringlist (f : 'a list -> 'res) (list : ('b * 'a) list)  =
  let strings, terms = List.split list in
  let terms' = f terms in
    List.combine strings terms'

(* deprecated, should remove its uses *)
exception AlreadyInferred
exception NotInferredYet
type 'a inferred = 'a option ref
let mk_inferred () = ref None
let inferred_is inf what = inf := Some what
let get_inferred inf = match !inf with None -> raise NotInferredYet | Some t -> t

let optionassign w s = match w with None -> () | Some r -> r := s
let rec repeatmany n (f : unit -> 'a) = if n = 1 then f () else (let _ = f () in repeatmany (n-1) f)


type 'a unifvar = Inst of   'a  * (('a unifvar ref) option) ref
	        | Uninst of int * (('a unifvar ref) option) ref

let (mk_unifvar : int ref -> 'a unifvar ref) unifcount =
  unifcount := !unifcount + 1;
  let typ = ref None in
  let unifvar = Uninst(!unifcount, typ) in
  ref unifvar
    
let rec match_unif (ifinfer : 'a -> ('a unifvar ref -> 'b) -> 'b -> 'b) l =
  match !l with
      Inst(t,_) -> (ifinfer t (match_unif ifinfer) l)
    | t -> l

let unifvar_type_unify (unification : 'a -> 'a -> bool)
                       (ifinfer : 'a -> ('a unifvar ref -> 'b) -> 'b -> 'b)
		       (inject : 'a unifvar ref -> ('a -> 'a) -> 'a)
		       (unifcount : int ref)
		       l1 f1 l2 f2 =
  let rec unifvar_type_unify l1 f1 l2 f2 =
    let otypunify otyp1 otyp2 =
      match !otyp1, !otyp2 with
	  Some typ1, Some typ2 -> if not (unification (inject typ1 f1) (inject typ2 f2)) then failwith "inferrencing is type-unsafe!"
	| Some typ1, None -> otyp2 := Some typ1
	| None, Some typ2 -> otyp1 := Some typ2
	| None, None -> (let uv = mk_unifvar unifcount in otyp1 := (Some uv); otyp2 := Some uv)
    in
    match !l1, !l2 with
	Uninst(_, otyp1), Uninst(_, otyp2) -> otypunify otyp1 otyp2
      | Inst(t1, otyp1), Uninst(_, otyp2) ->
	otypunify otyp1 otyp2;
	ifinfer t1 (fun uv' -> unifvar_type_unify uv' f1 l2 f2) ()
      | Uninst(_, otyp1), Inst(t2,otyp2) ->
	otypunify otyp1 otyp2;
	ifinfer t2 (fun uv' -> unifvar_type_unify l1 f1 uv' f2) ()
      | Inst(t1,otyp1), Inst(t2,otyp2) ->
	otypunify otyp1 otyp2;
	ifinfer t1 (fun uv' -> unifvar_type_unify uv' f1 l2 f2) ();
	ifinfer t2 (fun uv' -> unifvar_type_unify l1 f1 uv' f2) ()
  in
  ()
  (* unifvar_type_unify l1 f1 l2 f2 *)
    

