#directory "_build";;
#directory ".";;

open Logic_core;;
open Logic_typing;;
open Logic_cst;;
open Logic_print;;
open Utils;;
open Resumable;;
open Comp_cst;;
open Comp_print;;
open Comp_typing;;

#load "camlp4o.cma";;
#load "syntax_logic.cmo";;
#load "syntax_comp.cmo";;
#load "syntax_tac.cmo";;
open Syntax_logic;;
open Syntax_comp;;
open Syntax_tac;;

#install_printer pr_lterm;;
#install_printer pr_modal;;
#install_printer pr_ctxdesc;;
#install_printer pr_cterm;;

comp_global_reset_all ();;
comp_global_import "prog2_rewrite_list";;

#use ".veriml.init2.ml";;
