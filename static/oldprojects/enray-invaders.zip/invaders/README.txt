enRay invaders version 0.1 
Copyright (C) 2002 Antonis Stampoulis

-------------------------------------------------------------------------
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
-------------------------------------------------------------------------


enRay is a realtime raytracing engine written in C. It has most of the
standard features of realtime raytracers (phong shading, sphere
and plane primitive types, multiple lights, shadows, reflections,
etc. - no textures yet though), plus:

 - Implicit surface rendering
 - Mathematical expressions parser, so that the implicit surface's
   function can be specified at run-time
 - Adaptive sub-sampling (from 2x2 to 256x256), using OpenGL to
   draw interpolated quads
 - Hardware accelerated triangle mesh rendering, using OpenGL (only
   for primary rays)
 

enRay Invaders is a very simple shoot'em-up, made just to show off the
raytracer. :-) Don't take me wrong, it is not meant to be a proper
game...


Controls:
 up / down      zoom in/out
 left / right   move ship
 space          shoot
 F1             nausea mode (wobbly camera movement)
 F2             add a plane into the scene, placed behind the ship and the
                spheres
 F3             add shadows to the plane
 F4             add procedural bump mapping to the plane - really slow
 + / -          increase/decrease max width of adaptive sampling blocks
 0 / 9          increase/decrease min width of adaptive sampling blocks
 ins / del      move camera to the left/right
 pgup / pgdn    move camera up/down
 escape         quit

You can specify the desired resolution as a command-line argument, eg. 
enrayinv 800 600
(or just run highres.bat for 512x384 resolution)
The ship's implicit surface function can be specified in the shipfunc.txt
file. (This slows things down of course. Make sure the first
character of the file is a colon (:) and then an expression in the
form x^2+y^2-z^2)

enRay invaders includes Windows binaries. It can be compiled in
Linux, after some minor modifications to the makefile, provided
that you have the SDL library installed.

enRay v0.1 and enRay invaders were developped by Antonis Stampoulis. Questions,
suggestions, etc. go to enplo00@yahoo.com.

