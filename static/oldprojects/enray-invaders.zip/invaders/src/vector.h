/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#ifndef _vector_h_
#define _vector_h_

typedef struct {
  float x, y, z, rsq;
} vector;

void vectorSetOpt (vector *v, float x, float y, float z);
void vectorSet (vector *v, float x, float y, float z);
void vectorSubOpt (vector *a, vector *b, vector *r);
void vectorSub (vector *a, vector *b, vector *r);
void vectorMultOpt (vector *a, float b, vector *r);
void vectorMult (vector *a, float b, vector *r);
void vectorAddOpt (vector *a, vector *b, vector *r);
void vectorAdd (vector *a, vector *b, vector *r);
void vectorOpposite (vector *a);
void vectorNormalize (vector *a);
float vectorNormalizeRetMag (vector *a);
void vectorNormalizeOpt (vector *a);
float vectorNorm (vector *a);
float vectorNormOpt (vector *a);
float vectorDot (vector *a, vector *b);
void vectorCross (vector *a, vector *b, vector *r);
void vectorCrossOpt (vector *a, vector *b, vector *r);

#endif





