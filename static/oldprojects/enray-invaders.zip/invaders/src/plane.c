/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include "vector.h"
#include "scene.h"
#include "camera.h"
//#include <math.h>


extern bool proc_bump_map;

typedef struct {

  vector normal, point;
  float displacement, opt, vd;
  
} Plane;

float Plane_IntersectRay(ray *cray, void *vp, bool primary) {

  PMTCAST(p, Plane, vp);
  float d;
  float opt;

  if (primary) opt = p->opt;
  else opt = cray->origin.x * p->normal.x + cray->origin.y * p->normal.y +
             cray->origin.z * p->normal.z + p->displacement;

  p->vd = p->normal.x*cray->dir.x + p->normal.y*cray->dir.y +
          p->normal.z*cray->dir.z;
  
  if (p->vd<0.008f && p->vd>-0.008f) return -1.0f;
  
  d = - opt / p->vd;
  if (d>EPSILON) {
/*
    vector i;
    vectorSetOpt(&i,
                 cray->origin.x + cray->dir.x * d - p->point.x,
                 cray->origin.y + cray->dir.y * d - p->point.y,
                 cray->origin.z + cray->dir.z * d - p->point.z);
    if (i.x>30||i.x<-30||i.y>30||i.y<-30||i.z>30||i.z<-30) return -1;        
*/    
    return d;
  }
  else return -1.0f;

}

void Plane_SurfaceNormal(void *vp, vector *intersection, vector *normal) {
  PMTCAST(p, Plane, vp);
  
  if (proc_bump_map) {

  vector i;
  float bump;
  vectorSetOpt(&i,
               intersection->x - p->point.x,
               intersection->y - p->point.y,
               intersection->z - p->point.z);
  bump = sin(vectorNormOpt(&i)/10.0f+SDL_GetTicks()/1550.0f)*0.7f;
  vectorSetOpt(&i,
               intersection->x - p->point.x-40,
               intersection->y - p->point.y+80,
               intersection->z - p->point.z);
  bump += sin(vectorNormOpt(&i)/25.0f+SDL_GetTicks()/1800.0f+124.0f)*0.8f;


  if (p->vd<0) {
    normal->x = p->normal.x+bump;
    normal->y = p->normal.y+bump;
    normal->z = p->normal.z+bump;
    vectorNormalize(normal);
  } else {
    normal->x = -p->normal.x+bump;
    normal->y = -p->normal.y+bump;
    normal->z = -p->normal.z+bump;
    vectorNormalize(normal);
  }
  
  } else {
  
  if (p->vd<0) {
    normal->x = p->normal.x;
    normal->y = p->normal.y;
    normal->z = p->normal.z;
  } else {
    normal->x = -p->normal.x;
    normal->y = -p->normal.y;
    normal->z = -p->normal.z;
  }
  
  }
}

void Plane_PerFrameOpt(Camera *c, void *vp) {
  PMTCAST(p, Plane, vp);
  
  p->opt = c->position.x * p->normal.x +
           c->position.y * p->normal.y +
           c->position.z * p->normal.z +
           p->displacement;
           
}

PrimitiveDecl PlanePrimitive = { Plane_IntersectRay,
                                 Plane_SurfaceNormal,
                                 Plane_PerFrameOpt };
                                 
Primitive NewPlane (float x, float y, float z,
                    float a, float b, float c) {

  Primitive pP;
  Plane *p = NEW(Plane,1);
  
  vectorSet(&p->normal,x,y,z);
  vectorSet(&p->point,a,b,c);
  vectorNormalize(&p->normal);
  p->displacement = -(x*a+y*b+z*c);
  pP.properties = (void *) p;
  pP.type = &PlanePrimitive;
  
  return pP;
  
}

void ChangePlane (void *Vp, float x, float y, float z, float a, float b, float c) {

  PMTCAST(p, Plane, Vp);
  
  vectorSet(&p->normal,x,y,z);
  vectorSet(&p->point,a,b,c);
  vectorNormalize(&p->normal);
  p->displacement = -(x*a+y*b+z*c);

}
