/*  
 
    enRay Invaders, a simple game using the enRay raytracer
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include <stdio.h>
#include <time.h>
#include <math.h>
#include "graphics.h"
#include "maintrace.h"
#include "scene.h"
#include "primitives.h"
#include "parse.h"

#define FRND1() (rand()/(1.4*(float)(RAND_MAX)))

extern void Shoot(void);
extern int Update(void);
extern void DoMove(float);
extern float myx;

int zdist=200;
bool proc_bump_map = false;
int me;
float rm=-1, gm=-1, bm=-1;
Scene *s;
Expression *shipExpr = NULL;

float shipFunc1 (float x, float y, float z) { y+=25;return x*x + z*z - 50*y; }
float shipFunc2 (float x, float y, float z) { return parserEvaluate(shipExpr,x,y,z); }

int AddEnemy (float x, float y) {
  return AddObject(s, NewSphere(x, -y+150, 150, 30), NewMaterial(FRND1()+0.3,FRND1()+0.3,FRND1()+0.3,0.0,0.0), true, NOSHADOW);
}
void MoveEnemy (int handler, float x, float y) { ChangeSphere(ObjectProperties(s,handler),x,-y+150,150,30); }
void KillEnemy (int handler) { RmvObject(s, handler); }

int AddBullet (float x, float y) {
  int i;
  rm=FRND1()+(FRND1()/2)+0.3; gm=FRND1()+(FRND1()/2)+0.3; bm=FRND1()+(FRND1()/2)+0.3;
  i=AddObject(s, NewSphere(x, -y+150, 150, 10), NewMaterial(rm,gm,bm,0.0,0.0), true, NOSHADOW);
  i<<=8;
  i+=AddLight(s,x,-y+138,150,rm,gm,bm);
  return i;
}
void MoveBullet (int handler, float x, float y) { 
ChangeLight(s,handler&0xff,x,-y+138,150,DONT_CHANGE_LIGHT_COLOR,0,0);
ChangeSphere(ObjectProperties(s,handler>>8),x,-y+150,150,10);
}
void DeleteBullet (int handler) { RmvObject(s, handler>>8); RmvLight(s,handler&0xff); }

void MoveMe (float x, float y) { MoveImplicit(ObjectProperties(s,me),x,-y+150,150); }
 

int main (int argc, char **argv) {

  graphics *g;                                                  
  Camera *c;
  FILE *shipFuncFile;

  int light, plane=-1, bms, bs;
  bool nausea=false;
  float r, phi=0, theta=0;

  time_t starttime;
  long frames=0;
  
  g = argc>=3?
      GraphicsInit(atoi(argv[1]),atoi(argv[2]),32):
      GraphicsInit(320, 240, 32);
  if (!g) { printf("No graphics."); return -1; }
  
  c = NewCamera(45,0,0,-zdist,0,0,g->xres,g->yres);
  
  {
    int bs1, bms1;
    bs = 1; bms = 1;
    bs1 = (g->xres/40)>>1;
    bms1 = (g->xres/160)>>1;
    while (bs1!=0) {bs1>>=1; bs<<=1;}
    while (bms1!=0) {bms1>>=1; bms<<=1;}
    printf("%d %d\n", bs, bms);
  }

  srand(time(NULL));
  
  shipFuncFile = fopen("shipfunc.txt", "r");
  if (shipFuncFile) {
    char buffer[1024];
    fgets(buffer, 1024, shipFuncFile);
    if (buffer[0]==':') shipExpr = parserNewExpression(buffer);
    fclose(shipFuncFile);
  }
  
  s = NewScene(0,FRND1()*50+150,250);
  light = AddLight(s, 0, 160, 100, 1.5, 1.5, 1.5);

  if (!shipExpr) {
    me = AddObject(s, NewImplicit(0,100,100,50,shipFunc1,5,2),
                      NewMaterial(0.3,0.32,0.9,0.0,0.0),
                      true, NOSHADOW);
  } else {
    me = AddObject(s, NewImplicit(0,100,100,50,shipFunc2,5,2),
                      NewMaterial(0.3,0.32,0.9,0.0,0.0),
                      true, NOSHADOW);
  }
  MoveMe(0,0);
    
  starttime = time(NULL);

  while (GraphicsExist()) {

    if (!Update()) break;

    ChangeLight(s, light, myx, 160, 50, DONT_CHANGE_LIGHT_COLOR, 0, 0);
    RaytraceMain(c, s, bms, bs);
    if (nausea) {
      CameraLookAt(c, 
                   sin(SDL_GetTicks()/150.0f)*30+cos(SDL_GetTicks()/1700.0f)*40+sin(SDL_GetTicks()/600.0f+44.0f)*14, 
                   cos(SDL_GetTicks()/500.0f)*55+cos(SDL_GetTicks()/350.0f+4.44f)*15, 
                   -zdist, 0, 0, 0);
    } else {
//      CameraLookAt(c,0,0, -zdist, 0, 0, 0);
        r=-zdist;
        CameraLookAt(c, r*cos(phi)*sin(theta), r*sin(phi), r*cos(phi)*cos(theta), 0, 0, 0);

    }
    
    GraphicsUpdate();

    if (Keys[SDLK_UP]) zdist-=10;
    if (Keys[SDLK_DOWN]) zdist+=10;
    if (Keys[SDLK_LEFT]) DoMove(1);
    if (Keys[SDLK_RIGHT]) DoMove(-1);
    if (Keys[SDLK_SPACE]) Shoot();
    if (Keys[SDLK_ESCAPE]) break;

    if (Keys[SDLK_F1]) { nausea=nausea?false:true; Keys[SDLK_F1]=false; }
    if (Keys[SDLK_F2]) { 
       if (plane==-1) plane=AddObject(s,NewPlane(0,0,-1,0,0,200),NewMaterial(FRND1(),FRND1(),FRND1(),0.0,0.9),false,NOSHADOW);
       else { RmvObject(s,plane); plane=-1; }
       Keys[SDLK_F2] = false;
    }
    if (Keys[SDLK_F3] && plane!=-1) {
       RmvObject(s,plane);
       plane=AddObject(s,NewPlane(0,0,-1,0,0,200),NewMaterial(FRND1(),FRND1(),FRND1(),0.0,0.9),false,HARDSHADOW);
       Keys[SDLK_F3] = false;
    }
    if (Keys[SDLK_F4]) { proc_bump_map=proc_bump_map?false:true; Keys[SDLK_F4]=false; }

    if (Keys[SDLK_PAGEUP]) { phi+=0.1f; SDL_Delay(10);}
    if (Keys[SDLK_PAGEDOWN]) { phi-=0.1f; SDL_Delay(10); }
    if (Keys[SDLK_KP0] || Keys[SDLK_INSERT]) { theta-=0.1f; SDL_Delay(10); }
    if (Keys[SDLK_KP_PERIOD] || Keys[SDLK_DELETE]) { theta+=0.1f; SDL_Delay(10); }

    if (Keys[SDLK_0] && bms>2) { bms >>= 1; Keys[SDLK_0]=false; }
    if (Keys[SDLK_9] && bms<bs) { bms <<= 1; Keys[SDLK_9]=false; }
    if (Keys[SDLK_EQUALS] && bs>2) { bs >>= 1; Keys[SDLK_EQUALS]=false; }
    if (Keys[SDLK_MINUS] && bs<512) { bs <<= 1; Keys[SDLK_MINUS]=false; }
    if (Keys[SDLK_BACKSPACE]) { bms=2; bs=8; Keys[SDLK_BACKSPACE]=false; }


    frames++;
  };
  
  GraphicsDestroy(g);
  if (shipExpr) parserDestroyExpression(shipExpr);
  
  printf("average fps: %f\n", (float)(frames)/(float)(time(NULL)-starttime));
  
  return 0;
  
}

