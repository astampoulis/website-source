/*  
 
    enRay Invaders, a simple game using the enRay raytracer
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */
 
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <time.h>

#define TICKS() (SDL_GetTicks())
#define FRND()  (rand()/(float)(RAND_MAX))

extern int AddEnemy(float, float);
extern void MoveEnemy(int, float, float);
extern void KillEnemy(int);

extern int AddBullet(float, float);
extern void MoveBullet(int, float, float);
extern void DeleteBullet(int);

extern void MoveMe(float, float);

typedef struct { float x, y; int handler; } enemyT;
#define MAXENEMIES 10
enemyT enemies[MAXENEMIES]; int enemiesNum=0;

typedef struct { float x, y; int handler; } bulletT;
#define MAXBULLETS 5
bulletT bullets[MAXBULLETS]; int bulletNum=0;

float myx=0;
int level=0;
time_t previoustime=0;

void DoMove (float dir) {
float x = dir * (TICKS()-previoustime) * 0.2f;
if (myx+x>-300 && myx+x<300) { myx+=x; MoveMe(myx,0); }
}

int Update (void) {

  int i, j, k;
  float deltat;
  
  if (!previoustime) previoustime=TICKS();
  
  deltat = (TICKS()-previoustime);  
  for (i=0;i<bulletNum;i++) {
    bullets[i].y+=deltat * 0.2f;
    if (bullets[i].y>400) {
      DeleteBullet(bullets[i].handler);
      bulletNum--;
      for(k=i;k<bulletNum;k++) bullets[k]=bullets[k+1];
      i--;
    } else {
      MoveBullet(bullets[i].handler, bullets[i].x, bullets[i].y);
      for (j=0; j<enemiesNum; j++)
        if (pow(bullets[i].x-enemies[j].x,2)+pow(bullets[i].y-enemies[j].y,2)<=40*40) {
          DeleteBullet(bullets[i].handler);
          KillEnemy(enemies[j].handler);
          enemiesNum--;
          for (k=j;k<enemiesNum;k++) enemies[k]=enemies[k+1];
          bulletNum--;
          for (k=i;k<bulletNum;k++) bullets[k]=bullets[k+1];
          i--;
          break;
        }
    }
  }
  
  if (!enemiesNum) {
    if (level+1<MAXENEMIES) level++;
    for (i=0; i<level; i++) {
      enemies[i].x = (i%5)*110-(((i<5?(level<=5?level:5):level%5)-1)*110/2); 
      enemies[i].y = (FRND()*150)+300;
      enemies[i].handler = AddEnemy(enemies[i].x, enemies[i].y);
      enemiesNum++;
    }
  }
  
  for (i=0;i<enemiesNum;i++) {
    enemies[i].y -= (int)(1+level/5)*0.01*deltat;
    MoveEnemy(enemies[i].handler, enemies[i].x, enemies[i].y);
    if (pow(enemies[i].x-myx,2)+pow(enemies[i].y,2)<=80*80 || enemies[i].y<0)
      return 0;
  }
  
  previoustime = TICKS();
  
  return 1;
  
  
}

void Shoot (void) {

  if (bulletNum<MAXBULLETS) {
    
    if (bulletNum && bullets[bulletNum-1].y<70) return;
    bullets[bulletNum].x = myx;
    bullets[bulletNum].y = 50;
    bullets[bulletNum].handler = AddBullet(bullets[bulletNum].x, bullets[bulletNum].y);
    bulletNum++;
    
  }
  
}

