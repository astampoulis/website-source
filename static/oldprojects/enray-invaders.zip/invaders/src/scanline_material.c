/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include <math.h>
#include <stdio.h>

#ifdef WIN32
# include <windows.h>
#endif

#include <GL/gl.h>
#include <GL/glu.h>
#include "gendefs.h"
#include "camera.h"
#include "scanline.h"
#include "vector.h"

#define MAXVERTEX 64000

static float SLOGLM_modelviewNorm[9], SLOGLM_modelview[16];
static unsigned short *SLOGLM_normal, *SLOGLM_zbuf, *SLOGLM_color;
static unsigned char *SLOGLM_normal24bit, *SLOGLM_color24bit;
static GLfloat SLOGLM_vertices[MAXVERTEX*3];
static GLfloat SLOGLM_normals[MAXVERTEX*3];
static GLfloat SLOGLM_depthA, SLOGLM_depthB;
static int SLOGLM_vertexnum;
static int SLOGLM_last, SLOGLM_xres, SLOGLM_yres;

#define SLOGLM_zFar 500.0f
#define SLOGLM_zNear 10.0f

static void slFrameBegin_Material (Camera *c) {

  SLOGLM_last = -1;
  SLOGLM_vertexnum = 0;
  glDepthMask(GL_TRUE);
  glDepthFunc(GL_LESS);
  glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
  glEnable(GL_DEPTH_TEST);
  glDisable(GL_DITHER);
  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
  glLoadIdentity();
  gluPerspective(c->fov, (GLfloat)SLOGLM_xres/(GLfloat)SLOGLM_yres, SLOGLM_zNear, SLOGLM_zFar);
  SLOGLM_depthA = 65535.0f*(2.0f*SLOGLM_zNear*SLOGLM_zFar)/(SLOGLM_zFar-SLOGLM_zNear);
  SLOGLM_depthB = 65535.0f*(SLOGLM_zNear+SLOGLM_zFar)/(SLOGLM_zFar-SLOGLM_zNear);
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
  glLoadIdentity();
  gluLookAt(c->position.x, c->position.y, c->position.z,c->lookAt.x,c->lookAt.y,c->lookAt.z,0,1,0);
  
}

static void slFrameEnd_Material24bit (void) {

  int i;
  
  glReadPixels(0,0,SLOGLM_xres,SLOGLM_yres,GL_RGB,GL_UNSIGNED_BYTE,SLOGLM_color24bit);
  glReadPixels(0,0,SLOGLM_xres,SLOGLM_yres,GL_DEPTH_COMPONENT,GL_UNSIGNED_SHORT,SLOGLM_zbuf);
  glClear(GL_COLOR_BUFFER_BIT);
  glLoadIdentity();
  glDepthMask(GL_FALSE);
  glDepthFunc(GL_EQUAL);
  glBegin(GL_TRIANGLES);
  for (i=0; i<SLOGLM_vertexnum; i++) {
    glColor3fv(&SLOGLM_normals[3*i]);
    glVertex3fv(&SLOGLM_vertices[3*i]);
  }
  glEnd();
  glReadPixels(0,0,SLOGLM_xres,SLOGLM_yres,GL_RGB,GL_UNSIGNED_BYTE,SLOGLM_normal24bit);

  glPopMatrix();
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glDisable(GL_DEPTH_TEST);
  glEnable(GL_DITHER);
  glMatrixMode(GL_MODELVIEW);
  
}

static void slBegin_Material (int id) {

  glGetFloatv(GL_MODELVIEW_MATRIX, SLOGLM_modelview);

  SLOGLM_modelviewNorm[0] = SLOGLM_modelview[0]*0.5;
  SLOGLM_modelviewNorm[1] = SLOGLM_modelview[4]*0.5;
  SLOGLM_modelviewNorm[2] = SLOGLM_modelview[8]*0.5;
  SLOGLM_modelviewNorm[3] = SLOGLM_modelview[1]*0.5;
  SLOGLM_modelviewNorm[4] = SLOGLM_modelview[5]*0.5;
  SLOGLM_modelviewNorm[5] = SLOGLM_modelview[9]*0.5;
  SLOGLM_modelviewNorm[6] = SLOGLM_modelview[2]*0.5;
  SLOGLM_modelviewNorm[7] = SLOGLM_modelview[6]*0.5;
  SLOGLM_modelviewNorm[8] = SLOGLM_modelview[10]*0.5;

  glPushMatrix();
  glLoadIdentity();
  glBegin(GL_TRIANGLES);

}

static void slEnd_Material (void) { glEnd(); glPopMatrix(); }

static void slNormal3f_Material (float x, float y, float z) {

  GLfloat mx, my, mz;
  float *m = SLOGLM_modelviewNorm;

  mx = m[0]*x + m[1]*y + m[2]*z + 0.5;
  my = m[3]*x + m[4]*y + m[5]*z + 0.5;
  mz = m[6]*x + m[7]*y + m[8]*z + 0.5;
  
  SLOGLM_normals[3*SLOGLM_vertexnum] = mx;
  SLOGLM_normals[3*SLOGLM_vertexnum+1] = my;
  SLOGLM_normals[3*SLOGLM_vertexnum+2] = mz;

}

static void slVertex3f_Material (float x, float y, float z) {

  GLfloat mx, my, mz, *m = SLOGLM_modelview;
  
  mx = (m[0]*x + m[4]*y + m[8]*z + m[12]);
  my = (m[1]*x + m[5]*y + m[9]*z + m[13]);
  mz = (m[2]*x + m[6]*y + m[10]*z + m[14]);
  glVertex3f(mx,my,mz);

  SLOGLM_vertices[3*SLOGLM_vertexnum] = mx;
  SLOGLM_vertices[3*SLOGLM_vertexnum+1] = my;
  SLOGLM_vertices[3*SLOGLM_vertexnum+2] = mz;
  
  SLOGLM_vertexnum++;
  
}

static void slUniScalef_Material(float s) { glScalef(s,s,s); }

static float slGetDistance_Material24bit (int id, int x, int y) {

  SLOGLM_last = (SLOGLM_yres-1-y)*SLOGLM_xres + x;
  if (id!=0 || SLOGLM_zbuf[SLOGLM_last]>=65534) return -1;
  else return SLOGLM_depthA / (SLOGLM_depthB - SLOGLM_zbuf[SLOGLM_last]);

}

static void slGetLastNormal_Material24bit (vector *normal) {

  normal->x = ((signed int)(SLOGLM_normal24bit[3*SLOGLM_last])-128)/128.0f;
  normal->y = ((signed int)(SLOGLM_normal24bit[3*SLOGLM_last+1])-128)/128.0f;
  normal->z = ((signed int)(SLOGLM_normal24bit[3*SLOGLM_last+2])-128)/128.0f;

}

static void slGetMaterial_Material24bit (colorf *material) {

  material->r = (float)(SLOGLM_color24bit[3*SLOGLM_last])/255.0f;
  material->g = (float)(SLOGLM_color24bit[3*SLOGLM_last+1])/255.0f;
  material->b = (float)(SLOGLM_color24bit[3*SLOGLM_last+2])/255.0f;
  
}
  

static void slTranslatef_Material (float x, float y, float z) { glTranslatef(x,y,z); }
static void slRotatef_Material (float d, float x, float y, float z) { glRotatef(d,x,y,z); }

static void slInit_Material (int xres, int yres) {

  SLOGLM_xres = xres; SLOGLM_yres = yres;
  SLOGLM_zbuf = NEW(unsigned short,xres*yres);
  
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glEnable(GL_CULL_FACE);
  glCullFace(GL_BACK);
  slFrameBegin = slFrameBegin_Material;
  slBegin = slBegin_Material;
  slEnd = slEnd_Material;
  slTranslatef = slTranslatef_Material;
  slRotatef = slRotatef_Material;
  slUniScalef = slUniScalef_Material;
  slVertex3f = slVertex3f_Material;
  slNormal3f = slNormal3f_Material;
  
}

void slInit_Material24bit (int xres, int yres) {
  SLOGLM_normal24bit = NEW(unsigned char,3*xres*yres);
  SLOGLM_color24bit = NEW(unsigned char,3*xres*yres);
  slFrameEnd = slFrameEnd_Material24bit;
  slGetDistance = slGetDistance_Material24bit;
  slGetLastNormal = slGetLastNormal_Material24bit;
  slGetMaterial = slGetMaterial_Material24bit;
  slInit_Material(xres,yres);
}

void slDestroy_Material24bit (void) { free(SLOGLM_normal24bit); free(SLOGLM_zbuf); free(SLOGLM_color24bit); }

#ifdef GL_VERSION_1_2

static void slFrameEnd_Material16bit (void) {

  int i;

  glReadPixels(0,0,SLOGLM_xres,SLOGLM_yres,GL_RGB,GL_UNSIGNED_SHORT_5_6_5,SLOGLM_color);
  glReadPixels(0,0,SLOGLM_xres,SLOGLM_yres,GL_DEPTH_COMPONENT,GL_UNSIGNED_SHORT,SLOGLM_zbuf);
  glClear(GL_COLOR_BUFFER_BIT);
  glLoadIdentity();
  glDepthMask(GL_FALSE);
  glDepthFunc(GL_EQUAL);
  glBegin(GL_TRIANGLES);
  for (i=0; i<SLOGLM_vertexnum; i++) {
    glColor3fv(&SLOGLM_normals[3*i]);
    glVertex3fv(&SLOGLM_vertices[3*i]);
  }
  glEnd();
  glReadPixels(0,0,SLOGLM_xres,SLOGLM_yres,GL_RGB,GL_UNSIGNED_SHORT_5_6_5,SLOGLM_normal);

  glPopMatrix();
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glDisable(GL_DEPTH_TEST);
  glEnable(GL_DITHER);
  glMatrixMode(GL_MODELVIEW);
  
}


static float slGetDistance_Material16bit (int id, int x, int y) {

  SLOGLM_last = (SLOGLM_yres-1-y)*SLOGLM_xres + x;
  if (id!=0 || SLOGLM_zbuf[SLOGLM_last]>=65534) return -1;
  else return SLOGLM_depthA / (SLOGLM_depthB - SLOGLM_zbuf[SLOGLM_last]);

}

static void slGetLastNormal_Material16bitREV (vector *normal) {

  normal->z = (((signed char)(SLOGLM_normal[SLOGLM_last]>>11)&31)-16)*0.0625f;
  normal->y = (((signed char)(SLOGLM_normal[SLOGLM_last]>>5)&63)-32)*0.03125f;
  normal->x = ((signed char)(SLOGLM_normal[SLOGLM_last]&31)-16)*0.0625f;

}

static void slGetLastNormal_Material16bit (vector *normal) {

  normal->x = (((signed char)(SLOGLM_normal[SLOGLM_last]>>11)&31)-16)*0.0625f;
  normal->y = (((signed char)(SLOGLM_normal[SLOGLM_last]>>5)&63)-32)*0.03125f;
  normal->z = ((signed char)(SLOGLM_normal[SLOGLM_last]&31)-16)*0.0625f;

}

static void slGetMaterial_Material16bitREV (colorf *material) {


  material->b = (((signed char)(SLOGLM_color[SLOGLM_last]>>11)&31))*0.03125f;
  material->g = (((signed char)(SLOGLM_color[SLOGLM_last]>>5)&63))*0.015625f;
  material->r = ((signed char)(SLOGLM_color[SLOGLM_last]&31))*0.03125f;
  
}

static void slGetMaterial_Material16bit (colorf *material) {


  material->r = (((signed char)(SLOGLM_color[SLOGLM_last]>>11)&31))*0.03125f;
  material->g = (((signed char)(SLOGLM_color[SLOGLM_last]>>5)&63))*0.015625f;
  material->b = ((signed char)(SLOGLM_color[SLOGLM_last]&31))*0.03125f;
  
}

void slInit_Material16bit (int xres, int yres) {
  SLOGLM_normal = NEW(unsigned short,xres*yres);
  SLOGLM_color = NEW(unsigned short,xres*yres);
  slFrameEnd = slFrameEnd_Material16bit;
  slGetDistance = slGetDistance_Material16bit;
  slGetLastNormal = slGetLastNormal_Material16bit;
  slGetMaterial = slGetMaterial_Material16bit;
  slInit_Material(xres,yres);
}

void slInit_Material16bitREV (int xres, int yres) {
  SLOGLM_normal = NEW(unsigned short,xres*yres);
  SLOGLM_color = NEW(unsigned short,xres*yres);
  slFrameEnd = slFrameEnd_Material16bit;
  slGetDistance = slGetDistance_Material16bit;
  slGetLastNormal = slGetLastNormal_Material16bitREV;
  slGetMaterial = slGetMaterial_Material16bitREV;
  slInit_Material(xres,yres);
}

void slDestroy_Material16bit (void) { free(SLOGLM_normal); free(SLOGLM_zbuf); free(SLOGLM_color); }
void slDestroy_Material16bitREV (void) { free(SLOGLM_normal); free(SLOGLM_zbuf); free(SLOGLM_color); }

#endif
