/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include <math.h>
#include "vector.h"

inline void vectorSetOpt (vector *v, float x, float y, float z) {
  v->x = x;
  v->y = y;
  v->z = z;
  v->rsq = x*x + y*y + z*z;
}

inline void vectorSet (vector *v, float x, float y, float z) {
  v->x = x;
  v->y = y;
  v->z = z;
}

inline void vectorSubOpt (vector *a, vector *b, vector *r) {
  r->x = a->x - b->x;
  r->y = a->y - b->y;
  r->z = a->z - b->z;
  r->rsq = r->x*r->x + r->y*r->y + r->z*r->z;
}

inline void vectorSub (vector *a, vector *b, vector *r) {
  r->x = a->x - b->x;
  r->y = a->y - b->y;
  r->z = a->z - b->z;
}

inline void vectorAddOpt (vector *a, vector *b, vector *r) {
  r->x = a->x + b->x;
  r->y = a->y + b->y;
  r->z = a->z + b->z;
  r->rsq = r->x*r->x + r->y*r->y + r->z*r->z;
}

inline void vectorAdd (vector *a, vector *b, vector *r) {
  r->x = a->x + b->x;
  r->y = a->y + b->y;
  r->z = a->z + b->z;
}

inline void vectorOpposite (vector *r) {
  r->x = -r->x;
  r->y = -r->y;
  r->z = -r->z;
}

inline void vectorNormalize (vector *a) {
  float f = 1/sqrtf(a->x*a->x + a->y*a->y + a->z*a->z);
  a->x *= f; a->y *= f; a->z *= f;
}

inline float vectorNormalizeRetMag (vector *a) {
  float f = sqrt(a->x*a->x + a->y*a->y + a->z*a->z), onebyf = 1/f;
  a->x *= onebyf; a->y *= onebyf; a->z *= onebyf;
  return f;
}

inline void vectorNormalizeOpt (vector *a) {
  float f = 1/sqrt(a->rsq);
  a->x *= f; a->y *= f; a->z *= f;
}

inline float vectorNorm (vector *a) {
  return sqrt(a->x*a->x + a->y*a->y + a->z*a->z);
}

inline float vectorNormOpt (vector *a) { return sqrt(a->rsq); }

inline float vectorDot (vector *a, vector *b) {
  return a->x * b->x + a->y * b->y + a->z * b->z;
}

inline void vectorCross (vector *a, vector *b, vector *r) {
  
  r->x = a->y * b->z - b->y * a->z;
  r->y = a->x * b->z - a->z * b->x;
  r->z = a->x * b->y - a->y * b->x;
  
}

inline void vectorCrossOpt (vector *a, vector *b, vector *r) {
  
  r->x = a->y * b->z - b->y * a->z;
  r->y = a->x * b->z - a->z * b->x;
  r->z = a->x * b->y - a->y * b->x;
  r->rsq = r->x*r->x + r->y*r->y + r->z*r->z;
  
}

inline void vectorMult (vector *a, float b, vector *c) {

  c->x = b * a->x;
  c->y = b * a->y;
  c->z = b * a->z;
  
}

inline void vectorMultOpt (vector *a, float b, vector *c) {

  c->x = b * a->x;
  c->y = b * a->y;
  c->z = b * a->z;
  c->rsq *= b*b;
  
}


inline void vectorMultMatrix (vector *a, float m[9], vector *c) {

  c->x = m[0] * a->x + m[3] * a->y + m[6] * a->z;
  c->y = m[1] * a->x + m[4] * a->y + m[7] * a->z;
  c->z = m[2] * a->x + m[5] * a->y + m[8] * a->z;
  
}
