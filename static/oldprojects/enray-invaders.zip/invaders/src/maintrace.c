/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include <math.h>
#include "maintrace.h"
#include "vector.h"
#include "scene.h"
#include "camera.h"
#include "graphics.h"

#define MAXDEPTH 2

//#define INTERPOLATE_HIGHQUALITY

Scene *myscene;
int myblksize, myblkminsize;
ray myRay;
Camera *mycamera;
colorf  blkColors[256*256];
int     blkIds[256*256];
bool    blkTraced[256*256];


void ReflectedRay (vector *normal, vector *rayDir, vector *reflected) {

  float dotProduct = 2 * vectorDot(normal, rayDir);
  vectorSet(reflected,rayDir->x - normal->x * dotProduct,
                      rayDir->y - normal->y * dotProduct,
                      rayDir->z - normal->z * dotProduct);
  vectorNormalize(reflected);

}

colorf RaytraceSingle (ray *cray, Scene *scene, int depth, int skip) {

  float closestDistance = 1e+38;
  int closestObject = -1, i;
  int lightID = 0, specularID = 0;
  colorf c;
  float tr;
  
  if (depth == MAXDEPTH) { c.r = c.g = c.b = 0; return c; }

  cray->id = 0;
  
  for (i=0; i<scene->objectsNum; i++) {
    if (skip==i) continue;
    tr = (*scene->objects[i].primitive.type->IntersectRay)(cray, scene->objects[i].primitive.properties, depth==0);
    if (tr>0 && tr<closestDistance-EPSILON) {
        closestDistance = tr;
        closestObject = i;
    }
  }
  
  if (closestObject == -1) {
    if (depth) c.r=c.g=c.b=0;
    else c=scene->backgroundColor;
  }else { 
  
    vector intersection, normal, intersectionToLight, reflected;
    int i = closestObject, j;
    float diffuseCoeff, reflectivity;
    ray reflectRay;
    register Object *sceneobjects = scene->objects;
    Object curObject = scene->objects[i];
    
    cray->id = closestObject + 1;
    c.r = c.g = c.b = 0;
    intersection.x = closestDistance * cray->dir.x + cray->origin.x;
    intersection.y = closestDistance * cray->dir.y + cray->origin.y;
    intersection.z = closestDistance * cray->dir.z + cray->origin.z;
    
    (*curObject.primitive.type->SurfaceNormal)(curObject.primitive.properties, &intersection, &normal);
    
    reflectivity = curObject.material->reflectivity;

    if (reflectivity || curObject.material->specular)
      ReflectedRay(&normal, &cray->dir, &reflected);

    if (reflectivity<1.0) {
      for (j=0; j<scene->lightsNum; j++) {
        
        ray shadowRay;
        float st, iToLdist;
        int l, lo;
        bool hit = false;
        float opacity=1;
        int x1,y1,z1;

        vectorSub(&scene->lights[j].position, &intersection, &intersectionToLight);
        iToLdist = vectorNormalizeRetMag(&intersectionToLight);

        if (curObject.receiveShadow == HARDSHADOW) {
          
          shadowRay.origin = intersection;
          shadowRay.dir = intersectionToLight;
          l = curObject.lastOcc;
          if (l!=-1) {
            st = (*sceneobjects[l].primitive.type->IntersectRay)(&shadowRay, sceneobjects[l].primitive.properties, false);
            if (st>0 && st<iToLdist-EPSILON) hit=true;
          }
          if (!hit) {
            for (l=0; l<scene->objectsNum; l++) {
              if (l==closestObject || l==curObject.lastOcc || !sceneobjects[l].castShadow) continue;
              st = (*sceneobjects[l].primitive.type->IntersectRay)(&shadowRay, sceneobjects[l].primitive.properties, false);
              if (st>0 && st<iToLdist-EPSILON) { hit=true; curObject.lastOcc=l; break; }
            }
          }
          if (hit) continue;
          
        } else if (curObject.receiveShadow == SOFTSHADOW) {
 
          shadowRay.origin = intersection;
          shadowRay.dir = intersectionToLight;
          lo = curObject.lastOcc;
          for (x1=-1;x1<=1;x1++) for (y1=-1;y1<=1;y1++) for (z1=-1;z1<=1;z1++) {
            shadowRay.dir = intersectionToLight;
            shadowRay.dir.x += x1/50.0f;
            shadowRay.dir.y += y1/50.0f;
            shadowRay.dir.z += z1/50.0f;
            vectorNormalize(&shadowRay.dir);
            hit = false;
            if (lo!=-1) {
              st = (*sceneobjects[lo].primitive.type->IntersectRay)(&shadowRay, sceneobjects[lo].primitive.properties, false);
              if (st>0 && st<iToLdist-EPSILON) { opacity-=1/27.0f; hit=true; }
            }
            if (!hit) {
              for (l=0;l<scene->objectsNum; l++) {
                if (l==closestObject || l==lo || !sceneobjects[l].castShadow) continue;
                st = (*sceneobjects[l].primitive.type->IntersectRay)(&shadowRay, sceneobjects[l].primitive.properties, false);
                if (st>0 && st<iToLdist-EPSILON) { opacity-=1/27.0f; lo=l; break; }
              }
            }
          }

          curObject.lastOcc = lo;
          if (opacity<1/27.0f) continue;

        }
        
        diffuseCoeff = opacity==1?vectorDot(&intersectionToLight, &normal):
                       opacity*vectorDot(&intersectionToLight, &normal);

        if (diffuseCoeff>0) {

          float specular;
          
          if (reflectivity) diffuseCoeff *= 1-reflectivity;

          if (curObject.material->specular) {
            specular = vectorDot(&intersectionToLight, &reflected);
            if (specular<0 || depth!=0) specular = 0;
            else specular = opacity * pow(specular, 32) * curObject.material->specular;
#ifdef INTERPOLATE_HIGHQUALITY
            specularID += specular*8.0f;
            if (specularID>1.0f) specularID=1.0f;
#endif
          } else {
            specular = 0;
          }
          
/*
          c.r += curObject.material->color.r * diffuseCoeff * scene->lights[j].diffuse.r +specular;
          c.g += curObject.material->color.g * diffuseCoeff * scene->lights[j].diffuse.g +specular;
          c.b += curObject.material->color.b * diffuseCoeff * scene->lights[j].diffuse.b +specular;
*/
          c.r += (specular+curObject.material->color.r * diffuseCoeff) * scene->lights[j].diffuse.r;
          c.g += (specular+curObject.material->color.g * diffuseCoeff) * scene->lights[j].diffuse.g;
          c.b += (specular+curObject.material->color.b * diffuseCoeff) * scene->lights[j].diffuse.b;

#ifdef INTERPOLATE_HIGHQUALITY
          lightID += (diffuseCoeff>0.33?(diffuseCoeff>0.66?3:2):1)<<(j<<1);
#else
          lightID += 1<<j;
#endif

        }
        
      }

    }


    if (reflectivity) {

      colorf reflection;
      
      reflectRay.dir = reflected;
      reflectRay.origin = intersection;
      reflection = RaytraceSingle(&reflectRay, scene, depth+1, closestObject);
      
      cray->id += reflectRay.id + ((depth + 1) << 16);
            
      c.r += reflection.r * reflectivity;
      c.g += reflection.g * reflectivity;
      c.b += reflection.b * reflectivity;
      
    }
    
    cray->id += (lightID << 23) + (specularID << 20);
    
    if (c.r>1.0f) c.r = 1.0f;
    if (c.g>1.0f) c.g = 1.0f;
    if (c.b>1.0f) c.b = 1.0f;

  }

  return c;
    
}



void RaytraceInterpolate (int sx, int sy, int step, int x, int y) {

  int cp1 = sx+(sy*myblksize), cp2 =cp1+step-1, cp3 =cp1+((step-1)*myblksize), cp4=cp3+step-1;

  if (!blkTraced[cp1]) { RayDirection(mycamera,x+sx,y+sy,&myRay);
                         blkColors[cp1] = RaytraceSingle(&myRay, myscene,0,-1);
                         blkIds[cp1] = myRay.id; blkTraced[cp1] = true; } 
  if (!blkTraced[cp2]) { RayDirection(mycamera,x+sx+step-1,y+sy,&myRay);
                         blkColors[cp2] = RaytraceSingle(&myRay, myscene,0,-1);
                         blkIds[cp2] = myRay.id; blkTraced[cp2] = true; } 
  if (!blkTraced[cp3]) { RayDirection(mycamera,x+sx,y+sy+step-1,&myRay);
                         blkColors[cp3] = RaytraceSingle(&myRay, myscene,0,-1);
                         blkIds[cp3] = myRay.id; blkTraced[cp3] = true; } 
  if (!blkTraced[cp4]) { RayDirection(mycamera,x+sx+step-1,y+sy+step-1,&myRay);
                         blkColors[cp4] = RaytraceSingle(&myRay, myscene,0,-1);
                         blkIds[cp4] = myRay.id; blkTraced[cp4] = true; }
  if (step>myblkminsize &&
      !(blkIds[cp1]==blkIds[cp2] && blkIds[cp2]==blkIds[cp3] && blkIds[cp3]==blkIds[cp4]) ) {
    int st=floor(step/2.0f);
    RaytraceInterpolate(sx, sy, st, x, y);
    RaytraceInterpolate(sx+st, sy, step-st, x, y);
    RaytraceInterpolate(sx, sy+st, step-st, x, y);
    RaytraceInterpolate(sx+st, sy+st, step-st, x, y);
  } else
    GraphicsDrawblock(x,y,sx,sy,step,&blkColors[cp1],&blkColors[cp2],&blkColors[cp3],&blkColors[cp4]);

}  
  
void RaytraceMain (Camera *c, Scene *scene, int blkminsize, int blksize) {

  int y, x, i; 

  myRay.origin = c->position;
  
  for (i=0; i<scene->objectsNum; i++)
    if (scene->objects[i].primitive.type->PerFrameOpt) 
      scene->objects[i].primitive.type->PerFrameOpt(c,scene->objects[i].primitive.properties);

  myscene = scene; mycamera = c;
  myblksize = blksize; myblkminsize = blkminsize;

  for (y=c->sy; y+myblksize<=c->ey; y+=myblksize) {
    for (x=c->sx; x+myblksize<=c->ex; x+=myblksize) {
      for(i=blksize*blksize-1;i>=0;i--) blkTraced[i]=false;
      RaytraceInterpolate(0,0,myblksize,x,y);
    }
  }

}


