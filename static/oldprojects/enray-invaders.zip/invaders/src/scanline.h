/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#ifndef _scanline_h_
#define _scanline_h_

#include "camera.h"
#include "gendefs.h"

extern bool slInit (char *driver, int xres, int yres);
extern void slGetMeshId (Scene *s, int object);

extern void (*slFrameBegin)(Camera *c);
extern void (*slFrameEnd)(void);

extern void (*slBegin)(int objectID);
extern void (*slEnd)(void);
extern void (*slTranslatef)(float x, float y, float z);
extern void (*slRotatef)(float deg, float x, float y, float z);
extern void (*slVertex3f)(float x, float y, float z);
extern void (*slNormal3f)(float x, float y, float z);
extern void (*slUniScalef)(float s);

extern float (*slGetDistance)(int objectID,int x,int y);
extern void (*slGetLastNormal)(vector *normal);
extern void (*slGetMaterial)(colorf *color);

#endif

