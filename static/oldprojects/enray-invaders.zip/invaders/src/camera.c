/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include "math.h"
#include "gendefs.h"
#include "scene.h"
#include "camera.h"

Camera *NewCamera (float fov, float x, float y, float z, int sx, int sy, int ex, int ey) {

  Camera *c = NEW(Camera, 1);
  float xres = (ex-sx), yres = (ey-sx);
  
  c->fov = fov;
  c->sx = sx; c->sy = sy; c->ex = ex; c->ey = ey;
  c->width = tan(M_PI * fov / 180.0f); c->height = c->width * (yres/xres);
  c->rightStepFactor = (c->width+c->width)/xres; c->downStepFactor = (c->height+c->height)/yres;
  CameraLookAt(c,x,y,z,0,0,0);
  
  return c;
  
}

void CameraLookAt (Camera *c, float x, float y, float z, float tx, float ty, float tz) {

  vector dir, right, down, up = { 0, 1, 0};

  vectorSet(&c->position, x, y, z);
  vectorSet(&c->lookAt, tx, ty, tz);
  
  vectorSetOpt(&dir, tx-x, ty-y, tz-z);
  vectorNormalizeOpt(&dir);
  vectorCross(&dir, &up, &right);
  vectorCross(&dir, &right, &down);
  vectorNormalize(&right); vectorNormalize(&down);
  
  vectorMult(&right, c->rightStepFactor, &c->rightStep);
  vectorMult(&down, c->downStepFactor, &c->downStep);

  c->topLeft.x = dir.x - c->width * right.x - c->height * down.x;
  c->topLeft.y = dir.y - c->height * down.y - c->width * right.y;
  c->topLeft.z = dir.z - c->height * down.z - c->width * right.z;
  

}

void RayDirection (Camera *c, float x, float y, ray *cray) {

  cray->dir.x = c->topLeft.x + x * c->rightStep.x + y * c->downStep.x;
  cray->dir.y = c->topLeft.y + y * c->downStep.y  + x * c->rightStep.y;
  cray->dir.z = c->topLeft.z + x * c->rightStep.z + y * c->downStep.z;
  vectorNormalize(&cray->dir);
 
  cray->x = (int)x; cray->y = (int)y;
  
}

