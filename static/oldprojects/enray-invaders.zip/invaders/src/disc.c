/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include "vector.h"
#include "scene.h"
#include "camera.h"

typedef struct {

  vector normal, point;
  float displacement, opt, vd, dr, in;
  
} Disc;

float Disc_IntersectRay(ray *cray, void *vp, bool primary) {

  PMTCAST(p, Disc, vp);
  float d;
  float opt;

  if (primary) opt = p->opt;
  else opt = cray->origin.x * p->normal.x + cray->origin.y * p->normal.y +
             cray->origin.z * p->normal.z + p->displacement;

  p->vd = p->normal.x*cray->dir.x + p->normal.y*cray->dir.y +
          p->normal.z*cray->dir.z;
  
  if (p->vd<0.008f && p->vd>-0.008f) return -1.0f;
  
  d = - opt / p->vd;
  if (d>EPSILON) {
    vector i;
    vectorSetOpt(&i,
                 cray->origin.x + cray->dir.x * d - p->point.x,
                 cray->origin.y + cray->dir.y * d - p->point.y,
                 cray->origin.z + cray->dir.z * d - p->point.z);
    if (vectorNormOpt(&i)>p->dr) return -1;        
    return d;
  }
  else return -1.0f;

}

void Disc_SurfaceNormal(void *vp, vector *intersection, vector *normal) {
  PMTCAST(p, Disc, vp);
/*
    vector i;
    vectorSetOpt(&i,
                 intersection->x - p->point.x,
                 intersection->y - p->point.y,
                 intersection->z - p->point.z);
    p->in = sin(vectorNormOpt(&i)/10.0f+SDL_GetTicks()/1550.0f)*0.7f;
    vectorSetOpt(&i,
                 intersection->x - p->point.x-40,
                 intersection->y - p->point.y+80,
                 intersection->z - p->point.z);
    p->in += sin(vectorNormOpt(&i)/25.0f+SDL_GetTicks()/1800.0f+124.0f)*0.8f;
*/
  if (p->vd<0) {
    normal->x = p->normal.x;
    normal->y = p->normal.y;
    normal->z = p->normal.z;
  } else {
    normal->x = -p->normal.x;
    normal->y = -p->normal.y;
    normal->z = -p->normal.z;
  }

}

void Disc_PerFrameOpt(Camera *c, void *vp) {
  PMTCAST(p, Disc, vp);
  
  p->opt = c->position.x * p->normal.x +
           c->position.y * p->normal.y +
           c->position.z * p->normal.z +
           p->displacement;
           
}

PrimitiveDecl DiscPrimitive = { Disc_IntersectRay,
                                 Disc_SurfaceNormal,
                                 Disc_PerFrameOpt };
                                 
Primitive NewDisc (float x, float y, float z,
                    float a, float b, float c, float dr) {

  Primitive pP;
  Disc *p = NEW(Disc,1);
  
  vectorSet(&p->normal,x,y,z);
  vectorSet(&p->point,a,b,c);
  vectorNormalize(&p->normal);
  p->displacement = -(x*a+y*b+z*c);
  p->dr = dr;
  pP.properties = (void *) p;
  pP.type = &DiscPrimitive;
  
  return pP;
  
}

void ChangeDisc (void *Vp, float x, float y, float z, float a, float b, float c, float dr) {

  PMTCAST(p, Disc, Vp);
  
  vectorSet(&p->normal,x,y,z);
  vectorSet(&p->point,a,b,c);
  vectorNormalize(&p->normal);
  p->displacement = -(x*a+y*b+z*c);
  p->dr = dr;

}
