/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#ifndef _gendefs_h_
#define _gendefs_h_

#include <stdlib.h>

#ifdef WIN32
# define M_PI		3.14159265358979323846
# define sqrtf sqrt
# define expf  exp
# define logf  log
#endif

typedef struct {
  unsigned int r, g, b;
} color;

typedef struct {
  float r, g, b;
} colorf;

typedef unsigned char bool;
#define true 1
#define false 0
#define EPSILON 0.05f

#define NEW(x,y) (x *) malloc ( (y) * sizeof(x) )
#define PMTCAST(typevar, type, voidvar) type *typevar = (type *) voidvar
#define FRND() (2*((rand()/(float)(RAND_MAX))-0.5f))

#endif


