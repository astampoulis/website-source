/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include <stdio.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include "graphics.h"
#include "maintrace.h"
#include "scene.h"
#include "primitives.h"
#include "camera.h"
#include "scanline.h"
#include "meshload.h"
#include "parse.h"

float f=0.0f;
int zdist = 300, ycam = 0, xcam = 0, bs = 8, bms = 8;

MeshObject *m;
float spinx = 0, spiny = 0, spinz = 0, velx = 0, vely = 0, velz = 0;
char objfname[256];
Expression *e;

float parser_func (float x, float y, float z) { return parserEvaluate(e,x,y,z); }
float normal_func (float x, float y, float z) {
  float l=y+((sin(x/3+y/2+f)+1.0));
  return x*x + z*z - 30*l;
}

bool HandleKeys (void) {
  
  if (Keys[SDLK_UP] && zdist>10) zdist -= 10;
  if (Keys[SDLK_DOWN]) zdist += 10;
  if (Keys[SDLK_PAGEUP] && ycam <= 100) ycam += 10;
  if (Keys[SDLK_PAGEDOWN] && ycam >= -100) ycam -= 10;
  if (Keys[SDLK_KP0] && xcam >= -100) xcam -= 10;
  if (Keys[SDLK_KP_PERIOD] && xcam <= 100) xcam += 10;

  if (Keys[SDLK_q]) velx -= 0.2;
  if (Keys[SDLK_a]) velx += 0.2;
  if (Keys[SDLK_w]) vely -= 0.2;
  if (Keys[SDLK_s]) vely += 0.2;
  if (Keys[SDLK_e]) velz -= 0.2;
  if (Keys[SDLK_d]) velz += 0.2;
  if (Keys[SDLK_SPACE]) { velx = vely = velz = 0; }
  if (Keys[SDLK_HOME]) { velx = vely = velz = spinx = spiny = spinz = 0; }

  if (Keys[SDLK_0] && bms>2) bms >>= 1;
  if (Keys[SDLK_9] && bms<bs) bms <<= 1;

  if (Keys[SDLK_EQUALS] && bs>2) bs >>= 1;
  if (Keys[SDLK_MINUS] && bs<512) bs <<= 1;
  
  if (Keys[SDLK_F1]) MeshReverseTriangles(m);
  if (Keys[SDLK_F2]) MeshScale(m,2.0f);
  if (Keys[SDLK_F3]) MeshScale(m,0.5f);
  if (Keys[SDLK_F4]) SaveObject(objfname,m);

  if (Keys[SDLK_ESCAPE]) return false;
  return true;

}

int main (int argc, char **argv) {

  FILE *cfg = fopen("enray.cfg", "r");

  graphics *g;  
  Camera *c;
  Scene *s;
  
  int light;

  time_t starttime;
  long frames=0;
  
  char driver[64];
  
  if (cfg) {
  
    char fn[256];
    int i;
  
    fgets(objfname,252,cfg);
      i=strlen(objfname)-1; while(i>=0 && objfname[i] && isspace(objfname[i])) objfname[i--]='\0';
    fgets(fn,256,cfg);
      i=strlen(fn)-1; while(i>=0 && fn[i] && isspace(fn[i])) fn[i--]='\0';
    if (fn[0]!='\0') e = parserNewExpression(fn);
    else e=NULL;
    fgets(driver,64,cfg);
      i=strlen(driver)-1; while(i>=0 && driver[i] && isspace(driver[i])) driver[i--]='\0';
    fclose(cfg);
    
  } else {
  
    strcpy(objfname,"models/pharaoh.vnb");
    driver[0] = '\0';
    e = NULL;
    
  }
  
  
  if (!(m=LoadObject(objfname))) {
    printf("Could not load object.\n");
    return -1;
  }
  
  strcat(objfname,".vnb");
  
  g = argc>=3?
      GraphicsInit(atoi(argv[1]),atoi(argv[2]),32):
      GraphicsInit(320, 240, 32);
  if (!g) { printf("No graphics.\n"); return -1; }
  
  if (!slInit(driver,g->xres,g->yres)) { printf("No scanline renderer.\n"); return -1; }
  
  c = NewCamera(30,0,0,200,0,0,g->xres,g->yres);
  s = NewScene(0,0,0);
  
  AddObject(s, NewMesh(), NewMaterial(0.9,0.34,0.95,0.5,1.0), false, NOSHADOW);
  AddObject(s, NewImplicit(30,0,0,50,e?parser_func:normal_func,5,3), NewMaterial(0.2,0.6,0.86,0.0,0.5), false, NOSHADOW);
  AddObject(s, NewPlane(0,1,0,0,-300,-100), NewMaterial(0.9, 0.7, 0.25, 0.0, 0.0), false, NOSHADOW);
  
  light = AddLight(s, 0, 0, 200, 1.0, 1.0, 1.0);
    
  starttime = time(NULL);
  while (GraphicsExist() && HandleKeys()) {
    CameraLookAt(c, xcam, ycam, zdist, 0, 0, 0);
    ChangeLight(s, light, ((MouseX-g->xres/2)/(float)g->xres/2)*300.0f, ((-MouseY+g->yres/2)/(float)g->yres/2)*300.0f, 200, 1.0, 1.0, 1.0);
    slFrameBegin(c);
      slTranslatef(-25,0,0);
      slRotatef(spinx,1,0,0);
      slRotatef(spiny,0,1,0);
      slRotatef(spinz,0,0,1);
      DrawObject(m);
    slFrameEnd();
    RaytraceMain(c, s, bms, bs);
    GraphicsUpdate();
    f+=0.1f; frames++; spinx += velx; spiny += vely; spinz += velz;
  };
  
  GraphicsDestroy(g);
  
  printf("average fps: %f\n", (float)(frames)/(float)(time(NULL)-starttime));
  
  return 0;

}

