/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include <stdlib.h>
#include <string.h>

#ifdef WIN32
# include <windows.h>
#endif

#include <SDL/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include "gendefs.h"

#define FRND (rand()/(float)RAND_MAX)

typedef struct { int xres, yres; } graphics;

SDL_Surface *surface;
SDL_Event event;
bool Keys[SDLK_LAST];
int MouseX, MouseY;

graphics *GraphicsInit (size_t width, size_t height, size_t bpp) {

  graphics *g = NEW(graphics, 1);

  SDL_Init (SDL_INIT_VIDEO);

  SDL_GL_SetAttribute(SDL_GL_RED_SIZE,5);
  SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE,5);
  SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE,5);
  SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE,16);
  SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER,1);
  
  if (!(surface = SDL_SetVideoMode (width, height, bpp, SDL_HWSURFACE | SDL_OPENGL)))
    return NULL;

  g->xres = width;
  g->yres = height;
  memset(Keys, SDLK_LAST, 0);
  
  glShadeModel(GL_SMOOTH);
    
  glViewport(0,0,width,height);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluOrtho2D(0.0,width,height,0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glShadeModel(GL_SMOOTH);

  return g;
}

void GraphicsDestroy (graphics *g) {
  
  free(g);
  SDL_Quit();
  
}

void GraphicsUpdate (void) {
   
  SDL_GL_SwapBuffers();
  
}

void GraphicsDrawblock (int x, int y, int sx, int sy, int step, colorf *a, colorf *b, colorf *c, colorf *d) {
  glBegin(GL_QUADS);
    glColor3fv((GLfloat *)a); glVertex2i(x+sx,y+sy);
    glColor3fv((GLfloat *)c); glVertex2i(x+sx,y+sy+step);
    glColor3fv((GLfloat *)d); glVertex2i(x+sx+step,y+sy+step);
    glColor3fv((GLfloat *)b); glVertex2i(x+sx+step,y+sy);
  glEnd();
}

bool GraphicsExist (void) {

  int KeystackDown[256], KeystackDownLen = 0;
  static int KeystackUp[256], KeystackUpLen = 0;
  int i;
  
  for (i=0;i<KeystackUpLen;i++) Keys[KeystackUp[i]] = false;
  KeystackUpLen = 0;
  
  while (SDL_PollEvent(&event)) {
  
    switch (event.type) {
      case SDL_QUIT:
        return false;
      case SDL_KEYDOWN:
        KeystackDown[KeystackDownLen++] = event.key.keysym.sym;
        break;
      case SDL_KEYUP:
        Keys[event.key.keysym.sym] = false;
        KeystackUp[KeystackUpLen++] = event.key.keysym.sym;
        break;
    }
  }

  for (i=0;i<KeystackDownLen;i++) Keys[KeystackDown[i]] = true;
  
  SDL_GetMouseState(&MouseX, &MouseY);
  
  return true;
  
}


