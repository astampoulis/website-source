/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "vector.h"
#include "scanline.h"
#include "gendefs.h"
#include "meshload.h"

#define MAX_OBJ_VERTICES 64000

void MeshReverseTriangles (MeshObject *obj) {

  int i;

#define RT_SWAP(a,b,c) \
{\
  float t1=a[3*(b)], t2=a[3*(b)+1], t3=a[3*(b)+2];\
  a[3*(b)] = a[3*(c)]; a[3*(b)+1]=a[3*(c)+1]; a[3*(b)+2]=a[3*(c)+2];\
  a[3*(c)] = t1; a[3*(c)+1]=t2; a[3*(c)+2]=t3;\
}
  
  for (i=0;i<obj->vnum/3;i++) {
    RT_SWAP(obj->vertices,3*i+1,3*i+2);
    RT_SWAP(obj->normals,3*i+1,3*i+2);
  }

#undef RT_SWAP

}

void MeshScale (MeshObject *obj, float s) {
  int i;
  for (i=0;i<3*obj->vnum;i++) obj->vertices[i]*=s;
}
    

static int LoadRayshade (char *file, MeshObject *obj) {

  FILE *f = fopen(file,"r");
  char buffer[2048], *a;
  int inList = 0, inTriangle=0;
  
  obj->vertices = NEW(float, MAX_OBJ_VERTICES*3);
  obj->normals = NEW(float, MAX_OBJ_VERTICES*3);
  obj->vnum = 0;
  
  if (!f || !obj->vertices || !obj->normals) return -1;
  
  while (!feof(f)) {
  
    fgets(buffer,2048,f);
    a=buffer;
    while (*a&&isspace(*a)) a++;
    while (*a) {
      if (isspace(*a)) { a++; continue; }
      else if (*a=='/'&& *(a+1)=='*') {
        a = a+2;
        while (*a && (*a!='*' && *(a+1)!='/')) a++;
        if (*a=='*') a+=2;
      } else if (inTriangle) {
        int nums=0;
        if (sscanf(a, "%f %f %f %f %f %f",&obj->vertices[3*obj->vnum],&obj->vertices[3*obj->vnum+1],&obj->vertices[3*obj->vnum+2],
            &obj->normals[3*obj->vnum],&obj->normals[3*obj->vnum+1],&obj->normals[3*obj->vnum+2])!=6)
          return -1;
        obj->vnum++;
        while (nums<6) {
          while (*a&&isspace(*a)) a++;
          nums++;
          while (*a&&!isspace(*a)) a++;
        }
        inTriangle++;
        if (inTriangle==4) inTriangle=0;
      } else {
        if (!strncasecmp(a,"list",4)) { a+=4; if (inList||inTriangle) return -1; else inList=1; }
        else if (!strncasecmp(a,"end",3)) { a+=3; if (!inList||inTriangle) return -1; else inList=0; }
        else if (!strncasecmp(a,"triangle",8)) { a+=8; if (!inList||inTriangle) return -1; else inTriangle=1; }
        else return -1;
      }
    }
    
  }
  
  fclose(f);
  
  return 0;
  
}

static int LoadSmoothRaw (char *file, MeshObject *obj) {

  FILE *f = fopen(file,"r");
  int i, j=0;
  
  obj->vertices = NEW(float, MAX_OBJ_VERTICES*3);
  obj->normals = NEW(float, MAX_OBJ_VERTICES*3);
  obj->vnum = 0;
  
  if (!f || !obj->vertices || !obj->normals) return -1;
  
  fscanf(f,"%*s");
  
  while (!feof(f)) {
  
    if (fscanf(f, "%f", &obj->vertices[j])!=1) return 0;
    for (i=1;i<9;i++) if (fscanf(f, "%f",&obj->vertices[j+i])!=1) return -1;
    for (i=0;i<9;i++) if (fscanf(f, "%f",&obj->normals[j+i])!=1) return -1;
    j+=9; obj->vnum+=3;
    
  }
  
  fclose(f);
  
  return 0;
  
}


static int LoadCompiled (char *file, MeshObject *obj) {

  FILE *f = fopen(file,"rb");
  
  if (!f) return 1;
    
  if (fread(&obj->vnum,sizeof(int),1,f)!=1) return 1;

  obj->vertices = NEW(float, 3*obj->vnum);
  if (!obj->vertices || fread(obj->vertices,sizeof(float),3*obj->vnum,f)!=3*obj->vnum) return 1;

  obj->normals = NEW(float, 3*obj->vnum);
  if (!obj->normals || fread(obj->normals,sizeof(float),3*obj->vnum,f)!=3*obj->vnum) return 1;
  
  fclose(f);
  
  return 0;
  
}


bool SaveObject (char *file, MeshObject *obj) {

  FILE *f = fopen(file,"wb");
  
  if (!f) return 1;
  if (fwrite(&obj->vnum,sizeof(int),1,f)!=1) return 1;
  if (fwrite(obj->vertices,sizeof(float),3*obj->vnum,f)!=3*obj->vnum) return 1;
  if (fwrite(obj->normals,sizeof(float),3*obj->vnum,f)!=3*obj->vnum) return 1;
  
  fclose(f);
  
  return 0;
  
}

MeshObject *LoadObject (char *file) {

  MeshObject *m = NEW(MeshObject, 1);
  char *a = strrchr(file,'.')+1;
  int ret = -1;

  if (!a || !m) return false;
  else if (!strncasecmp(a,"ray",3)) ret = LoadRayshade(file,m);
  else if (!strncasecmp(a,"raw",3)) ret = LoadSmoothRaw(file,m);
  else if (!strncasecmp(a,"vnb",3)) ret = LoadCompiled(file,m);
  
  if (ret==-1) return NULL;
  else return m;
  
}
        
void DrawObject (MeshObject *obj) {

  int i;
  
  slBegin(0);
  for(i=0;i<obj->vnum;i++) {
    slNormal3f(obj->normals[3*i],obj->normals[3*i+1],obj->normals[3*i+2]);
    slVertex3f(obj->vertices[3*i],obj->vertices[3*i+1],obj->vertices[3*i+2]);
  }
  slEnd();

}

void DestroyObject (MeshObject *obj) {
  free(obj->vertices); free(obj->normals); free(obj);
}

