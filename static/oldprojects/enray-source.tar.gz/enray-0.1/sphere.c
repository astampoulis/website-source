/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include <math.h>
#include "vector.h"
#include "scene.h"
#include "gendefs.h"

typedef struct {

  vector center;
  float radius, rsq, oneOverRadius;
  vector OriginToCenter;
  
} Sphere;


float Sphere_IntersectRay (ray *cray, void *Vs, bool primaryRay) {

  vector OriginToCenter;
  float dotProduct, delta;
  PMTCAST(s, Sphere, Vs);
  
  if (primaryRay) OriginToCenter = s->OriginToCenter;
  else vectorSubOpt(&cray->origin, &s->center, &OriginToCenter);
  
  dotProduct = vectorDot(&OriginToCenter, &cray->dir);
  
  delta = dotProduct*dotProduct - OriginToCenter.rsq + s->rsq;

  if (delta < 0) return -1.0f;
  
  return - dotProduct - sqrtf(delta);
  
}

void Sphere_SurfaceNormal (void *Vs, vector *intersection, vector *normal) {

  PMTCAST(s, Sphere, Vs);
  
  normal->x = (intersection->x - s->center.x) * s->oneOverRadius;
  normal->y = (intersection->y - s->center.y) * s->oneOverRadius;
  normal->z = (intersection->z - s->center.z) * s->oneOverRadius;

}

void Sphere_PerFrameOpt (Camera *c, void *Vs) {

  PMTCAST(s, Sphere, Vs);

  vectorSubOpt(&c->position, &s->center, &s->OriginToCenter);

}

PrimitiveDecl SpherePrimitive = { Sphere_IntersectRay,
                                  Sphere_SurfaceNormal,
                                  Sphere_PerFrameOpt };

Primitive NewSphere (float x, float y, float z, float r) {

  Primitive sP;
  Sphere *s = NEW(Sphere, 1);
  
  sP.type = &SpherePrimitive;
  vectorSet(&s->center,x,y,z);
  s->radius = r; s->rsq = r*r; s->oneOverRadius = 1/r;
  sP.properties = (void *) s;
  
  return sP;
  
}

void ChangeSphere (void *Vs, float x, float y, float z, float r) {

  PMTCAST(s, Sphere, Vs);

  vectorSet(&s->center,x,y,z);
  s->radius = r; s->rsq = r*r; s->oneOverRadius = 1/r;

}
