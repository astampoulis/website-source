/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#ifndef _scene_h_
#define _scene_h_

#include "vector.h"
#include "gendefs.h"

#define DONT_CHANGE_LIGHT_COLOR  -1000

typedef struct {
  vector origin, dir;
  int id, x, y;
} ray;

#include "camera.h"

typedef struct {

  float (*IntersectRay) (ray *, void *, bool);
  void (*SurfaceNormal) (void *, vector *, vector *);
  void (*PerFrameOpt) (Camera *, void *);
  
} PrimitiveDecl;

typedef struct {
  colorf color;
  float reflectivity;
  float specular;
} Material;

typedef struct {

  PrimitiveDecl *type;
  void *properties;
  
} Primitive;

typedef enum { NOSHADOW, HARDSHADOW, SOFTSHADOW } shadowType;

typedef struct {

  Primitive primitive;
  Material *material;
  bool castShadow;
  shadowType receiveShadow;
  int lastOcc;
  
} Object;

typedef struct {
  
  colorf diffuse;
  vector position;
  
} Light;  

typedef struct {

  Object *objects; int objectsNum;
  int *comobj; int comobjNum;
  Light *lights; int lightsNum;
  int *comlgt; int comlgtNum;
  colorf backgroundColor;
  
} Scene;


Scene *NewScene (float r, float g, float b);
void DestroyScene (Scene *s);
int AddObject (Scene *s, Primitive p, Material *m, bool castShadow, shadowType receiveShadow);
int AddLight (Scene *s, float x, float y, float z, float r, float g, float b);
void ChangeLight (Scene *s, int light, float x, float y, float z, float r, float g, float b);
void *ObjectProperties (Scene *s, int object);
Material *ObjectMaterial (Scene *s, int object);
Material *NewMaterial (float r, float g, float b, float reflectivity, float specular);
void ChangeMaterial (Material *m, float r, float g, float b, float reflectivity, float specular);
void RmvObject (Scene *s, int object);
void RmvLight (Scene *s, int light);

#endif


