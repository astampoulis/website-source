/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#ifndef _camera_h_
#define _camera_h_

#include "vector.h"

typedef struct {

  float fov, width, height, rightStepFactor, downStepFactor;
  int sx, sy, ex, ey;
  vector position, lookAt, topLeft, rightStep, downStep;
  
} Camera;

#include "scene.h"

void RayDirection (Camera *c, float x, float y, ray *cray);
Camera *NewCamera (float fov, float x, float y, float z, int sx, int sy, int ex, int ey);
void CameraLookAt (Camera *c, float x, float y, float z, float tx, float ty, float tz);

#endif

