/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#ifndef _graphics_h_
#define _graphics_h_

#include <stdio.h>
#include <SDL/SDL_keysym.h>
#include "gendefs.h"

typedef struct {

  int xres, yres;
  
} graphics;

graphics *GraphicsInit (size_t xres, size_t yres, size_t bpp);
void GraphicsDestroy (graphics *);
void GraphicsUpdate (void);
inline void GraphicsDrawblock (int,int,int,int,int,colorf *a,colorf *b,colorf *c,colorf *d);
bool GraphicsExist (void);

extern bool Keys[];
extern int MouseX, MouseY;

#endif


