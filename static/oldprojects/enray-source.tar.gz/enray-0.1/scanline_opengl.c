/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include <math.h>
#include <stdio.h>

#ifdef WIN32
# include <windows.h>
#endif

#include <GL/gl.h>
#include <GL/glu.h>
#include "gendefs.h"
#include "camera.h"
#include "scanline.h"

#define SLO_zNear 10.0f
#define SLO_zFar  500.0f

static float SLO_mag;
static unsigned short *SLO16bit_normal, *SLO_zbuf;
static GLubyte *SLO24bit_normal;
static int SLO_last, SLO_xres, SLO_yres;
static float SLO_depthA; static int SLO_depthB;
static GLfloat SLO_modelview[16];

static void slFrameBegin_OpenGL (Camera *c) {

  SLO_last = -1; SLO_mag = vectorNorm(&c->position); 
  glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
  glEnable(GL_DEPTH_TEST);
  glDisable(GL_DITHER);
  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
  glLoadIdentity();
  gluPerspective(c->fov, (GLfloat)SLO_xres/(GLfloat)SLO_yres, SLO_zNear, SLO_zFar);
  SLO_depthA = 65535.0f*(2.0f*SLO_zNear*SLO_zFar)/(SLO_zFar-SLO_zNear);
  SLO_depthB = 65535.0f*(SLO_zNear+SLO_zFar)/(SLO_zFar-SLO_zNear);
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
  glLoadIdentity();
  gluLookAt(c->position.x, c->position.y, c->position.z,c->lookAt.x,c->lookAt.y,c->lookAt.z,0,1,0);
  
}

static void slFrameEnd_OpenGL24bit (void) {

  glReadPixels(0,0,SLO_xres,SLO_yres,GL_RGB,GL_UNSIGNED_BYTE,SLO24bit_normal);
  glReadPixels(0,0,SLO_xres,SLO_yres,GL_DEPTH_COMPONENT,GL_UNSIGNED_SHORT,SLO_zbuf);
  glPopMatrix();
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glDisable(GL_DEPTH_TEST);
  glEnable(GL_DITHER);
  glMatrixMode(GL_MODELVIEW);
  
}

int sloint[16];

static void slBegin_OpenGL (int id) {

  glGetFloatv(GL_MODELVIEW_MATRIX, SLO_modelview);

/* normally the inverse transpose matrix would be calculated here,
   but we only care about rotation transformation matrices, so
   M(-1)T = M */

  SLO_modelview[0]*=0.5;SLO_modelview[4]*=0.5;SLO_modelview[8]*=0.5;
  SLO_modelview[1]*=0.5;SLO_modelview[5]*=0.5;SLO_modelview[9]*=0.5;
  SLO_modelview[2]*=0.5;SLO_modelview[6]*=0.5;SLO_modelview[10]*=0.5;

  glBegin(GL_TRIANGLES);

}

static void slUniScalef_OpenGL(float s) { glScalef(s,s,s); }

static void slNormal3f_OpenGL (float x, float y, float z) {

  GLfloat mx, my, mz;
  GLfloat *m = SLO_modelview;

  
  mx = m[0]*x + m[4]*y + m[8]*z + 0.5;
  my = m[1]*x + m[5]*y + m[9]*z + 0.5;
  mz = m[2]*x + m[6]*y + m[10]*z + 0.5;

  glColor3f(mx, my, mz);
    
}

static float slGetDistance_OpenGL (int id, int x, int y) {

  SLO_last = (SLO_yres-1-y)*SLO_xres + x;
  if (id!=0 || SLO_zbuf[SLO_last]>=65534) return -1;
  else return SLO_depthA / (SLO_depthB - SLO_zbuf[SLO_last]);
  
}

static void slGetLastNormal_OpenGL24bit (vector *normal) {

  normal->x = ((signed int)(SLO24bit_normal[3*SLO_last])-128)/128.0f;
  normal->y = ((signed int)(SLO24bit_normal[3*SLO_last+1])-128)/128.0f;
  normal->z = ((signed int)(SLO24bit_normal[3*SLO_last+2])-128)/128.0f;

}

static void slEnd_OpenGL (void) { glEnd(); }
static void slTranslatef_OpenGL (float x, float y, float z) { glTranslatef(x,y,z); }
static void slRotatef_OpenGL (float d, float x, float y, float z) { glRotatef(d,x,y,z); }
static void slVertex3f_OpenGL (float x, float y, float z) { glVertex3f(x,y,z); }

static void slInit_OpenGL (int xres, int yres) {

  SLO_xres = xres; SLO_yres = yres;
  SLO_zbuf = NEW(unsigned short,xres*yres);
  
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glDepthFunc(GL_LESS);
  glDepthMask(GL_TRUE);
  glEnable(GL_CULL_FACE);
  glCullFace(GL_BACK);
  slFrameBegin = slFrameBegin_OpenGL;
  slBegin = slBegin_OpenGL;
  slEnd = slEnd_OpenGL;
  slTranslatef = slTranslatef_OpenGL;
  slUniScalef = slUniScalef_OpenGL;
  slRotatef = slRotatef_OpenGL;
  slVertex3f = slVertex3f_OpenGL;
  slNormal3f = slNormal3f_OpenGL;
  slGetDistance = slGetDistance_OpenGL;

}

void slInit_opengl24bit (int xres, int yres) {

  SLO24bit_normal = NEW(unsigned char,xres*yres*3);
  slFrameEnd = slFrameEnd_OpenGL24bit;
  slGetLastNormal = slGetLastNormal_OpenGL24bit;
  slInit_OpenGL (xres, yres);
  
}

void slDestroy_opengl24bit (void) { free(SLO24bit_normal); free(SLO_zbuf); }

#ifdef GL_VERSION_1_2

static void slFrameEnd_OpenGL16bit (void) {
  
  glReadPixels(0,0,SLO_xres,SLO_yres,GL_RGB,GL_UNSIGNED_SHORT_5_6_5,SLO16bit_normal);
  glReadPixels(0,0,SLO_xres,SLO_yres,GL_DEPTH_COMPONENT,GL_UNSIGNED_SHORT,SLO_zbuf);
  glPopMatrix();
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glDisable(GL_DEPTH_TEST);
  glEnable(GL_DITHER);
  glMatrixMode(GL_MODELVIEW);
  
}

static void slGetLastNormal_OpenGL16bit_REV (vector *normal) {

  normal->z = (((signed char)(SLO16bit_normal[SLO_last]>>11)&31)-16)*0.0625f;
  normal->y = (((signed char)(SLO16bit_normal[SLO_last]>>5)&63)-32)*0.03125f;
  normal->x = ((signed char)(SLO16bit_normal[SLO_last]&31)-16)*0.0625f;

}


static void slGetLastNormal_OpenGL16bit (vector *normal) {

  normal->x = (((signed char)(SLO16bit_normal[SLO_last]>>11)&31)-16)*0.0625f;
  normal->y = (((signed char)(SLO16bit_normal[SLO_last]>>5)&63)-32)*0.03125f;
  normal->z = ((signed char)(SLO16bit_normal[SLO_last]&31)-16)*0.0625f;

}


void slInit_opengl16bit (int xres, int yres) {

  SLO16bit_normal = NEW(unsigned short,xres*yres);
  slFrameEnd = slFrameEnd_OpenGL16bit;
  slGetLastNormal = slGetLastNormal_OpenGL16bit;
  slInit_OpenGL (xres, yres);
  
}

void slInit_opengl16bitREV (int xres, int yres) {

  SLO16bit_normal = NEW(unsigned short,xres*yres);
  slFrameEnd = slFrameEnd_OpenGL16bit;
  slGetLastNormal = slGetLastNormal_OpenGL16bit_REV;
  slInit_OpenGL (xres, yres);
  
}

void slDestroy_opengl16bitREV (void) { free(SLO16bit_normal); free(SLO_zbuf); }
void slDestroy_opengl16bit (void) { free(SLO16bit_normal); free(SLO_zbuf); }

#endif
