/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#ifdef WIN32
# include <windows.h>
#endif

#include <SDL/SDL.h>
#include <GL/gl.h>
#include "vector.h"
#include "scene.h"
#include "gendefs.h"
#include "camera.h"

#define CLOCKFUNC() SDL_GetTicks()

typedef struct {
  char *name, *desc;
  void (*initFunc)(int xres, int yres);
  void (*destrFunc)(void);
} ScanlineRenderers_t;

#define SLR_PROTO(a) extern void slInit_##a (int, int); extern void slDestroy_##a (void)
#define SLR_DEF(a,desc) { #a, desc, slInit_##a, slDestroy_##a }

SLR_PROTO(opengl24bit);
SLR_PROTO(twopass24bit);

#ifdef GL_VERSION_1_2
SLR_PROTO(opengl16bit);
SLR_PROTO(opengl16bitREV);
SLR_PROTO(twopass16bit);
SLR_PROTO(twopass16bitREV);
#endif

ScanlineRenderers_t ScanlineRenderers[] = {
  SLR_DEF(opengl24bit,"OpenGL (24-bit)"),
  SLR_DEF(twopass24bit,"Two-pass OpenGL (24-bit)"),
#ifdef GL_VERSION_1_2
  SLR_DEF(opengl16bit,"OpenGL (16-bit)"),
  SLR_DEF(opengl16bitREV,"OpenGL (16-bit BGR)"),
  SLR_DEF(twopass16bit,"Two-pass OpenGL (16-bit)"),
  SLR_DEF(twopass16bitREV,"Two-pass OpenGL (16-bit BGR)"),
#endif
  { NULL, NULL, NULL }
};

void (*slFrameBegin)(Camera *c);
void (*slFrameEnd)(void);

void (*slBegin)(int objectID);
void (*slEnd)(void);
void (*slTranslatef)(float x, float y, float z);
void (*slRotatef)(float deg, float x, float y, float z);
void (*slVertex3f)(float x, float y, float z);
void (*slNormal3f)(float x, float y, float z);
void (*slUniScalef)(float s);

float (*slGetDistance)(int objectID, int x, int y);
void (*slGetLastNormal)(vector *normal);
  
int lastObjectID;
  
typedef struct {

  int id;
  
} Mesh;

float Mesh_IntersectRay (ray *cray, void *Vm, bool primaryRay) {

  PMTCAST(m, Mesh, Vm);
  
  if (!primaryRay) return -1;
  return slGetDistance(m->id,cray->x,cray->y);
  
}

void Mesh_SurfaceNormal (void *Vm, vector *intersection, vector *normal) {

  slGetLastNormal(normal);
  
}

void Mesh_PerFrameOpt (Camera *c, void *Vm) {  }

PrimitiveDecl MeshPrimitive = { Mesh_IntersectRay,
                                Mesh_SurfaceNormal,
                                Mesh_PerFrameOpt };

Primitive NewMesh (void) {

  Primitive mP;
  Mesh *m = NEW(Mesh, 1);
  
  mP.type = &MeshPrimitive;
  m->id = lastObjectID++;
  mP.properties = m;
  
  return mP;
  
}

bool slInit (char *driver, int xres, int yres) {

  int i=0;
  bool found = false;
  Camera *c = NewCamera(30,0,0,10,0,0,xres,yres);
  int bestIndex=-1;
  long bestTime=0, currentTime, startclock;
  vector normal;

  CLOCKFUNC();
  
  while (ScanlineRenderers[i].name) {
      
    int j;
    
    if (driver && !strcmp(driver, ScanlineRenderers[i].name)) {
      ScanlineRenderers[i].initFunc(xres,yres);
      return true;
    } else if (driver && strncmp(driver, ScanlineRenderers[i].name, strlen(driver))) {
      i++; continue;
    }
    
    ScanlineRenderers[i].initFunc(xres,yres);
    startclock = CLOCKFUNC();
    slFrameBegin(c);
    slBegin(0);
    for (j=0; j<10; j++) {
      slNormal3f(0,0,1); slVertex3f(-50,50,-j);
      slNormal3f(0,0,1); slVertex3f(50,-50,-j);
      slNormal3f(0,0,1); slVertex3f(50, 50,-j);
    }
    slEnd();
    slFrameEnd();
    currentTime = CLOCKFUNC() - startclock;
    if (slGetDistance(0,xres/2,yres/4)!=-1.0f) {
      slGetLastNormal(&normal);
      if ((normal.x<0.1f&&normal.x>-0.1f)&&(normal.y<0.1f&&normal.y>-0.1f)&&(normal.z<1.1f&&normal.z>0.9f)) {
        found=true;
        if (bestIndex==-1 || currentTime < bestTime) { bestTime = currentTime; bestIndex = i; }
      }
    }
    ScanlineRenderers[i].destrFunc();
    i++;
  }
  
  if (found) {
    ScanlineRenderers[bestIndex].initFunc(xres,yres);
    printf("slInit: chose scanline renderer \"%s\" (%s)\n",ScanlineRenderers[bestIndex].desc,
                                                           ScanlineRenderers[bestIndex].name);
    return true;
  }
  
  return false;
      
}

int slGetMeshId (Scene *s, int object) {
  PMTCAST(m, Mesh, ObjectProperties(s,object));
  return m->id;
}
