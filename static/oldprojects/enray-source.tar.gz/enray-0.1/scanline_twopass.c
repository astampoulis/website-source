/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include <math.h>
#include <stdio.h>

#ifdef WIN32
# include <windows.h>
#endif

#include <GL/gl.h>
#include <GL/glu.h>
#include "gendefs.h"
#include "camera.h"
#include "scanline.h"
#include "vector.h"

#define MAXVERTEX 64000

static float SLOGL2_modelviewNorm[9], SLOGL2_modelview[16], SLOGL2_min, SLOGL2_max, SLOGL2_factor;
static unsigned short *SLOGL2_normal, *SLOGL2_zbuf;
static unsigned char *SLOGL2_normal24bit, *SLOGL2_zbuf24bit;
static GLfloat SLOGL2_vertex[MAXVERTEX*3];
static GLfloat SLOGL2_distance[MAXVERTEX];
static int SLOGL2_vertexnum;
static int SLOGL2_last, SLOGL2_xres, SLOGL2_yres;

static void slFrameBegin_TwoPass (Camera *c) {

  SLOGL2_last = -1;
  SLOGL2_min = 1e+38; SLOGL2_max = -(1e38); SLOGL2_vertexnum = 0;
  glDepthMask(GL_TRUE);
  glDepthFunc(GL_LESS);
  glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
  glEnable(GL_DEPTH_TEST);
  glDisable(GL_DITHER);
  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
  glLoadIdentity();
  gluPerspective(c->fov, (GLfloat)SLOGL2_xres/(GLfloat)SLOGL2_yres, 10.0f, 500.0f);
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
  glLoadIdentity();
  gluLookAt(c->position.x, c->position.y, c->position.z,c->lookAt.x,c->lookAt.y,c->lookAt.z,0,1,0);
  
}

static void slFrameEnd_TwoPass24bit (void) {

  int i;
  double factor;
  
  factor=16777215.0f/(SLOGL2_max-SLOGL2_min);
  SLOGL2_factor = (SLOGL2_max-SLOGL2_min)/16777215.0f;
  glReadPixels(0,0,SLOGL2_xres,SLOGL2_yres,GL_RGB,GL_UNSIGNED_BYTE,SLOGL2_normal24bit);
  glClear(GL_COLOR_BUFFER_BIT);
  glLoadIdentity();
  glDepthMask(GL_FALSE);
  glDepthFunc(GL_EQUAL);
  glBegin(GL_TRIANGLES);
  for (i=0; i<SLOGL2_vertexnum; i++) {
    float normdist;
    int full;
    normdist = (SLOGL2_distance[i]-SLOGL2_min)*factor;
    full = normdist;
    glColor3ub((full>>16),(full>>8)&255,(full&255)|1);
    glVertex3fv(&SLOGL2_vertex[3*i]);
  }
  glEnd();
  glReadPixels(0,0,SLOGL2_xres,SLOGL2_yres,GL_RGB,GL_UNSIGNED_BYTE,SLOGL2_zbuf24bit);

  glPopMatrix();
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glDisable(GL_DEPTH_TEST);
  glEnable(GL_DITHER);
  glMatrixMode(GL_MODELVIEW);
  
}

static void slBegin_TwoPass (int id) {

  glGetFloatv(GL_MODELVIEW_MATRIX, SLOGL2_modelview);

  SLOGL2_modelviewNorm[0] = SLOGL2_modelview[0]*0.5;
  SLOGL2_modelviewNorm[1] = SLOGL2_modelview[4]*0.5;
  SLOGL2_modelviewNorm[2] = SLOGL2_modelview[8]*0.5;
  SLOGL2_modelviewNorm[3] = SLOGL2_modelview[1]*0.5;
  SLOGL2_modelviewNorm[4] = SLOGL2_modelview[5]*0.5;
  SLOGL2_modelviewNorm[5] = SLOGL2_modelview[9]*0.5;
  SLOGL2_modelviewNorm[6] = SLOGL2_modelview[2]*0.5;
  SLOGL2_modelviewNorm[7] = SLOGL2_modelview[6]*0.5;
  SLOGL2_modelviewNorm[8] = SLOGL2_modelview[10]*0.5;

  glPushMatrix();
  glLoadIdentity();
  glBegin(GL_TRIANGLES);

}

static void slEnd_TwoPass (void) { glEnd(); glPopMatrix(); }

static void slNormal3f_TwoPass (float x, float y, float z) {

  GLfloat mx, my, mz;
  float *m = SLOGL2_modelviewNorm;

  mx = m[0]*x + m[1]*y + m[2]*z + 0.5;
  my = m[3]*x + m[4]*y + m[5]*z + 0.5;
  mz = m[6]*x + m[7]*y + m[8]*z + 0.5;

  glColor3f(mx, my, mz);
  
}

static void slVertex3f_TwoPass (float x, float y, float z) {

  GLfloat mx, my, mz, *m = SLOGL2_modelview;
  float dist;
  
  mx = (m[0]*x + m[4]*y + m[8]*z + m[12]);
  my = (m[1]*x + m[5]*y + m[9]*z + m[13]);
  mz = (m[2]*x + m[6]*y + m[10]*z + m[14]);
  glVertex3f(mx,my,mz);

  SLOGL2_vertex[3*SLOGL2_vertexnum] = mx;
  SLOGL2_vertex[3*SLOGL2_vertexnum+1] = my;
  SLOGL2_vertex[3*SLOGL2_vertexnum+2] = mz;
  
  dist = sqrt(mx*mx+my*my+mz*mz);

  if (dist<SLOGL2_min) SLOGL2_min = dist;
  if (dist>SLOGL2_max) SLOGL2_max = dist;
  
  SLOGL2_distance[SLOGL2_vertexnum] = dist;
  
  SLOGL2_vertexnum++;
  
}

static void slUniScalef_TwoPass(float s) { glScalef(s,s,s); }

static float slGetDistance_TwoPass24bit (int id, int x, int y) {

  int full;

  SLOGL2_last = 3*((SLOGL2_yres-1-y)*SLOGL2_xres + x);
  full = (SLOGL2_zbuf24bit[SLOGL2_last]<<16) + (SLOGL2_zbuf24bit[SLOGL2_last+1]<<8) +
         (SLOGL2_zbuf24bit[SLOGL2_last+2]);
  
  if (id!=0 || full==0) return -1;
  else return SLOGL2_min + ((float)full)*SLOGL2_factor;

}

static void slGetLastNormal_TwoPass24bit (vector *normal) {

  normal->x = ((signed int)(SLOGL2_normal24bit[SLOGL2_last])-128)/128.0f;
  normal->y = ((signed int)(SLOGL2_normal24bit[SLOGL2_last+1])-128)/128.0f;
  normal->z = ((signed int)(SLOGL2_normal24bit[SLOGL2_last+2])-128)/128.0f;

}

static void slTranslatef_twopass (float x, float y, float z) { glTranslatef(x,y,z); }
static void slRotatef_twopass (float d, float x, float y, float z) { glRotatef(d,x,y,z); }

static void slInit_twopass (int xres, int yres) {

  SLOGL2_xres = xres; SLOGL2_yres = yres;
  SLOGL2_normal = NEW(unsigned short,xres*yres);
  SLOGL2_zbuf = NEW(unsigned short,xres*yres);
  
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glEnable(GL_CULL_FACE);
  glCullFace(GL_BACK);
  slFrameBegin = slFrameBegin_TwoPass;
  slBegin = slBegin_TwoPass;
  slEnd = slEnd_TwoPass;
  slTranslatef = slTranslatef_twopass;
  slRotatef = slRotatef_twopass;
  slUniScalef = slUniScalef_TwoPass;
  slVertex3f = slVertex3f_TwoPass;
  slNormal3f = slNormal3f_TwoPass;
  
}

void slInit_twopass24bit (int xres, int yres) {
  SLOGL2_normal24bit = NEW(unsigned char,3*xres*yres);
  SLOGL2_zbuf24bit = NEW(unsigned char,3*xres*yres);
  slFrameEnd = slFrameEnd_TwoPass24bit;
  slGetDistance = slGetDistance_TwoPass24bit;
  slGetLastNormal = slGetLastNormal_TwoPass24bit;
  slInit_twopass(xres,yres);
}

void slDestroy_twopass24bit (void) { free(SLOGL2_normal24bit); free(SLOGL2_zbuf24bit); }

#ifdef GL_VERSION_1_2

static void slFrameEnd_TwoPass16bitREV (void) {

  int i;
  float factor;
  
  factor=65535.0f/(SLOGL2_max-SLOGL2_min);
  SLOGL2_factor = (SLOGL2_max-SLOGL2_min)/65535.0f;
  glReadPixels(0,0,SLOGL2_xres,SLOGL2_yres,GL_RGB,GL_UNSIGNED_SHORT_5_6_5,SLOGL2_normal);
  glClear(GL_COLOR_BUFFER_BIT);
  glLoadIdentity();
  glDepthMask(GL_FALSE);
  glDepthFunc(GL_EQUAL);
  glBegin(GL_TRIANGLES);
  for (i=0; i<SLOGL2_vertexnum; i++) {
    float normdist;
    int full;
    normdist = (SLOGL2_distance[i]-SLOGL2_min)*factor;
    full = normdist;
    glColor3ub(((full&31)|1)<<3,((full>>5)&63)<<2,(full>>11)<<3);
    glVertex3fv(&SLOGL2_vertex[3*i]);
  }
  glEnd();
  glReadPixels(0,0,SLOGL2_xres,SLOGL2_yres,GL_RGB,GL_UNSIGNED_SHORT_5_6_5,SLOGL2_zbuf);

  glPopMatrix();
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glDisable(GL_DEPTH_TEST);
  glEnable(GL_DITHER);
  glMatrixMode(GL_MODELVIEW);
  
}

static void slFrameEnd_TwoPass16bit (void) {

  int i;
  float factor;
  
  factor=65535.0f/(SLOGL2_max-SLOGL2_min);
  SLOGL2_factor = (SLOGL2_max-SLOGL2_min)/65535.0f;
  glReadPixels(0,0,SLOGL2_xres,SLOGL2_yres,GL_RGB,GL_UNSIGNED_SHORT_5_6_5,SLOGL2_normal);
  glClear(GL_COLOR_BUFFER_BIT);
  glLoadIdentity();
  glDepthMask(GL_FALSE);
  glDepthFunc(GL_EQUAL);
  glBegin(GL_TRIANGLES);
  for (i=0; i<SLOGL2_vertexnum; i++) {
    float normdist;
    int full;
    normdist = (SLOGL2_distance[i]-SLOGL2_min)*factor;
    full = normdist;
    glColor3ub((full>>11)<<3,((full>>5)&63)<<2,((full&31)|1)<<3);
    glVertex3fv(&SLOGL2_vertex[3*i]);
  }
  glEnd();
  glReadPixels(0,0,SLOGL2_xres,SLOGL2_yres,GL_RGB,GL_UNSIGNED_SHORT_5_6_5,SLOGL2_zbuf);

  glPopMatrix();
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glDisable(GL_DEPTH_TEST);
  glEnable(GL_DITHER);
  glMatrixMode(GL_MODELVIEW);
  
}

static float slGetDistance_TwoPass16bit (int id, int x, int y) {

  SLOGL2_last = (SLOGL2_yres-1-y)*SLOGL2_xres + x;
  if (id!=0 || SLOGL2_zbuf[SLOGL2_last]==0) return -1;
  else return SLOGL2_min + ((float)SLOGL2_zbuf[SLOGL2_last])*SLOGL2_factor;

}

static void slGetLastNormal_TwoPass16bitREV (vector *normal) {

  normal->z = (((signed char)(SLOGL2_normal[SLOGL2_last]>>11)&31)-16)*0.0625f;
  normal->y = (((signed char)(SLOGL2_normal[SLOGL2_last]>>5)&63)-32)*0.03125f;
  normal->x = ((signed char)(SLOGL2_normal[SLOGL2_last]&31)-16)*0.0625f;

}

static void slGetLastNormal_TwoPass16bit (vector *normal) {

  normal->x = (((signed char)(SLOGL2_normal[SLOGL2_last]>>11)&31)-16)*0.0625f;
  normal->y = (((signed char)(SLOGL2_normal[SLOGL2_last]>>5)&63)-32)*0.03125f;
  normal->z = ((signed char)(SLOGL2_normal[SLOGL2_last]&31)-16)*0.0625f;

}

void slInit_twopass16bit (int xres, int yres) {
  SLOGL2_normal = NEW(unsigned short,xres*yres);
  SLOGL2_zbuf = NEW(unsigned short,xres*yres);
  slFrameEnd = slFrameEnd_TwoPass16bit;
  slGetDistance = slGetDistance_TwoPass16bit;
  slGetLastNormal = slGetLastNormal_TwoPass16bit;
  slInit_twopass(xres,yres);
}

void slInit_twopass16bitREV (int xres, int yres) {
  SLOGL2_normal = NEW(unsigned short,xres*yres);
  SLOGL2_zbuf = NEW(unsigned short,xres*yres);
  slFrameEnd = slFrameEnd_TwoPass16bitREV;
  slGetDistance = slGetDistance_TwoPass16bit;
  slGetLastNormal = slGetLastNormal_TwoPass16bitREV;
  slInit_twopass(xres,yres);
}

void slDestroy_twopass16bit (void) { free(SLOGL2_normal); free(SLOGL2_zbuf); }
void slDestroy_twopass16bitREV (void) { free(SLOGL2_normal); free(SLOGL2_zbuf); }

#endif
