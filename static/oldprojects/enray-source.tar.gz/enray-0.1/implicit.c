/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include <math.h>
#include "vector.h"
#include "scene.h"
#include "gendefs.h"
#include "camera.h"

typedef struct {

  vector center;
  vector OriginToCenter;
  float radius, rsq, oneOverRadius;
  float tStep;
  int refinement;
  float (*function)(float x, float y, float z);  
  
} Implicit;

float Implicit_IntersectRay (ray *cray, void *Vs, bool primaryRay) {

  vector OriginToCenter;
  float dotProduct, delta, sqrtdelta;
  float t1, t2, f;
  int i;
  bool hit;
  PMTCAST(s, Implicit, Vs);
  
  
  if (primaryRay) OriginToCenter = s->OriginToCenter;
  else vectorSubOpt(&cray->origin, &s->center, &OriginToCenter);
  
  dotProduct = vectorDot(&OriginToCenter, &cray->dir);
  
  delta = dotProduct*dotProduct - OriginToCenter.rsq + s->rsq;
  
  if (delta < 0) return -1.0f;
  
  sqrtdelta = sqrtf(delta);
  t1 = - dotProduct - sqrtdelta; t2 = - dotProduct + sqrtdelta;
  
  if (t2<0.0) return -1.0f;
  if (t1<0.0) t1 = 0.0f;
  
  
  f = s->function(cray->dir.x*t1+OriginToCenter.x,
                  cray->dir.y*t1+OriginToCenter.y,
                  cray->dir.z*t1+OriginToCenter.z);

  hit = false;
  while (t1 < t2) {
    if (f*s->function(cray->dir.x*t1+OriginToCenter.x,
                      cray->dir.y*t1+OriginToCenter.y,
                      cray->dir.z*t1+OriginToCenter.z) < 0.0f) {
      hit = true;
      break;
    }
    t1 += s->tStep;
  }
  if (!hit) return -1.0f;
  
  t2 = t1; t1 -= s->tStep;
  
  for (i=0; i<s->refinement; i++) {
    float tm = (t1+t2)*0.5f;
    if (f*s->function(cray->dir.x*tm+OriginToCenter.x,
                      cray->dir.y*tm+OriginToCenter.y,
                      cray->dir.z*tm+OriginToCenter.z)<0.0f)
      t2 = tm;
    else 
      t1 = tm;
  }
  
  return (t1+t2)*0.5f;
    
}

#define DELTA         0.01f
#define INVDELTA      (1/DELTA)

void Implicit_SurfaceNormal (void *Vs, vector *intersection, vector *normal) {

  PMTCAST(s, Implicit, Vs);
  float f, x, y, z;
  
  x = intersection->x - s->center.x;
  y = intersection->y - s->center.y;
  z = intersection->z - s->center.z;
  
  f = s->function(x,y,z);
  normal->x = INVDELTA * (s->function(x+DELTA,y,z) - f);
  normal->y = INVDELTA * (s->function(x,y+DELTA,z) - f);
  normal->z = INVDELTA * (s->function(x,y,z+DELTA) - f);
  vectorNormalize(normal);

}

void Implicit_PerFrameOpt (Camera *c, void *Vs) {
  PMTCAST(s, Implicit, Vs);
  vectorSubOpt(&c->position, &s->center, &s->OriginToCenter);
}

PrimitiveDecl ImplicitPrimitive = { Implicit_IntersectRay,
                                    Implicit_SurfaceNormal,
                                    Implicit_PerFrameOpt };

Primitive NewImplicit (float x, float y, float z, float r,
                       float (*func)(float, float, float),
                       float tStep, int refinement) {

  Primitive iP;
  Implicit *i = NEW(Implicit, 1);
  
  iP.type = &ImplicitPrimitive;
  vectorSet(&i->center,x,y,z);
  i->radius = r; i->rsq = r*r; i->oneOverRadius = 1/r;
  i->tStep = tStep; i->refinement = refinement; i->function = func;
  iP.properties = (void *) i;
  
  return iP;
  
}

void MoveImplicit (void *Vi, float x, float y, float z) {

  PMTCAST(i,Implicit,Vi);
  vectorSet(&i->center,x,y,z);
  
}
