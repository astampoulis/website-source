# Antonis Stampoulis, antonios.stampoulis@yale.edu

# The MapReduce runtime, implemented using NWS and Sleigh.

from nws.sleigh import Sleigh, sshcmd
from nws.client import NetWorkSpace
import zlib
import cPickle as pickle
import StringIO
import md5

# ----------------------------------------------------------------------
# Code for map-reduce master.

# The main mapreduce function that initiates a MapReduce
# computation. The parameters are the following: workers is the list
# containing the worker nodes. module is the module containing the
# input generation, map and reduce operations for the MapReduce
# computation at hand. gen_params is a list containing parameters for
# the input generation function, which must be named gen in the given
# module. map_params is a list of parameters for the map operation,
# which must be named 'map', and reduce_params are the parameters for
# the reduce operation, which must be named 'reduc' (to avoid clashes
# with the python built-in reduce operation). reduce_assoc is a boolean
# value specifying whether the reduce operation is associative -- that
# is: if reduc(k, a) == (k, ra) and reduc(k, b) == (k, rb) then
# reduc(k, a ++ b) == reduc(k, [ra, rb]). reduce_tasks is the number
# of reduce tasks that the reduce operation must be splitted in, in
# the case that the reduce operation is not associative.

def mapreduce(workers,
              module,
              gen_params,
              map_params,
              reduce_params,
              reduce_assoc,
              reduce_tasks):


    # initialize the sleigh, and have each worker import the necessary
    # modules
    
    s = Sleigh(nodeList = workers, launch = sshcmd)
    s.eachWorker('from mapreduce import *')
    s.eachWorker('import ' + module.__name__)


    # generate the first ticket for the map phase, and run the map worker
    # function on each worker

    s.nws.store('map_phase_ticket', 0)

    map_done = s.eachWorker(map_runner, module.gen, gen_params,
                            module.map, map_params, module.reduc,
                            reduce_params, reduce_assoc, reduce_tasks, blocking = False)
    map_done.wait()

    # when the map operation is done, we continue depending on whether the reduce
    # operation is associative or not.

    if reduce_assoc:

        # if it's associative, then the workers have already produced intermediate
        # reduce-operation results (they have executed the reduce operation in all
        # their results from their map operations). We need to execute the reduce
        # operation once again for these intermediate results, grouping by key.
        # We do this on the master, because in most cases the reduce operations
        # will be light-weight, so redistributing the intermediate results to workers
        # for a distributed reduce phase would take longer.

        results = dict()
        
        def my_emit(k, v):
            results[k] = [v]
        
        while True:
            r = s.nws.fetchTry('map_phase_result')
            if r == None: break
            d = zunpickle(r)
            for k in d:
                module.reduc(my_emit, k, results.get(k,[]) + d[k])

        return results
    
    else:

        # otherwise, the reduce operation is more heavy-weight,
        # because for each key we can have a big list of associated
        # values. So doing the reduce operation on the master might
        # not be optimal. Therefore we create reduce tasks on the
        # workers, and then gather the results. We will see later how
        # the intermediate key-value pairs are handed to the workers,
        # and how the tasks are actually specified.

        reduce_done = s.eachWorker(reduce_runner, module.reduc, reduce_params, blocking = False)
        for i in range(reduce_tasks): s.nws.store('reduce_phase_task', i)
        s.nws.store('reduce_phase_task', -1)

        reduce_done.wait()

        results = dict()
        while True:
            r = s.nws.fetchTry('reduce_phase_result')
            if r == None: break
            d = zunpickle(r)
            results.update(d)

        return results

# ----------------------------------------------------------------------
# Code for map-reduce workers.

# Initially we were compressing the results before storing them in the
# network space, and uncompressing when they were retrieved. We found
# that the computational overhead wasn't justified by the decrease in
# the communication overhead, so we disabled the compression code.

def zpickle(obj):
    return obj
    #s = StringIO.StringIO()
    #p = pickle.Pickler(s)
    #p.dump(obj)
    #r = zlib.compress(s.getvalue())
    #return r

def zunpickle(s):
    return s
    #st = StringIO.StringIO(zlib.decompress(s))
    #p = pickle.Unpickler(st)
    #return p.load()

# A simple hashing function, that is guaranteed to return the same
# hash value among all workers (the built-in hash function doesn't
# satisfy this property!). It returns a value from 0 to n-1.

def my_hash(w, n):
    return sum(ord(c) for c in md5.md5(str(w)).digest()) % n

# The emit functions for the map and the reduce phase. Note that
# we simply cache the results, deferring the NWS store operation
# until we have all the results we need to store. By reducing the
# number of store operations, the coordination overhead is also
# reduced.

map_results = dict()

def map_emit(k, v):
    map_results[k] = map_results.get(k,[]) + [v]
        
reduce_results = dict()

def reduce_emit(k, v):
    reduce_results[k] = [v]


# The code that the workers run in the map phase.

def map_runner(gen_op, gen_params, map_op, map_params, reduce_op, reduce_params, reduce_assoc, reduce_tasks):

    chunk_num = -1
    chunk_gen = gen_op(*gen_params)
    done = False
    
    while not done:

        # We use the DIY-like trick to reduce the communication
        # overhead for handing out tasks to workers. The workers know
        # how to generate the different tasks/partitions (using the
        # gen function), so they just grab a ticket describing which
        # partition to process. Note that this is not optimal in the
        # general case!  A case where this is not optimal is when the
        # size of gen_params is larger than the size of the resulting
        # partitions.
        
        ticket = SleighNws.fetch('map_phase_ticket')
        if ticket == None:
            SleighNws.store('map_phase_ticket', None)
            break
        
        SleighNws.store('map_phase_ticket', ticket+1)
        while chunk_num < ticket:
            try:
                chunk = chunk_gen.next()
                chunk_num = chunk_num + 1
            except StopIteration:
                done = True
                # poison the other workers
                SleighNws.fetch('map_phase_ticket')
                SleighNws.store('map_phase_ticket', None)
                break
            
        if not done:
            # for every instance of the input in the current partition
            # of the input set, we execute the map operation.
            for inp in chunk:
                map_op(map_emit, inp, *map_params)

    if reduce_assoc:

        # If the reduce operation is associative, we apply it to our
        # intermediate results before storing them in the network
        # space. The resulting key-value pairs will supposedly be of
        # smaller size than the original key-list of value pairs, so
        # we greatly reduce the reduce-operation work that remains to
        # be done.

        for k in map_results:
            reduce_op(reduce_emit, k, map_results[k], *reduce_params)
        SleighNws.store('map_phase_result', zpickle(reduce_results))

    else:

        # If it isn't there's nothing we can do but post the map results
        # to the network space. But, in order to split the results into
        # as many reduce tasks as we want to generate, we use the hashing
        # function we defined earlier. Before posting each key-list of values
        # pairs, we hash the key. This returns a value in the range of the
        # number of reduce tasks we want to have. We then create as many chunks
        # to store the intermediate pairs as there will be reduce tasks, and
        # store each pair to the corresponding chunk, using the hashed key
        # value.

        map_results_hashed = dict()
        for k in map_results:
            hk = my_hash(k, reduce_tasks)
            map_results_hashed[hk] = map_results_hashed.get(hk,[]) + [(k,map_results[k])]
        for k in map_results_hashed:
            SleighNws.store('reduce_chunk_' + str(k), zpickle(map_results_hashed[k]))

# The code that the workers run in the reduce phase.

def reduce_runner(reduce_op, reduce_params):

    while True:

        # This is straightforward agenda-parallelism; the reduce task
        # descriptions is just the number of the chunk we are to
        # process, or the poison task when all tasks are done.
        
        task = SleighNws.fetch('reduce_phase_task')
        if task == -1:
            SleighNws.store('reduce_phase_task', -1)
            break

        inp = dict()

        # we grab all the intermediate results for the specific task.
        # Each worker might have produced one dictionary of
        # intermediate results during the map phase.
        
        while True:
            r = SleighNws.fetchTry('reduce_chunk_' + str(task))
            if r == None: break
            d = zunpickle(r)
            for (k,l) in d: inp[k] = inp.get(k,[]) + l

        # For each key-list of value pairs, we execute the reduce
        # operation. We cache the results (using the provided emit
        # function), to store them all at once, when all tasks are
        # done.
        for k in inp:
            reduce_op(reduce_emit, k, inp[k], *reduce_params)

    # Finally we store the cached results.
    SleighNws.store('reduce_phase_result', zpickle(reduce_results))

