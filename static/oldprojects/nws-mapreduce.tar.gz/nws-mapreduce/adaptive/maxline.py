# Antonis Stampoulis, antonios.stampoulis@yale.edu

# This is the MapReduce implementation of the maxline sample program.
# The gen function generates partition with total bytesize
# more-or-less equal to the given limit; we make the assumption that
# there are no huge files (close to the given chunk-size), otherwise
# the partitioning isn't fair. The map function gets a file, and emits
# its maximum line. The reduce operation gets a list of maximum lines
# and emits the maximum line out of these. We will end up with one
# result key-value pair, where the value will be the overall maximum
# line.

from os import walk
from os.path import join, getsize
import re

def gen(path, chunk_size):
    current_size = 0
    current_partition = []
    for root, dirs, files in walk(path):
        for fn in files:
            name = join(root, fn)
            size = getsize(name)
            current_partition.append(name)
            current_size += size
            if current_size > chunk_size:
                yield current_partition
                current_size = 0
                current_partition = []
    if current_size > 0:
        yield current_partition

def map(emit, fn):
    lines = file(fn).readlines()
    if lines: emit('max', max(lines))

def reduc(emit, k, v):
    if v: emit(k, max(v))

if __name__ == '__main__':
    import maxline
    import mapreduce
    import sys

    if len(sys.argv) >= 2:
        directory = sys.argv[1]
    else:
        directory = "/usr/src/linux"
    
    r = mapreduce.mapreduce(
        workers = ['frog', 'gator', 'hippo'],
        module = maxline,
        gen_params = [directory, 32*1024*1024],
        map_params = [],
        reduce_params = [],
        reduce_assoc = True,
        reduce_tasks = 6)
    
    print r['max'][0]
