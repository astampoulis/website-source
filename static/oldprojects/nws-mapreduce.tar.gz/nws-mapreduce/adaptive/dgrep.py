# Antonis Stampoulis, antonios.stampoulis@yale.edu

# The dictionary grep implementation using MapReduce. The gen function
# partitions the input files into mostly equal (with regard to
# bytesize) chunks, just like the maxline program does. The map
# function emits, for each matching substring in a file, a key-value
# pair with that substring as key, and 1 as the value (since there is
# one matching for that substring). The reduce operation gets a
# matching substring and a list of counts of occurrences, and emits
# that matching substring together with the sum of the list as the
# result.

from os import walk
from os.path import join, getsize
import re

def gen(path, chunk_size):
    current_size = 0
    current_partition = []
    for root, dirs, files in walk(path):
        for fn in files:
            name = join(root, fn)
            size = getsize(name)
            current_partition.append(name)
            current_size += size
            if current_size > chunk_size:
                yield current_partition
                current_size = 0
                current_partition = []
    if current_size > 0:
        yield current_partition

def map(emit, fn, regexp):
    f = file(fn)
    contents = f.read()
    matches = regexp.findall(contents)
    for i in matches:
        emit(i, 1)
        

def reduc(emit, k, v):
    emit(k, sum(v))

if __name__ == '__main__':
    import dgrep
    import mapreduce
    import sys

    if len(sys.argv) >= 3:
        directory = sys.argv[1]
        pattern = sys.argv[2]
    else:
        directory = "/usr/src/linux"
        pattern = "hello|world|[a-z]{10}"
    
    r = mapreduce.mapreduce(
        workers = ['frog', 'gator', 'hippo'],
        module = dgrep,
        gen_params = [directory, 20*1024*1024],
        map_params = [re.compile(pattern)],
        reduce_params = [],
        reduce_assoc = True,
        reduce_tasks = 6)
    
    print len(r)
