# Antonis Stampoulis, antonios.stampoulis@yale.edu

# This is the primes finder, implemented using MapReduce. The gen
# operation just creates chunks, including only odd numbers in each
# partition. The map operation gets a number and emits a key-value
# pair with the number as the key and True as the value if the number
# is prime. The reduce operation just keeps the first value of the
# list of values -- there won't be key-value pairs with the same key
# generated anyway!

from math import sqrt, floor

def gen(up_to, chunk_size):
    current_partition = []
    for i in [2] + range(3,up_to+1,2):
        current_partition.append(i)
        if len(current_partition) >= chunk_size:
            yield current_partition
            current_partition = []
    if current_partition:
        yield current_partition

def map(emit, i):
    for div in range(2, floor(sqrt(i))+1):
        if i % div == 0:
            break
    else:
        emit(i, True)

def reduc(emit, k, v):
    emit(k, v[0])

if __name__ == '__main__':
    import primes
    import mapreduce
    r = mapreduce.mapreduce(
        workers = ['aphid', 'tiger', 'termite', 'monkey' ],
        module = primes,
        gen_params = [500000, 5000],
        map_params = [],
        reduce_params = [],
        reduce_assoc = True,
        reduce_tasks = 6)
#    print r
    print len(r)
