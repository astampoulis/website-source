#!/usr/bin/python
# Antonis Stampoulis, antonios.stampoulis@yale.edu

# This is the bobsleigh client, that needs to be run in an X
# session in every node that we want to potentially take part
# in an adaptive computation.

# When a new task comes along, this client creates a GTK+ window that
# enables the user to manually specify whether the node should take
# part in the computation. By default, this program automatically
# decides about that, based on interactive usage characteristics and
# current load. But if the user makes a choice, it overrides the
# automatic decisions.

import nws.client as nws
from socket import gethostname
import sys
from gtk import *
import gobject
from os import listdir
from os.path import dirname, join
from time import time

# add the location of the xss library to the python path. This
# depends on sys.argv[0] containing the location of bobsleigh.py
# relative to the current directory. If this doesn't work, the
# user must explicitly add the xss directory to the python path.

sys.path.append(join(dirname(sys.argv[0]), "xss"))
import xss

# the BobSleigh server's hostname is either specified as an argument
# of this program (-sservername), or it's lion by default. We can
# also use an argument to control whether initially we are to automatically
# determine whether this worker should take part in the computation,
# or whether the initial behavior is fixed. This is done by giving
# an argument of auto, always, or never.

servername = "lion"
defaultmode = "auto"
for arg in sys.argv[1:]:
    if arg.startswith("-s"):
        servername = arg[2:]
    elif arg == "auto" or arg == "always" or arg == "never":
        defaultmode = arg

# Connect to the bobsleigh server.
n = nws.NetWorkSpace("bobsleigh", servername, useUse = True)

# Get the current node's name.
host = gethostname()


# This class implements the computation-control window. By default,
# it automatically chooses when to take part in a computation and
# when to bail out. This is done by monitoring the load because of
# the other processes, plus the interactive usage idle time. When
# the node is idle for 5 seconds (that is, there are no keyboard or
# mouse events for 5 seconds), plus the load because of other processes
# is less than 50%, we start executing the computation. When one of
# these doesn't hold, we stop the computation. The rest of the code
# handles the event where the user explicitly selects whether the
# node should or shouldn't take part in the computation, and updates
# some info shown on the window periodically.

class Control(Window):

    def __init__(self, task, pid):

        Window.__init__(self)
        self.set_title("Bobsleigh control for " + host)
        v = VBox()
        h = HBox()
        v.add(Label("This enables you to control the execution of the current BobSleigh task in this machine."))
        self.load_label = Label()
        v.add(self.load_label)
        v.add(h)
        self.task = task
        self.pid = pid
        self.auto_button = ToggleButton("Auto")
        self.start_button = Button("Start")
        self.stop_button = Button("Stop")
        h.add(self.auto_button)
        h.add(self.start_button)
        h.add(self.stop_button)
        self.auto_button.connect("toggled", self.auto_toggle)
        self.start_button.connect("clicked", self.start)
        self.stop_button.connect("clicked", self.stop)
        self.stop_button.set_sensitive(False)
        self.timeout = gobject.timeout_add(200, self.status)
        self.timeout2 = gobject.timeout_add(1000, self.load_update)
        self.add(v)
        self.mode = "stop"
        self.prev_otherjiffies = 0
        self.prev_idle = 0
        self.timeout3 = None
        if defaultmode == "auto":
            self.enable_auto()
        elif defaultmode == "always":
            self.start_computing()

    # Called  when   this  node  should  start  taking   part  in  the
    # computation. We store a value in the 'allowed' variable for this
    # task and host  in the bobsleigh server, and  also the same value
    # in the stillallowed variable.
    def start_computing(self):
        if self.mode <> "stop": return
        print "starting computation"
        self.start_button.set_sensitive(False)
        self.stop_button.set_sensitive(True)
        self.mode = "start"
        n.store(self.task + "_allowed_" + host, True)
        # remove False still allowed if it exists.
        n.fetchTry(self.task + "_stillallowed_" + host) 
        n.store(self.task + "_stillallowed_" + host, True)

    # Called when  we should stop  taking part in the  computation. We
    # fetch out the  value of the allowed variable,  and if it's equal
    # to done,  we post it back  (the computation is done  so we might
    # want to  wrap up;  there's no  need to stop  taking part  in the
    # computation any more). If it's True, then we just flip the value
    # of  the stillallowed  variable. Since  no value  exists  for the
    # allowed variable anymore, the node will block at the point where
    # it finds the value of the  variable, not doing any work for this
    # computation.
    def stop_computing(self):
        if self.mode <> "start": return
        print "stopping computation"
        self.start_button.set_sensitive(True)
        self.stop_button.set_sensitive(False)
        r = n.fetch(self.task + "_allowed_" + host)
        if r == "done":
            n.store(self.task + "_allowed_" + host, r)
            self.done()
        else:
            n.fetch(self.task + "_stillallowed_" + host)
            n.store(self.task + "_stillallowed_" + host, False)
            self.mode = "stop"

    # called periodically, in order to check whether the task is done
    # or not. If it's done, just destroy the window.
    def status(self):
        r = n.findTry(self.task + "_allowed_" + host)
        if r == "done": self.done()
        return True

    # return the average load of all processes over the last minute.
    def getload_all(self):
        loadavg = float(file("/proc/loadavg").read().split()[0])
        return loadavg

    # return the msec where X input has been idle.
    def getidle(self):
        info = xss.get_info()
        return info.idle

    # get the percentage of time over two consequent calls of this
    # function where the CPU was occupied by any other task than the
    # bobsleigh task. Remember that the bobsleigh task informs us
    # of its PID, so this computation is possible!
    def getload_others(self):

        otherjiffies = 0
        for p in listdir("/proc"):
            try:
                pid = int(p)
                if pid == self.pid: continue
                info = file("/proc/%d/stat" % pid).read().split()
                otherjiffies += int(info[13]) + int(info[14])
            except ValueError:
                pass

        info = file("/proc/stat").read().split()
        idle = int(info[4])

        this_sec_other = float(otherjiffies - self.prev_otherjiffies)
        this_sec_idle  = float(idle - self.prev_idle)

        self.prev_otherjiffies = otherjiffies
        self.prev_idle = idle

        if this_sec_idle == 0 and this_sec_other == 0: return 0.0

        return (this_sec_other / (this_sec_idle + this_sec_other))

    # implement the dynamic decision based on load and interactive
    # usage characteristics
    def auto_update(self):

        idletime = self.getidle()
        loadavg = self.getload_others()
        print "load of others:", loadavg, "idle time:", idletime

        if idletime > 5000 and loadavg < 0.1:
            self.start_computing()
        else:
            self.stop_computing()
            
        return True

    # update the average load display.
    def load_update(self):
        self.load_label.set_label("Load average: " + str(self.getload_all()) + ", input idle for: " + str( self.getidle() / 1000 ) + " seconds.")
        return True

    # destroy the window
    def done(self):
        gobject.source_remove(self.timeout)
        gobject.source_remove(self.timeout2)
        if self.timeout3: gobject.source_remove(self.timeout3)
        self.destroy()
        main_quit()

    # called on start button clicked event
    def start(self, widget):
        self.disable_auto()
        self.start_computing()

    # called on stop button clicked event
    def stop(self, widget):
        self.disable_auto()
        self.stop_computing()

    def disable_auto(self):
        self.auto_button.set_active(False)

    def enable_auto(self):
        self.auto_button.set_active(True)

    # called on auto button toggled event
    def auto_toggle(self, widget):
        if widget.get_active():
            self.timeout3 = gobject.timeout_add(1000, self.auto_update)
            self.auto_update()
        else:
            if self.timeout3: gobject.source_remove(self.timeout3)
            self.timeout3 = None

# ----------------------------------------------------------------------
# Main code.

# register this node with the BobSleigh server

n.store("workers", host)

# this is a daemon, so loop forever.

while True:

    # wait for a new bobsleigh task
    t, pid = n.fetch("task_" + host)
    
    # launch a window when a bobsleigh task appears
    w = Control(t, pid)
    w.show_all()
    main()

    # after the task is done, we will return here automatically


