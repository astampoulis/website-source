# This file was created automatically by SWIG 1.3.27.
# Don't modify this file, modify the SWIG interface instead.

import _xss

# This file is compatible with both classic and new-style classes.
def _swig_setattr_nondynamic(self,class_type,name,value,static=1):
    if (name == "this"):
        if isinstance(value, class_type):
            self.__dict__[name] = value.this
            if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
            del value.thisown
            return
    method = class_type.__swig_setmethods__.get(name,None)
    if method: return method(self,value)
    if (not static) or hasattr(self,name) or (name == "thisown"):
        self.__dict__[name] = value
    else:
        raise AttributeError("You cannot add attributes to %s" % self)

def _swig_setattr(self,class_type,name,value):
    return _swig_setattr_nondynamic(self,class_type,name,value,0)

def _swig_getattr(self,class_type,name):
    method = class_type.__swig_getmethods__.get(name,None)
    if method: return method(self)
    raise AttributeError,name

import types
try:
    _object = types.ObjectType
    _newclass = 1
except AttributeError:
    class _object : pass
    _newclass = 0
del types


class XScreenSaverInfo(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, XScreenSaverInfo, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, XScreenSaverInfo, name)
    def __repr__(self):
        return "<%s.%s; proxy of C XScreenSaverInfo instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["window"] = _xss.XScreenSaverInfo_window_set
    __swig_getmethods__["window"] = _xss.XScreenSaverInfo_window_get
    if _newclass:window = property(_xss.XScreenSaverInfo_window_get, _xss.XScreenSaverInfo_window_set)
    __swig_setmethods__["state"] = _xss.XScreenSaverInfo_state_set
    __swig_getmethods__["state"] = _xss.XScreenSaverInfo_state_get
    if _newclass:state = property(_xss.XScreenSaverInfo_state_get, _xss.XScreenSaverInfo_state_set)
    __swig_setmethods__["kind"] = _xss.XScreenSaverInfo_kind_set
    __swig_getmethods__["kind"] = _xss.XScreenSaverInfo_kind_get
    if _newclass:kind = property(_xss.XScreenSaverInfo_kind_get, _xss.XScreenSaverInfo_kind_set)
    __swig_setmethods__["til_or_since"] = _xss.XScreenSaverInfo_til_or_since_set
    __swig_getmethods__["til_or_since"] = _xss.XScreenSaverInfo_til_or_since_get
    if _newclass:til_or_since = property(_xss.XScreenSaverInfo_til_or_since_get, _xss.XScreenSaverInfo_til_or_since_set)
    __swig_setmethods__["idle"] = _xss.XScreenSaverInfo_idle_set
    __swig_getmethods__["idle"] = _xss.XScreenSaverInfo_idle_get
    if _newclass:idle = property(_xss.XScreenSaverInfo_idle_get, _xss.XScreenSaverInfo_idle_set)
    __swig_setmethods__["eventMask"] = _xss.XScreenSaverInfo_eventMask_set
    __swig_getmethods__["eventMask"] = _xss.XScreenSaverInfo_eventMask_get
    if _newclass:eventMask = property(_xss.XScreenSaverInfo_eventMask_get, _xss.XScreenSaverInfo_eventMask_set)
    def __init__(self, *args):
        _swig_setattr(self, XScreenSaverInfo, 'this', _xss.new_XScreenSaverInfo(*args))
        _swig_setattr(self, XScreenSaverInfo, 'thisown', 1)
    def __del__(self, destroy=_xss.delete_XScreenSaverInfo):
        try:
            if self.thisown: destroy(self)
        except: pass


class XScreenSaverInfoPtr(XScreenSaverInfo):
    def __init__(self, this):
        _swig_setattr(self, XScreenSaverInfo, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, XScreenSaverInfo, 'thisown', 0)
        self.__class__ = XScreenSaverInfo
_xss.XScreenSaverInfo_swigregister(XScreenSaverInfoPtr)

ScreenSaverOff = _xss.ScreenSaverOff
ScreenSaverOn = _xss.ScreenSaverOn
ScreenSaverCycle = _xss.ScreenSaverCycle
ScreenSaverDisabled = _xss.ScreenSaverDisabled
ScreenSaverBlanked = _xss.ScreenSaverBlanked
ScreenSaverInternal = _xss.ScreenSaverInternal
ScreenSaverExternal = _xss.ScreenSaverExternal

get_info = _xss.get_info

cvar = _xss.cvar

