# Antonis Stampoulis, antonios.stampoulis@yale.edu

# This is the adaptive MapReduce implementation. This is based on the
# bobsleigh server/client architecture, which works as follows: All
# the potential workers have a bobsleigh client daemon running, which
# registers that worker node with the bobsleigh server. When a new
# computation comes along, a bobsleigh task is generated, informing
# the potential workers of its creation.  This computation runs in a
# sleigh that contains all the potential workers. But, the core of the
# task is only executed at will by the workers: All workers can
# decide, according to their load and interactive usage
# characteristics, whether they want to take part in the execution of
# that task or not. This decision is dynamic, throughout the execution
# of the task; the potential workers can join in or bail out of the
# computation at any point, with minimal overhead. The BobSleigh
# client running on each potential worker is the place where this
# decision is actually made.

# Using this architecture, MapReduce is implemented as follows:
# instead of using Sleigh, we use BobSleigh, which contacts the
# BobSleigh server in order to get the list of currently registered
# workers. A Sleigh is initiated using all of these workers. Then,
# when the map phase is about to start, a BobSleigh task is
# generated. The map code that the workers execute runs the actual
# computation based on the dynamic decision of each worker, incurring
# minimal overhead on the nodes that don't want to take part in the
# computation. If a worker bails out while executing a map task, it
# posts the rest of the task in the list of pending tasks, enabling
# someone else to grab it. When the map phase is done, either the
# master wraps up by executing the reduce operation on the resulting
# key-value pairs (when reduce is associative), or it initiates a
# second round of BobSleigh computation, for distributing the reduce
# tasks.

from nws.sleigh import Sleigh, sshcmd
from nws.client import NetWorkSpace
from socket import gethostname
from time import time, sleep
from os import getpid
import zlib
import pickle
import StringIO
import md5
import sys

# ----------------------------------------------------------------------
# The BobSleigh class.

# This class is used as a replacement for Sleigh. Instead of
# specifying the list of Sleigh workers as a parameter, we fetch that
# list off the BobSleigh server. This server is actually nothing more
# than a persistent network space named bobsleigh in an agreed-upon
# host.  While one program that uses bobsleigh is executing, no other
# bobsleigh program is permitted to execute, in order to make the
# implementation of the bobsleigh clients simpler; in production code
# we could remove this restriction. But, in our case, we must make
# sure that after we're done, somebody else can execute a BobSleigh
# program, something that is made sure by calling the provided done()
# method when our program won't produce other bobsleigh tasks.

# The class also provides two helper functions for creating new
# bobsleigh tasks and notifying for the completion of a task. The
# first function generates a unique name for the new task (having
# different names for different tasks makes matters simpler), while
# the second poisons all the workers waiting on getting allowed to
# work on that task.

class BobSleigh(Sleigh):

    def __init__(self, bob_host = "localhost"):

        self.bnws = NetWorkSpace("bobsleigh", bob_host, persistent = True)
        self.workers = []
        while True:
            worker = self.bnws.fetchTry('workers')
            if worker == None: break
            self.workers.append(worker)
        if not self.workers:
            print "No worker in bobsleigh!"
            sys.exit(0)
        Sleigh.__init__(self, nodeList = self.workers, launch = sshcmd)

    def done(self):

        for w in self.workers: self.bnws.store('workers', w)

    def new_bobsleigh_task(self):
        # create new task
        task_number = self.bnws.fetchTry("next_task_num")
        if task_number == None: task_number = 0
        self.bnws.store("next_task_num", task_number+1)
        bob_task = "bobtask" + str(task_number)

        return bob_task

    def bobsleigh_task_done(self, task):

        for w in self.workers: self.bnws.store(task + "_allowed_" + w, "done")


# ----------------------------------------------------------------------
# Code for the map-reduce master.

# The mapreduce function has the same signature as the equivalent
# function for the non-adaptive version. This means that there is no
# porting required from one version to the other; in fact, the sample
# programs are identical between the two implementations of MapReduce.

# Out of the parameters, the workers list is unnecessary and gets
# ignored here, because the workers are specified by the BobSleigh
# architecture.

def mapreduce(workers,
              module,
              gen_params,
              map_params,
              reduce_params,
              reduce_assoc,
              reduce_tasks):

    # By default we assume that the bobsleigh server is the server
    # where the master process is run.
    bobhost = gethostname()
    s = BobSleigh()

    # since BobSleigh is a sub-class of Sleigh, we can use the
    # standard Sleigh methods for initialization, etc.
    
    s.eachWorker('from mapreduce import *')
    s.eachWorker('import ' + module.__name__)

    # Find out how many map tasks there are, and post them. The task
    # description is the task number plus the starting element in the
    # partition (initially this is always zero). Note that this part
    # is different than the original MapReduce implementation: here we
    # need to know how many tasks there are, in order to be able to
    # tell when all the tasks are done! Of course, this incurs the
    # extra (non-parallelizable) overhead on the master of generating
    # all the partitions, which we have avoided in the normal
    # implementation.
    
    gen = module.gen(*gen_params)
    num_tasks = 0
    while True:
        try:
            gen.next()
            num_tasks += 1
        except StopIteration:
            break

    for i in range(num_tasks): s.nws.store('map_phase_task', (i,0))

    # we initiate a BobSleigh task, and run the worker code in *every*
    # potential worker. Then, we wait until all tasks are done (we
    # know how many there are, so we can do this), and then we poison
    # all the workers: both those waiting on a new task, and those
    # waiting to be allowed to get tasks. Note that poisoning before
    # all tasks are done would not work, as new tasks can be generated
    # by the workers themselves. This is the case when a worker bails
    # out of computation while it is executing a task.

    map_bobtask = s.new_bobsleigh_task()
    map_done = s.eachWorker(map_runner, bobhost, map_bobtask, module.gen, gen_params,
                            module.map, map_params, module.reduc,
                            reduce_params, reduce_assoc, reduce_tasks, blocking = False)
    for i in range(num_tasks): s.nws.fetch('map_phase_task_done')
    s.nws.store('map_phase_task', None)
    s.bobsleigh_task_done(map_bobtask)
    map_done.wait()

    # What we do next depends on whether the reduce operation is
    # associative or not. If it's associative we proceed as in the
    # normal mapreduce implementation.

    if reduce_assoc:

        results = dict()
        
        def my_emit(k, v):
            results[k] = [v]
        
        while True:
            r = s.nws.fetchTry('map_phase_result')
            if r == None: break
            d = zunpickle(r)
            for k in d:
                module.reduc(my_emit, k, results.get(k,[]) + d[k])

        # important: call the done method of the BobSleigh so that
        # another program can use the workers of the BobSleigh.
        s.done()

        return results
    
    else:

        # otherwise we have to generate new bobsleigh tasks to execute
        # the reduce operation in a distributed manner. Note that in
        # this case we do not permit for computation to be terminated
        # while a worker has grabbed a reduce task and is executing
        # it, because the overhead would be greater than finishing the
        # task: the worker would have to store back to the network
        # space the intermediate key-value pairs from the map phase.
        
        for i in range(reduce_tasks): s.nws.store('reduce_phase_task', i)

        reduce_bobtask = s.new_bobsleigh_task()
        reduce_done = s.eachWorker(reduce_runner, bobhost, reduce_bobtask, module.reduc, reduce_params, blocking = False)

        for i in range(reduce_tasks): s.nws.fetch('reduce_phase_task_done')

        s.nws.store('reduce_phase_task', -1)
        s.bobsleigh_task_done(reduce_bobtask)
        reduce_done.wait()

        # when the reduce workers are done, we just gather the results.

        results = dict()
        while True:
            r = s.nws.fetchTry('reduce_phase_result')
            if r == None: break
            d = zunpickle(r)
            results.update(d)

        s.done()

        return results

# ----------------------------------------------------------------------
# Code for the map-reduce workers.

# These are the same as in the normal implementation.

def zpickle(obj):
    return obj
    #s = StringIO.StringIO()
    #p = pickle.Pickler(s)
    #p.dump(obj)
    #r = zlib.compress(s.getvalue())
    #return r

def zunpickle(s):
    return s
    #st = StringIO.StringIO(zlib.decompress(s))
    #p = pickle.Unpickler(st)
    #return p.load()

def my_hash(w, n):
    return sum(ord(c) for c in md5.md5(str(w)).digest()) % n

map_results = dict()

def map_emit(k, v):
    map_results[k] = map_results.get(k,[]) + [v]
        
reduce_results = dict()

def reduce_emit(k, v):
    reduce_results[k] = [v]

# The get_chunk function caches the results of the input-set partition
# generating function. This is useful because, contrary to the normal
# map-reduce code, the tasks that a worker gets assigned are not
# necessarily sequential: a node might grab task 1, execute it, and
# then it might grab task 0, which was abandoned mid-computation by
# some other node.

input_cache = []
def get_chunk(n, chunk_gen, chunk_num):

    if n <= chunk_num:
        
        return (input_cache[n], chunk_num)
    
    else:

        while chunk_num < n:
            chunk = chunk_gen.next()
            input_cache.append(chunk)
            chunk_num += 1

        return (chunk, chunk_num)

# The code that is run on the workers, in the map phase.

def map_runner(bobhost, bobtask, gen_op, gen_params, map_op, map_params, reduce_op, reduce_params, reduce_assoc, reduce_tasks):

    chunk_gen = gen_op(*gen_params)
    chunk_num = -1

    # Connect to the BobSleigh server.
    bobnws = NetWorkSpace("bobsleigh", bobhost)
    
    # Store the task along with our current PID in the server, so that
    # the BobSleigh client running on our node can get informed of the
    # new task.
    me = gethostname()
    bobnws.store("task_" + me, (bobtask, getpid()))

    # The names of the variables that the BobSleigh client
    # updates. The first signifies whether we are allowed to grab a
    # task, and the second whether we are still allowed to work on the
    # task if we have grabbed one.
    allowed_var = bobtask + "_allowed_" + me
    still_var = bobtask + "_stillallowed_" + me


    while True:

        # wait until we are allowed to grab a task. If the computation
        # is over, we get poisoned, and break out of the loop.
        am_i_allowed = bobnws.find(allowed_var)
        if am_i_allowed == "done": break

        # now we're allowed to take part in the computation, so grab
        # a task.
        task = SleighNws.fetch('map_phase_task')
        if task == None:
            # tasks are over and we got poisoned.
            # remove the allowed = True value that we are sure that
            # exists (since we did a find for this variable and not
            # a fetch)
            bobnws.fetch(allowed_var) 
            SleighNws.store('map_phase_task', task)
            break
        task_chunk, task_start = task

        # get the chunk that the task specifies.
        chunk, chunk_num = get_chunk(task_chunk, chunk_gen, chunk_num)

        # iterate over the chunk, and execute the map operation. Note
        # that we start from the point in the chunk where the task
        # description specifies.
        start_time = time()
        current = task_start
        for inp in chunk[task_start:]:

            # periodically (every 100msec) we check with the BobSleigh
            # server to see whether we're still allowed to execute this
            # computation. If we're not, we store the rest of the task
            # for somebody else to execute.
            if time() - start_time > 0.1:
                start_time = time()
                still_allowed = bobnws.find(still_var)
                if not still_allowed:
                    SleighNws.store('map_phase_task', (task_chunk, current))
                    break
            
            map_op(map_emit, inp, *map_params)
            current += 1
        else:
            # if we're done with the task, inform the master.
            SleighNws.store('map_phase_task_done', 1)


    # now we've got the map results, and we need to either process
    # them before posting them to the network space (if reduce is
    # associative), or partition them into reduce-chunks. 

    if not map_results:
        return

    if reduce_assoc:

        # This is exactly the same as the normal version; this also
        # means that even workers that were allowed to work during
        # some part of the computation and are not allowed any more
        # will still do some work. This is not a problem because,
        # presumably, the reduce operation is faster than storing the
        # full intermediate results back.

        for k in map_results:
            reduce_op(reduce_emit, k, map_results[k], *reduce_params)
        SleighNws.store('map_phase_result', zpickle(reduce_results))

    else:

        map_results_hashed = dict()
        for k in map_results:
            hk = my_hash(k, reduce_tasks)
            map_results_hashed[hk] = map_results_hashed.get(hk,[]) + [(k,map_results[k])]
        for k in map_results_hashed:
            SleighNws.store('reduce_chunk_' + str(k), zpickle(map_results_hashed[k]))


# The code that the workers execute in the reduce phase.

def reduce_runner(bobhost, bobtask, reduce_op, reduce_params):

    bobnws = NetWorkSpace("bobsleigh", bobhost)
    me = gethostname()
    bobnws.store("task_" + me, (bobtask, getpid()))
    allowed_var = bobtask + "_allowed_" + me

    # This is more or less the same as the normal version, with the
    # exception that before grabbing a task, each node waits until it
    # is allowed to grab a task.

    while True:

        am_i_allowed = bobnws.find(allowed_var)
        if am_i_allowed == "done": break
        
        task = SleighNws.fetch('reduce_phase_task')
        if task == -1:
            bobnws.fetch(allowed_var)
            SleighNws.store('reduce_phase_task', -1)
            break

        inp = dict()
        while True:
            r = SleighNws.fetchTry('reduce_chunk_' + str(task))
            if r == None: break
            d = zunpickle(r)
            for (k,l) in d: inp[k] = inp.get(k,[]) + l


        # note that here we execute the whole reduce task that we
        # just grabbed. This is because posting the reduce_chunk
        # back is probably more work than finishing the task and
        # posting the result.
        for k in inp:
            reduce_op(reduce_emit, k, inp[k], *reduce_params)

        SleighNws.store('reduce_phase_task_done', 1)

    if reduce_results:
        SleighNws.store('reduce_phase_result', zpickle(reduce_results))

