from os import walk
from os.path import join, getsize

def generate_tasks(path, chunk_size):
    current_size = 0
    current_partition = []
    tasks = []
    for root, dirs, files in walk(path):
        for fn in files:
            name = join(root, fn)
            size = getsize(name)
            current_partition.append(name)
            current_size += size
            if current_size > chunk_size:
                yield current_partition
                current_size = 0
                current_partition = []
    if current_size > 0:
        yield current_partition

def worker(path, chunk_size):
    cur_max = ""
    gen = generate_tasks(path, chunk_size)
    cur = -1
    done = False
    
    while True:
        ticket = SleighNws.fetch('max_ticket')
        SleighNws.store('max_ticket', ticket+1)
        while cur < ticket:
            try:
                files = gen.next()
                cur += 1
            except StopIteration:
                done = True
                break
        if done: break
        for fn in files:
            l = file(fn).readlines()
            l.append(cur_max)
            cur_max = max(l)

    SleighNws.store('max_line', cur_max)
