from os import walk
from os.path import join, getsize
import re
import zlib
import pickle
import StringIO

# ----------------------------------------------------------------------
# these are not used (the gain because of communication overhead is
# less than the loss of computational overhead)

def zpickle(obj):
    s = StringIO.StringIO()
    p = pickle.Pickler(s)
    p.dump(obj)
    r = zlib.compress(s.getvalue())
    return r

def zunpickle(s):
    st = StringIO.StringIO(zlib.decompress(s))
    p = pickle.Unpickler(st)
    return p.load()

# ----------------------------------------------------------------------


def generate_chunks(path, chunk_size):
    current_size = 0
    current_partition = []
    for root, dirs, files in walk(path):
        for fn in files:
            name = join(root, fn)
            size = getsize(name)
            current_partition.append(name)
            current_size += size
            if current_size > chunk_size:
                yield current_partition
                current_size = 0
                current_partition = []
    if current_size > 0:
        yield current_partition

def worker(path, chunk_size, pattern):

    results = dict()
    regexp = re.compile(pattern)
    chunk_num = -1
    chunk_gen = generate_chunks(path, chunk_size)
    done = False
    
    while not done:
        ticket = SleighNws.fetch('search_ticket')
        SleighNws.store('search_ticket', ticket+1)
        while chunk_num < ticket:
            try:
                chunk = chunk_gen.next()
                chunk_num = chunk_num + 1
            except StopIteration:
                done = True
                break
        if not done:
            for fn in chunk:
                f = file(fn)
                contents = f.read()
                matches = regexp.findall(contents)
                for i in matches:
                    results[i] = results.get(i,0) + 1
                f.close()

    SleighNws.store('search_result', results)

    SleighNws.store('search_done', 1)
