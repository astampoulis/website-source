# Antonis Stampoulis, antonios.stampoulis@yale.edu

# This is the dictionary grep, implemented using NWS. We use the same
# trick as in maxline, in order to reduce the communication overhead:
# the description of a task is just a number, and partitions are
# generated in the workers (so they're not sent as task descriptions
# from the master).

from nws.sleigh import Sleigh, sshcmd
from nws.client import NetWorkSpace
from time import time

from os import walk
from os.path import join, getsize
import re
import sys

workers = [ 'aphid', 'grizzly', 'jaguar' ]
s = Sleigh(nodeList = workers, launch = sshcmd)

import dgrep_aux
s.eachWorker('import dgrep_aux')

def master(path, chunk_size, pattern):

    s.eachWorker(dgrep_aux.worker, path, chunk_size, pattern, blocking = False)
    s.nws.store('search_ticket', 0)

    for i in range(len(workers)):
        s.nws.fetch('search_done')

    results = dict()
    while True:
        r = s.nws.fetchTry('search_result')
        if not r: break
        for k in r: results[k] = results.get(k,0) + r[k]

    return results

if len(sys.argv) >= 3:
    directory = sys.argv[1]
    pattern = sys.argv[2]
else:
    directory = "/usr/src/linux"
    pattern = "hello|world|[a-z]{10}"

results = master(directory, 32*1024*1024, pattern)
print len(results)


