# Antonis Stampoulis, antonios.stampoulis@yale.edu

# This finds the maximum line over a set of files, and uses NWS and
# Sleigh for distributing the computation among a set of workers. Each
# worker grabs a number of partitions of files, partitioned so as to
# be almost of the same bytesize. Note that we use something like the
# DIY parallelism to hand off tasks to the workers: the workers have a
# generator function for the partitions of the input set, and grab
# tickets, denoting the number of the task they are to process
# next. This means that the communication overhead is low, since the
# master doesn't have to generate the partitions and send their
# descriptors (which are big) off to the workers.


from nws.sleigh import Sleigh, sshcmd
from nws.client import NetWorkSpace
from time import time

import sys

workers = [ 'frog', 'gator', 'hippo' ]
s = Sleigh(nodeList = workers, launch = sshcmd)

import maxline_aux

def master(path, chunk_size):

    s.nws.store('max_ticket', 0)
    s.eachWorker('import maxline_aux')
    s.eachWorker(maxline_aux.worker,path,chunk_size,blocking = False)
    cur_max = ""
    for i in workers:
        cur_max = max(cur_max, s.nws.fetch('max_line'))
    return cur_max

if len(sys.argv) >= 3:
    directory = sys.argv[1]
else:
    directory = "/usr/src/linux"

result = master(directory, 32*1024*1024)
print result


