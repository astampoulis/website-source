# Antonis Stampoulis, antonios.stampoulis@yale.edu

# This is the prime numbers finder, implemented using NWS. We are
# using chunking with a fixed chunk size. The description of a task is
# simply the start number of the chunk, and not the list of numbers in
# the chunk, thus reducing the communication overhead.

from nws.sleigh import Sleigh, sshcmd
from nws.client import NetWorkSpace
from math import sqrt, floor, ceil
from time import time

s = Sleigh(nodeList = ['aphid', 'grizzly', 'hornet', 'lion', 'monkey', 'newt' ], launch = sshcmd)
s.eachWorker('from math import sqrt, floor')

def primefinder(n,chunk):

    def prime_test(chunk_start, t):
	chunk_size, n = t
        primes = []
        l = (chunk_start == 3 and [2] or [])
        l.extend(range(chunk_start,min(chunk_start+2*chunk_size,n+1),2))
        # test all numbers in the chunk
        for i in l:
            for test_factor in range(2, floor(sqrt(i))+1):
                if i % test_factor == 0:
                    break
            else:
                primes.append(i)
        SleighNws.store('prime_table',primes)

    def chunk_start_list():
        l = []
        i = 3
        while i < n:
            l.append(i)
            i += 2*chunk
        return l

    s.eachElem(prime_test, chunk_start_list(), (chunk,n))

    primes = []
    while True:
        r = s.nws.fetchTry('prime_table')
        if r == None: break
        primes.extend(r)

    print len(primes)

primefinder(500000,5000)
