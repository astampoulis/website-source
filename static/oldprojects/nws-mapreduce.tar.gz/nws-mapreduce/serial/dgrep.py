# Antonis Stampoulis, antonios.stampoulis@yale.edu

# dictionary grep -- serial implementation
# this matches a regexp against a set of files (all files under a directory)
# and returns all the substrings that match the regexp, plus how many times
# each substring matches.

# results from runs on zoo machines with light loads:
#  first time (nothing cached): ~58 seconds
#  second time (most files are cached): ~29 seconds

from os import walk
from os.path import join, getsize
import re
import sys

def grep(basepath, pattern):

    results = dict()
    regexp = re.compile(pattern)

    for root, dirs, files in walk(basepath):
        for fn in files:
            name = join(root, fn)
            contents = file(name).read()
            matches = regexp.findall(contents)
            for i in matches:
                results[i] = results.get(i,0) + 1

    return results

if len(sys.argv) >= 3:
    directory = sys.argv[1]
    pattern = sys.argv[2]
else:
    directory = "/usr/src/linux"
    pattern = "hello|world|[a-z]{10}"

results = grep(directory, pattern)
print len(results)
