# Antonis Stampoulis, antonios.stampoulis@yale.edu

# Serial prime finder

from math import sqrt, floor, ceil
from time import time

def is_prime(i):
    for div in range(2, int(floor(sqrt(i)))+1):
        if i % div == 0:
            return False
    else:
        return True

def primefinder(n):
    primes = []
    for i in [2]+range(3,n+1,2):
        if is_prime(i): primes.append(i)
    print len(primes)

primefinder(500000)
