# Antonis Stampoulis, antonios.stampoulis@yale.edu

# Find max line of a set of files.

from os import walk
from os.path import join, getsize
import sys

def maxline(basepath):

    curmax = ""
    for root, dirs, files in walk(basepath):
        for fn in files:
            name = join(root, fn)
            contents = file(name).readlines()
            contents.append(curmax)
            curmax = max(contents)

    return curmax

if len(sys.argv) >= 3:
    directory = sys.argv[1]
else:
    directory = "/usr/src/linux"

l = maxline(directory)
print str(l)
