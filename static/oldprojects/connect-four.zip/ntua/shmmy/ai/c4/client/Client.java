package ntua.shmmy.ai.c4.client;

import java.net.*;
import java.io.*;

abstract public class Client extends Thread {

    String server;
    
    public Client(String server) {
        this.server = server;
    }
    
    public void run () {
        try {
			Socket s = new Socket(server, 4444);
			s.getOutputStream().write('P');
			synchronized (this) {
				notifyAll();
			}
			InputStream in = s.getInputStream();
			OutputStream out = s.getOutputStream();
			int first = in.read();
			GameStart(first == '1' ? true : false);
			if (first == '1') {
				int move = MyMove();
				out.write(move + '0');
				if (move == 0)
					return;
			}
			while (true) {
				int move = in.read() - '0';
				int ret = in.read() - '0';
				OtherMove(move);
				if (move == 0 || ret != 0) {
					OnEnd(ret);
					break;
				}
				move = MyMove();
				out.write(move + '0');
				if (move == 0)
					return;
			}
			s.close();
		} catch (IOException e) {
			System.out.println(e.getMessage());
			System.exit(1);
		}
    }
    
    abstract public void GameStart(boolean first);
    abstract public int MyMove();
    abstract public void OtherMove(int col);
    abstract public void OnEnd(int status);
    
}
