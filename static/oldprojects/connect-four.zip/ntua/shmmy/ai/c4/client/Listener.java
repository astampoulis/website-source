package ntua.shmmy.ai.c4.client;

import java.net.*;
import java.io.*;

abstract public class Listener extends Thread {
    
    String server;
    
    public Listener(String server) {
        this.server = server;
    }
    
    public void run () {
        try {
        Socket s = new Socket(server, 4444);
        s.getOutputStream().write('L');
        synchronized(this) { notifyAll(); }
        InputStream in = s.getInputStream();
        in.read(); OnPlayerConnect();
        in.read(); OnPlayerConnect();
        int first = in.read(); OnStart(first-'0');
        while (true) {
            int move = in.read() - '0';
            int ret = in.read() - '0';
            if (move!=0) OnMove(move);
            if (move==0 || ret!=0) {
                OnEnd(ret); break;
            }
        }
        s.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
            System.exit(1);
        }
        synchronized(this) { notifyAll(); }
    }
    
    abstract public void OnStart(int first);
    abstract public void OnMove(int col);   
    abstract public void OnPlayerConnect();
    abstract public void OnEnd(int status);
    
}
