package ntua.shmmy.ai.c4.client;

public class AIClient extends Client {
	
	final private int MAX_TETRADES = 69, MAX_SYMMETOXH = 13, INF = Integer.MAX_VALUE;
	
	final private int table[][] = new int[6][7];
	final private int howmany[] = new int[7];
	
	private class Tetrada {
		public int row[] = new int [4];
		public int col[] = new int [4];
		public int occupied[] = new int[2];
		public Tetrada() { }
		public Tetrada(int r1,int c1,int r2,int c2,int r3,int c3,int r4,int c4) {
			row[0]=r1;row[1]=r2;row[2]=r3;row[3]=r4;
			col[0]=c1;col[1]=c2;col[2]=c3;col[3]=c4;
			occupied[0] = occupied[1] = 0;
		}
	}
	
	final private Tetrada tetrades[] = new Tetrada[MAX_TETRADES];
	final private int symmetoxh[][][] = new int[6][7][MAX_SYMMETOXH];
	final private int sym_num[][] = new int[6][7];
	
	int ab_result;
	
	public AIClient (String host) {
		super(host);
		
		int i, j, t;
		for (i=0; i<7; i++) howmany[i]=0;
		for (i=0; i<6; i++)
			for (j=0; j<7; j++)
				 table[i][j] = 0;
		
		t = 0;
		for (i=0; i<6; i++) {
			for (j=0; j<7; j++) {
				// orizontia 
				if (j+3<7) {
					Tetrada cur =  new Tetrada(i,j, i,j+1, i,j+2, i,j+3);
					tetrades[t++] = cur;
				}

				// katheta
				if (i+3<6) {
					Tetrada cur = new Tetrada(i,j, i+1,j, i+2,j, i+3,j);
					tetrades[t++] = cur;
				}

				// diagwnia (\)
				if (i+3<6 && j-3>=0) {
					Tetrada cur = new Tetrada(i,j, i+1,j-1, i+2,j-2, i+3,j-3);
 				    tetrades[t++] = cur;
				}

				if (i+3<6 && j+3<7) {
					Tetrada cur = new Tetrada(i,j, i+1,j+1, i+2,j+2, i+3,j+3);
					 tetrades[t++] = cur;
				}
				
			}
		}

		for (i=0;i<6;i++)
			for (j=0;j<7;j++)
				 sym_num[i][j] = 0;

		for (i=0;i<MAX_TETRADES;i++) {
			for (j=0;j<4;j++) {
				int row = tetrades[i].row[j];
				int col = tetrades[i].col[j];
				symmetoxh[row][col][sym_num[row][col]++] = i;
			}
		}

	}
	
	boolean playFirst;
	int move;
	
	public void GameStart(boolean first) {
		playFirst = first;
		move=0;
	}

	public int MyMove() {
		print();
		AlphaBeta_Max(-INF, INF, move>20?24:10, true);
		System.out.println(ab_result);
		move++;
		Insert(ab_result,1);
		return ab_result+1;
	}

	public void OtherMove(int col) {
		if (col!=0) {
			move++;
			Insert(col-1,2);
		}
	}

	public void OnEnd(int status) { }
	
	void print () {
		int i,j;
		System.out.println("\n-------");
		for (i=0;i<6;i++) {
			for (j=0;j<7;j++)
				System.out.print(table[5-i][j]);
			System.out.println();
		}
		System.out.println("-------");
		System.out.println("0123456");
		System.out.println("-------\n");
			
	}
		
	private void Insert (int col, int color) {

		int i, row;
		
		row = howmany[col]++;
		table[row][col] = color;
		for (i=0;i<sym_num[row][col];i++)
			tetrades[symmetoxh[row][col][i]].occupied[color-1]++;
	
	}
	
	private void Remove (int col) {

		int i, row, color;
		
		row = --howmany[col]; color = table[row][col];
		table[row][col] = 0;
		for (i=0;i<sym_num[row][col];i++)
			tetrades[symmetoxh[row][col][i]].occupied[color-1]--;
		
	}
	
	final private int order[] = { 3,1,5,2,4,0,6 };
	
	private int AlphaBeta_Max (int a, int b, int depth, boolean storeResult) {

		int i, j;
		int maxcol = -1;
		int keep[]={0,0,0,0,0,0,0};

		for (j=0;j<7;j++) {
			int cur;
			i=j;
			if (howmany[i]==6) continue;
			Insert(i, 1);
			cur = evaluate_fast(i, 1);
			keep[i] = cur;
			Remove(i);
			if (cur==INF) {
				if (storeResult) ab_result = i;
				return (b<INF)?b:cur;
			}
		}
		
		for (j=0;j<7;j++) {
			
			int cur;

			i = order[j];
			
			if (howmany[i]==6) continue;
			if (maxcol == -1) maxcol = i;
			
			Insert(i,1);
			cur = keep[i];
			if (cur==-1) {
				if (depth == 1) cur = evaluate(i, 2);
				else cur = AlphaBeta_Min(a, b, depth-1);
			}
			
			if (storeResult) {
		       	System.out.println("column->" + i + "eval->" + cur);
			}

			if (cur>a) { a = cur; maxcol = i; }
			Remove(i);
			
			if (a>=b) {
				if (storeResult) ab_result = maxcol;
				return b;
			}
		}
		
		if (storeResult) ab_result = maxcol;
		return a;
		
	}
	

	private int AlphaBeta_Min (int a, int b, int depth) {

		int i, j;
		int keep[]={0,0,0,0,0,0,0};

		for (j=0;j<7;j++) {
			int cur;
			i = j;
			if (howmany[i]==6) continue;
			Insert(i, 2);
			cur = evaluate_fast(i, 2);
			keep[i] = cur;
			Remove(i);
			if (cur==-INF) {
				return (a>-INF)?a:cur;
			}
		}

		
		for (j=0;j<7;j++) {
			
			int cur;
			
			i = order[j];
			
			if (howmany[i]==6) continue;
			
			Insert(i, 2);
			cur = keep[i];
			if (cur==-1) {
				if (depth == 1) cur = evaluate(i, 1);
				else cur = AlphaBeta_Max(a, b, depth-1, false);
			}
			if (cur<b) b = cur;
			Remove(i);
			
			if (a>=b) return a;
			
		}
		
		return b;

	}
	
	private int evaluate_fast (int col, int whoPlayed) {

		int w = whoPlayed, hw = (w==1?INF:-INF);
	    int row = howmany[col]-1;
		int k;
	        
		for (k=0;k<sym_num[row][col];k++) {
			if (tetrades[symmetoxh[row][col][k]].occupied[w-1] == 4) return hw;
		}	

		boolean allFull = true;
		for (k=0;k<7;k++) if (howmany[k]!=6) { allFull = false; break; }
		if (allFull) return 0;
	        
        return -1;
	}
	
	private int evaluate (int col, int whoPlaysNext) {

		int i, cur = 0, total = 0;

		for (i=0;i<MAX_TETRADES;i++) {
			int good = tetrades[i].occupied[0], bad = tetrades[i].occupied[1];
			if ((good!=0 && bad!=0) || (good==0 && bad==0)) cur = 0;
			else {				
				if (good!=0) {
					switch(good) {
					case 1: cur = 1; break;
					case 2: cur = 20; break;
					case 3: cur = 100; break;
					}
				} else {
					switch(bad) {
					case 1: cur = 1; break;
					case 2: cur = -20; break;
					case 3: cur = -100; break;
					}
				}
				
			}
			total += cur;
		}
		
		int[] odd={0,0}, even={0,0};
		
		for (int c=0;c<7;c++) {
			for (int r=howmany[c];r<6;r++) {
				
				boolean firstInCol = true;
				
				for (int t=0;t<sym_num[r][c];t++) {
					
					i = symmetoxh[r][c][t];
					
					if (tetrades[i].occupied[0] != 3 &&
						tetrades[i].occupied[1] != 3) 
						continue;
					
					if (tetrades[i].occupied[0] == 3) {
						if (r%2==0) { 
							if (firstInCol) { odd[0] += 2; firstInCol = false; }
							else { odd[0]++; }
						}
						else even[0]++;
					} else {
						if (r%2==0) {
							if (firstInCol) { odd[1] += 2; firstInCol = false; }
							else { odd[1]++; }
						}
						else even[1]++;
					}
										
				}
				
			}
		}
		
		cur = odd[0]*2 + even[0] - odd[1]*2 - even[1];
		if (playFirst)
			total += cur;
		else
			total -= cur;
		
		
		return total;

	}


}
