package ntua.shmmy.ai.c4.server;

import java.net.*;
import java.io.*;
import java.util.*;

public class Server extends Thread {
	
	public static final int C4_PORT = 4444;
	
	public void run () {
		
		final Random random = new Random();
		ArrayList listeners = new ArrayList();
		int index = 0;
		Socket [] sockets = new Socket[2];
		
		try {
			
			ServerSocket listen = new ServerSocket(C4_PORT);
			listen.setReuseAddress(true);
			while (true) {
				Socket csock = listen.accept();
				int type = csock.getInputStream().read();
				if (type == 'L') {
					listeners.add(csock);
					if (index == 1)
						csock.getOutputStream().write('.');
				} else {

					sockets[index] = csock;

					Iterator i = listeners.iterator();
					while (i.hasNext()) {
						((Socket) i.next()).getOutputStream().write('.');
					}

					index++;
					if (index >= 2) {
						index = 0;
						int first = 0;
						if (random.nextBoolean())
							first = 1;
						i = listeners.iterator();
						while (i.hasNext()) {
							((Socket) i.next()).getOutputStream().write(first + '1');
						}
						new Game(sockets[first], sockets[1 - first], listeners.toArray());
						listeners = new ArrayList();
					}
				}
			}
			
		} catch (IOException e) {
			System.out.println(e.getMessage());
			System.exit(1);
		}
		
		
	}
	
	static public void startServer () {
		(new Server()).start();
	}
	
	public static void main(String[] args) {
		startServer();
	}

}
