package ntua.shmmy.ai.c4.server;

import java.net.*;
import java.io.*;


public class Game extends Thread {
    
    private Socket pl1, pl2;
    
    private InputStream in1, in2;
    
    private OutputStream out1, out2;
    
    private int[] howmany = { 0,0,0,0,0,0,0 };
    private int[][] table = new int[7][6];
    
    private Object[] listen;
    
    private int notFull = 7;
    
    static final public int OK = 0, EXITED = 5, INVALID = 1, FULL = 2, PL1WIN = 3, PL2WIN = 4;
    
    public Game(Socket s1, Socket s2, Object[] listen) {
        try {
            this.pl1 = s1;
            this.in1 = s1.getInputStream();
            this.out1 = s1.getOutputStream();
            out1.write('1');
            this.pl2 = s2;
            this.in2 = s2.getInputStream();
            this.out2 = s2.getOutputStream();
            out2.write('2');
            this.listen = listen;
        } catch (IOException e) {
            System.out.println(e.getMessage());
            System.exit(1);
        }
        start();
    }
    
    public void run() {
	    
        try {
            int pl = 0;
            while (true) {
                
                int move, ret = OK;

				move = in1.read();
				if (move == -1)
					move = 0;
				else
					move -= '0';
		
                ret = CheckMove(move, pl + 1);
                if (ret == INVALID) move=0;
                
                out2.write(move+'0');
                out2.write(ret+'0');

                try {
                for (int i=0;i<listen.length;i++) {
                    ((Socket)listen[i]).getOutputStream().write(move+'0');
                    ((Socket)listen[i]).getOutputStream().write(ret+'0');
                }
                } catch (IOException e) { }
                
                if (move != 0 && ret != 0) {
                    out1.write('0'); out1.write(ret + '0');
                    break;
                }
		
                InputStream t = in1;
                in1 = in2;
                in2 = t;
                OutputStream t2 = out2;
                out2 = out1;
                out1 = t2;
                pl = 1 - pl;
                
            }
            pl1.close(); pl2.close();
            for (int i=0;i<listen.length;i++)
                    ((Socket)listen[i]).close();
            
        } catch (IOException e1) {
			// Disconnect everybody.
			try { out1.write('0'); out1.write('0'); } catch (IOException e) { }
			try { out2.write('0'); out2.write('0'); } catch (IOException e) { }
                for (int i=0;i<listen.length;i++) {
				try {
                    			((Socket)listen[i]).getOutputStream().write('0');
                    			((Socket)listen[i]).getOutputStream().write('0');
				} catch (IOException e) { }
			}
			
	}
        
    }
    
    public int CheckMove(int col, int w) {
        
        if (col==0) return EXITED;
        if (col<0 || col>7) return INVALID;
        col--;
        
        if (howmany[col] == 6) return INVALID;
        
        howmany[col]++;
        
        table[col][howmany[col]-1] = w;
        int row = howmany[col]-1;
        
        // Horizontal check.
        boolean leftPossible = true, rightPossible = true;
        int howManyInRow = 1;
        for (int j = 1; j<4; j++) {
            
            if (leftPossible) {
                if (col-j>=0 && table[col-j][row] == w) howManyInRow++;
                else leftPossible = false;
            }
            
            if (rightPossible) {
                if (col+j<7 && table[col+j][row] == w) howManyInRow++;
                else rightPossible = false;
            }
            
            if (howManyInRow>=4) return FULL + w;
            if (!leftPossible && !rightPossible) break;
            
        }
        
        // Vertical check.
        boolean vertical4 = true;
        for (int k=1;k<4;k++) {
            if (row-k<0 || table[col][row-k] != w) {
                vertical4 = false;
                break;
            }
        }
        if (vertical4) return FULL + w;
        
        // Diagonal (\) check.
        boolean ul = true, dr = true;
        int howManyInLR = 1;
        for (int k=1;k<4;k++) {
            
            if (ul) {
                if (row+k < 6 && col-k>=0 && table[col-k][row+k] == w) howManyInLR++;
                else ul = false;
            }
            if (dr) {
                if (row-k >= 0 && col+k<7 && table[col+k][row-k] == w) howManyInLR++;
                else dr = false;
            }
            if (howManyInLR>=4) return FULL+w;
            if (!ul && !dr) break;
        }

        // Diagonal (/) check.
        boolean dl = true, ur = true;
        int howManyInRL = 1;
        for (int k=1;k<4;k++) {
            
            if (dl) {
                if (row-k >= 0 && col-k>=0 && table[col-k][row-k] == w) howManyInRL++;
                else dl = false;
            }
            if (ur) {
                if (row+k < 6 && col+k<7 && table[col+k][row+k] == w) howManyInRL++;
                else ur = false;
            }
            if (howManyInRL>=4) return FULL+w;
            if (!ur && !dl) break;
        }

        if (howmany[col] == 6) {
            notFull--;
        }
        if (notFull == 0) return FULL;

        
        return OK;
    }
    
}
