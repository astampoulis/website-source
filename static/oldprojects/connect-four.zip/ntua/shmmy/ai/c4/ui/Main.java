package ntua.shmmy.ai.c4.ui;

import javax.swing.*;
import java.awt.event.*;
import ntua.shmmy.ai.c4.client.*;
import ntua.shmmy.ai.c4.server.*;

public class Main extends JFrame {

	public GameBoard gameboard;
	Server server = null;
	String serverHost = "localhost";
	Listener listener = null;
	HumanClient pl1 = null, pl2 = null;

	final static int HUMAN = 0, CPU = 1, OTHER = 2;
	int pl1Type = HUMAN, pl2Type = CPU;

	public Main() {

		initComponents();
		gameboard = new GameBoard();
		getContentPane().add(gameboard, java.awt.BorderLayout.CENTER);
		this.setSize(gameboard.getWidth(), gameboard.getHeight() + 24);
		this.setTitle("Connect Four");

		this.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent evt) {
				stopGame();
			}
		});

		server = new Server();
		server.setDaemon(true);
		server.start();

	}

	private void NewGame() {

		if (listener != null) stopGame();

		gameboard.emptyBoard();
		
		listener = new UIListener(serverHost, this);
		synchronized (listener) {
			listener.start();
			try { listener.wait(); } catch (InterruptedException e) { }
		}

		Thread t = null;

		if (pl1Type == HUMAN) {
			t = pl1 = new HumanClient(serverHost, this);
		} else if (pl1Type == CPU) {
			t = new AIClient(serverHost);
		}
		
		if (t != null) {
			synchronized (t) {
				t.start();
				try { t.wait(); } catch (InterruptedException e) { }
			}
		}

		t = null;

		if (pl2Type == HUMAN) {
			t = pl2 = new HumanClient(serverHost, this);
		} else if (pl2Type == CPU) {
			t = new AIClient(serverHost);
		}

		if (t != null) {
			synchronized (t) {
				t.start();
				try { t.wait();	} catch (InterruptedException e) { }
			}
		}

	}

	
	public void stopGame() {
		
		if (pl1 != null) {
			synchronized (pl1) {
				pl1.exited = true;
				pl1.notifyAll();
			}
		}
		if (pl2 != null) {
			synchronized (pl2) {
				pl2.exited = true;
				pl2.notifyAll();
			}
		}
		

		if (listener!=null && listener.isAlive()) {
			setStatus("Waiting for game to end...");
			this.invalidate();
			try { listener.join(); } catch (InterruptedException e) { }
		}

		listener = null;
		pl1 = null;
		pl2 = null;

		gameboard.removeDropButtonListeners();

	}

	synchronized public void endGame(int status) {

		String reason = "";
		switch (status) {
		case 5:
			reason = "Other player exited."; break;
		case 0:
			reason = "Exited.";	break;
		case 1:
			reason = "Invalid move."; break;
		case 2:
			reason = "Tie."; break;
		case 3:
			reason = "Red player wins."; break;
		case 4:
			reason = "Yellow player wins."; break;
		}
		setStatus("Game ended: " + reason);

	}

	public void setStatus(String what) {
		StatusBar.setText(what);
	}

	
	private void initComponents() {
		jPanel1 = new javax.swing.JPanel();
		StatusBar = new javax.swing.JLabel();
		jMenuBar1 = new javax.swing.JMenuBar();
		jMenu1 = new javax.swing.JMenu();
		jMenuItem1 = new javax.swing.JMenuItem();
		jMenuItem2 = new javax.swing.JMenuItem();
		jMenu2 = new javax.swing.JMenu();
		jMenu3 = new javax.swing.JMenu();
		jMenuItem3 = new javax.swing.JMenuItem();
		jMenuItem4 = new javax.swing.JMenuItem();
		jMenuItem5 = new javax.swing.JMenuItem();
		jMenu4 = new javax.swing.JMenu();
		jMenuItem6 = new javax.swing.JMenuItem();
		jMenuItem7 = new javax.swing.JMenuItem();
		jMenuItem8 = new javax.swing.JMenuItem();
		jMenu5 = new javax.swing.JMenu();
		jMenuItem9 = new javax.swing.JMenuItem();
		jMenuItem10 = new javax.swing.JMenuItem();

		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
		jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1,
				javax.swing.BoxLayout.X_AXIS));

		jPanel1.setBorder(new javax.swing.border.EtchedBorder());
		StatusBar.setText("Welcome to Connect Four!");
		jPanel1.add(StatusBar);

		getContentPane().add(jPanel1, java.awt.BorderLayout.SOUTH);

		jMenu1.setText("File");
		jMenuItem1.setText("New Game");
		jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				NewGame();
			}
		});

		jMenu1.add(jMenuItem1);

		jMenuItem2.setText("Exit");
		jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				stopGame();
				dispose();
			}
		});

		jMenu1.add(jMenuItem2);

		jMenuBar1.add(jMenu1);

		jMenu2.setText("Game");
		jMenu3.setText("Red Player");
		jMenuItem3.setText("Human");
		jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				pl1Type = HUMAN;
			}
		});

		jMenu3.add(jMenuItem3);

		jMenuItem4.setText("CPU");
		jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				pl1Type = CPU;
			}
		});

		jMenu3.add(jMenuItem4);

		jMenuItem5.setText("Other");
		jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				pl1Type = OTHER;
			}
		});

		jMenu3.add(jMenuItem5);

		jMenu2.add(jMenu3);

		jMenu4.setText("Yellow Player");
		jMenuItem6.setText("Human");
		jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				pl2Type = HUMAN;
			}
		});

		jMenu4.add(jMenuItem6);

		jMenuItem7.setText("CPU");
		jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				pl2Type = CPU;
			}
		});

		jMenu4.add(jMenuItem7);

		jMenuItem8.setText("Other");
		jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				pl2Type = OTHER;
			}
		});

		jMenu4.add(jMenuItem8);

		jMenu2.add(jMenu4);

		jMenu5.setText("Server");
		jMenuItem9.setText("Local");
		jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				serverHost = "localhost";
			}
		});

		jMenu5.add(jMenuItem9);

		jMenuItem10.setText("Remote");
		jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jMenuItem10ActionPerformed(evt);
			}
		});

		jMenu5.add(jMenuItem10);

		jMenu2.add(jMenu5);

		jMenuBar1.add(jMenu2);

		setJMenuBar(jMenuBar1);
		

		pack();
	}//GEN-END:initComponents

	public void setRemoteHost(String w) {
		serverHost = w;
		setStatus("Remote server set to " + w + ".");
		jPanel1.remove(1);
		jPanel1.validate();
	}

	private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem10ActionPerformed
		// Remote server
		setStatus("Please enter remote host: ");
		JTextField f = new JTextField();
		jPanel1.add(f);
		jPanel1.validate();
		f.addActionListener(new RemoteHostEntered(this, f));
	}//GEN-LAST:event_jMenuItem10ActionPerformed

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Main().setVisible(true);
			}
		});
	}


	// Variables declaration - do not modify//GEN-BEGIN:variables
	private javax.swing.JLabel StatusBar;
	private javax.swing.JMenu jMenu1;
	private javax.swing.JMenu jMenu2;
	private javax.swing.JMenu jMenu3;
	private javax.swing.JMenu jMenu4;
	private javax.swing.JMenu jMenu5;
	private javax.swing.JMenuBar jMenuBar1;
	private javax.swing.JMenuItem jMenuItem1;
	private javax.swing.JMenuItem jMenuItem10;
	private javax.swing.JMenuItem jMenuItem2;
	private javax.swing.JMenuItem jMenuItem3;
	private javax.swing.JMenuItem jMenuItem4;
	private javax.swing.JMenuItem jMenuItem5;
	private javax.swing.JMenuItem jMenuItem6;
	private javax.swing.JMenuItem jMenuItem7;
	private javax.swing.JMenuItem jMenuItem8;
	private javax.swing.JMenuItem jMenuItem9;
	private javax.swing.JPanel jPanel1;
	// End of variables declaration//GEN-END:variables

}

class UIListener extends Listener {

	Main form;
	final int[] cols = { 0, 0, 0, 0, 0, 0, 0 };
	boolean turn = true;
	int players = 0;
	int first;

	public UIListener(String s, Main form) {
		super(s);
		this.form = form;
	}

	public void run() {
		form.setStatus("Waiting for 2 clients to connect...");
		super.run();
	}

	public void OnStart(int first) {
		this.first = first;
		turn = first == 1;
		form.setStatus((turn ? "Red" : "Yellow") + " player's turn.");
	}

	public void OnPlayerConnect() {
		players++;
		if (players == 1) form.setStatus("Waiting for 1 client to connect...");
		else form.setStatus("Ready!");
	}

	public void OnEnd(int status) {
		form.endGame((status == 3 || status == 4) ? (first == 2 ? 7 - status : status) : status);
	}

	public void OnMove(int col) {
		form.gameboard.setPiece(col - 1, cols[col - 1]++, turn);
		turn = !turn;
		form.setStatus((turn ? "Red" : "Yellow") + " player's turn.");
	}

}

class RemoteHostEntered implements ActionListener {

	Main form;

	JTextField field;

	public RemoteHostEntered(Main form, JTextField field) {
		this.form = form;
		this.field = field;
	}

	public void actionPerformed(ActionEvent evt) {
		form.setRemoteHost(field.getText());
	}

}
