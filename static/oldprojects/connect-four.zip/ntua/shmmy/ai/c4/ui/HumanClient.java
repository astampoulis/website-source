package ntua.shmmy.ai.c4.ui;

import ntua.shmmy.ai.c4.client.*;

public class HumanClient extends Client implements DropButtonListener {
    
    Main form;
    int move;
    public boolean exited = false;
    int [] howmany = { 0, 0, 0, 0, 0, 0, 0 };
    boolean mymove = false;
    
    public HumanClient(String server, Main form) {
        super(server);
        this.form = form;
    }
    
    public void run () {
        form.gameboard.addDropButtonListener(this);
        super.run();
    }
    
    public void GameStart(boolean first) {
    }
    
    synchronized public int MyMove() {
        
    	if (exited) return 0;
    	mymove = true;
        try { wait(); } catch (InterruptedException e) {}
        mymove = false;
        return exited?0:move;
    }
    
    public void OtherMove(int col) { if (col!=0) howmany[col-1]++; }
    public void OnEnd(int status) {}
    
    synchronized public void buttonPressed(int col) {
    	if (!mymove) return;
        if (howmany[col-1] == 6) return;
        move = col;
        howmany[col-1]++;
        synchronized(this) { notifyAll(); }
    }
    
}
