package ntua.shmmy.ai.c4.ui;

public interface DropButtonListener {
	void buttonPressed(int i);	
}
