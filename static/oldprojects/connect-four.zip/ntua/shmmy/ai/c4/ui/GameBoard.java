package ntua.shmmy.ai.c4.ui;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;
import javax.swing.border.*;

public class GameBoard extends JPanel {
	
	final static int
		DROP = 0, DROP_PRESS = 1, BLANK = 2,
		FIRST = 3, SECOND = 4;
		
	final static String[] iconsFilenames =
		{ "drop.png", "drop_pressed.png", "blank.png", "first.png", "second.png" };
	final static Icon[] icons = new Icon[iconsFilenames.length];
	
	protected JButton [] dropButtons = new JButton[7];
	final protected JLabel [][] holes = new JLabel[7][6];
        
    final protected ArrayList listeners = new ArrayList();
    
	static {
		for (int i=0;i<iconsFilenames.length;i++) {
			icons[i] = new ImageIcon(Main.class.getResource("/images/" + iconsFilenames[i]));
		}
	}
	
	public GameBoard () {
		super();
		InitComponents();
	}
	
	protected void InitComponents () {
		
		this.setLayout(new GridLayout(7,7));
		this.setBorder(new EmptyBorder(10,10,10,10));
		this.setBackground(new Color(52,7,198));
		this.setSize(50*7+80, 52*7+80);

		for (int i=0;i<7;i++) { 
			JButton me = new JButton();
			me.setBackground(new Color(52,7,198));
			me.setIcon(icons[DROP]);
			me.setPressedIcon(icons[DROP_PRESS]);
            me.addActionListener(new DropButtonHandler(i+1, listeners));
			add(me);
			dropButtons[i] = me;
		}
		for (int j=0;j<6;j++) {
			for (int i=0;i<7;i++) {
				JLabel me = new JLabel();
				me.setIcon(icons[BLANK]);
				add(me);
				holes[i][5-j] = me;
			}
		}
	}
	
	public void setPiece(int col, int row, boolean first) {
		holes[col][row].setIcon(icons[first ? FIRST : SECOND]);
	}

	public void emptyBoard() {
		for (int i = 0; i < 7; i++)
			for (int j = 0; j < 6; j++)
				holes[i][j].setIcon(icons[BLANK]);
	}

	public void addDropButtonListener(DropButtonListener dbl) {
		listeners.add(dbl);
	}

	public void removeDropButtonListeners() {
		listeners.clear();
	}


}

class DropButtonHandler implements ActionListener {

	int col;
	ArrayList ls;
	
	public DropButtonHandler(int col, ArrayList ls) {
		this.col = col;
		this.ls = ls;
	}
	
	public void actionPerformed(ActionEvent e) {
            Iterator i = ls.iterator();
            while (i.hasNext()) {
                ((DropButtonListener)i.next()).buttonPressed(col);
            }
	}
	
}
