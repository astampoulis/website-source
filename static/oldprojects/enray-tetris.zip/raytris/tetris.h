#ifndef TETRIS_H
#define TETRIS_H

#include <bitset>
#include <vector>
#include <string>
#include <ctime>


class Tetris {

	public:
	static const int width = 10, height = 19;
	enum input_t { MOVE_LEFT, MOVE_RIGHT, MOVE_DOWN, ROTATE };
	Tetris();
	virtual ~Tetris() { };
	virtual void HandleInput(input_t);
	virtual void DrawBoard(void);
	virtual bool IdleFunc(void);
	friend std::ostream &operator<<(std::ostream &, Tetris &);
	bool updated;

	protected:

	class Block {
		private:
		std::bitset<16> data;
		int type;
		std::bitset<16>::reference at (int, int);
		public:
		Block();
		Block(const std::string &, int);
		void RotateCW (void);
		void RotateCCW (void);
		int GetType (void) const;
		
		class col_iterator;
		friend class col_iterator;
		class row_iterator {
			int r;
			const Block &b;
			public:
			row_iterator (const Block &, int);
			col_iterator begin () const;
			col_iterator end () const;
			void operator++ (void);
			bool operator!= (const row_iterator &);
		};
		class col_iterator {
			int r, c;
			const Block &b;
			public:
			col_iterator (const Block &, int, int);
			int type() const;
			bool on() const;
			void operator++ (void);
			bool operator!= (const col_iterator &);
		};
		row_iterator begin () const;
		row_iterator end () const;
		
		class box_iterator {
			const Block &b;
			int cx, cy;
			public:
			box_iterator (const Block &, int, int);
			int x() const;
			int y() const;
			int type() const;
			void operator++ (void);
			bool operator!= (const box_iterator &);
		};
		box_iterator bbegin() const;
		box_iterator bend() const;

		friend std::ostream &operator<< (std::ostream &s, const Block &b) {
			for (row_iterator i = b.begin(); i != b.end(); ++i) {
				for (col_iterator j = i.begin(); j != i.end(); ++j)
					if (j.on()) s << j.type(); else s << " ";
				s << std::endl;
			}
			return s;
		};

		bool operator== (const Tetris::Block &);
		
	};
	class BlankGenerator;

	class iterator;
	friend class iterator;
	class iterator {
		const Tetris &t;
		int mi, mj, ctype;
		Block::box_iterator b;
		void FindCurrent();
		public:
		iterator (const Tetris &);
		iterator (const Tetris &, int);
		int x() { return mi; }
		int y() { return mj; }
		int type() { return ctype; }
		void operator++ (void);
		bool operator!= (const iterator &);
	};
	iterator begin() const;
	iterator end() const;

	
	std::vector<Block> blocks;
	int board[height+2][width+2];
	Block curblock;
	int curx, cury;
	time_t last_time;

	int &Board (int, int);
	bool CheckBlock (Block &, int, int);

	virtual bool Delay (void);
	virtual bool NewBlock (Block &);
	virtual bool MoveBlock (int, int);
	virtual bool RotateBlock (void);
	virtual void LayBlock (void);
	virtual void DeleteLine (int);
	virtual int CheckLines (void);
	
	
};

#endif

