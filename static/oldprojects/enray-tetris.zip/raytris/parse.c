/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include <stdio.h>
#include <ctype.h>
#include <math.h>
#include <string.h>
#include "parse.h"
#include "gendefs.h"

bool parserOperatorPrecedes (char a, char b) {

  if (b=='(') return false;
  else if ((b>='A' && b<='Z') || b=='\\') return false;
  else if ((a>='A' && a<='Z') || a=='\\') return true;
  else if (a=='^' && b=='^') return false;
  else if (a=='^') return true;
  else if (a=='*' || a=='/') return true;
  else return false;
  
}

char parserConvertFuncName (char *f) {
  return toupper(f[0]);
}

void parserInfixCompile (char *source, Expression *compiled) {

  char stack[50], a;
  int stackNum=0, codelen=0, numbers=0;
  bool firstNum = true;
  
  compiled->rexist = false;
  
  while ((a=*source)) {
    
    if ( isdigit(a) || a=='.' ) {

      float n;
      sscanf(source,"%f",&n);
      do source++; while( isdigit(*source) || *source=='.' || *source=='e' || *source=='E' ||
                        ((*source=='+'||*source=='-')&&(*(source-1)=='e'||*(source-1)=='E')) );
      source--;
      compiled->code[codelen++]='0';
      compiled->constants[numbers++]=n;
      firstNum=false;
      
    } else if (a==')') {
      while (stackNum) { if (stack[--stackNum]!='(') compiled->code[codelen++]=stack[stackNum];
                         else break; }
    } else if (a=='(') {
      stack[stackNum++] = '('; firstNum = true;
    } else if ((a>='a' && a<='z')&&!(*(source+1)>='a'&&*(source+1)<='z')) {
      compiled->code[codelen++]=a;
      if (a=='r') compiled->rexist = true;
      firstNum = false;
    } else if (!isspace(a)) {
      if (a=='-' && firstNum==true) a='N';
      else if (isalpha(a)) {
        char funcname[30]; int funcnum=1; funcname[0]=a;
        while (isalpha(*(++source))) funcname[funcnum++] = *source;
        funcname[funcnum]='\0'; source--;
        a=parserConvertFuncName(funcname);
      }
      firstNum = false;
      if (stackNum && parserOperatorPrecedes(stack[stackNum-1],a)) compiled->code[codelen++] = stack[--stackNum];
      stack[stackNum++] = a;
    }

    source++;
    
  }
  
  compiled->code[codelen] = '\0';

  while (stackNum) if (stack[--stackNum]!='(') compiled->code[codelen++]=stack[stackNum];
  
}
      

void parserPostfixCompile (char *source, Expression *compiled) {

  char *a = source;
  int codelen=0; int numbers=0;

  while(*a) {

    if ( ( (*a=='+'||*a=='-') && (a==source||isspace(*(a-1))) && isdigit(*(a+1)) ) ||
         *a == '.' || isdigit(*a) ) {
      
      float n;
      sscanf(a,"%f",&n);
      do a++; while( isdigit(*a) || *a=='.' || *a=='e' || *a=='E' ||
                     ((*a=='+'||*a=='-')&&(*(a-1)=='e'||*(a-1)=='E')) );
      compiled->code[codelen++]='0';
      compiled->constants[numbers++]=n;
      
    } else {

      if (!isspace(*a)) compiled->code[codelen++]=*a;
      a++;

    }

  }
  
  compiled->code[codelen]='\0';
  
}

float parserEvaluate (Expression *which, float x, float y, float z) {

  char *a = which->code;
  float stack[100], *stackCur = stack, r;
  int constNum = 0;
  
  if (which->rexist) r=sqrt(x*x+y*y+z*z);
  
  while (*a) {
    switch(*a) {
      case '0':  *(stackCur++) = which->constants[constNum++]; break;
#ifdef IMPLICIT_INTERNAL_COORDINATES
      case 'x':  *(stackCur++) = x; break;
      case 'y':  *(stackCur++) = y; break;
      case 'z':  *(stackCur++) = z; break;
#else
      case 'x':  *(stackCur++) = z; break;
      case 'y':  *(stackCur++) = x; break;
      case 'z':  *(stackCur++) = y; break;
#endif
      case 'r':  *(stackCur++) = r; break;
      case '+':  stackCur--; *(stackCur-1) += *stackCur; break;
      case '-':  stackCur--; *(stackCur-1) -= *stackCur; break;
      case '*':  stackCur--; *(stackCur-1) *= *stackCur; break;
      case '/':  stackCur--; *(stackCur-1) /= *stackCur; break;
      case '^':  stackCur--; *(stackCur-1) = pow( *(stackCur-1), *stackCur); break;
      case '\\': *(stackCur-1) = sqrtf(*(stackCur-1)); break;
      case 'S':  *(stackCur-1) = sin(*(stackCur-1)); break;
      case 'C':  *(stackCur-1) = cos(*(stackCur-1)); break;
      case 'T':  *(stackCur-1) = tan(*(stackCur-1)); break;
      case 'A':  *(stackCur-1) = fabs(*(stackCur-1)); break;
      case 'N':  *(stackCur-1) = -(*(stackCur-1)); break;
      case 'L':  *(stackCur-1) = logf(*(stackCur-1)); break;
      case 'E':  *(stackCur-1) = expf(*(stackCur-1)); break;      
      default :  if (*a>='a' && *a<='f')
                   *(stackCur++) = *(which->variables[*a-'a']);
    }
    a++;
  }
  
  return *(stackCur-1);
  
}

Expression *parserNewExpression (char *source) {

  Expression *e;
  
  e = NEW(Expression, 1);
  if (!e) return NULL;

  e->constants = NEW(float, 50);
  if (!e->constants) return NULL;

  e->code = NEW(char, strlen(source)+1);
  if (!e->code) return NULL;
  
  parserInfixCompile(source, e);
  
  return e;
  
}

void parserDestroyExpression (Expression *e) {
  
  free(e->constants);
  free(e->code);
  free(e);
  
}
