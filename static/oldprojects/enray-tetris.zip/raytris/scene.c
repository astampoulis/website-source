/*  
 
    enRay, a realtime raytracer written in C
    Copyright (C) 2002  Antonis Stampoulis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 */

#include "scene.h"
#include "vector.h"

#define MAXOBJECTS  1000
#define MAXLIGHTS   16

Scene *NewScene (float r, float g, float b) {

  Scene *s = NEW(Scene, 1);
  
  s->backgroundColor.r = r;
  s->backgroundColor.g = g;
  s->backgroundColor.b = b;
  s->objects = NEW(Object, MAXOBJECTS); s->objectsNum = 0;
  s->comobj = NEW(int, MAXOBJECTS*16); s->comobjNum = 0;
  s->lights  = NEW(Light, MAXLIGHTS); s->lightsNum = 0;
  s->comlgt = NEW(int, MAXLIGHTS*16); s->comlgtNum = 0;
  
  return s;
  
}

void DestroyScene (Scene *s) {

  int i;
  
  for (i=0;i<s->objectsNum;i++) free(s->objects[i].primitive.properties);
  free(s->objects); free(s->comobj);
  free(s->lights); free(s->comlgt);
  free(s);
  
}

int AddObject (Scene *s, Primitive p, Material *m, bool castShadow, shadowType receiveShadow) {

  int i = s->objectsNum++, j = s->comobjNum++;
  
  s->objects[i].primitive = p;
  s->objects[i].material = m;
  s->objects[i].castShadow = castShadow;
  s->objects[i].receiveShadow = receiveShadow;
  s->objects[i].lastOcc = -1;
  
  s->comobj[j] = i;
  
  return j;
  
}

int AddLight (Scene *s, float x, float y, float z, float r, float g, float b) {

  int i = s->lightsNum++, j = s->comlgtNum++;
  
  vectorSet(&s->lights[i].position, x, y, z);
  s->lights[i].diffuse.r = r;
  s->lights[i].diffuse.g = g;
  s->lights[i].diffuse.b = b;

  s->comlgt[j] = i;
  
  return j;
  
}

void ChangeLight (Scene *s, int i, float x, float y, float z, float r, float g, float b) {
  i = s->comlgt[i];
  vectorSet(&s->lights[i].position, x, y, z);
  if (r!=DONT_CHANGE_LIGHT_COLOR) {
    s->lights[i].diffuse.r = r;
    s->lights[i].diffuse.g = g;
    s->lights[i].diffuse.b = b;
  }
  
}

void *ObjectProperties (Scene *s, int object) { return s->objects[s->comobj[object]].primitive.properties; }
Material *ObjectMaterial (Scene *s, int object) { return s->objects[s->comobj[object]].material; }

Material *NewMaterial (float r, float g, float b, float reflectivity, float specular) {
  Material *m = NEW(Material, 1);
  m->color.r = r; m->color.g = g; m->color.b = b; m->reflectivity = reflectivity; m->specular = specular;
  return m;
}

void ChangeMaterial (Material *m, float r, float g, float b, float reflectivity, float specular) {
  m->color.r = r; m->color.g = g; m->color.b = b; m->reflectivity = reflectivity; m->specular = specular;
}

void RmvObject (Scene *s, int object) {

  int i;
  
  free(s->objects[s->comobj[object]].primitive.properties);

  s->objectsNum--;
  for (i=s->comobj[object]; i<s->objectsNum; i++) s->objects[i] = s->objects[i+1];
  s->comobj[object]=-1;
  
  if (object+1==s->comobjNum)
    for (i=s->comobjNum-1;s->comobj[i]<=-1;i--) s->comobjNum--;
  else for (i=object+1; i<s->comobjNum; i++) s->comobj[i]--;
  
}

void RmvLight (Scene *s, int light) {

  int i;
  
  s->lightsNum--;
  for (i=s->comlgt[light]; i<s->lightsNum; i++) s->lights[i] = s->lights[i+1];
  s->comlgt[light]=-1;
  
  if (light+1==s->comlgtNum)
    for (i=s->comlgtNum-1;s->comlgt[i]<=-1;i--) s->comlgtNum--;
  else for (i=light+1; i<s->comlgtNum; i++) s->comlgt[i]--;
  
}

