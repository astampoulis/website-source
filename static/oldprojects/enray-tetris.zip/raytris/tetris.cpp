#include "tetris.h" 
#include <vector>
#include <bitset>
#include <string>
#include <cassert>
#include <iostream>
#include <algorithm>
#include <functional>
#include <ctime>
#include <cstdlib>

using namespace std;

Tetris::Block::Block () : type(-1) { };
Tetris::Block::Block (const string &s, int t) : data(s), type(t) { };

std::bitset<16>::reference Tetris::Block::at (int i, int j) {

	if (type==-1) throw string("Uninitialized tetris block used.");
	if (i>=0 && i<4 && j>=0 && j<4) return std::bitset<16>::reference(data, i*4+j);
	else throw string("Out of bounds when accessing block.");

}


void Tetris::Block::RotateCCW (void) {

	if (type==-1) throw string("Uninitialized tetris block used.");

	Tetris::Block keep(*this);

	for (int cy=0;cy<4;cy++)
		for (int cx=0;cx<4;cx++)
			at(cx,cy) = keep.at(cy,3-cx);

}

void Tetris::Block::RotateCW (void) {

	if (type==-1) throw string("Uninitialized tetris block used.");

	Tetris::Block keep(*this);

	for (int cy=0;cy<4;cy++)
		for (int cx=0;cx<4;cx++)
			at(cx,cy) = keep.at(3-cy,cx);

}

int Tetris::Block::GetType (void) const { return type; }

Tetris::Block::row_iterator Tetris::Block::begin () const { return row_iterator(*this, 0); }
Tetris::Block::row_iterator Tetris::Block::end () const { return row_iterator(*this, 4); }
Tetris::Block::row_iterator::row_iterator (const Block &bl, int ii) : r(ii), b(bl) { };
void Tetris::Block::row_iterator::operator++ (void) { r++; }
bool Tetris::Block::row_iterator::operator!= (const Tetris::Block::row_iterator &check) {
	assert(&b == &check.b);
	if (r == check.r) return false;
	else return true;
}
Tetris::Block::col_iterator Tetris::Block::row_iterator::begin (void) const { return col_iterator(b, r, 0); }
Tetris::Block::col_iterator Tetris::Block::row_iterator::end (void) const { return col_iterator(b, r, 4); }

Tetris::Block::col_iterator::col_iterator (const Block &bl, int rr, int cc) : r(rr), c(cc), b(bl) { };
int Tetris::Block::col_iterator::type () const {
	if (r>=0 && r<4 && c>=0 && c<4) return b.type;
	else throw("Dereferencing past-the-end iterator.");
}
bool Tetris::Block::col_iterator::on () const { 
	if (r>=0 && r<4 && c>=0 && c<4) return b.data[r*4+c];
	else throw("Dereferencing past-the-end iterator.");
}
void Tetris::Block::col_iterator::operator++ (void) { c++; }
bool Tetris::Block::col_iterator::operator!= (const Tetris::Block::col_iterator &check) { 
	assert(&b == &check.b);
	if (c == check.c) return false;
	else return true;
}


Tetris::Block::box_iterator::box_iterator (const Block &bl, int xx = 0, int yy = 0) : b(bl), cx(xx), cy(yy) {
	if (bl.type==-1) { cx = cy = -1; }
	if (cx>=0 && cx<4 && cy>=0 && cy<4 && !b.data[cy*4+cx]) ++(*this);
};
int Tetris::Block::box_iterator::x () const { return cx; }
int Tetris::Block::box_iterator::y () const { return cy; }
int Tetris::Block::box_iterator::type () const { return b.type; }
void Tetris::Block::box_iterator::operator++ () {
	if (cx<0) return;
	do {
		cx++;
		if (cx==4) {
			cx = 0; cy++;
			if (cy == 4) { cx = cy = -1; break; }
		}
	} while (!b.data[cy*4+cx]);
}
bool Tetris::Block::box_iterator::operator!= (const Tetris::Block::box_iterator &check) {
	assert(&b == &check.b);
	if (cx == check.cx && cy == check.cy) return false;
	else return true;
}
Tetris::Block::box_iterator Tetris::Block::bbegin() const { return box_iterator(*this); }
Tetris::Block::box_iterator Tetris::Block::bend() const { return box_iterator(*this,-1,-1); }


bool Tetris::Block::operator== (const Tetris::Block &check) {
	if (GetType() != check.GetType()) return false;
	for (row_iterator i1=begin(), i2 = check.begin(); i1 != end() && i2 != check.end(); ++i1, ++i2) {
		for (col_iterator j1 = i1.begin(), j2 = i2.begin(); j1 != i1.end() && j2 != i2.end(); ++j1, ++j2) {
			if (j1.on() != j2.on()) return false;
		}
	}
	return true;
}


class Tetris::BlankGenerator {
	int x, y;
	public:
	BlankGenerator(int yy) : x(-1), y(yy) { }
	int operator() () {
		x++;
		if (y==Tetris::height+1 || x==0 || x==Tetris::width+1 || (y==0 && (x<4 || x>7))) return -1;
		else return 0;
	}
};

/* Board looks like this:
11111...11     > index 0
10000...01     > index 1
  :
  :
10000...01     > index height
11111...11     > index height+1
*/


Tetris::Tetris () {

	const char *TempBlocks[] =
	{	"0000001011100000",
		"0000100011100000",
		"0000011001100000",
		"0000111100000000",
		"0000010011100000",
		"0000011011000000",
		"0000011000110000" 	};

	for (unsigned int i=0; i<sizeof TempBlocks/sizeof *TempBlocks; i++)
		blocks.push_back(Block(string(TempBlocks[i]),i+1));

	for (int y=0; y<height+2; y++)
		generate(board[y],board[y]+width+2,BlankGenerator(y));

	last_time = time(NULL);
	updated = true;

}

int &Tetris::Board (int y, int x) {
	if (x < 0) x = 0;
	else if (x >= width + 2) x = width + 1;
	if (y < 0) y = 0;
	else if (y >= height + 2) y = height + 1;
	return board[y][x];
}

bool Tetris::CheckBlock (Block &b, int y, int x) {

	int keepx = x;
	for (Block::row_iterator i = b.begin(); i != b.end(); ++i) {
		x = keepx;
		for (Block::col_iterator j = i.begin(); j != i.end(); ++j) {
			if (j.on() && Board(y,x)) return false;
			x++;
		}
		y++;
	}

	return true;

}

bool Tetris::NewBlock (Block &b) {

	if (!CheckBlock(b,0,3)) return false;
	else {
		cury = 0; curx = 3;
		curblock = b;
		return true;
	}

}

bool Tetris::MoveBlock (int y, int x) {

	if (!CheckBlock(curblock,cury+y,curx+x)) return false;
	else {
		curx+=x; cury+=y;
		return true;
	} 

}

bool Tetris::RotateBlock  (void) {

	Block temp(curblock);

	temp.RotateCCW();
	if (!CheckBlock(temp,cury,curx)) return false;
	else {
		curblock.RotateCCW();
		return true;
	}

}

void Tetris::LayBlock (void) {

	int y = cury;	
	for (Block::row_iterator i = curblock.begin(); i != curblock.end(); ++i) {
		int x = curx;
		for (Block::col_iterator j = i.begin(); j != i.end(); ++j) {
			if (j.on()) Board(y,x) = j.type();
			x++;
		}
		y++;
	}

}

void Tetris::DeleteLine (int i) {

	assert(i>=1 && i<=height);
	for (int y = i; y > 1; y--)
		copy(board[y-1],board[y-1]+width+2,board[y]);
	generate(board[1],board[1]+width+2,BlankGenerator(1));

}

int Tetris::CheckLines (void) {

	int c = 0;
	int y = height;
	while (y >= 1) {
		if (!count(board[y]+1,board[y]+width+1,0)) { DeleteLine(y); c++; }
		else y--;
	}
	return c;

}

bool Tetris::Delay (void) {

	if (time(NULL) - last_time >= 1) { last_time = time(NULL); return true; }
	else return false;

}

void Tetris::HandleInput (input_t i) {

	bool u = false;
	if (curblock.GetType()==-1) return;
	if (i==MOVE_LEFT) u = MoveBlock(0,-1);
	else if (i==MOVE_RIGHT) u = MoveBlock(0,1);
	else if (i==MOVE_DOWN) u = MoveBlock(1,0);
	else if (i==ROTATE) u = RotateBlock();
	if (u) updated = true;

}

bool Tetris::IdleFunc (void) {

	if (!Delay()) return true;
	if (curblock.GetType()==-1) {
		if (!NewBlock(blocks[rand()%blocks.size()])) return false;
		else updated = true;
	} else if (!MoveBlock(1,0)) {
		LayBlock();
		if (CheckLines()) updated = true;
		curblock = Block();
	} else {
		updated = true;
	}
	return true;

}

void Tetris::DrawBoard (void) {

	if (updated) {

		for (iterator i=begin(); i!=end(); ++i) {

			if (i.type()==-1) cout << '*';
			else if (!i.type()) cout << ' ';
			else cout << i.type();

		}

		updated = false;

	}

}

Tetris::iterator::iterator (const Tetris &tt, int) : t(tt), mi(-1), mj(-1), ctype(-1), b(t.curblock.bbegin()) { };
Tetris::iterator::iterator (const Tetris &tt) : t(tt), mi(0), mj(0), ctype(-1), b(t.curblock.bbegin()) { FindCurrent(); };

void Tetris::iterator::FindCurrent () {

	if (mi<0 || mj<0) return;
	else if (mi==width+2) {
		mi=0; mj++;
		if (mj==height+2) { mi=mj=-1; return; }
	}
	if (t.board[mj][mi]) ctype = t.board[mj][mi];
	else if (b != t.curblock.bend() && b.x()+t.curx == mi && b.y()+t.cury == mj) { ctype = b.type(); ++b; }
	else ctype = 0;

}

void Tetris::iterator::operator++ () { mi++; FindCurrent(); }
bool Tetris::iterator::operator!= (const Tetris::iterator &check) {
	assert(&t == &check.t);
	return (mi != check.mi || mj != check.mj);
}
Tetris::iterator Tetris::begin () const { return iterator(*this); }
Tetris::iterator Tetris::end () const { return iterator(*this,1); }

