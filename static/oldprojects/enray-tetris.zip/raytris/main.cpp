#include <time.h>
#include "graphics.h"
#include "maintrace.h"
#include "scene.h"
#include "primitives.h"
#include "camera.h"
#include "tetris.h"
#include <SDL/SDL.h>
#include <iostream>
#include <string>
#include <list>
#include <cmath>

using namespace std;

int bs = 8, bms = 4;
int zdist = 250;

void GuessObjectUpdate();
void GuessObjectInit(int,int);
void GuessObjectDestroy();

bool HandleKeys (Tetris *t) {

  static Uint32 last = SDL_GetTicks(), lastup = 0;

  if (SDL_GetTicks()-last<50) return true;

  if (Keys[SDLK_LEFT]) t->HandleInput(Tetris::MOVE_LEFT);
  if (Keys[SDLK_RIGHT]) t->HandleInput(Tetris::MOVE_RIGHT);
  if (Keys[SDLK_DOWN]) t->HandleInput(Tetris::MOVE_DOWN);
  if (Keys[SDLK_UP] && SDL_GetTicks() - lastup > 100) { t->HandleInput(Tetris::ROTATE); lastup = SDL_GetTicks(); }
  if (Keys[SDLK_ESCAPE]) return false;
  if (Keys[SDLK_MINUS] && 2*bms<=bs) { GuessObjectUpdate(); bms*=2; }
  if (Keys[SDLK_EQUALS] && bs>=1) { GuessObjectUpdate(); bms/=2; }
  Keys[SDLK_MINUS] = Keys[SDLK_EQUALS] = false;

  if (Keys[SDLK_PAGEUP]) { zdist-=5; GuessObjectUpdate(); }
  if (Keys[SDLK_PAGEDOWN]) { zdist+=5; GuessObjectUpdate(); }

  last = SDL_GetTicks();

  return true;

}

class RayTetris : public Tetris {

	private:
	Scene *s;
	Camera *c;
	int light, light1;
	int keep[(height+2)*(width+2)], curkeep;
	Uint32 lasttick, lasttick_gfx;
	static const colorf mats[7];
	float togox, togoy, lx, ly;
	Material *materials[10];

	int del_lines[4];
	float sphere_rad[4];
	int del_lines_num;
	bool animation;
	int lines_deleted;
	
	void MoveLight () { togox = (curx+1)*10-60+5; togoy = 100-(cury-2)*10-25; }

	public:

	RayTetris (Scene *ss, Camera *cc) : Tetris(), s(ss), c(cc), del_lines_num(0), animation(false) {

		light = AddLight(s, 0, 0, -200, 0.0, 0.0, 0.0);
		light1 = AddLight(s, 0, 0, -200, 0.0, 0.0, 0.0);
      lx = ly = togox = togoy = 0;
		lasttick_gfx = lasttick = SDL_GetTicks();

		materials[0] = NewMaterial(0.5,0.5,0.5,0.0,0.8);
		materials[1] = NewMaterial(0.1,0.1,0.2,0.0,0.8);
		for (unsigned int i=0; i<7; i++) materials[i+2] = NewMaterial(mats[i].r,mats[i].g,mats[i].b,0.0,0.8);

		for (Tetris::iterator i=begin(); i!=end(); ++i)
			keep[curkeep++] = AddObject(s,NewSphere(i.x()*10-60,100-i.y()*10,0,4),materials[i.type()+1],false,NOSHADOW);

	};

	void DrawBoard (void) {
		if (updated && !animation) {
			updated = false;
			int cur = 0;
			for (iterator i=begin(); i!=end(); ++i) s->objects[ s->comobj[ keep[cur++] ] ].material = materials[i.type()+1];
		}
		RaytraceMain(c,s,bs,bms);
	}

	~RayTetris () {
		RmvLight(s,light);
		for (int i = 0; i<curkeep; i++) RmvObject(s,i);
		for (int i = 0; i<10; i++) free(materials[i]);
	}

   bool IdleFunc (void) {
		lx += (togox - lx)*(SDL_GetTicks()-lasttick_gfx)/500.0f;
		ly += (togoy - ly)*(SDL_GetTicks()-lasttick_gfx)/500.0f;
		ChangeLight(s,light,lx+40*sin(SDL_GetTicks()/2000.0f),ly,10,1.0,0.5,0);
		ChangeLight(s,light1,lx-40*sin(SDL_GetTicks()/2000.0f),ly,10,0,0.5,1.0);
		if (animation) {
			for (int i=0;i<del_lines_num;i++) {
				for (int x=1;x<=width;x++) {
					sphere_rad[i] += -sphere_rad[i]*(SDL_GetTicks()-lasttick)/500.0f;
					ChangeSphere(ObjectProperties(s,keep[del_lines[i]*(width+2)+x]),(x)*10-60,100-del_lines[i]*10,0,sphere_rad[i]); //4-4.0f*(SDL_GetTicks()-lasttick)/500.0f);
				}
			}
			GuessObjectUpdate();
			lasttick_gfx = SDL_GetTicks();
			if (SDL_GetTicks() - lasttick >= 500) {
				animation = false; 
				for (int *i=del_lines;i<del_lines+del_lines_num;i++) {
					for (int x=1;x<=width;x++)
			 			ChangeSphere(ObjectProperties(s,keep[(*i)*(width+2)+x]),(x)*10-60,100-(*i)*10,0,4.0);
				}
				GuessObjectUpdate();
				del_lines_num = 0;
			} 
			return true;
		} else {
	      lasttick_gfx = SDL_GetTicks();
			return Tetris::IdleFunc();
		}
	}

	protected:

	bool NewBlock (Block &b) {
		int nextblock = int((rand()/(float)RAND_MAX)*7.0f);
		if (Tetris::NewBlock(blocks[nextblock%7])) {
			MoveLight();
			return true;
		} else return false;
	}

	bool MoveBlock (int y, int x) {
		if (Tetris::MoveBlock(y, x)) {
			MoveLight();
			return true;
		} else return false;
	}


	bool Delay (void) {
		if (SDL_GetTicks() - lasttick < 500) return false;
		else { lasttick = SDL_GetTicks(); return true; }
	}

	int CheckLines (void) {
		lines_deleted = 0;
		return Tetris::CheckLines();
	}

	void DeleteLine (int which) {
		animation = true;
		sphere_rad[del_lines_num] = 4.0f;
		del_lines[del_lines_num++] = which - lines_deleted;
		lines_deleted++;
		Tetris::DeleteLine(which);
	}


};

const colorf RayTetris::mats[] = { { 0.2, 0.4, 0.928}, { 0.4, 0.8, 0.1 }, { 0.7, 0.1, 0.15}, {0.1, 0.6, 0.9},
	                                { 0.62763, 0.61724, 0.1 }, { 0.5054, 0.1283, 0.8324}, {0.94265, 0.46147, 0.1838} };


int main (int argc, char **argv) {

  graphics *g;
  Camera *c;
  Scene *s;
  
  int light;
  unsigned int frames=0;

  srand(time(NULL));

  g = argc>=3?
      GraphicsInit(atoi(argv[1]),atoi(argv[2]),32):
      GraphicsInit(640, 480, 32);
  if (!g) { printf("No graphics.\n"); return -1; }
  
  c = NewCamera(30,0,0,300,0,0,g->xres,g->yres);
  s = NewScene(0,0,0);

  light = AddLight(s, 0, 0, 1000, 1.0, 1.0, 1.0);

  GuessObjectInit(g->xres,g->yres);

  RayTetris *t = new RayTetris(s,c);

  Uint32 start_ticks = SDL_GetTicks();

  while (GraphicsExist() && t->IdleFunc()) {
		CameraLookAt(c, 0, 0, zdist, 0, 0, 0);
		t->DrawBoard();
	   GraphicsUpdate();
	   if (!HandleKeys(t)) break;
		frames++;
  };

  cout << "Average FPS: " << 1000 * float(frames) / float(SDL_GetTicks() - start_ticks) << endl;
  
  delete t;
  GraphicsDestroy(g);
  GuessObjectDestroy();
  
  return 0;

}
