#!/bin/sh
java -cp ./virtualmechanics.jar:lib/j3dcore.jar:lib/j3dutils.jar:lib/vecmath.jar:lib/odejava.jar:lib/log4j.jar -Djava.library.path=bin gr.ntua.softlab.vmech.upi.Yaya


